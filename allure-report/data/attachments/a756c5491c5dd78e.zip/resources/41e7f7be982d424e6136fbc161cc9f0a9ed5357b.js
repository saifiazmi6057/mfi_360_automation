SharedDeractives.directive('riskoMeterDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetEntryExitReportData','GetEntryExitReportDataAdvance',
    'GetAllPotfolioDates', 'MFIMsg', '$window', 'GetAllRiskOMeterType', 'ShowRisKOMerterReport','GetAllPRCType',
    function ($http, $q, $timeout, ApiInfo, GetEntryExitReportData, GetEntryExitReportDataAdvance, GetAllPotfolioDates, MFIMsg, $window, GetAllRiskOMeterType, ShowRisKOMerterReport, GetAllPRCType) {
        return {
            restrict: 'AE',
            scope: {
                lstMfiSchemes: '=',
                setfromRiskOMeterDirective: '&',
                setfromMarketCapforLoader: '&'
            },
            templateUrl: '/PortfolioAnalysis/RiskOMeterAdvance',
            link: function ($scope, $element, $attrs) {
                $scope.EntryExitPortfolioDate = "";
                $scope.PortfolioDateList = [];
                $scope.RiskTypeList = [];
                $scope.LoaderNewEntryExitTable = false;
                $scope.selectedPortDatesROM = [];
                $scope.selectedRiskType = [];
                $scope.selectedPRCType = [];
                $scope.ShowType = "Both";
                $scope.RiskPrcType = "RiskOmeter";
               
                $scope.UserSetsettingsPortDateforRiskoMeter = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: true,
                    ddltext: "Select Portfolio Period",
                    Keyprop: "MonthYear",
                    Valueprop: "MonthYear",
                };
                $scope.UserSetsettingsforRiskType = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: true,
                    ddltext: "Select Type",
                    Keyprop: "RiskId",
                    Valueprop: "RiskOMeterTypeName",
                };
                $scope.UserSetsettingsforPRCType = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: true,
                    ddltext: "Select Type",
                    Keyprop: "RiskId",
                    Valueprop: "RiskOMeterTypeName",
                };
                $scope.SwitchRiskOMeterTab = "IsloadedRiskOMeterTab";
                var getPortfolioDDLData = GetAllPotfolioDates.Call(20);
                $scope.LstPeriodOptions = [];
                getPortfolioDDLData.then(function (response) {
                    $scope.PortfolioDateList = response.data.data;
                    $scope.LstPeriodOptions = response.data.data.map(function (a) {
                        return JSON.parse(JSON.stringify(a));
                    });
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Failed to fetch portfolio date list.", MFIAlertType.Error, "OK");
                    });
                var getPortfolioRiskData = GetAllRiskOMeterType.Call();
                $scope.LstRisktypeOptions = [];
                getPortfolioRiskData.then(function (response) {
                    $scope.RiskTypeList = response.data;
                    $scope.LstRisktypeOptions = response.data.map(function (a) {
                        return JSON.parse(JSON.stringify(a));
                    });
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Failed to fetch Risktype date list.", MFIAlertType.Error, "OK");
                    });
                
                var getPortfolioPRCData = GetAllPRCType.Call();
                $scope.LstPRCTypeOptions = [];
                getPortfolioPRCData.then(function (response) {
                    $scope.PRCTypeList = response.data;
                    $scope.LstPRCTypeOptions = response.data.map(function (a) {
                        return JSON.parse(JSON.stringify(a));
                    });
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Failed to fetch PRC type list.", MFIAlertType.Error, "OK");
                    });

                var CollapseSelCriteria = function () {
                    angular.element("#DivRiskOMeterDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                };

                $scope.ShowRiskOMeterReport = function () {
                    $scope.ArrPortDatesforDetailedPortfolio = [];
                    angular.forEach($scope.selectedPortDatesROM, function (value, index) {
                        $scope.ArrPortDatesforDetailedPortfolio.push(value.MonthYear);
                    });
                    $scope.ArrRiskTypes=[];
                    $scope.ArrPRCTypes=[];
                    angular.forEach($scope.selectedRiskType, function (value, index) {
                        $scope.ArrRiskTypes.push(value);
                    });
                            angular.forEach($scope.selectedPRCType, function (value, index) {
                                $scope.ArrPRCTypes.push(value);
                    });

                    if ($scope.lstMfiSchemes.length == 0) {
                        MFIMsg.AlertHtml("User have to select atleast one scheme.", MFIAlertType.Information, "OK");
                        return;
                    }
                    //      if ($scope.lstMfiSchemes.length > MaxSchemeSelectionAllowed) {
                    //          MFIMsg.AlertHtml("You can select only " + MaxSchemeSelectionAllowed + " schemes to show the report", MFIAlertType.Information);
                    //    return false;
                    //}
                    if ($scope.ArrPortDatesforDetailedPortfolio.length == 0) {
                        MFIMsg.AlertHtml("Please select portfolio periods", MFIAlertType.Information);
                        return false;
                    }
                    if ($scope.ArrPortDatesforDetailedPortfolio.length > MaxPortDatesSelectionAllowed) {
                        MFIMsg.AlertHtml("You can select maximum " + MaxPortDatesSelectionAllowed + " periods", MFIAlertType.Information);
                        return false;
                    }
                    $scope.LstSelectedMFISchemes = [];
                    angular.forEach($scope.lstMfiSchemes, function (value) {
                        var item = JSON.parse(value).Id;
                        $scope.LstSelectedMFISchemes.push(item)
                    });

                    CollapseSelCriteria();

                    var Input = {
                        "PortfolioDates": $scope.ArrPortDatesforDetailedPortfolio,
                        "SchemeIds": $scope.LstSelectedMFISchemes,
                        "LstRiskOMeters": $scope.ArrRiskTypes,
                        "LstPRC": $scope.ArrPRCTypes,
                     
                    "RiskPrcType": $scope.RiskPrcType,
                     
                    };
                    $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "RISKOMETER" });
                    //angular.element("#DivTradeAnalysisDetails").hide();
                    var RiskOMeterDetails = ShowRisKOMerterReport.Call(Input);
                    RiskOMeterDetails.then(function (response) {
                        if (response.data != null && response.data.Success == false) {
                            if (response.data.Message != "")
                                MFIMsg.Alert(response.data.Message);
                            else
                                MFIMsg.Alert("Warning!! internal error occurred.");
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "RISKOMETER"});
                            return false;
                        }
                        var Riskodata=response.data;
                        if ($scope.setfromRiskOMeterDirective != undefined) {
                            $scope.setfromRiskOMeterDirective({ Riskdata: Riskodata, flag: $scope.RiskPrcType});
                        }
                    },
                    function errorCallback(response) {
                        MFIMsg.Alert("Waning!! Internal error occurred.");
                        $scope.setfromRiskoMeterDirective({ ShowLoader: false, tabname: "RISKOMETER" });
                    });
                };

                

                $scope.Reset = function () {
                    $window.location.reload();
                }
                $scope.CheckTab = function (subtabname) {
                    if (subtabname == "Riskometer") {
                        $scope.RiskPrcType = "RiskOmeter";
                }
                    else if (subtabname == "PRC")
{
                        $scope.RiskPrcType ="PRC"
            }
                    else if (subtabname == "Both") {
                        $scope.RiskPrcType = "Both";
}
                }


                //$scope.EntryExitReportExportToExcel = function () {

                //    if ($scope.SelectedStockOptios == "Both")
                //        window.open("/NewEntryExit/ExportToExcelBoth?porfolioDate=" + $scope.EntryExitPortfolioDate);
                //    else
                //        window.open("/NewEntryExit/ExportToExcel?porfolioDate=" + $scope.EntryExitPortfolioDate);

                //}
            }
        };
    }]);