SharedDeractives.directive('dirDashboardMainSearch', ['MFIMsg', 'FetchKeyword', 'FetchMetaData',
    function (MFIMsg, FetchKeyword, FetchMetaData) {
        return {
            restrict: 'A',
            scope: {
                loginId: "@",
                parentPage: "@",
                parentSearchFn: '&parentSearch',
                searchText:"@"
            },
            //templateUrl: function (elem, attrs) {
            //    return "/Home/MainSearch";
            //},

            templateUrl: '/Home/MainSearch',
            controller: function ($scope, $http, $q) {
                $scope.MainSearch = {};

                $scope.MainSearch.querySearch = querySearch;
                $scope.MainSearch.selectedItemChange = selectedItemChange;
                $scope.MainSearch.searchTextChange = searchTextChange;
                $scope.MainSearch.SearchText = "";
                //$scope.SearchPG.LstMenus = [];

                function querySearch(query) {
                    if (angular.isUndefinedOrNullOrEmpty(query)) {
                        $scope.MainSearch.SearchText = "";
                        return { KeyWord: "", MetadataId: 0 };
                    }
                    if (query.indexOf("&") > -1)
                        query = query.replace('&', '%26');

                    var results = {};
                    var inputs = {};
                    inputs.StrText = query;
                    var AutoSchList = FetchKeyword.Call(inputs);
                    return AutoSchList.then(function (response) {
                        if (query != "") {
                            var BlankObj = { MenuName: "", MenuId: 0 ,ParentId:0};
                            results = response.data == null ? BlankObj : response.data.data == null ? BlankObj : response.data.data;

                            if (results == BlankObj)
                                $scope.SearchText = "Sorry, no results found! Please check the spelling or try searching for something else";
                            //else
                            //    $scope.SearchText = "";
                        }
                        return results;
                    },
                        function (stu) { alert("Records gathering failed!"); });
                }

                function searchTextChange(text) {
                    $scope.MainSearch.SearchText = text;
                }

                function selectedItemChange(item) {
                    if (item != undefined) {
                        $scope.MainSearch._item = item;
                        var AutoSchList = FetchMetaData.Call(item);
                        return AutoSchList.then(function (response) {
                            if (response.data.data != null) {
                                var PageUrl = JSON.parse(response.data.data.ActionData);
                                var URL = PageUrl.AreaName ? "/" + PageUrl.AreaName + "/" + PageUrl.ControllerName + "/" + PageUrl.ActionName :
                                    "/" + PageUrl.ControllerName + "/" + PageUrl.ActionName;
                                location.href = URL;
                            }
                        },
                            function (stu) {
                                alert("Records gathering failed!");
                            });
                    }
                    else {
                        $scope.MainSearch.SearchText = "";
                        $scope.MainSearch._item = null;
                        return true;
                    }
                }

                //$scope.MainSearch.FnSearch = function () {

                //    if ($scope.MainSearch._item != null) {
                //            location.href = "/PortfolioAnalysis/Search?MenuId=" + $scope.MainSearch._item.MenuId + "&MenuName=" + $scope.MainSearch._item.MenuName;
                //        }
                //    else if ($scope.MainSearch.SearchText != "") {
                //            location.href = "/PortfolioAnalysis/Search?MenuId=" + -1 + "&MenuName=" + $scope.MainSearch.SearchText;
                //        }
                //}
            }
        }
}]);