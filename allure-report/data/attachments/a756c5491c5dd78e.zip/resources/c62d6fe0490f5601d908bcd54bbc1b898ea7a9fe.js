SharedDeractives.directive('indexSelectionDirective', ['$http', '$filter', 'GetAllCompositeIndex', 'GetAllCustomIndex', 'GetAllMFIIndex', function ($http, $filter, GetAllCompositeIndex, GetAllCustomIndex, GetAllMFIIndex)
{
               return {
                   restrict: 'AE',
                   scope: {
                       selectedPartialText: '=',
                       selectedMfiindexModel: '=',
                       selectedCustomindexModel: '=?',
                       selectedCompositeindexModel: '=?',
                       //selectedModel: '=',
                       toDate: '=?',
                       options: '=',
                       extraSettings: '=',
                       isSchemeIndex: '=?',
                       isSchemeIndexTri: '=?',
                       hideSchemeIndexCheckbox: '=?',
                       setfromIndexDirective: '&',
                       excludeRestrictedIndex: '=?',//? means attribute will be optional
                       AddIndexTooltip: '=?',
                       AddPtscannerIndexTooltip: '=?',
                       setAllInputIndexData: '&',
                       setAllInputIndexDataCustom: '&',
                       setAllInputIndexDataComposite:'&'
                   },
                   //compile: function (tElement, tAttributes) {
                   //    // CAUTION: You cannot use .wrapInner() unless you include jQuery.
                   //    // You don't get this kind of sweet-ass functionality with jQLite.
                   //    debugger;
                   //    tElement.wrapInner("<div id='temp" + tAttributes.id+"'></div>");
                   //},

                   //template: '<input  type="text" class="form-control" ng-model="selectedPartialText"/>',
                   templateUrl: '/SchemePerformance/IndexSelection',
                   link: function ($scope, $element, $attrs) {
                       $scope.divheightMfi = $attrs.divheightMfi || "350px";
                       $scope.divheightCustomized = $attrs.divheightCustomized || "350px";
                       $scope.divheightComposite = $attrs.divheightComposite || "350px";
                       var isBothSchemeIndex = $attrs.isBothSchemeIndex || false;
                       $scope.AddIndexTooltip = false;
                       $scope.IndexTooltip = false;
                       //$scope.searchMFIIndex = "";
                       $scope.selectedCustomindexModel = $scope.selectedCustomindexModel || [];
                       $scope.selectedCompositeindexModel = $scope.selectedCompositeindexModel || [];

                       var AllMFIIndex = GetAllMFIIndex.Call();
                       AllMFIIndex.then(function successCallback(response) {
                           $scope.options.LstMFIndexes = response.data.data;
                           $scope.LstMergedIndexs = $scope.options.LstMFIndexes || [];
                           //$scope.LoaderCommon = false;
                       },
                           function errorCallback(response) {
                           });
                       var AllCustomIndex = GetAllCustomIndex.Call();
                       AllCustomIndex.then(function successCallback(response) {
                           $scope.options.LstCustomIndexes = response.data.data;
                           $scope.LstMergedCustIndexs = $scope.options.LstCustomIndexes || [];
                       },
                           function errorCallback(response) {
                           });
                       var AllCompositeIndex = GetAllCompositeIndex.Call();
                       AllCompositeIndex.then(function successCallback(response) {
                           $scope.options.LstCompositeIndexes = response.data.data;
                           $scope.LstMergedCompIndexs = $scope.options.LstCompositeIndexes || [];
                       },
                           function errorCallback(response) {
                           });

                       //var AllMFIIndex = GetAllMFIIndex.Call();
                       //var AllCustomIndex = GetAllCustomIndex.Call();
                       //var AllCompositeIndex = GetAllCompositeIndex.Call();

                       //$q.all([
                       //    AllMFIIndex,
                       //    AllCustomIndex,
                       //    AllCompositeIndex
                       //]).then(function successCallback(response) {
                       //    $scope.options.LstMFIndexes = response[0].data.data == null ? [] : response[0].data.data;
                       //    $scope.options.LstCustomIndexes = response[1]?.data?.data ?? [];
                       //    $scope.options.LstCompositeIndexes = response[2]?.data?.data ?? [];
                       //    //$scope.options.LstMFIndexes = $scope.options.LstMFIndexes || [];
                       //    $scope.LstMergedIndexs = $scope.options.LstMFIndexes || [];
                       //    //$scope.options.LstCustomIndexes = $scope.options.LstCustomIndexes || [];
                       //    $scope.LstMergedCustIndexs = $scope.options.LstCustomIndexes || [];
                       //    //$scope.options.LstCompositeIndexes = $scope.options.LstCompositeIndexes || [];
                       //    $scope.LstMergedCompIndexs = $scope.options.LstCompositeIndexes || [];
                           
                       //});
                   

                       //$scope.options.LstMFIndexes = $scope.options.LstMFIndexes || [];
                       //$scope.LstMergedIndexs = $scope.options.LstMFIndexes || [];
                       //$scope.options.LstCustomIndexes = $scope.options.LstCustomIndexes || [];
                       //$scope.LstMergedCustIndexs = $scope.options.LstCustomIndexes || [];
                       //$scope.options.LstCompositeIndexes = $scope.options.LstCompositeIndexes || [];
                       //$scope.LstMergedCompIndexs = $scope.options.LstCompositeIndexes || [];


                       //alert($scope.divHeight);
                  // controller: function ($scope, $element, $attrs) {
                       //scope.PartialText = scope.selectedPartialText;
                       //$scope.selectedModel.MFIndexModel = [];
                       //$($element).iCheck({
                       //    checkboxClass: 'icheckbox_flat-green',
                       //    radioClass: 'iradio_flat-green'
                       //});
                       $scope.excludeRestrictedIndex = $scope.excludeRestrictedIndex || false;
                       $scope.attrid = $attrs.id;
                       if ($scope.attrid == "SebiPerformanceIndexSelection") {
                           $scope.IndexTooltip = true;
                       }
                       else if ($scope.attrid == "IndexSelection")
                       {
                           $scope.AddPtscannerIndexTooltip = true;
                       }
                       else {
                           $scope.AddIndexTooltip = true;
                       }

                       $scope.IsMFIIndexAllChecked = false;
                       $scope.IsCustomIndexAllChecked = false;
                       $scope.IsCompositeIndexAllChecked = false;
                       var GetMaxIndexDate = "";
                       if (!angular.isUndefinedOrNullOrEmpty($scope.options.LstMFIndexes) && $scope.options.LstMFIndexes.length > 0) {
                           GetMaxIndexDate = $scope.options.LstMFIndexes[0].LatestIndexDateFomatted;
                       }
                       $scope.toDate = GetMaxIndexDate;
                       if ($scope.setfromIndexDirective != undefined) {
                           $scope.setfromIndexDirective({ MaxDate: "MaxDate", LatestIndexDate: $scope.toDate });
                       }
                       $scope.settings = {
                           IsSingleSelection: ($scope.extraSettings != undefined && $scope.extraSettings.IsSingleSelection) || false,
                           isFullHide: ($scope.extraSettings != undefined && $scope.extraSettings.isFullHide) || false
                       };
                       $scope.checkAssociatedMFIIndexCheckBox = function (idindex, attrid, IsDisabled) {
                           if (!IsDisabled) {
                               setTimeout(function () {
                                   //angular.element("#" + attrid + "chkDirectiveIndex_Mfi_" + idindex).find("fieldset").trigger('click');
                                   angular.element("#" + attrid + "chkDirectiveIndex_Mfi_" + idindex).trigger('click');
                               }, 0);
                           }
                       };
                       $scope.checkAssociatedCustomIndexCheckBox = function (idindex, attrid, IsDisabled) {
                           if (!IsDisabled) {
                               setTimeout(function () {
                                   // angular.element("#" + attrid + "chkDirectiveIndex_Custom_" + idindex).find("fieldset").trigger('click');
                                   angular.element("#" + attrid + "chkDirectiveIndex_Custom_" + idindex).trigger('click');
                               }, 0);
                           }
                       };
                       $scope.checkAssociatedCompositeIndexCheckBox = function (idindex, attrid, IsDisabled) {
                           if (!IsDisabled) {
                               setTimeout(function () {
                                   //angular.element("#" + attrid + "chkDirectiveIndex_Composite_" + idindex).find("fieldset").trigger('click');
                                   angular.element("#" + attrid + "chkDirectiveIndex_Composite_" + idindex).trigger('click');
                               }, 0);
                           }
                       };
                       //====MFI Index
                       var Selectedindx = [] /*JSON.parse($scope.selectedMfiindexModel)*/;
                       var SelectedCusindx = [];
                       var SelectedComindx = [];
                       $scope.chkMFIndexClick = function (event, Id, Name,IsItemClickForCheck) {                           
                           var itemMFIndex = JSON.stringify({ Id: Id, Name: Name });
                           //if (event.target.checked == true) {
                           IsItemClickForCheck = event.target.checked;
                           if (IsItemClickForCheck) {
                               if ($scope.settings.IsSingleSelection) {
                                   $scope.selectedMfiindexModel = [];
                                   angular.forEach($scope.options.LstMFIndexes, function (value) {
                                       value.IsChecked = value.Id==Id?true:false;
                                   });

                                   //angular.forEach($scope.LstMergedIndexs, function (value) {
                                   //    value.IsChecked = value.Id==Id?true:false;
                                   //});
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                                   angular.element("#" + $scope.attrid + "chkDirectiveIndex_Mfi_" + Id).prop("checked", true);
                               }
                               $scope.selectedMfiindexModel.push(itemMFIndex);
                               // Selectedindx.push(JSON.parse(JSON.stringify(itemMFIndex)));
                               Selectedindx.push(JSON.parse(itemMFIndex))
                               //if ($scope.searchMFIIndex != "" && $scope.LstMergedIndexs.length != 0) {
                               //    $scope.IsMFIIndexAllChecked = true;

                               //}
                               //else {
                               //    $scope.IsMFIIndexAllChecked = $scope.options.LstMFIndexes.length == $scope.selectedMfiindexModel.length;
                               //}

                           }
                           else {
                               var index = $scope.selectedMfiindexModel.indexOf(itemMFIndex);
                               $scope.selectedMfiindexModel.splice(index, 1);
                               Selectedindx.splice(index, 1);
                               if ($scope.settings.IsSingleSelection) {
                                   //angular.forEach($scope.options.LstMFIndexes, function (value) {
                                   //    value.IsChecked = false;
                                   //});
                                   angular.forEach($scope.LstMergedIndexs, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                               }
                           }
                           $scope.IsMFIIndexAllChecked = $scope.options.LstMFIndexes.length == $scope.selectedMfiindexModel.length;
                           if ($scope.isSchemeIndex != undefined) {
                               if (!isBothSchemeIndex)
                                   $scope.isSchemeIndex = false;
                           }
                           $scope.setAllInputIndexData({ IndexModel: $scope.selectedMfiindexModel });
                       };
                       //$scope.$watchCollection('selectedMfiindexModel', function (newValue, oldValue) {
                       //    $scope.IsMFIIndexAllChecked = $scope.selectedMfiindexModel.length > 0 && ($scope.LstMergedIndexs.length == $scope.selectedMfiindexModel.length)?true:false;
                       //});
                       $scope.$watch('searchMFIIndex', function (newValue) {
                           $scope.LstMergedIndexs = $filter('filter')($scope.options.LstMFIndexes, $scope.searchMFIIndex);
                          // $scope.selectedMfiindexModel = $scope.selectedMfiindexModel.filter(x => $scope.LstMergedIndexs.findIndex(y=>y.Id == x.Id) !=-1)
                           $scope.IsMFIIndexAllChecked = $scope.options.LstMFIndexes.length == $scope.selectedMfiindexModel.length;
                           $scope.Alfilterlistselected = false;
                          // $scope.pagingStatus.onPageChanged();
                       }, true);
                       $scope.chkMFIndexAllClick = function (event) {
                           if ($scope.IsMFIIndexAllChecked) {
                               //$scope.selectedMfiindexModel = [];
                               //angular.forEach($scope.options.LstMFIndexes, function (value) {
                               //    $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, IsRestrictedIndex: value.IsRestrictedIndex }));
                               //    value.IsChecked = true;
                               //});
                               //angular.forEach(angular.element("input[id^='chkDirectiveIndexMfi_']"), function (value, index) {
                               //    angular.element("#"+value.id).prop("checked", true);
                               //});
                               if ($scope.selectedMfiindexModel.length > 0) {
                                   angular.forEach($scope.selectedMfiindexModel, function (jsonStr) {
                                       var value;
                                       try {
                                           value = JSON.parse(jsonStr); // Convert JSON string to object
                                       } catch (e) {
                                           console.error("Invalid JSON string:", jsonStr);
                                           return; // Skip this item if it's not valid JSON
                                       }
                                       // Check if the Id is not already present in Selectedindx
                                       if (Selectedindx.findIndex(x => x.Id === value.Id) === -1) {
                                           Selectedindx.push({ Id: value.Id, Name: value.Name });
                                       }
                                   });
                               }

                               if ($scope.searchMFIIndex != "" && $scope.LstMergedIndexs.length != 0) { // if searchd and found
                                   if ($scope.LstMergedIndexs.length <= $scope.options.LstMFIndexes.length) {
                                       angular.forEach($scope.LstMergedIndexs, function (value) {
                                           if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name,/* IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                               //Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                               Selectedindx.push(value);
                                               value.IsChecked = true;
                                           }

                                       });
                                       // angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                                       $scope.IsMFIIndexAllChecked = true; /*$scope.LstMergedIndexs.length == $scope.selectedMfiindexModel.length*/;

                                   }
                                   else {
                                       angular.forEach($scope.options.LstMFIndexes, function (value) {
                                           if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                               value.IsChecked = true;
                                               // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                               Selectedindx.push(value);
                                           }

                                       });
                                   }
                               }
                               else {
                                   angular.forEach($scope.options.LstMFIndexes, function (value) {
                                       // var Selectedindx = JSON.parse($scope.selectedMfiindexModel);
                                       if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                                           $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                           value.IsChecked = true;
                                           // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                           Selectedindx.push(value);
                                       }

                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", true);
                                   //$scope.options.LstMFIndexes.forEach(p=>)
                               }
                               $scope.Alfilterlistselected = true;
                           }
                           else {
                               $scope.selectedMfiindexModel = [];
                               Selectedindx = [];
                               angular.forEach($scope.options.LstMFIndexes, function (value) {
                                   value.IsChecked = false;
                               });
                               angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                               $scope.Alfilterlistselected = false;

                           }
                           if ($scope.isSchemeIndex != undefined) {
                               if (!isBothSchemeIndex)
                                   $scope.isSchemeIndex = false;
                           }
                           $scope.setAllInputIndexData({ IndexModel: $scope.selectedMfiindexModel });
                          // $scope.IsMFIIndexAllChecked = $scope.options.LstMFIndexes.length == $scope.selectedMfiindexModel.length;
                       };
                       $scope.chkSchemeIndexTRI = function () {
                           localStorage.removeItem("isSchemeIndexTri");
                           localStorage.setItem("isSchemeIndexTri", $scope.isSchemeIndexTri);
                       };
                       $scope.chkSchemeIndexClick = function (event) {
                           //if (event.target.checked == true) {
                           localStorage.removeItem("isSchemeIndex");
                           localStorage.removeItem("isSchemeIndexTri");
                           localStorage.setItem("isSchemeIndex", $scope.isSchemeIndex);
                           localStorage.setItem("isSchemeIndexTri", $scope.isSchemeIndexTri);
                           
                           if ($scope.isSchemeIndex == true && !isBothSchemeIndex) {
                               $scope.selectedMfiindexModel = [];
                               angular.forEach($scope.options.LstMFIndexes, function (value) {
                                   value.IsChecked = false;
                               });
                               $scope.IsMFIIndexAllChecked = false;
                               angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                           }
                           //else {
                           //    $scope.isSchemeIndex = false;
                           //}
                           if ($scope.isSchemeIndexTri != undefined && $scope.isSchemeIndex == false) {
                               $scope.isSchemeIndexTri = false;
                           }
                           $scope.setAllInputIndexData({ IndexModel: $scope.selectedMfiindexModel });
                       };
                       //====MFI Index
                       //====Custom Index
                       $scope.chkCustomIndexClick = function (event, Id, Name,IsItemClickForCheck) {
                           var itemCustomIndex = JSON.stringify({ Id: Id, Name: Name });
                           IsItemClickForCheck = event.target.checked;
                           if (IsItemClickForCheck) {
                               if ($scope.settings.IsSingleSelection) {
                                   $scope.selectedCustomindexModel = [];
                                   angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                       value.IsChecked = value.Id == Id ? true : false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", false);
                                   angular.element("#" + $scope.attrid + "chkDirectiveIndex_Custom_" + Id).prop("checked", true);
                               }
                               $scope.selectedCustomindexModel.push(itemCustomIndex);
                               SelectedCusindx.push(JSON.parse(itemCustomIndex))
                           }
                           else {
                               var index = $scope.selectedCustomindexModel.indexOf(itemCustomIndex);
                               $scope.selectedCustomindexModel.splice(index, 1);
                               SelectedCusindx.splice(index, 1);
                               if ($scope.settings.IsSingleSelection) {
                                   angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", false);
                               }
                           }
                           $scope.setAllInputIndexDataCustom({ IndexModel: $scope.selectedCustomindexModel });

                           $scope.IsCustomIndexAllChecked = $scope.options.LstCustomIndexes.length == $scope.selectedCustomindexModel.length;
                       };
                       //$scope.$watchCollection('selectedCustomindexModel', function (newValue, oldValue) {
                       //         $scope.IsCustomIndexAllChecked = $scope.selectedCustomindexModel.length > 0 &&($scope.options.LstCustomIndexes.length == $scope.selectedCustomindexModel.length)?true:false;
                       //});
                       $scope.$watch('searchCustomIndex', function (newValue) {
                           $scope.LstMergedCustIndexs = $filter('filter')($scope.options.LstCustomIndexes, $scope.searchCustomIndex);
                           // $scope.selectedMfiindexModel = $scope.selectedMfiindexModel.filter(x => $scope.LstMergedIndexs.findIndex(y=>y.Id == x.Id) !=-1)
                           $scope.IsCustomIndexAllChecked = $scope.options.LstCustomIndexes.length == $scope.selectedCustomindexModel.length;
                           // $scope.pagingStatus.onPageChanged();
                       }, true);
                       $scope.chkCustomIndexAllClick = function (event) {
                           if ($scope.IsCustomIndexAllChecked) {
                               //$scope.selectedCustomindexModel = [];
                               //angular.forEach($scope.options.LstCustomIndexes, function (value) {
                               //    $scope.selectedCustomindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name,IsRestrictedIndex: value.IsRestrictedIndex }));
                               //    value.IsChecked = true;
                               //});
                               //angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", true);
                               if ($scope.selectedCustomindexModel.length > 0) {
                                   angular.forEach($scope.selectedCustomindexModel, function (jsonStr) {
                                       var value;
                                       try {
                                           value = JSON.parse(jsonStr); // Convert JSON string to object
                                       } catch (e) {
                                           console.error("Invalid JSON string:", jsonStr);
                                           return; // Skip this item if it's not valid JSON
                                       }
                                       // Check if the Id is not already present in SelectedCusindx
                                       if (SelectedCusindx.findIndex(x => x.Id === value.Id) === -1) {
                                           SelectedCusindx.push({ Id: value.Id, Name: value.Name });
                                       }
                                   });
                               }
                               if ($scope.searchCustomIndex != "" && $scope.LstMergedCustIndexs.length != 0) { // if searchd and found
                                   if ($scope.LstMergedCustIndexs.length <= $scope.options.LstCustomIndexes.length) {
                                       angular.forEach($scope.LstMergedCustIndexs, function (value) {
                                           if (SelectedCusindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedCustomindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name,/* IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                               //Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                               SelectedCusindx.push(value);
                                               value.IsChecked = true;
                                           }

                                       });
                                       // angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                                       $scope.IsCustomIndexAllChecked = true; /*$scope.LstMergedIndexs.length == $scope.selectedMfiindexModel.length*/;

                                   }
                                   else {
                                       angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                           if (SelectedCusindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedCustomindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                               value.IsChecked = true;
                                               // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                               SelectedCusindx.push(value);
                                           }

                                       });
                                   }
                               }
                               else {
                                   angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                       // var Selectedindx = JSON.parse($scope.selectedMfiindexModel);
                                       if (SelectedCusindx.findIndex(x => x.Id === value.Id) == -1) {
                                           $scope.selectedCustomindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                                           value.IsChecked = true;
                                           // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                                           SelectedCusindx.push(value);
                                       }

                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", true);
                                   //$scope.options.LstMFIndexes.forEach(p=>)
                               }
                           }
                           else {
                               $scope.selectedCustomindexModel = [];
                               SelectedCusindx = [];
                               angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                   value.IsChecked = false;
                               });
                               angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", false);
                           }
                           $scope.setAllInputIndexDataCustom({ IndexModel: $scope.selectedCustomindexModel });

                       };
                       //====Custom Index
                       //====Composite Index
                       $scope.chkCompositeIndexClick = function (event, Id, Name, IsItemClickForCheck) {
                           var itemCompositeIndex = JSON.stringify({ Id: Id, Name: Name });
                           IsItemClickForCheck = event.target.checked;
                           if (IsItemClickForCheck) {
                               if ($scope.settings.IsSingleSelection) {
                                   $scope.selectedCompositeindexModel = [];
                                   angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                       value.IsChecked = value.Id == Id ? true : false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Composite_").prop("checked", false);
                                   angular.element("#" + $scope.attrid + "chkDirectiveIndex_Composite_" + Id).prop("checked", true);
                               }
                               $scope.selectedCompositeindexModel.push(itemCompositeIndex);
                               SelectedComindx.push(JSON.parse(itemCompositeIndex));
                           }
                           else {
                               var index = $scope.selectedCompositeindexModel.indexOf(itemCompositeIndex);
                               $scope.selectedCompositeindexModel.splice(index, 1);
                               SelectedComindx.splice(index, 1);
                               if ($scope.settings.IsSingleSelection) {
                                   angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Composite_").prop("checked", false);
                               }
                           }
                           $scope.IsCompositeIndexAllChecked = $scope.options.LstCompositeIndexes.length == $scope.selectedCompositeindexModel.length;
                           $scope.setAllInputIndexDataComposite({ IndexModel: $scope.selectedCompositeindexModel });

                       };
                       //$scope.$watchCollection('selectedCompositeindexModel', function (newValue, oldValue) {
                       //        $scope.IsCompositeIndexAllChecked = $scope.selectedCompositeindexModel.length > 0 && ($scope.options.LstCompositeIndexes.length == $scope.selectedCompositeindexModel.length)?true:false;
                       //});
                       $scope.$watch('searchCompositeIndex', function (newValue) {
                           $scope.LstMergedCompIndexs = $filter('filter')($scope.options.LstCompositeIndexes, $scope.searchCompositeIndex);
                           // $scope.selectedMfiindexModel = $scope.selectedMfiindexModel.filter(x => $scope.LstMergedIndexs.findIndex(y=>y.Id == x.Id) !=-1)
                           $scope.IsCompositeIndexAllChecked = $scope.options.LstCompositeIndexes.length == $scope.selectedCompositeindexModel.length;
                           // $scope.pagingStatus.onPageChanged();
                       }, true);
                       $scope.chkCompositeIndexAllClick = function (event) {
                           if ($scope.IsCompositeIndexAllChecked) {
                               //$scope.selectedCompositeindexModel = [];
                               if ($scope.selectedCompositeindexModel.length > 0) {
                                   angular.forEach($scope.selectedCompositeindexModel, function (jsonStr) {
                                       var value;
                                       try {
                                           value = JSON.parse(jsonStr); // Convert JSON string to object
                                       } catch (e) {
                                           console.error("Invalid JSON string:", jsonStr);
                                           return; // Skip this item if it's not valid JSON
                                       }
                                       // Check if the Id is not already present in SelectedComindx
                                       if (SelectedComindx.findIndex(x => x.Id === value.Id) === -1) {
                                           SelectedComindx.push({ Id: value.Id, Name: value.Name });
                                       }
                                   });
                               }
                               if ($scope.searchCompositeIndex != "" && $scope.LstMergedCompIndexs.length != 0) {
                                   if ($scope.LstMergedCompIndexs.length <= $scope.options.LstCompositeIndexes.length) {
                                       angular.forEach($scope.LstMergedCompIndexs, function (value) {
                                           if (SelectedComindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedCompositeindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name }));
                                               SelectedComindx.push(value);
                                               value.IsChecked = true;
                                           }
                                       });
                                       $scope.IsCompositeIndexAllChecked = true;
                                   }
                                   else {
                                       angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                           if (SelectedComindx.findIndex(x => x.Id === value.Id) == -1) {
                                               $scope.selectedCompositeindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name }));
                                               value.IsChecked = true;
                                               //SelectedComindx.push(value);
                                           }
                                       });
                                   }
                               }
                               else {
                                   angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                       if (SelectedComindx.findIndex(x => x.Id === value.Id) == -1) {
                                           $scope.selectedCompositeindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name }));
                                           value.IsChecked = true;
                                           SelectedComindx.push(value);
                                       }
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Composite_").prop("checked", true);
                               }
                           }
                           else {
                               $scope.selectedCompositeindexModel = [];
                               SelectedComindx = [];
                               angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                   //$scope.selectedCompositeindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name }));
                                   value.IsChecked = false;
                               });
                               angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Composite_").prop("checked", false);
                           }
                           $scope.setAllInputIndexDataComposite({ IndexModel: $scope.selectedCompositeindexModel });

                       };

                       //#region For SIP Report
                       // Watch for changes to the selected MFI index model
                       $scope.$watchCollection('selectedMfiindexModel', function (newVal) {
                           if (angular.isArray(newVal)) {
                               // Uncheck all checkboxes and IsChecked flags if array is empty
                               if (newVal.length === 0) {
                                   angular.forEach($scope.options.LstMFIndexes, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);
                                   //$scope.searchMFIIndex = "";
                                   $scope.IsMFIIndexAllChecked = false;
                               }
                           }
                       });

                       // Watch for changes to the selected Custom index model
                       $scope.$watchCollection('selectedCustomindexModel', function (newVal) {
                           if (angular.isArray(newVal)) {
                               if (newVal.length === 0) {
                                   angular.forEach($scope.options.LstCustomIndexes, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Custom_").prop("checked", false);
                                   //$scope.searchCustomIndex = "";
                                   $scope.IsCustomIndexAllChecked = false;
                               }
                           }
                       });

                       // Watch for changes to the selected Composite index model
                       $scope.$watchCollection('selectedCompositeindexModel', function (newVal) {
                           if (angular.isArray(newVal)) {
                               if (newVal.length === 0) {
                                   angular.forEach($scope.options.LstCompositeIndexes, function (value) {
                                       value.IsChecked = false;
                                   });
                                   angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Composite_").prop("checked", false);
                                   //$scope.searchCompositeIndex = "";
                                   $scope.IsCompositeIndexAllChecked = false;
                               }
                           }
                       });
                       //#endregion

                       //====Custom Index
                       $scope.Alfilterlistselected = false;
                       //$scope.AllFilterlistSelect = function () {
                       //    //$scope.Alfilterlistselected = !$scope.Alfilterlistselected;
                       //    if ($scope.Alfilterlistselected) {
                       //        //$scope.selectedMfiindexModel = [];
                       //        //angular.forEach($scope.options.LstMFIndexes, function (value) {
                       //        //    $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, IsRestrictedIndex: value.IsRestrictedIndex }));
                       //        //    value.IsChecked = true;
                       //        //});
                       //        if ($scope.searchMFIIndex != "" && $scope.LstMergedIndexs.length != 0) { // if searchd and found
                       //            if ($scope.LstMergedIndexs.length < $scope.options.LstMFIndexes.length) {
                       //                angular.forEach($scope.LstMergedIndexs, function (value) {
                       //                    if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                       //                        $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name,/* IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                       //                        //Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                       //                        Selectedindx.push(value);
                       //                        value.IsChecked = true;
                       //                    }

                       //                });
                       //               // angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);

                       //            }
                       //            else {
                       //                angular.forEach($scope.options.LstMFIndexes, function (value) {
                       //                    if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                       //                        $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                       //                        value.IsChecked = true;
                       //                        // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                       //                        Selectedindx.push(value);
                       //                    }

                       //                });
                       //            }
                       //        }
                       //        else {
                       //            angular.forEach($scope.options.LstMFIndexes, function (value) {
                       //                // var Selectedindx = JSON.parse($scope.selectedMfiindexModel);
                       //                if (Selectedindx.findIndex(x => x.Id === value.Id) == -1) {
                       //                    $scope.selectedMfiindexModel.push(JSON.stringify({ Id: value.Id, Name: value.Name, /*IsRestrictedIndex: value.IsRestrictedIndex*/ }));
                       //                    value.IsChecked = true;
                       //                    // Selectedindx.push(JSON.parse(JSON.stringify($scope.selectedMfiindexModel)));
                       //                    Selectedindx.push(value);
                       //                }

                       //            });
                       //            angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", true);
                       //            //$scope.options.LstMFIndexes.forEach(p=>)
                       //        }
                       //        //angular.forEach(angular.element("input[id^='chkDirectiveIndexMfi_']"), function (value, index) {
                       //        //    angular.element("#"+value.id).prop("checked", true);
                       //        //});

                       //    }
                       //    else {
                       //        $scope.selectedMfiindexModel = [];
                       //        Selectedindx = [];
                       //        angular.forEach($scope.options.LstMFIndexes, function (value) {
                       //            value.IsChecked = false;
                       //        });
                       //        angular.element("input[id^=" + $scope.attrid + "chkDirectiveIndex_Mfi_").prop("checked", false);

                       //    }
                       //    if ($scope.isSchemeIndex != undefined) {
                       //        if (!isBothSchemeIndex)
                       //            $scope.isSchemeIndex = false;
                       //    }
                       //    $scope.IsMFIIndexAllChecked = $scope.options.LstMFIndexes.length == $scope.selectedMfiindexModel.length;
                       //}
                   }
               };
           }]);
