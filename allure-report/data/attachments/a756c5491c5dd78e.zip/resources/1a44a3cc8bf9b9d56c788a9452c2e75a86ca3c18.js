angular.module('angular-icheck', [])
    .directive('iCheck', [function () {
        return {
            restrict: 'EA',
            scope: {
                isDisabled: '=?',
                setLabelStyle: '=?'
            },
            transclude: true,
            require: 'ngModel',
            replace: true,
            //template: '<div class="angular-icheck"><div ng-click="ToggleClass($event);"  ng-class="SetClass"></div><div class="ichecklabel" ng-transclude></div></div>',
            template: '<span class="angular-icheck"><fieldset ng-disabled="isDisabled" ng-style="isDisabled?setCursorStyledisabled:setCursorStyle" ng-click="ToggleClass($event);" ng-class="SetClass"></fieldset><span ng-click="ToggleClass($event);" ng-style="setLabelStyle" class="angular-icheck-span" ng-transclude></span></span>',
            link: function (scope, ele, attrs, ctrl) {
                //scope.Disabled = scope.isDisabled||false;
                scope.isDisabled = scope.isDisabled || false;//scope.isDisabled == true ? true : false;
                scope.isCheckBox = attrs.type == "checkbox" ? true : false;
                scope.SetClass = scope.isCheckBox ? "checkbox" : "radio";
                scope.setCursorStyle = { "cursor": "pointer", "opacity": "1" };
                scope.setCursorStyledisabled = { "cursor": "not-allowed", "opacity": ".3" };
                scope.setLabelStyle = scope.setLabelStyle||{ "color": "black" };
                scope.ToggleClass = function (event) {
                    if (scope.isDisabled) {
                        event.stopPropagation();
                        return false;
                    }
                    if (scope.isCheckBox) {
                        var box = angular.element(ele[0].querySelector('.checkbox'));
                        scope.SetClass = box[0].className == "checkbox" ? "checkbox checked" : "checkbox"; //event.target.className == "checkbox" ? "checkbox checked" : "checkbox";
                        ctrl.$setViewValue(scope.SetClass == "checkbox checked");
                    }
                    else {
                        var box = angular.element(ele[0].querySelector('.radio'));
                        scope.SetClass = box[0].className == "radio" ? "radio checked" : "radio";//event.target.className == "radio" ? "radio checked" : "radio";
                        ctrl.$setViewValue(scope.SetClass == "radio checked");
                    }
                };
                ctrl.$render = function () {
                    if (ctrl.$viewValue) {
                        if (scope.isCheckBox) {
                            scope.SetClass = "checkbox checked";
                        }
                        else {
                            scope.SetClass = "radio checked";
                        }
                    } else {
                        if (scope.isCheckBox) {
                            scope.SetClass ="checkbox";
                        }
                        else {
                            scope.SetClass = "radio";
                        }
                    }
                };

                //var box = scope.isCheckBox ? angular.element(ele[0].querySelector('.checkbox')) : angular.element(ele[0].querySelector('.radio'));
                //ele.bind("click", function () {
                //    box.toggleClass("checked");
                //  //  ctrl.$setViewValue(box.hasClass("checked"));
                //});
                //ctrl.$render = function () {
                //    if (ctrl.$viewValue) {
                //        box.addClass("checked");
                //    } else {
                //        box.removeClass("checked");
                //    }
                //};
                // https://github.com/angular/angular.js/issues/2594
                // override $isEmpty method
                //ctrl.$isEmpty = function(value) {
                //    return value === false;
                //};
                //ctrl.$setViewValue(box.hasClass("checked"));
                //ctrl.$validate();
            }
        }
    }]);