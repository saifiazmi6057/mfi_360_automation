SharedServices.service('GetFrequencySIPDateSelectPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiSWPCalculator/GetFrequencySIPDateSelectPeriodDetails',
            method: 'GET'
        });
    }
}]);

SharedServices.service('SWPCalculation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSWPCalculator/SWPCalculation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);