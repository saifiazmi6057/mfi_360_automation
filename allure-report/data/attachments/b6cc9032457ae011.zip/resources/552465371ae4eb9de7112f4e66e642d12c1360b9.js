//var ServiceCustomIndex = angular.module('ServiceCustomIndex', []);

//ServiceCustomIndex.config(BaseServiceConfig);

SharedServices.service('GetAllCustomIndexSettings', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllCustomIndex',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetUserListByClientID', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetUserListByClientID',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PostAddCustomIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostModificationPermission', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostModificationPermission',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostModifyCustomIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostModifyCustomIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostDeleteCustomIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteCustomIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('FetchCustomIndexTemplate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchCustomIndexTemplate',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostCustomIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostCustomIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostDeleteCustomIndexDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteCustomIndexDetailRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostSearchCustomIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostSearchCustomIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostAddCustomIndexDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        //debugger;
        //var formData = new FormData();
        //if (obj.ObjFile != null) {
        //    formData.append("UploadedFile", obj.ObjFile);
        //}
        //formData.append("CustomIndexId", obj.CustomIndexId);
        //var uploadUrl = 'http://localhost:56543/api/ApiPortfolio/PostAddCustomIndexDetailRecord';
        //var fileFormData = obj.ObjFile;
        //var deffered = $q.defer();
        //$http.post(uploadUrl, fileFormData, {
        //    transformRequest: angular.identity,
        //    headers: { 'Content-Type': undefined }

        //}).success(function (response) {
        //    deffered.resolve(response);

        //}).error(function (response) {
        //    deffered.reject(response);
        //});

        //return deffered.promise;
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexDetailRecord',
            headers: { 'Content-Type': undefined },
            transformRequest: function (data, headersGetter) {
                            var formData = new FormData();
                            angular.forEach(data, function (value, key) {
                                formData.append(key, value);
                            });
                            //var headers = headersGetter();
                            //delete headers['Content-Type'];
                            return formData;
                        },
            data: { "CustomIndexId": obj.CustomIndexId, "files": obj.file }
            //dataType: 'json',
            //contentType: false,
            //processData: false
            //files: obj.ObjFile,
            //data: {"CustomIndexId":obj.CustomIndexId}
            //data: $.param(obj)
            //dataType: "json"
        });
    }

}]);

SharedServices.service('GetAllCustomIndexPortfolioSettings', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllCustomIndexPortfolio',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PostAddCustomIndexPortfolioRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexPortfolioRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostSearchCustomIndexPortRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostSearchCustomIndexPortRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostAddCustomIndexPortDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexPortDetailRecord',
            headers: { 'Content-Type': undefined },
            transformRequest: function (data, headersGetter) {
                var formData = new FormData();
                angular.forEach(data, function (value, key) {
                    formData.append(key, value);
                });
                
                return formData;
            },
            data: { "CustomIndexId": obj.CustomIndexId, "files": obj.file }
            
        });
    }

}]);

SharedServices.service('PostModifyCustomIndexPortRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostModifyCustomIndexPortRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostDeleteCustomIndexPortRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteCustomIndexPortRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostDeleteCustomIndexPortDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteCustomIndexPortDetailRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostCustomIndexPortRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostCustomIndexPortRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);