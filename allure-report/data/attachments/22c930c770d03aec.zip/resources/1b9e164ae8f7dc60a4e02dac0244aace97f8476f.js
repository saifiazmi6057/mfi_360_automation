SharedDeractives.directive('newentryExitDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetEntryExitReportData','GetEntryExitReportDataAdvance',
    'GetPortfolioDDL', 'MFIMsg', '$window',
    function ($http, $q, $timeout, ApiInfo, GetEntryExitReportData, GetEntryExitReportDataAdvance, GetPortfolioDDL, MFIMsg, $window) {
        return {
            restrict: 'AE',
            scope: {
                lstMfiSchemes: '=',
                setfromNewentryExitDirective: '&',
                setfromMarketCapforLoader: '&'
            },
            templateUrl: '/PortfolioAnalysis/NewentryExitAdvance',
            link: function ($scope, $element, $attrs) {
                $scope.EntryExitPortfolioDate = "";
                //$scope.OptionsForSelectedSchesmes = {};
                //$scope.OptionsForSelectedSchesmes.LstSelectedSchemes = [];
                //$scope.OptionsForSelectedSchesmes.LstUserSetSchemes = [];
                //$scope.OptionsForSelectedSchesmes.LstMywatchListSchemes = [];
                //$scope.LstMergedSchemes = [];
                //$scope.LstMFISchemes = [];
                //$scope.ShowExportIcon = false;
                $scope.PortfolioDateList = [];
                //$scope.SelectedStockOptios = "";
                $scope.LoaderNewEntryExitTable = false;
                //$scope.ShowReportTable = false;
                //$scope.LstNewStocks = [];
                //$scope.LstStocksExited = [];
                //$scope.LstStocksExitedCompanyName = [];
                //$scope.LstCompanyName = [];
                //$scope.HeaderName = "Market Value";

                //$scope.LstTableHeaderName = [{ Name: "% of Net Asset" }, { Name: "Market Value" }, { Name: "No. of Shares" }];
                //$scope.LstNewStocksTableHeader = [];
                //$scope.LstStocksExitedTableHeader = [];

                //$scope.UserSetSettings = {
                //    scrollableHeight: '300px',
                //    scrollable: true,
                //    enableSearch: true,
                //    ddltext: "Select User Set",
                //    Keyprop: "UssId",
                //    Valueprop: "UssName",
                //};

                $scope.ShowType = "Both";
                //$scope.ShowNewStocks = false;
                //$scope.ShowStocksExited = false;

                var getPortfolioDDLData = GetPortfolioDDL.Call(5);

                getPortfolioDDLData.then(function (response) {
                    $scope.PortfolioDateList = response.data.data;
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Failed to fetch protfolio date list.", MFIAlertType.Error, "OK");
                    });

                $scope.GetSelectNewEntryExitType = function (StockType) {
                    $scope.ShowType = StockType;
                };

                var CollapseSelCriteria = function () {
                    angular.element("#DivNewEntryExitDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                }

                $scope.GetEntryExitDetailsReport = function () {
                    if ($scope.lstMfiSchemes.length == 0) {
                        MFIMsg.AlertHtml("User have to select atleast one scheme.", MFIAlertType.Information, "OK");
                        return;
                    }
                    if ($scope.EntryExitPortfolioDate == "" || $scope.EntryExitPortfolioDate == "Select Period" || $scope.EntryExitPortfolioDate == null) {
                        MFIMsg.AlertHtml("User have to select portfolio date.", MFIAlertType.Information, "OK");
                        return;
                    }
                    //if ($scope.lstMfiSchemes.length > MaxSchemeSelectionAllowed) {
                    //    MFIMsg.AlertHtml("You can select only " + MaxSchemeSelectionAllowed + " schemes to show the report", MFIAlertType.Information);
                    //    return false;
                    //}
                    $scope.LstSelectedMFISchemes = [];
                    angular.forEach($scope.lstMfiSchemes, function (value) {
                        var item = { "Id": JSON.parse(value).Id, "Name": JSON.parse(value).Name };
                        $scope.LstSelectedMFISchemes.push(item)
                    });

                    if ($scope.ShowType == "New Stocks") {
                        //$scope.LstNewStocks = [];
                        //$scope.LstCompanyName = [];
                        //$scope.SelectedStockOptios = "NewStocks";
                        //$scope.LoaderNewEntryExitTable = true;
                        $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "NEWENTRYEXIT" });
                        CollapseSelCriteria();
                        var entryExitParam = { "LstScheme": $scope.LstSelectedMFISchemes, "PortfolioDate": $scope.EntryExitPortfolioDate, "SelectedStockOptios": "NewStocks", "IsBoth": false };
                        var getData = GetEntryExitReportDataAdvance.Call(entryExitParam);
                        getData.then(function (response) {
                            //$scope.LoaderNewEntryExitTable = false;
                            if ($scope.setfromNewentryExitDirective != undefined) {
                                $scope.setfromNewentryExitDirective({ NewEntryExitDetails: response.data, ShowType: "New Stocks", EntryExitPortfolioDate: $scope.EntryExitPortfolioDate });
                            }
                            //if (response.data != null) {
                            //    $scope.LstCompanyName = response.data.data[0].CompanyName;
                            //    $scope.LstNewStocks = response.data.data;
                            //    $scope.ShowNewStocks = true;
                            //    $scope.ShowStocksExited = false;
                            //    $scope.ShowReportTable = true;
                            //    $("#newStock").addClass("active");
                            //    $("#stocksExited").addClass("");
                            //    $("#tab_NewStocks").addClass("tab-pane fade active in");
                            //    $("#tab_StocksExited").addClass("tab-pane fade");
                            //    $scope.ShowExportIcon = true;
                            //    $scope.SetNewStocksHeaderData();
                            //}
                            //else {
                            //    $scope.ShowNewStocks = false;
                            //    $scope.ShowStocksExited = false;
                            //    $scope.ShowExportIcon = false;
                            //    $scope.ShowReportTable = false;
                            //    MFIMsg.AlertHtml("Data not found against selected scheme", MFIAlertType.Information, "OK");
                            //}
                        },
                            function (stu) {
                                //$scope.LoaderNewEntryExitTable = false;
                                MFIMsg.AlertHtml("Error in fetched data.", MFIAlertType.Error, "OK");
                            });
                    }

                    if ($scope.ShowType == "Stocks Exited") {
                      
                        $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "NEWENTRYEXIT" });
                        CollapseSelCriteria();
                        var entryExitParam = { "LstScheme": $scope.LstSelectedMFISchemes, "PortfolioDate": $scope.EntryExitPortfolioDate, "SelectedStockOptios": "StocksExited", "IsBoth": false };
                        var getData = GetEntryExitReportDataAdvance.Call(entryExitParam);
                        getData.then(function (response) {
                            //$scope.LoaderNewEntryExitTable = false;
                            if ($scope.setfromNewentryExitDirective != undefined) {
                                $scope.setfromNewentryExitDirective({ NewEntryExitDetails: response.data, ShowType: "Stocks Exited", EntryExitPortfolioDate: $scope.EntryExitPortfolioDate });
                            }
                           
                        },
                            function (stu) {
                                //$scope.LoaderNewEntryExitTable = false;
                                MFIMsg.AlertHtml("Error in fetched data.", MFIAlertType.Error, "OK");
                            });
                    }

                    if ($scope.ShowType == "Both") {
                        //$scope.LstNewStocks = [];
                        //$scope.LstStocksExited = [];
                        //$scope.LstStocksExitedCompanyName = [];
                        //$scope.LstCompanyName = [];
                        //$scope.ShowExportIcon = true;
                        //$scope.ShowNewStocks = true;
                        //$scope.ShowStocksExited = true;
                        //$scope.ShowReportTable = true;
                        //$("#newStock").addClass("active");
                        //$("#stocksExited").removeClass("active");
                        //$("#stocksExited").addClass("");
                        //$("#tab_NewStocks").addClass("tab-pane fade active in");
                        //$("#tab_StocksExited").removeClass("tab-pane fade active in");
                        //$("#tab_StocksExited").addClass("tab-pane fade");
                        //$scope.SelectedStockOptios = "Both";
                        //$scope.LoaderNewEntryExitTable = true;
                        $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "NEWENTRYEXIT" });
                        CollapseSelCriteria();
                        var entryExitParam = { "LstScheme": $scope.LstSelectedMFISchemes, "PortfolioDate": $scope.EntryExitPortfolioDate, "SelectedStockOptios": "NewStocks", "IsBoth": true };
                        var getData = GetEntryExitReportDataAdvance.Call(entryExitParam);
                        getData.then(function (response) {
                            //$scope.LoaderNewEntryExitTable = false;
                            if ($scope.setfromNewentryExitDirective != undefined) {
                                $scope.setfromNewentryExitDirective({ NewEntryExitDetails: response.data, ShowType: "BothNewStocks", EntryExitPortfolioDate: $scope.EntryExitPortfolioDate });
                            }
                            //if (response.data != null) {
                            //    $scope.LstCompanyName = response.data.data[0].CompanyName;
                            //    $scope.LstNewStocks = response.data.data;
                            //    $scope.SetNewStocksHeaderData();
                            //}
                            //else
                            //    $scope.ShowNewStocks = false;
                            $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "NEWENTRYEXIT" });
                            var entryExitParam = { "LstScheme": $scope.LstSelectedMFISchemes, "PortfolioDate": $scope.EntryExitPortfolioDate, "SelectedStockOptios": "StocksExited", "IsBoth": true };
                            var getData = GetEntryExitReportDataAdvance.Call(entryExitParam);
                            getData.then(function (response) {
                                if ($scope.setfromNewentryExitDirective != undefined) {
                                    $scope.setfromNewentryExitDirective({ NewEntryExitDetails: response.data, ShowType: "BothStocksExited", EntryExitPortfolioDate: $scope.EntryExitPortfolioDate });
                                }
                                //if (response.data != null) {
                                //    $scope.LstStocksExitedCompanyName = response.data.data[0].CompanyName;
                                //    $scope.LstStocksExited = response.data.data;
                                //    $scope.SetStocksExitedHeaderData();
                                //}
                                //else {
                                //    $scope.ShowStocksExited = false;
                                //    if ($scope.LstNewStocks.length == 0) {
                                //        $scope.ShowReportTable = false;
                                //        $scope.ShowExportIcon = false;
                                //        MFIMsg.AlertHtml("No data found.", MFIAlertType.Information, "OK");
                                //    }

                                //}
                                //if ($scope.ShowNewStocks == false && $scope.ShowStocksExited == true) {
                                //    $("#newStock").removeClass("active");
                                //    $("#newStock").addClass("");
                                //    $("#stocksExited").removeClass("");
                                //    $("#stocksExited").addClass("active");
                                //    $("#tab_NewStocks").addClass("tab-pane fade active in");
                                //    $("#tab_StocksExited").removeClass("tab-pane fade");
                                //    $("#tab_StocksExited").addClass("tab-pane fade active in");
                                //}

                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Error in fetched data.", MFIAlertType.Error, "OK");
                                });
                        },
                            function (stu) {
                                //$scope.LoaderNewEntryExitTable = false;
                                MFIMsg.AlertHtml("Error in fetched data.", MFIAlertType.Error, "OK");
                            });
                        
                    }
                }

                //$scope.SetNewStocksHeaderData = function () {
                //    $scope.LstNewStocksTableHeader = [];
                //    angular.forEach($scope.LstCompanyName, function (value) {
                //        $scope.LstNewStocksTableHeader = $scope.LstNewStocksTableHeader.concat($scope.LstTableHeaderName);
                //    });
                //}

                //$scope.SetStocksExitedHeaderData = function () {
                //    $scope.LstStocksExitedTableHeader = [];
                //    angular.forEach($scope.LstStocksExitedCompanyName, function (value) {
                //        $scope.LstStocksExitedTableHeader = $scope.LstStocksExitedTableHeader.concat($scope.LstTableHeaderName);
                //    });
                //}

                $scope.Reset = function () {
                    $window.location.reload();
                }

                //$scope.EntryExitReportExportToExcel = function () {

                //    if ($scope.SelectedStockOptios == "Both")
                //        window.open("/NewEntryExit/ExportToExcelBoth?porfolioDate=" + $scope.EntryExitPortfolioDate);
                //    else
                //        window.open("/NewEntryExit/ExportToExcel?porfolioDate=" + $scope.EntryExitPortfolioDate);

                //}
            }
        };
    }]);