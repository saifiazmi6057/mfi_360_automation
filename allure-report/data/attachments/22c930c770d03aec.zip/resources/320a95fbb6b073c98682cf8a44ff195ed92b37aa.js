//var ServiceSchemePerformance = angular.module('ServiceSchemePerformance', []);

//ServiceSchemePerformance.config(BaseServiceConfig);

SharedServices.service('GetUserSelectedSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchUserSelectedSchemes',
            //transformRequest: function (obj) {
            //    var str = [];
            //    for (var p in obj)
            //        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //    return str.join("&");
            //},
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetMyWatchListSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchMyWatchListSelectedSchemes',
            //transformRequest: function (obj) {
            //    var str = [];
            //    for (var p in obj)
            //        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //    return str.join("&");
            //},
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            // data: obj,
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetAllLoginName', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchAllLoginName',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            dataType: "json"
        });
    }

}]);


SharedServices.service('GetUserSetExistStatus', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchUserSetExistStatus',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
        });
    }

}]);

SharedServices.service('TransferUserSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/TransferUserSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
        });
    }

}]);

SharedServices.service('GetBSEInvestorListBySearch', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiBackOfficeAdmin/GetBSEInvestorListBySearch',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('SearchFamilyByLoginID', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiTrackerCommonMaster/SearchFamilyByLoginID',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetRequriedSchemeCodesByFamilyInvestor', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiInvestorPortfolio/FetchRequriedSchemeCodesByFamilyInvestor',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetMyInvestorsSelectedSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchMyInvestorsSelectedSchemes',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetAllCustomIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllCustomIndex',
            //params: obj
        });
    }

}]);
SharedServices.service('GetProductModuleInfoByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetProductModuleInfoByLoginId',
            //params: obj
        });
    }

}]);
SharedServices.service('GetAllMFIIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        if (angular.isUndefinedOrNullOrEmpty(obj)) {
            obj = { isDiscardRestrictedIndex: true };
        }
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllMFIIndex',
            params: obj
        });
    }

}]);
SharedServices.service('GetAllCompositeIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllCompositeIndex',
            //params: obj
        });
    }

}]);
SharedServices.service('GetUserSetByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    //this.Call = function (obj) {
    this.Call = function () {

        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetUserSetByLoginId',
            //params: obj
        });
    }

}]);

SharedServices.service('GetUserSetByLoginIdAssign', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    //this.Call = function (obj) {
    this.Call = function (obj) {

        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetUserSetByLoginIdAssign?LoginID=' + obj,
            params: obj
        });
    }

}]);

SharedServices.service('GetAllP2PPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllP2PPeriod',
            //params: obj
        });
    }
}]);
SharedServices.service('GetOtherCriteriaList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetOtherCriteriaList'
        });
    }
}]);
SharedServices.service('GetReturnSettingByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetReturnSettingByLoginId',
            //params: obj
        });
    }
}]);
SharedServices.service('GetUserParameterSetByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetUserParameterSetByLoginId',
            params: obj
        });
    }
}]);
SharedServices.service('GetDefaultUserParameterSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetDefaultUserParameterSet',
            params: obj
        });
    }
}]);
SharedServices.service('GetAllFixedPeriodicList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllFixedPeriodicList'
        });
    }
}]);


SharedServices.service('PeriodOfNewsLetter', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/PeriodOfNewsLetter',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetWAUserData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ReportDate, Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetWAUserData?ReportDate=' + ReportDate + '&Id=' + Id,
        });
    }
}]);

SharedServices.service('GetWANavDataByCommodityID', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ReportDate, Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetWANavDataByCommodityID?ReportDate=' + ReportDate + '&Id=' + Id,
        });
    }
}]);

SharedServices.service('GetWANavDataByCurrencyID', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ReportDate, Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetWANavDataByCurrencyID?ReportDate=' + ReportDate + '&Id=' + Id,
        });
    }
}]);

SharedServices.service('GetWAUserDashboardDetailsData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ReportDate, Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetWAUserDashboardDetailsData?ReportDate=' + ReportDate + '&Id=' + Id,
        });
    }
}]);
SharedServices.service('GetMaxReportId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetMaxReportId'
        });
    }
}]);
SharedServices.service('GetWAIndexReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ReportDate,Id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetWAIndexReturn?ReportDate=' + ReportDate +'&Id=' + Id,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetLogoByClientId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Mid) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnonymous/GetLogoByClientId?MatchId='+Mid,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetPerformanceReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var url = IsService == true ? 'ShowPerfomanceRollingReturnService' : 'ShowPerfomanceReturn';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/' + url,
            //transformRequest: function (obj) {
            //    var str = [];
            //    for (var p in obj)
            //        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //    return str.join("&");
            //},
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('FilterPerformanceReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var url = 'FilterPerformanceData';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/' + url,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetPerformanceReturnAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var url = IsService == true ? 'ShowPerfomanceRollingReturnServiceAdvance' : 'ShowPerfomanceReturnAdvance';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/' + url,
            //transformRequest: function (obj) {
            //    var str = [];
            //    for (var p in obj)
            //        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //    return str.join("&");
            //},
            //headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            headers: { 'Content-Type': undefined },
            //data: $.param(obj),
            data: obj,
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetReturnSortResult', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: '/SchemePerformance/ShowReturnSortResult',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetReturnSortResultAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: '/SchemePerformance/ShowReturnSortResultAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetPerformanceReturnService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowPerfomanceRollingReturnOutputForService',//ShowPerfomanceRollingReturnOutput',
            //transformRequest: function (obj) {
            //    var str = [];
            //    for (var p in obj)
            //        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            //    return str.join("&");
            //},
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetStatisticalRatioFromService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowStatisticalRatioOutputForService',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetSEBIReportSchemeIndexMap', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/FetchSEBIReportSchemeIndexMap',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('MapSebiSchemeIndexMap', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/MapSebiSchemeIndex',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('UnMapSebiSchemeIndexMap', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/UnMapSebiSchemeIndex',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetSebiPerformanceReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowSebiPerfomanceReturn',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetSebiPerformanceReturnForFundManager', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowSebiPerfomanceReturnForFundManager',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetAllRatios', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllRatioList'
        });
    }
}]);
SharedServices.service('GetAmfiLastDayOfMonth', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAmfiLastDayOfMonth',
            params: obj
        });
    }
}]);
SharedServices.service('GetCurrentIndexValue', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetCurrentIndexValue',
            params: obj
        });
    }
}]);
SharedServices.service('GetStatisticalRatioReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var url = IsService == true ? 'ShowStatisticalRatioReturnService' : 'ShowStatisticalRatioReturn';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/' + url,//ShowStatisticalRatioReturn',
            headers: IsService == true ? { 'Content-Type': undefined } : { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: IsService == true ? obj : $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetRiskReturnMatrixReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowRiskReturnMatrixReturn',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('SaveUserParameterSetByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/SaveUserParameterSetByLoginId',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('RemoveUserParameterSetById', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/RemoveUserParameterSetById',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('SchemesAndSetDetailsByUserSetId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/SchemesDetailsAndSetByUserSchemeSetId',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetReturnSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/GetReturnSet',
        });
    }
}]);

SharedServices.service('InsertDateRangeSettingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/InsertDateRangeSettingSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('FetchDateRangeSettingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/FetchDateRangeSettingSet',
        });
    }
}]);

SharedServices.service('AddParameterSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/AddParameterSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('FetchParameterSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/FetchParameterSet',
        });
    }
}]);

SharedServices.service('GenerateExcelReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/GenerateExcelReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('EditDateRangeSettingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/EditDateRangeSettingSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json",
        });
    }
}]);

SharedServices.service('DeleteDateRangeSettingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/DeleteDateRangeSettingSet?Id=' +obj,
        });
    }
}]);

SharedServices.service('ReturnTriIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, isService) {
        var url = isService == true ? 'FetchReturnTriIndexService' : 'ReturnTriIndex';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/' + url,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('DeleteParameterSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReturn/DeleteParameterSet?Id=' + obj,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('GetRedeemedSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetRedeemedSchemes',
        });
    }
}]);

SharedServices.service('ShowReturnTRIOutputForService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/ShowReturnTRIOutputForService',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);