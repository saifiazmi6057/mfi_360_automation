/* applicable for barGp, bar, barclick *****
 * data [{name : '', color: '', data: [9, 30, 3]}] **** xcategoriey = ["test1","test2"]  / [["test1"],["test2"],[]] *** charttype = 'bar' / 'column'
 */
SharedDeractives.directive("barGraph", ['$parse', '$rootScope', function ($parse, $rootScope) {
    return {
        restrict: 'E',
        template: '<div></div>',
        scope: {
            charttitle: '=',
            titlechartstyle: '=',
            subtitle: '=',
            subtitlechartstyle: '=',
            xcategoriey: '=',
            xtextprimary: '=',
            yxchartstyle: '=',
            xtextsecondary: '=',
            ytextprimary: '=',
            specialprop: '=',
            islegend: '=',
            legendstyle: '=',
            isexport: '=',
            credittext: '=',
            creditlink: '=',
            dataplot: '=',
            minvalue: '=',
            isrequiredtooltip: '=',
            bgcolor: '=',
            charttype: '=',
            tooltipdecimalpoint: '='

        },
        link: function (scope, element, attribute) {
            var drawChart = function(){
                //console.log("draw chart", scope.tooltipdecimalpoint );
                var dataTmp = angular.copy(scope.dataplot);
                var tooltipDecimalPoint = scope.tooltipdecimalpoint;
            new Highcharts.chart(element[0], {
                chart: {
                    type: scope.charttype ? scope.charttype : 'bar',//column
                    backgroundColor: scope.bgcolor ? scope.bgcolor :'rgba(255, 255, 255, 0.0)'
                },
                annotationsOptions: {
                    enabledButtons: false
                },
                title: {
                    text: scope.charttitle ? scope.charttitle : '',
                    style: {
                        fontSize: scope.titlechartstyle && scope.titlechartstyle.fontSize ? scope.titlechartstyle.fontSize : "25px",
                        fontFamily: scope.titlechartstyle && scope.titlechartstyle.fontFamily ? scope.titlechartstyle.fontFamily : "latoregular",
                        color: scope.titlechartstyle && scope.titlechartstyle.color ? scope.titlechartstyle.color : "blue",
                        fontWeight: scope.titlechartstyle && scope.titlechartstyle.fontWeight ? scope.titlechartstyle.fontWeight : "Normal"
                    }
                },
                subtitle: {
                    text: scope.subtitle ? scope.subtitle : "",
                    style: {
                        fontSize: scope.subtitlechartstyle && scope.subtitlechartstyle.fontSize ? scope.subtitlechartstyle.fontSize: "12px",
                        fontFamily: scope.subtitlechartstyle && scope.subtitlechartstyle.fontFamily ? scope.subtitlechartstyle.fontFamily : "latoregular",
                        color: scope.subtitlechartstyle && scope.subtitlechartstyle.color ? scope.subtitlechartstyle.color : "pink",
                        fontWeight: scope.subtitlechartstyle && scope.subtitlechartstyle.fontWeight ? scope.subtitlechartstyle.fontWeight : "lighter"
                    }
                },
                xAxis: [{ //--- Primary yAxis
                    categories: scope.xcategoriey? scope.xcategoriey : [],
                    title: {
                        text: scope.xtextPrimary ? scope.xtextPrimary: "",
                        style: {
                            fontSize: scope.yxchartstyle && scope.yxchartstyle.fontSize ? scope.yxchartstyle.fontSize : "13px",
                            fontFamily: scope.yxchartstyle && scope.yxchartstyle.fontFamily ? scope.yxchartstyle.fontFamily : "latoregular",
                            color: scope.yxchartstyle &&  scope.yxchartstyle.color ? scope.yxchartstyle.color : "black",
                            fontWeight: scope.yxchartstyle && scope.yxchartstyle.fontWeight ? scope.yxchartstyle.fontWeight : "Normal"
                        }
                    }
                }, { //--- Secondary yAxis
                    title: {
                        text: scope.xtextsecondary ? scope.xtextsecondary: "",
                        style: {
                            fontSize: scope.yxchartstyle && scope.yxchartstyle.fontSize ? scope.yxchartstyle.fontSize :"13px",
                            fontFamily: scope.yxchartstyle && scope.yxchartstyle.fontFamily ? scope.yxchartstyle.fontFamily :"latoregular",
                            color: scope.yxchartstyle && scope.yxchartstyle.color ? scope.yxchartstyle.color : "black",
                            fontWeight: scope.yxchartstyle && scope.yxchartstyle.fontWeight ? scope.yxchartstyle.fontWeight : "Normal"
                        }
                    },
                    opposite: true
                }],
                yAxis: {
                    min: scope.minvalue ? scope.minvalue : 0,
                    title: {
                        text: scope.ytextprimary ? scope.ytextprimary: "",
                        align: 'middle',//high
                        style: {
                            fontSize: scope.yxchartstyle && scope.yxchartstyle.fontSize ? scope.yxchartstyle.fontSize : "13px",
                            fontFamily: scope.yxchartstyle && scope.yxchartstyle.fontFamily ? scope.yxchartstyle.fontFamily : "latoregular",
                            color: scope.yxchartstyle && scope.yxchartstyle.color ? scope.yxchartstyle.color : "black",
                            fontWeight: scope.yxchartstyle && scope.yxchartstyle.fontWeight ? scope.yxchartstyle.fontWeight : "Normal"
                        }

                    },
                    labels: {
                        style: {
                            color: scope.specialprop && scope.specialprop.Xlablecolor ? scope.specialprop.Xlablecolor : '',

                        }
                        //  overflow: 'justify'
                    }
                },
                tooltip: {
                    enabled: scope.isrequiredtooltip == 'false' ? false : true,
                    pointFormat: '{series.name}: <b>{point.y:.' + tooltipDecimalPoint + 'f}</b>'
                    //pointFormat: '<b>{point.y:.' + tooltipDecimalPoint + 'f}</b>'
                    //pointFormat: '<b>{point.x},{point.y:.' + tooltipDecimalPoint + 'f}</b>'
                    //headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    //pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    //    '<td style="padding:0"><b>{point.y:.'+tooltipDecimalPoint+'f}</b></td></tr>',
                    //footerFormat: '</table>',
                    //shared: true,
                    //useHTML: true
                    //valueSuffix: ' millions'

                },
                plotOptions: {
                    series: {
                        maxPointWidth: scope.specialprop && scope.specialprop.maxPointWidth ? scope.specialprop.maxPointWidth : "45",
                        events: {
                            click: function (event) {
                                if (scope.specialprop && (scope.specialprop.FundName == "MultiplePortfolioSectorFilter")) {
                                    $rootScope.$broadcast("barClickedOnMultiplePortfolioSectorFilter",event.point.category);
                                    //FNSectorFilter(event.point.category);
                                }
                            }
                        }
                    },
                    bar: {
                        dataLabels: {
                            // enabled: false
                        }
                    },
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },
                legend: {
                    enabled: scope.islegend ? scope.islegend: "",
                    align: scope.legendstyle && scope.legendstyle.align ? scope.legendstyle.align : "center",
                    verticalAlign: scope.legendstyle && scope.legendstyle.verticalAlign ? scope.legendstyle.verticalAlign : "bottom",
                    layout: scope.legendstyle && scope.legendstyle.layout ? scope.legendstyle.layout : "horizontal",//vertical
                    //x: -40,
                    //y: 80,
                    itemStyle: {
                        fontSize: scope.legendstyle && scope.legendstyle.fontSize ? scope.legendstyle.fontSize: "13px",
                        fontFamily: scope.legendstyle && scope.legendstyle.fontFamily ? scope.legendstyle.fontFamily : "latoregular",
                        color: scope.legendstyle && scope.legendstyle.color ? scope.legendstyle.color : "green",
                        fontWeight: scope.legendstyle && scope.legendstyle.fontWeight ? scope.legendstyle.fontWeight : "bold",
                    }
                },
                //navigation: {
                //    buttonOptions: {
                //        verticalAlign: 'top',
                //        y: -10,
                //        x: 10
                //    }
                //},
                exporting: {
                    enabled: scope.isexport ? scope.isexport: ""
                },
                credits: {
                    enabled: true,
                    text: scope.credittext ? scope.credittext: "",
                    href: scope.creditlink ? scope.creditlink: ""
                },
                series: dataTmp // format [{name:'',data:[], color:""}]
            });
}
            scope.$watch("dataplot", function (newValue) {
                //console.log("draw required");
                if(scope.dataplot && scope.dataplot.length > 0){
                    drawChart();
                }
                //chart.series[0].setData(newValue, true);
            }, true);
        }
    }
}]);