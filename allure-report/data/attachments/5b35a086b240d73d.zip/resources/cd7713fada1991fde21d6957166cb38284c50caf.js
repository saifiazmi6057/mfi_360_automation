SharedDeractives.directive('rzRangeSlider', ['$http', '$q', '$timeout', 'MFIMsg',
    function ($http, $q, $timeout, MFIMsg) {
        return {
            restrict: 'AE',
            scope: {
                min: '=',
                max: '=',
                options: '=',
                broadCast: '=?'
            },
            templateUrl: '/Home/RangeSliderTemplate',
            link: function ($scope, $element, $attrs) {
                $scope.broadCast = function () {
                   // alert("work");
                    setTimeout(function () {
                        $scope.$broadcast('rzSliderForceRender');
                    }, 500);
                };

                $scope.PrevFrmText = "";
                $scope.PrevToText = "";
                $scope.sliderInputActiveStatus = false;

                $scope.RangeClick = function () {
                    if (!$scope.sliderInputActiveStatus)
                    if ($(event.target).attr("class") == "rz-bubble rz-model-value" || $(event.target).attr("class") == "rz-bubble rz-model-high") {
                        AddSliderTest();
                        $scope.sliderInputActiveStatus = true;
                    }
                };

                function AddSliderTest() {
                    $scope.PrevFrmText = "";
                    $scope.PrevToText = "";

                    var FrmSpn = $(event.target).parent().find('.rz-model-value');
                    var ToSpn = $(event.target).parent().find('.rz-model-high');

                    SetControll(FrmSpn, ToSpn, true, "", 23);
                    SetControll(FrmSpn, ToSpn, false, "", 23);
                }

                function SetControll(spnFrm, spnTo, IsFrm, ParentId, len) {
                    var spn = IsFrm ? spnFrm : spnTo;
                    var txtCl = IsFrm ? 'rz-bubble rz-model-value' : 'rz-bubble rz-model-high';
                    var stl = spn.attr("style") +
                        "width:50px;height: 20px;box-sizing: border-box;border: 1px solid #ccc;border-radius: 4px; background-color: #f8f8f8;" +
                        "position: absolute;display: inline - block;white - space: nowrap;";
                    var $lbl = spn, o = $lbl.text(),
                        $txt = $('<input type="text" value="' + o + '" class="' + txtCl + '" style="' + stl + '" />');

                    if (IsFrm)
                        $scope.PrevFrmText = $lbl.text();
                    else
                        $scope.PrevToText = $lbl.text();

                    $lbl.replaceWith($txt);
                    $txt.focus();
                    $txt.blur(function () {

                        //var frmValTxt = $(this).parent().find('.rz-model-value');
                        //var ToValTxt = $(this).parent().find('.rz-model-high');

                        //spnFrm.text($scope.PrevFrmText);
                        //frmValTxt.replaceWith(spnFrm);

                        //spnTo.text($scope.PrevToText);
                        //ToValTxt.replaceWith(spnTo);

                        //$txt.replaceWith($lbl);
                        //var scope = angular.element(document.getElementById('DvYtm')).scope();
                        //scope.FNSetYtmRange(parseInt($txt.val()), 5);
                    }).keydown(function (evt) {
                        if (evt.keyCode == 13) {
                            $scope.sliderInputActiveStatus = false;
                            var frmValTxt = $(this).parent().find('.rz-model-value');
                            var ToValTxt = $(this).parent().find('.rz-model-high');

                            spnFrm.text(parseFloat(frmValTxt.val()));
                            frmValTxt.replaceWith(spnFrm);

                            spnTo.text(parseFloat(ToValTxt.val()));
                            ToValTxt.replaceWith(spnTo);

                            $scope.min = parseFloat(frmValTxt.val());
                            $scope.max = parseFloat(ToValTxt.val());
                            $scope.$broadcast('rzSliderForceRender');
                        }
                    });
                }
            }
        };
    }]);