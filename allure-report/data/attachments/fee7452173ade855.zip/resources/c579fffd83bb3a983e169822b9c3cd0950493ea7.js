//var FilterFundmanager = angular.module('FilterFundmanager', []);

SharedCommon.filter('FMbasicSerchFilter', function ($filter)
{
    return function (items, Fmids) {
     
        var filtered = [];
        if (Fmids.length>0)
        {
           // debugger;
           // filtered = $filter('filter')(items, { SectorName: scope });

            angular.forEach(Fmids, function (id)
            {
                angular.forEach(items, function (itm)
                {
                    if (itm.Data.FundManagerId == id)
                    {
                        filtered.push(itm);

                    }
                }); 
            });   

        }
        else
        {
            filtered = items;
        }
      //  debugger;
        return filtered;
    };
});



SharedCommon.filter('FMadvanceSerchFilter', function ($filter) {
    return function (items, searchparam) {

     //   debugger;
        var filteredamc = [];
        var filterednature = [];
        var filteredSubnature = [];
        var filteredfund = [];

        var filteredexp = [];
        var filteredCorpus = [];
        var filteredAverageMaturity = [];
        var filteredPTRatio = [];
        var filteredModifiedDuration = [];
        var filteredSharp = [];
        var filteredTreynor = [];
        var filteredSortino = [];
        var filteredAlpha = [];
        

        if (searchparam.allAMC.length > 0)
        {
            filteredamc = SearchAMC(items, searchparam.allAMC);
        }
        else
        {
            filteredamc = items;
        }
        if (searchparam.NatureID != null)
        {
            filterednature = SearchNature(filteredamc, searchparam.NatureID);
        }
        else
        {
            filterednature = filteredamc;
        }
        if (searchparam.SubNatureID != null)
        {
            filteredSubnature = SearchSubNature(filterednature, searchparam.SubNatureID);
        }
        else
        {
            filteredSubnature = filterednature;
        }
        if (searchparam.allFund.length > 0)
        {
            filteredfund = SearchFund(filteredSubnature, searchparam.allFund);
        }
        else
        {
            filteredfund = filteredSubnature;
        }

        filteredexp = SearchExp(filteredfund, searchparam.Minexp, searchparam.Maxexp);

        filteredCorpus = SearchCorpus(filteredexp, searchparam.Mincorpus, searchparam.Maxcorpus);

        filteredAverageMaturity = SearchAverageMaturity(filteredCorpus, searchparam.MinavgMaturity, searchparam.MaxavgMaturity);

        filteredPTRatio = SearchPTRatio(filteredAverageMaturity, searchparam.Minptr, searchparam.Maxptr);

        filteredModifiedDuration = SearchModifiedDuration(filteredPTRatio, searchparam.Minmd, searchparam.Maxmd);

        filteredSharp = SearchSharp(filteredModifiedDuration, searchparam.Minsharp, searchparam.Maxsharp);

        filteredTreynor = SearchTreynor(filteredSharp, searchparam.Mintreynor, searchparam.Maxtreynor);

        filteredSortino = SearchSortino(filteredTreynor, searchparam.Minsortino, searchparam.Maxsortino);

        filteredAlpha = SearchAlpha(filteredSortino, searchparam.Minalpha, searchparam.Maxalpha);                          

        return filteredAlpha;
    };
});


function SearchAMC(items, AMCids)
{//debugger;
    var filtered = [];

    angular.forEach(AMCids, function (id)
    {
        angular.forEach(items, function (itm)
        {
            if (itm.FMSearchItems[0].AMCId == id) {
                filtered.push(itm);

            }
        });
    });   

    return filtered;

}

function SearchNature(items, Natureid) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm)
    {
        angular.forEach(itm.FMSearchItems, function (natureitm) {
            if (natureitm.NatureId == Natureid && c==0)
            {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;

}

function SearchSubNature(items, SubNatureid) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (subnatureitm) {
            if (subnatureitm.SubNatureId == SubNatureid && c == 0)
            {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;

}

function SearchFund(items, Fundids) {
    var filtered = [];
    var c = 0;
    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (objDetails) {
            if (Fundids.indexOf(objDetails.FundId) != -1 && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });
    return filtered;

}

function SearchExp(items,mindata,maxdata)
{
    var filtered = [];

    angular.forEach(items, function (itm)
    {
        if (itm.TotalExperience >= mindata && itm.TotalExperience <= maxdata)
        {
                filtered.push(itm);
              
         }
    });

    return filtered;

}

//function SearchCorpus(items, mindata, maxdata)
//{
//    var filtered = [];
//    var c = 0;

//    angular.forEach(items, function (itm) {
//        angular.forEach(itm.FMSearchItems, function (flt) {
//            if (flt.Corpus >= mindata && flt.Corpus <= maxdata && c == 0) {
//                filtered.push(itm);
//                c = c + 1;
//            }
//        });
//        c = 0;
//    });

//    return filtered;
//}
function SearchCorpus(items, mindata, maxdata) {
    var filtered = [];
   
    angular.forEach(items, function (itm) {
        
        if (itm.TotalCorpusManaged >= mindata && itm.TotalCorpusManaged <= maxdata)  {
                filtered.push(itm);
              
            }    
        
    });

    return filtered;
}


function SearchAverageMaturity(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.AverageMaturity >= mindata && flt.AverageMaturity <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}

function SearchPTRatio(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.PTRatio >= mindata && flt.PTRatio <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}


function SearchModifiedDuration(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.ModifiedDuration >= mindata && flt.ModifiedDuration <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}


function SearchSharp(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.Sharp >= mindata && flt.Sharp <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}


function SearchTreynor(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.Treynor >= mindata && flt.Treynor <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}

function SearchSortino(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.Sortino >= mindata && flt.Sortino <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}

function SearchAlpha(items, mindata, maxdata) {
    var filtered = [];
    var c = 0;

    angular.forEach(items, function (itm) {
        angular.forEach(itm.FMSearchItems, function (flt) {
            if (flt.Alpha >= mindata && flt.Alpha <= maxdata && c == 0) {
                filtered.push(itm);
                c = c + 1;
            }
        });
        c = 0;
    });

    return filtered;
}




SharedCommon.filter('FMAssetsAllocationFilter', function ($filter) {
    return function (items,level,id) {
       // debugger;
        var filtered = [];
        if (id != null)
        {
            if (level == 0)
            {
                filtered = $filter('filter')(items, { NatureID: parseInt(id )},true);
            }
            if (level == 1) {
                filtered = $filter('filter')(items, { InstrumentID: parseInt(id) },true);
            }
         
        }
        else
        {
            filtered = items;
        }
        
        return filtered;
    };
});



SharedCommon.filter('FMRatingFilter', function ($filter) {
    return function (items, level, id) {
       //  debugger;
        var filtered = [];
        if (id != null) {
            if (level == 0) {
                filtered = $filter('filter')(items, { RatingSubSetID: parseInt( id )}, true);
            }
            if (level == 1) {
                filtered = $filter('filter')(items, { RatingID: parseInt(id) },true);
            }

        }
        else {
            filtered = items;
        }

        return filtered;
    };
});



SharedCommon.filter('FMSectorFilter', function ($filter) {
    return function (items, level, id) {
        // debugger;
        var filtered = [];
        if (id != null)
        {
            filtered = $filter('filter')(items, { SectorName: id },true);

        }
        else {
            filtered = items;
        }

        return filtered;
    };
});