SharedServices.service('GetDashboardDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/GetUserDashboardDetailsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
     }
}]);

SharedServices.service('SaveUserDashboardData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/SaveUserDashboardData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('UserDashboardSingleDetailsData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/UserDashboardSingleDetailsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('FundPerformaneDetailsData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/FundPerformaneDetailsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('UserDashboardTopPrfrmngFilterdata', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/UserDashboardTopPrfrmngFilterdata',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('UserDashboardFiterData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/UserDashboardFiterData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetDefaultSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFetchUserBasicSettings',
            method: 'GET'
        });
    }

}]);

SharedServices.service('FetchKeyword', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiCommonData/FetchPageKeywordMFI',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('FetchMetaData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiCommonData/FetchPageMetaDataMFI',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


// -- added pdf download service
SharedServices.service('ExportToPDFExist', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/ExportToPDFExist',
            method: 'POST',
            data: $.param(obj)

        });
    }
}]);
// -- added pdf download service