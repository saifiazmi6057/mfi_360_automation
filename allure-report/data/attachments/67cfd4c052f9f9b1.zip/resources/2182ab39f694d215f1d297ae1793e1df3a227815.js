SharedServices.service('SearchSchemesList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiPortfolioScanner/SearchSchemesList',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetSchemesDetailsList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetSchemesDetailsList',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetAdvisorInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetAdvisorInfo',
            //data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetSchemeListBysearchTxt', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // console.log("ckjkkhkjh")
    this.Call = function (Str) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetSchemeListBysearchTxt?StrScheme=' + Str,
            method: 'GET'
        });
    }
}]);

//// Get Fund /////////////////////////////////////////////////////////////////////
SharedServices.service('GetFundListFromPTScanner', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // debugger;
    this.Call = function (AMCId, NatureId, SubNatureId, StructureIds, MFId, FundId, OptionId, StructureID) {

        var AMCIds = [];
        var ArrStructureId = [];
        var MFIds = [];
        if (angular.isUndefinedOrNullOrEmpty(AMCId) == false) {
            AMCIds.push(AMCId);
        }
        if (angular.isUndefinedOrNullOrEmpty(StructureIds) == false) {
            //if (StructureIds != null && typeof (StructureIds) != undefined && StructureIds.length > 0) {
            ArrStructureId = StructureIds;
        }
        if (angular.isUndefinedOrNullOrEmpty(MFId) == false) {
            //if (MFId != null && typeof (MFId) != undefined) {
            //MFIds.push(MFId);
            MFIds = MFId;
        }
        var ViewFundInputEntity = {};
        //ViewFundInputEntity.AMCId = null;
        //ViewFundInputEntity.NatureId = NatureId;
        //ViewFundInputEntity.SubNatureID = SubNatureId;
        ViewFundInputEntity.NatureId = "";
        ViewFundInputEntity.NatureIDList = NatureId;
        ViewFundInputEntity.SubNatureID = "";
        ViewFundInputEntity.SubNatureIDList = SubNatureId;
        ViewFundInputEntity.StructureIds = StructureIds;
        ViewFundInputEntity.MFId = MFId;
        ViewFundInputEntity.FundId = FundId;
        ViewFundInputEntity.StructureID = 2;
        //ViewFundInputEntity.StructureID = StructureID;
        ViewFundInputEntity.OptionId = OptionId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FundList',
            data: $.param(ViewFundInputEntity),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetSearchSetListBysearchTxt', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // console.log("ckjkkhkjh")
    this.Call = function (Str) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetSearchSetListBysearchTxt?Str=' + Str,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetSchemesDetailsBySchemeId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiPortfolioScanner/GetSchemesDetailsBySchemeId',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('PTScannerExportToAllSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiPortfolioScanner/PTScannerExportToAllSchemes',
            method: 'POST',
            //data: $.param(obj)
        });
    }
}]);

SharedServices.service('saveAdvisorInfoAndSchemes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/SaveAdvisorInfoAndSchemes',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SaveSchemesWithSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/SaveSchemesWithSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('DeleteSchemesORSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/DeleteSchemesORSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('GetPSMaxPortDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSMaxPortDate',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PSSebiCurrentPortfolio', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSSebiCurrentPortfolio',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetMktCapGrph', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetMktCapGrph',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PSAssetCurrentPortfolio', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSAssetCurrentPortfolio',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('SectorCurrentPortfolio', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSSectorCurrentPortFolio',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('PSCompanyAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSCompanyAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PSConcentrationAnalysis', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSConcentrationAnalysis',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('PSCAMCAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPSAMCAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('AllApplicationSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetBasicSettingsData',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetAvgMatGrph', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetAvgMatGrph',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetMatProGrph', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetMatProGrph',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetInsAlloGrphTbl', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetInsAlloGrphTbl',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetStatCompTbl', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetStatCompTbl',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetWhatsInOutTbl', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetWhatsInOutTbl',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('ExportToPDFPTScannerReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/ExportToPDFPTScannerReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('DownloadPTScannerPDFReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: '/Analysis/DownloadPTScannerPDFReport',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetRatioGraphDataPT', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetStatisticalDataNewPTScan',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetCorrMatrix', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetCorrMatrix',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetRatProPTScanner', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetRatProPTScanner',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetProOverLapMatrix', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetProOverLapMatrix',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('SearchTrackerFamilyByLoginID', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiTrackerCommonMaster/SearchFamilyByLoginID',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SearchTrackerInvestorByFamilyID', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiTrackerCommonMaster/SearchInvestorByFamilyID',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetTrackerSchemeIdNameDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.APIMfiTrackerUrl + 'ApiTrackerCommonMaster/FetchSchemeIdNameDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetPortReturnGrph', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPortReturnGrphAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetPTScannerTopFundReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPTScannerTopFundReturnAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetPTScannerGetYearlyReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPTScannerGetYearlyReturnAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetSEBIFormatReturnPTScanner', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, LoginId) {
        //var SEBIFormatReturnParam = {};
        //SEBIFormatReturnParam.SchemeId = SchemeId;
        ////SEBIFormatReturnParam.LoginId = LoginId;
        //// SEBIFormatReturnParam.DATEF = DATEF;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetSEBIFormatReturnPTScanner',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetSearchClientListBysearchTxt', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // console.log("ckjkkhkjh")
    this.Call = function (Str) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetSearchClientListBysearchTxt?Str=' + Str,
            method: 'GET'
        });
    }
}]);

SharedServices.service('PTScannerSaveUpdClientDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/PTScannerSaveUpdClientDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('GetPageLdPdfData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Str) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPageLdPdfData?ReportGenerationUId=' + Str,
            method: 'GET'
        });
    }
}]);

SharedServices.service('SavePTScannerUploadInput', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/SavePTScannerUploadInput',
            method: 'POST',
            headers: {
                'Content-Type': undefined,
                //"RequestVerificationToken": $('#RiskReturnMatrixantiForgeryToken').val()
            },
            transformRequest: function (data, headersGetter) {
                var formData = new FormData();
                angular.forEach(data, function (value, key) {
                    formData.append(key, value);
                });
                return formData;
            },
            data: obj,
        });
    }
}]);
SharedServices.service('GetPtSchemesDetailsBySchemeId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioScanner/GetPtSchemesDetailsBySchemeId',
            data: $.param(obj)
        });
    }
}]);