
var ICRA = {
    ShowMessage: function (UICtrlFieldName) {
//        if (typeof JQuery === 'undefined') {
//        }
        $(document).ready(function () {
            if ($("#" + UICtrlFieldName).val() != "") {
                OpenAlert($("#" + UICtrlFieldName).val());
            }
        });
    }
};

//function OpenAlert(messageBody, headerText, width) {
//    //    if (height == null) {
//    //        height = 200;
//    //    }
//   // debugger;
//    var width1 = 430;
//    if (width == null) {
//        width = 400;
//    }
//    if (headerText == null) {
//        headerText = "&nbsp;";
//    }
//    var divv = "<div id='mfiMessageBox' style='position:fixed;top:30%;left:0%' class='modal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>"
//        + "<div class='modal-dialog' style='width:" + width.toString() + "px'>"
//        + "<div class='modal-content'>"
//        + "<div class='modal-header'>"
//        + "<span >" + headerText + "</label>" + "</span>" + "<button type='button' class='close' data-dismiss='modal' aria-hidden='true' style='padding-right:1px; color:#fff'>×</button>" +
//        "</div>" +
//        "<div class='modal-body'>" +
//        "<p style='margin-bottom:0px;'>" + messageBody + "</p>" +
//        "</div>" + '<div></div>' +
//        "<div class='modal-footer'>" +
//        "<button class='btn btn-danger'  data-dismiss='modal' >OK</button>" +
//        "</div>" +
//        "</div>" +
//        "</div>" +
//        "</div>";
//    $('#mfiMessageBox').remove();
//    //var modal = $('#mfiMessageBox');
//    //modal.css({"margin-top":(modal.outerHeight() / 2) * -1,'margin-left':(modal.outerWidth() / 2) * -1});
//    //modal.css('margin-left', (modal.outerWidth() / 2) * -1);
//    var modalAlert = $(divv);
//    //    modalAlert.modal({                
//    //                keyboard: true,
//    //                backdrop:false
//    //    })  
//    //======i have to register the event before modal show like following way
//    modalAlert.on('show.bs.modal', function () {
//        $('.btn').focus();
//    });

//    modalAlert.on('hidden.bs.modal', function () {
//        $(this).remove();
//    });
//    modalAlert.modal({
//        keyboard: true,
//        backdrop: false
//    });
//    //==============
//    modalAlert.draggable({
//        handle: ".modal-header1",
//        // cursor: "move"
//    });
//    modalAlert.mouseenter(function () {
//        $('.modal-header1').css('cursor', 'move');
//    });
//    return false;
//}