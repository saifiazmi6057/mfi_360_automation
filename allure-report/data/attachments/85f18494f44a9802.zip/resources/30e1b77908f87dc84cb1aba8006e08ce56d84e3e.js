SharedDeractives.directive('dirFundDashboardOthers',
    ['GetFundOthersInfo', 'GetStyleBox', 'GetDividendSchemeByFundId', 'GetDividendHist', 'GetTopFundReturnComperation', 'GetAddendum', 'GetNews', 'GetPePbDivYieldMarketcap', 'GetNewsDetails', 'MFIMsg', 'GetAvgMatYTMMacDuration',
        function (GetFundOthersInfo, GetStyleBox, GetDividendSchemeByFundId, GetDividendHist, GetTopFundReturnComperation, GetAddendum, GetNews, GetPePbDivYieldMarketcap, GetNewsDetails, MFIMsg, GetAvgMatYTMMacDuration) {
            return {
                //restrict: 'E',
                scope: { fundId: "=", schemeId: "=", loginId: "=", natureName: "=", fundType: "=", plan: "=" },
                templateUrl: function (elem, attrs) {
                    // //
                    return "/FundDashboard/GetOthersHTML";
                },
                controller: function ($scope, $http) {
                    //
                    $scope.FundOthersInfo = "";
                    $scope.isPagedataExist = false;
                    $scope.NewsDetails = "";
                    $scope.FDOthers = {};
                    $scope.FDOthers.InfoLoader = true;
                    $scope.FDOthers.FundComperisonLoader = true;
                    $scope.FDOthers.DividendHistoryLoader = true;
                    $scope.FDOthers.FundNewsLoader = true;
                    $scope.FDOthers.AddendumsLoader = true;
                    $scope.AvgMatYTMValData = {};

                    $scope.FDOthers.PEPBRatioIsComplite = false;
                    $scope.FDOthers.StyleBoxIsComplite = false;
                    $scope.FDOthers.OthersInfoIsComplite = false;
                    $scope.FDOthers.StyleBoxXAxisText = "";
                    $scope.FDOthers.StyleBoxYAxisImage = "";

                    $scope.FDOthers.IsDividendExist = true;
                    $scope.DividendHistorySchemeId = "";
                    $scope.ShowMoreDividendHistory = false;

                    var portfolioDate = null;

                    if ($scope.fundId != 0) {

                        var AvgMatYTMVal = GetAvgMatYTMMacDuration.Call($scope.fundId);
                        AvgMatYTMVal.then(function (response) {
                            if (!angular.isUndefinedOrNullOrEmpty(response.data.data)) {
                                $scope.AvgMatYTMValData = response.data.data;
                            }
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching pre calculated ratio", MFIAlertType.Error, "OK");
                                $scope.Loader_StatisticalRatio = false;
                            });

                        var PePbDivYieldMarketcap = GetPePbDivYieldMarketcap.Call($scope.schemeId, $scope.loginId);
                        PePbDivYieldMarketcap.then(function (response) {
                            if (response.data.Success) {
                                $scope.PePbDivYieldMarketcap = response.data.data;
                                $scope.PePbDivYieldMarketcap.IsSuccess = response.data.Success;
                                portfolioDate = $scope.PePbDivYieldMarketcap.StrPortDate;
                                $scope.FDOthers.PEPBRatioIsComplite = true;
                                if (($scope.FDOthers.PEPBRatioIsComplite == true) || ($scope.FDOthers.StyleBoxIsComplite == true) || ($scope.FDOthers.OthersInfoIsComplite == true)) {
                                    $scope.FDOthers.InfoLoader = false;
                                }

                                FN_GetStyleBox($scope.fundId, portfolioDate);

                            }
                            else
                                MFIMsg.AlertHtml("Error in fetching PE, PB", MFIAlertType.Error, "OK");

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching PE, PB", MFIAlertType.Error, "OK");
                            });


                        var ApiGetNews = GetNews.Call($scope.fundId, $scope.loginId);
                        ApiGetNews.then(function (response) {
                            $scope.LstMfiNews = response.data.data;
                            if (response.data.Success) {
                                //Pagination
                                $scope.OthMfiNewsCurrentPage = 0;
                                $scope.LstMfiNewsPg = [];

                                var OthMfiNewsPageCnt = 1;
                                var PageSize = 5;
                                $scope.LstMfiNewsPg = $scope.LstMfiNews.slice(0, PageSize);

                                if (($scope.LstMfiNews.length % PageSize) == 0) {
                                    OthMfiNewsPageCnt = $scope.LstMfiNews.length / PageSize;
                                }
                                else {
                                    OthMfiNewsPageCnt = parseInt(($scope.LstMfiNews.length / PageSize)) + 1;
                                }
                                $scope.pagingOthMfiNews = {
                                    total: OthMfiNewsPageCnt,
                                    current: 1,
                                    onPageChanged: OthMfiNewsPages,
                                };
                                $scope.OthMfiNewsCurrentPage = $scope.pagingOthMfiNews.current;

                                function OthMfiNewsPages() {
                                    //debugger;
                                    $scope.LstMfiNewsPg = $scope.LstMfiNews.slice(($scope.pagingOthMfiNews.current - 1) * PageSize, ($scope.pagingOthMfiNews.current * PageSize));
                                    $scope.OthMfiNewsCurrentPage = $scope.pagingOthMfiNews.current;
                                }
                            }
                            else {
                                MFIMsg.AlertHtml("Error in fetching mfi news.", MFIAlertType.Error, "OK");
                            }
                            $scope.FDOthers.FundNewsLoader = false;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching mfi news.", MFIAlertType.Error, "OK");
                            });

                        ///end
                        var ApiGetAddendum = GetAddendum.Call($scope.fundId, 10, $scope.loginId);
                        ApiGetAddendum.then(function (response) {
                            if (response.data.Success) {
                                $scope.LstAddendumDetails = response.data.data;
                            }
                            else {
                                MFIMsg.AlertHtml("Error in fetching addendum.", MFIAlertType.Error, "OK");
                            }
                            $scope.FDOthers.AddendumsLoader = false;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching addendum.", MFIAlertType.Error, "OK");
                            });

                        var ApiGetFundOthersInfo = GetFundOthersInfo.Call($scope.fundId);
                        ApiGetFundOthersInfo.then(function (response) {
                            if (response.data.Success) {
                                $scope.FundOthersInfo = response.data.data;
                                $scope.FundOthersInfo.SIPDatesHtml = [];
                                if (!angular.isUndefinedOrNullOrEmpty($scope.FundOthersInfo.SIPDates)) {

                                    var dates = "";
                                    for (x = 1; x <= $scope.FundOthersInfo.SIPDates.length; x++) {
                                        dates = dates + $scope.FundOthersInfo.SIPDates[x - 1] + ",";
                                        if ((x % 5) == 0) {
                                            $scope.FundOthersInfo.SIPDatesHtml.push(dates);
                                            dates = "";
                                        }
                                        else {
                                            continue;
                                        }
                                    }
                                    if (dates != "")
                                        $scope.FundOthersInfo.SIPDatesHtml.push(dates);

                                    $scope.FundOthersInfo.SIPDatesHtml[$scope.FundOthersInfo.SIPDatesHtml.length - 1] = $scope.FundOthersInfo.SIPDatesHtml[$scope.FundOthersInfo.SIPDatesHtml.length - 1].slice(0, -1)
                                }
                                else {
                                    //$scope.FundOthersInfo.SIPDatesHtml.push("N.A.");
                                    $scope.FundOthersInfo.SIPDatesHtml = null;
                                }
                            }
                            else {
                                MFIMsg.AlertHtml("Error in fetching others info.", MFIAlertType.Error, "OK");
                            }
                            $scope.FDOthers.OthersInfoIsComplite = true;
                            if (($scope.FDOthers.PEPBRatioIsComplite == true) || ($scope.FDOthers.StyleBoxIsComplite == true) || ($scope.FDOthers.OthersInfoIsComplite == true)) {
                                $scope.FDOthers.InfoLoader = false;
                            }
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching others info.", MFIAlertType.Error, "OK");
                            });

                        var FN_GetStyleBox = function () {
                            var ApiGetStyleBox = GetStyleBox.Call($scope.fundId, portfolioDate);
                            ApiGetStyleBox.then(function (response) {
                                if (response.data.Success == true) {
                                    //  debugger;
                                    $scope.ObjStyleBox = response.data.data;
                                    $scope.FDOthers.StyleBoxIsComplite = true;
                                    if ($scope.natureName.toUpperCase() == "EQUITY") {
                                        $scope.FDOthers.StyleBoxXAxisText = "P/E";
                                        $scope.FDOthers.StyleBoxYAxisImage = "styleBoxMarketCapLabel.png";
                                    }
                                    else {
                                        $scope.FDOthers.StyleBoxXAxisText = "Average Maturity";
                                        $scope.FDOthers.StyleBoxYAxisImage = "styleBoxCreditQualityLabel.png";
                                    }
                                }
                                else {
                                    MFIMsg.AlertHtml("Error in fetching style box.", MFIAlertType.Error, "OK");
                                }
                                if (($scope.FDOthers.PEPBRatioIsComplite == true) || ($scope.FDOthers.StyleBoxIsComplite == true) || ($scope.FDOthers.OthersInfoIsComplite == true)) {
                                    $scope.FDOthers.InfoLoader = false;
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Error in fetching style box.", MFIAlertType.Error, "OK");
                                });
                        }

                        var ApiGetDividendSchemeByFundId = GetDividendSchemeByFundId.Call($scope.fundId);
                        ApiGetDividendSchemeByFundId.then(function (response) {
                            if (response.data.Success) {
                                $scope.LstDividendScheme = response.data.data;
                            }
                            else
                                MFIMsg.AlertHtml("Error in fetching dividend schemes.", MFIAlertType.Error, "OK");

                            $scope.FDOthers.DividendHistoryLoader = false;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching dividend schemes.", MFIAlertType.Error, "OK");
                            });

                        var Sch = [];
                        Sch.push($scope.schemeId);
                        var ApiGetTopFundReturnComperation = GetTopFundReturnComperation.Call(Sch, 4);
                        ApiGetTopFundReturnComperation.then(function (response) {
                            if (response.data.Success) {
                                $scope.LstSchemeComperationData = [];
                                $scope.LstSchemeComperationData = response.data.data;
                                if ($scope.LstSchemeComperationData.length > 0) {
                                    $scope.isPagedataExist = true;
                                }
                            }
                            else
                                MFIMsg.AlertHtml("Error in fetching peer schemes", MFIAlertType.Error, "OK");
                            $scope.FDOthers.FundComperisonLoader = false;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching peer schemes", MFIAlertType.Error, "OK");
                            });

                        $scope.LstDividendDataAll = [];
                        $scope.FN_FeatchDividend = function (event) {
                            $scope.ShowMoreDividendHistory = false;
                            $scope.DividendHistorySchemeId = event;
                            var ApiGetDividendHist = GetDividendHist.Call(event, 10);
                            ApiGetDividendHist.then(function (response) {
                                //$scope.FDOthers.IsDividendExist = true;
                                if (response.data.Success) {
                                    if (response.data.data != null) {
                                        $scope.LstDividendData = [];

                                        if (response.data.data.length == 0) {
                                            $scope.FDOthers.IsDividendExist = false;
                                            $scope.ShowMoreDividendHistory = false;

                                        }
                                        else if (response.data.data.length >= 10) {

                                            $scope.LstDividendDataAll = response.data.data;

                                            $scope.ShowMoreDividendHistory = true;
                                            $scope.FDOthers.IsDividendExist = true;
                                            for (g = 0; g < 10; g++) {
                                                $scope.LstDividendData.push(response.data.data[g]);
                                            }
                                        }
                                        else {
                                            $scope.LstDividendData = response.data.data;
                                            $scope.ShowMoreDividendHistory = false;
                                            $scope.FDOthers.IsDividendExist = true;
                                        }
                                        //else (response.data.data == null) {
                                        //    $scope.FDOthers.IsDividendExist = false;
                                        //}
                                    }
                                }
                                else {
                                    MFIMsg.AlertHtml("Error in fetching dividend", MFIAlertType.Error, "OK");
                                    $scope.FDOthers.IsDividendExist = false;
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Error in fetching dividend", MFIAlertType.Error, "OK");
                                });
                        };

                        $scope.FN_FeatchDividendMore = function () {
                            //$scope.ShowMoreDividendHistory = true;
                            $scope.FDOthers.AddendumsLoader = true;
                            var ApiGetDividendHist = GetDividendHist.Call($scope.DividendHistorySchemeId, '', $scope.loginId);
                            ApiGetDividendHist.then(function (response) {
                                $scope.FDOthers.IsDividendExist = true;
                                if (response.data.Success) {
                                    if (response.data != null) {
                                        $scope.LstDividendData = [];
                                        $scope.LstDividendData = response.data.data;
                                        //$scope.ShowMoreDividendHistory = false;
                                        $scope.FDOthers.AddendumsLoader = false;
                                        if (response.data.data == null) {
                                            $scope.FDOthers.IsDividendExist = false;
                                            MFIMsg.AlertHtml("No data found", MFIAlertType.Warning, "OK");
                                        }
                                    }
                                }
                                else {
                                    MFIMsg.AlertHtml("Error in fetching show more dividend", MFIAlertType.Error, "OK");
                                    $scope.FDOthers.IsDividendExist = false;
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Error in fetching show more dividend", MFIAlertType.Error, "OK");
                                });
                        }

                        $scope.FN_FeatchNews = function (id) {
                            var ApiGetNewsDetails = GetNewsDetails.Call(id, $scope.loginId);
                            ApiGetNewsDetails.then(function (response) {
                                if (response.data.Success) {
                                    if (response.data != null) {
                                        $scope.NewsDetails = "";
                                        $scope.NewsDetails = response.data.data.Matter;
                                    }
                                }
                                else
                                    MFIMsg.AlertHtml("Error in fetching news details", MFIAlertType.Error, "OK");
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Error in fetching news details", MFIAlertType.Error, "OK");
                                });
                        }
                    }

                    $scope.FDOthers.FN_E2EPeerPerformance = function () {
                        window.open("/FundDashboard/ExportToExcelPeePerformance?SchemeId=" + $scope.schemeId);
                    };
                }
            }
        }
    ]);