SharedDeractives.directive('customSector', ['$timeout', '$q', '$log', 'MFIMsg', 'GetCustomSectorSetData', 'GetSingleCustomSectorSetdetails', 'GetSectorListDetails', 'GetCompanyListDetails', 'GetSingleSectorSetDetails', 'GetCompanySelectUnselectListDetails', 'CustomSectorSave', 'CustomSectorSetDelete', 'DefaultCustomSectorSave', '$filter',
    function ($timeout, $q, $log, MFIMsg, GetCustomSectorSetData, GetSingleCustomSectorSetdetails, GetSectorListDetails, GetCompanyListDetails, GetSingleSectorSetDetails, GetCompanySelectUnselectListDetails, CustomSectorSave, CustomSectorSetDelete, DefaultCustomSectorSave, $filter) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '='
            },
            replace: false,
            templateUrl: '/Home/CustomizedSector',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    $scope.LoaderCustomSectorSearch = true;
                    $scope.showCreateSector = false;
                    $scope.showCompanyName = false;
                    $scope.showSectorName = false;
                    $scope.radioSelectionId;
                    $scope.radioSelectionCmpnySectId = 0;
                    $scope.SectorId = "";
                    $scope.radioCompany = false;
                    $scope.radioSector = false;
                    $scope.showAllCustomSector = false;
                    $scope.showUpdateSector = false;
                    $scope.showCreateDetails = false;
                    $scope.showSelectList = false;
                    $scope.showSave = false;
                    $scope.showUpdate = false;
                    $scope.selectionOneId;
                    $scope.selectionTwoId;
                    $scope.showSelectListSectorDetails = false;
                    //$scope.LstColor = ["Red", "Pink", "Blue", "Gray"];
                    $scope.LstColor = ["#1b847d", "#a0700f", "#1e5205", "#a22409", "#0e6ba0", "#3339FF", "#7e0684", "#FF33A2", "#FFD433"];
                    $scope.SetName = "";
                    $scope.Default;
                    $scope.SectorCompany = "";
                    $scope.showSectorDetails = false;
                    $scope.showCompanyDetails = false;
                    $scope.BasicSelectionList = false;
                    $scope.Gen = false;
                    $scope.selectionId;
                    $scope.AddCreateSector = "";
                    $scope.showRadio = false;
                    $scope.SectorSetId = 0;
                    $scope.CustomSectorId = 0;
                    $scope.radioSelectionId = 0;
                    $scope.selectionOneId = 0;
                    $scope.selectionTwoId = 0;
                    $scope.BscId = 0;
                    $scope.SectorSetName = "";
                    $scope.CustomSectorName = "";
                    $scope.IsCheckedCompany = false;
                    $scope.IsCheckedSector = false;
                    $scope.showSaveUpdate = false;
                    $scope.searchText = "";
                    $scope.IsSectorSetNameDisabled = false;
                    $scope.UserLogInId = "";
                    $scope.CreatedLogInId = "";
                    $scope.LstSectorMasterCrt = [];
                    $scope.FromAdd = false;
                    $scope.SectorLevelName = "";
                    $scope.SectorName = "";

                    $scope.getClassForDefault = function (IsDefault) {
                        if (IsDefault)
                            return "label label-primary";
                        else
                            return "label label-warning";
                    }

                    //$scope.getClass = function (radioSelectionId) {
                    //    if (radioSelectionId == 0)
                    //        return $scope.LstColor[0];
                    //    else if (radioSelectionId == 1)
                    //        return $scope.LstColor[1];
                    //    else if (radioSelectionId == 2)
                    //        return $scope.LstColor[2];
                    //    else if (radioSelectionId == 3)
                    //        return $scope.LstColor[3];
                    //}

                    //$scope.getClassForCheckbox = function (radioSelectionId, IsChecked) {
                    //    if (radioSelectionId == 0 && IsChecked == true)
                    //        return $scope.LstColor[0];
                    //    else if (radioSelectionId == 1 && IsChecked == true)
                    //        return $scope.LstColor[1];
                    //    else if (radioSelectionId == 2 && IsChecked == true)
                    //        return $scope.LstColor[2];
                    //    else if (radioSelectionId == 3 && IsChecked == true)
                    //        return $scope.LstColor[3];
                    //}

                    $scope.toggleSelectionSector = function (SectorName, IsDisable) {
                        if (IsDisable == false) {
                            if ($scope.LstSectorNameSelect == null)
                                $scope.LstSectorNameSelect = [];
                            var index = $scope.LstSectorNameSelect.indexOf(SectorName);
                            if (index == -1) {
                                $scope.LstSectorNameSelect.push(SectorName);
                                angular.forEach($scope.LstSectorMaster, function (value) {
                                    if (value.Name == SectorName)
                                        value.CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioSelectionId] };
                                });

                            }
                            else {
                                $scope.LstSectorNameSelect.splice(index, 1);
                                angular.forEach($scope.LstSectorMaster, function (value) {
                                    if (value.Name == SectorName)
                                        value.CheckBoxTextColor = { "color": "black" };
                                });
                            }
                        }
                    }

                    $scope.toggleSelectionCompany = function (CmpnyName, lstType, IsDisable) {
                        if (IsDisable == false) {
                            if ($scope.LstComapnyNameSelect == null)
                                $scope.LstComapnyNameSelect = [];
                            var index = $scope.LstComapnyNameSelect.indexOf(CmpnyName);
                            if (index == -1) {
                                $scope.LstComapnyNameSelect.push(CmpnyName);
                                if (lstType == 'Cmp') {
                                    angular.forEach($scope.LstCompanyMaster, function (value) {
                                        if (value.CompanyName == CmpnyName)
                                            value.CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioSelectionId] };
                                    });
                                }
                                if (lstType == 'CmpSelt') {
                                    angular.forEach($scope.LstSelectUnselectCompany, function (value) {
                                        if (value.CompanyName == CmpnyName)
                                            value.CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioSelectionId] };
                                    });
                                }
                            }
                            else {
                                $scope.LstComapnyNameSelect.splice(index, 1);
                                if (lstType == 'Cmp') {
                                    angular.forEach($scope.LstCompanyMaster, function (value) {
                                        if (value.CompanyName == CmpnyName)
                                            value.CheckBoxTextColor = { "color": "black" };
                                    });
                                }
                                if (lstType == 'CmpSelt') {
                                    angular.forEach($scope.LstSelectUnselectCompany, function (value) {
                                        if (value.CompanyName == CmpnyName)
                                            value.CheckBoxTextColor = { "color": "black" };
                                    });
                                }
                            }
                        }
                    }

                    var getData = GetCustomSectorSetData.Call();

                    getData.then(function (response) {
                        $scope.LoaderCustomSectorSearch = false;
                        $scope.LstCustomSectorSet = response.data.data.LstCustomSectorSet;
                        $scope.LstBasicSelectionCriteria = response.data.data.LstBasicSelectionCriteria;
                        if (response.data.data.LstCustomSectorSingleSetDetails != null) {
                            $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;

                            if (response.data.data.Data.IsDefault == true) {
                                //$scope.SetName = "Default";
                                //$scope.Default = true;
                                $scope.SetName = "Undo";
                                $scope.Default = false;
                            }
                            else {
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                            }
                            if (response.data.data.Data.IsGeneric == true) {
                                $scope.Gen = true;
                            }
                            else {
                                $scope.Gen = false;
                            }
                            $scope.UserLogInId = response.data.data.UserLogInId;
                            $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                        }

                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Custom Sector set loading failed.", MFIAlertType.Error, "OK");
                        });

                    $scope.querySearch = querySearch;
                    $scope.selectedItemChange = selectedItemChange;
                    $scope.searchTextChange = searchTextChange;


                    function querySearch(query) {
                        var results = query ? $scope.LstCustomSectorSet.filter(createFilterFor(query)) : $scope.LstCustomSectorSet;
                        return results;
                    }

                    function searchTextChange(text) {
                        $log.info('Text changed to ' + text);
                    }

                    function createFilterFor(query) {
                        var lowercaseQuery = angular.lowercase(query);

                        return function filterFn(state) {
                            return (angular.lowercase(state.Name).indexOf(lowercaseQuery) === 0);
                        };

                    }
                    $scope.FnCleanTextCustomSector = function () {
                        $scope.searchText = '';
                        $scope.ShowClearButton = false;
                    }
                    function selectedItemChange(item) {
                        if (item != undefined) {
                            $scope.ShowClearButton = true;
                            var instuParam = { "SetId": item.Id };
                            var getData = GetSingleCustomSectorSetdetails.Call(instuParam);
                            $scope.LoaderTableCustomSector = true;
                            getData.then(function (response) {
                                $scope.LoaderTableCustomSector = false;
                                $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;
                                $scope.showCreateSector = false;
                                $scope.showAllCustomSector = false;
                                $scope.showUpdateSector = false;
                                $scope.showCreateDetails = false;
                                $scope.showSelectList = false;
                                $scope.showCompanyName = false;
                                $scope.showSectorName = false;
                                $scope.showSaveUpdate = false;
                                $scope.showSave = false;
                                $scope.showUpdate = false;
                                if (response.data.data.Data.IsDefault == true) {
                                    //$scope.SetName = "Default";
                                    //$scope.Default = true;
                                    $scope.SetName = "Undo";
                                    $scope.Default = false;
                                }
                                else {
                                    $scope.SetName = "Make Default";
                                    $scope.Default = true;
                                }
                                if (response.data.data.Data.IsGeneric == true) {
                                    $scope.Gen = true;
                                }
                                else {
                                    $scope.Gen = false;
                                }
                                $scope.UserLogInId = response.data.data.UserLogInId;
                                $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                            },
                                function (stu) {
                                    $scope.LoaderTableCustomSector = false;
                                    MFIMsg.AlertHtml("Single custom set details fetch failed from search selection.", MFIAlertType.Error, "OK");
                                });
                        }
                        $log.info('Item changed to ' + JSON.stringify(item));
                    }

                    $scope.createNewSector = function (sectorName) {
                        $scope.IsCheckedCompany = false;
                        $scope.IsCheckedSector = false;
                        $scope.showCreateSector = true;
                        $scope.showAllCustomSector = false;
                        $scope.showUpdateSector = false;
                        $scope.showCreateDetails = false;
                        $scope.showSelectList = false;
                        $scope.showCompanyName = false;
                        $scope.showSectorName = false;
                        $scope.showSave = false;
                        $scope.showUpdate = false;
                        $scope.radioSelectionId = 0;
                        $scope.selectionOneId = 0;
                        $scope.selectionTwoId = 0;
                        $scope.BscId = 0;
                        $scope.SectorSetName = sectorName;
                        $scope.CustomSectorName = "";
                        $scope.SectorSetId = 0;
                        $scope.CustomSectorId = 0;
                        $scope.BasicSelectionList = false;
                        $scope.radioSector = false;
                        $scope.radioCompany = false;
                        if ($scope.LstSectorNameSelect != null || $scope.LstSectorNameSelect == null)
                            $scope.LstSectorNameSelect = [];
                        if ($scope.LstComapnyNameSelect != null || $scope.LstComapnyNameSelect == null)
                            $scope.LstComapnyNameSelect = [];
                        $scope.IsGeneric = false;
                        $scope.AddCreateSector = "Create Sector";
                        $scope.showRadio = true;
                        $scope.showSaveUpdate = false;
                        $scope.IsSectorSetNameDisabled = false;
                    }

                    $scope.selectionCompanyWise = function () {

                        $scope.showCompanyName = false;
                        $scope.showSectorName = false;
                        $scope.IsCompanyWise = true;
                        $scope.showCreateDetails = true;
                        $scope.showSelectList = true;
                        $scope.selectionOneId = 0;
                        $scope.selectionTwoId = 0;
                        $scope.showSave = false;
                        $scope.showUpdate = false;
                        $scope.IsCheckedSector = false;
                        $scope.IsCheckedCompany = true;
                        $scope.LstSectorMasterCrt = [];
                    }

                    $scope.selectionSectorWise = function () {

                        $scope.showCompanyName = false;
                        $scope.showSectorName = false;
                        $scope.IsCompanyWise = false;
                        $scope.showCreateDetails = true;
                        $scope.showSelectList = false;
                        $scope.selectionOneId = 0;
                        $scope.selectionTwoId = 0;
                        $scope.showSave = false;
                        $scope.showUpdate = false;
                        $scope.IsCheckedCompany = false;
                        $scope.IsCheckedSector = true;

                    }

                    $scope.getSectorList = function (BscId) {
                        $scope.BscId = BscId;
                        $scope.LoaderSectorList = true;
                        if ($scope.IsCompanyWise == false) {
                            $scope.LoaderSectorListShow = true;
                        }
                        var sectorListParam = { "BscId": BscId, "SectorSetId": 0 };
                        var getData = GetSectorListDetails.Call(sectorListParam);
                        getData.then(function (response) {
                            $scope.LoaderSectorList = false;
                            $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                            if ($scope.IsCompanyWise == false) {
                                $scope.showCompanyName = false;
                                $scope.showSectorName = true;
                                $scope.showSave = true;
                                $scope.showUpdate = false;
                                $scope.showSaveUpdate = true;
                                $scope.LoaderSectorListShow = false;
                            }
                        },
                            function (stu) {
                                $scope.LoaderSectorList = false;
                                $scope.LoaderSectorListShow = false;
                                MFIMsg.Alert("Sector list loading failed.", MFIAlertType.Error, "OK");
                            });
                    }

                    $scope.getCompanyDetails = function (SectId) {
                        if (SectId != null) {
                            $scope.SectorName = $filter('filter')($scope.LstSectorMasterCrt, { SectorId: SectId }).length > 0 ? $filter('filter')($scope.LstSectorMasterCrt, { SectorId: SectId }, true)[0].Name : "";
                            $scope.SectorLevelName = $filter('filter')($scope.LstBasicSelectionCriteria, { BscId: $scope.BscId }).length > 0 ? $filter('filter')($scope.LstBasicSelectionCriteria, { BscId: $scope.BscId }, true)[0].BscValue : "";

                            $scope.LoaderComapnyListShow = true;
                            var companyListParam = { "SectorId": SectId, "SectorSetId": $scope.SectorSetId, "SectorLevelName": $scope.SectorLevelName, "SectorName": $scope.SectorName };
                            var getData = GetCompanyListDetails.Call(companyListParam);
                            getData.then(function (response) {
                                $scope.LoaderComapnyListShow = false;
                                $scope.LstCompanyMaster = response.data.data.LstCompanyMaster;
                                $scope.showCompanyName = true;
                                $scope.showSectorName = false;
                                $scope.showSave = true;
                                $scope.showUpdate = false;
                                $scope.showSaveUpdate = true;
                                if (response.data.data.LstCompanyIdForDisable != null) {
                                    for (var i = 0; i < response.data.data.LstCompanyIdForDisable.length; i++) {
                                        for (var j = 0; j < $scope.LstCompanyMaster.length; j++) {
                                            if ($scope.LstCompanyMaster[j].CompanyId == response.data.data.LstCompanyIdForDisable[i]) {
                                                $scope.LstCompanyMaster[j].IsDisable = true;
                                            }
                                        }
                                    }
                                }
                            },
                                function (stu) {
                                    $scope.LoaderComapnyListShow = false;
                                    MFIMsg.AlertHtml("Sector list loading failed.", MFIAlertType.Error, "OK");
                                });
                        }

                    }

                    $scope.editSingleRow = function (customSector, Id) {
                        //if ($scope.search != "" && $scope.search != undefined)
                        //    $scope.search.Name = "";
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.LoaderAllCustomSector = true;
                            $scope.LoaderAllCustomSectorCompany = true;
                            $scope.BscId = customSector.BscId;
                            $scope.SectorSetName = customSector.SectorSetName;
                            $scope.CustomSectorName = customSector.CustomSectorName;
                            $scope.SectorSetId = customSector.SectorSetId;
                            $scope.CustomSectorId = customSector.CustomSectorId;
                            $scope.IsCompanyWise = customSector.IsCompanyWise;
                            $scope.radioSelectionId = Id;
                            $scope.selectionId = 0;
                            $scope.IsSectorSetNameDisabled = true;

                            $scope.LoaderTableEditAdd = true;
                            var singleSectorDetailsParam = { "BscId": customSector.BscId, "SectorSetId": customSector.SectorSetId, "CustomSectorId": customSector.CustomSectorId, "IsCompanyWise": customSector.IsCompanyWise };
                            var getData = GetSingleSectorSetDetails.Call(singleSectorDetailsParam);
                            getData.then(function (response) {
                                $scope.LoaderAllCustomSector = false;
                                $scope.LoaderAllCustomSectorCompany = false;
                                $scope.LoaderTableEditAdd = false;
                                $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;
                                $scope.IsGeneric = response.data.data.Data.IsGeneric;
                                if (customSector.IsCompanyWise == true) {
                                    $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                    $scope.LstSelectUnselectCompany = response.data.data.LstSelectUnselectCompany;
                                    if ($scope.LstComapnyNameSelect != null)
                                        $scope.LstComapnyNameSelect = [];
                                    if (response.data.data.LstCompanyId != null) {
                                        for (var i = 0; i < response.data.data.LstCompanyId.length; i++) {
                                            for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                                if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyId[i]) {
                                                    $scope.LstSelectUnselectCompany[j].IsChecked = true;
                                                    $scope.LstSelectUnselectCompany[j].CheckBoxTextColor = { "color": $scope.LstColor[Id] };
                                                    if ($scope.LstComapnyNameSelect == null)
                                                        $scope.LstComapnyNameSelect = [];
                                                    $scope.LstComapnyNameSelect.push($scope.LstSelectUnselectCompany[j].CompanyName);
                                                }
                                            }
                                        }
                                    }
                                    if (response.data.data.LstCompanyIdForDisable != null) {
                                        for (var i = 0; i < response.data.data.LstCompanyIdForDisable.length; i++) {
                                            for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                                if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyIdForDisable[i]) {
                                                    $scope.LstSelectUnselectCompany[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }

                                }
                                else {
                                    $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                    if ($scope.LstSectorNameSelect != null)
                                        $scope.LstSectorNameSelect = [];
                                    if (response.data.data.LstSectorId != null) {
                                        for (var i = 0; i < response.data.data.LstSectorId.length; i++) {
                                            for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                                if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorId[i]) {
                                                    $scope.LstSectorMasterCrt[j].IsChecked = true;
                                                    $scope.LstSectorMasterCrt[j].CheckBoxTextColor = { "color": $scope.LstColor[Id] };
                                                    if ($scope.LstSectorNameSelect == null)
                                                        $scope.LstSectorNameSelect = [];
                                                    $scope.LstSectorNameSelect.push($scope.LstSectorMasterCrt[j].Name);
                                                }
                                            }
                                        }
                                    }
                                    if (response.data.data.LstSectorIdForDisable != null) {
                                        for (var i = 0; i < response.data.data.LstSectorIdForDisable.length; i++) {
                                            for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                                if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorIdForDisable[i]) {
                                                    $scope.LstSectorMasterCrt[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                var incr = 0;
                                angular.forEach($scope.LstCustomSectorSingleSetDetails, function (value) {
                                    value.IsChecked = value.CustomSectorId == customSector.CustomSectorId ? true : false;
                                    value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                    incr++;
                                });
                                incr = 0;

                                if (customSector.IsCompanyWise == true) {
                                    $scope.showSelectListSectorDetails = true;
                                    $scope.showSectorDetails = false;
                                    $scope.showCompanyDetails = true;
                                    $scope.SectorCompany = "Company";
                                }
                                else {
                                    $scope.showSelectListSectorDetails = false;
                                    $scope.showSectorDetails = true;
                                    $scope.showCompanyDetails = false;
                                    $scope.SectorCompany = "Sector";
                                }
                                $scope.showAllCustomSector = true;
                                $scope.showCreateSector = false;
                                $scope.showCompanyName = false;
                                $scope.showSectorName = false;
                                $scope.showUpdateSector = true;
                                $scope.showUpdate = true;
                                $scope.showSave = false;
                                $scope.showSaveUpdate = true;
                            },
                                function (stu) {
                                    $scope.LoaderAllCustomSector = false;
                                    $scope.LoaderAllCustomSectorCompany = false;
                                    $scope.LoaderTableEditAdd = false;
                                    MFIMsg.AlertHtml("Single sector list details loading failed.", MFIAlertType.Error, "OK");
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to edit this set.", MFIAlertType.Information, "OK");
                        }
                    }

                    $scope.getSelectionCompanyDetails = function (SectId) {
                        $scope.LoaderAllCustomSectorCompany = true;
                        var companyDetailsParam = { "SectorId": SectId, "SectorSetId": $scope.SectorSetId, "CustomSectorId": $scope.CustomSectorId };
                        var getData = GetCompanySelectUnselectListDetails.Call(companyDetailsParam);
                        getData.then(function (response) {
                            $scope.LoaderAllCustomSectorCompany = false;
                            $scope.LstSelectUnselectCompany = response.data.data.LstSelectUnselectCompany;
                            if (response.data.data.LstCompanyId != null) {
                                for (var i = 0; i < response.data.data.LstCompanyId.length; i++) {
                                    for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                        if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyId[i]) {
                                            $scope.LstSelectUnselectCompany[j].IsChecked = true;
                                        }
                                    }
                                }
                            }
                            if (response.data.data.LstCompanyIdForDisable != null) {
                                for (var i = 0; i < response.data.data.LstCompanyIdForDisable.length; i++) {
                                    for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                        if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyIdForDisable[i]) {
                                            $scope.LstSelectUnselectCompany[j].IsDisable = true;
                                        }
                                    }
                                }
                            }
                        },
                            function (stu) {
                                $scope.LoaderAllCustomSectorCompany = false;
                                MFIMsg.AlertHtml("Company list loading failed.", MFIAlertType.Error, "OK");
                            });
                    }

                    $scope.customSectorSetUpdate = function () {
                        if ($scope.LstComapnyNameSelect == null && $scope.IsCompanyWise == true) {
                            MFIMsg.AlertHtml("Atleast select one company name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($scope.LstSectorNameSelect == null && $scope.IsCompanyWise == false) {
                            MFIMsg.AlertHtml("Atleast select one sector name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        $scope.LoaderSaveUpdateCustomSector = true;
                        var customSectorUpdateParam = { "SectorSetId": $scope.SectorSetId, "SectorSetName": $scope.SectorSetName, "CustomSectorId": $scope.CustomSectorId, "BscId": $scope.BscId, "IsCompanyWise": $scope.IsCompanyWise, "CustomSectorName": $scope.CustomSectorName, "LstSectorNameSelectSave": $scope.LstSectorNameSelect, "LstCompanyNameSelectSave": $scope.LstComapnyNameSelect, "IsGeneric": $scope.IsGeneric };
                        var getData = CustomSectorSave.Call(customSectorUpdateParam);
                        getData.then(function (response) {
                            $scope.LoaderSaveUpdateCustomSector = false;
                            MFIMsg.AlertHtml("Data updated successfully.", MFIAlertType.Success, "OK");
                            $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;
                            $scope.BasicSelectionList = true;
                            $scope.IsGeneric = response.data.data.Data.IsGeneric;
                            if ($scope.IsCompanyWise == true) {
                                $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                $scope.LstSelectUnselectCompany = response.data.data.LstSelectUnselectCompany;
                                if ($scope.LstComapnyNameSelect != null)
                                    $scope.LstComapnyNameSelect = [];
                                $scope.selectionId = 0;
                                if (response.data.data.LstCompanyId != null) {
                                    for (var i = 0; i < response.data.data.LstCompanyId.length; i++) {
                                        for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                            if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyId[i]) {
                                                $scope.LstSelectUnselectCompany[j].IsChecked = true;
                                                $scope.LstSelectUnselectCompany[j].CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioSelectionId] };
                                                if ($scope.LstComapnyNameSelect == null)
                                                    $scope.LstComapnyNameSelect = [];
                                                $scope.LstComapnyNameSelect.push($scope.LstSelectUnselectCompany[j].CompanyName);
                                            }
                                        }
                                    }
                                }
                                //if (response.data.data.LstCompanyIdForDisable != null) {
                                //    for (var i = 0; i < response.data.data.LstCompanyIdForDisable.length; i++) {
                                //        for (var j = 0; j < $scope.LstSelectUnselectCompany.length; j++) {
                                //            if ($scope.LstSelectUnselectCompany[j].CompanyId == response.data.data.LstCompanyIdForDisable[i]) {
                                //                $scope.LstSelectUnselectCompany[j].IsDisable = true;
                                //            }
                                //        }
                                //    }
                                //}
                            }
                            else {
                                $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                if ($scope.LstSectorNameSelect != null)
                                    $scope.LstSectorNameSelect = [];
                                if (response.data.data.LstSectorId != null) {
                                    for (var i = 0; i < response.data.data.LstSectorId.length; i++) {
                                        for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                            if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorId[i]) {
                                                $scope.LstSectorMasterCrt[j].IsChecked = true;
                                                $scope.LstSectorMasterCrt[j].CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioSelectionId] };
                                                if ($scope.LstSectorNameSelect == null)
                                                    $scope.LstSectorNameSelect = [];
                                                $scope.LstSectorNameSelect.push($scope.LstSectorMasterCrt[j].Name);
                                            }
                                        }
                                    }
                                }
                                //if (response.data.data.LstSectorIdForDisable != null) {
                                //    for (var i = 0; i < response.data.data.LstSectorIdForDisable.length; i++) {
                                //        for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                //            if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorIdForDisable[i]) {
                                //                $scope.LstSectorMasterCrt[j].IsDisable = true;
                                //            }
                                //        }
                                //    }
                                //}
                            }
                            var incr = 0;
                            angular.forEach($scope.LstCustomSectorSingleSetDetails, function (value) {
                                value.IsChecked = value.CustomSectorId == $scope.CustomSectorId ? true : false;
                                value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                incr++;
                            });
                            incr = 0;
                        },
                            function (stu) {
                                $scope.LoaderSaveUpdateCustomSector = false;
                                MFIMsg.AlertHtml("Update failed.", MFIAlertType.Error, "OK");
                            });

                    }

                    $scope.removeRow = function (SectorSetId, CustomSectorId) {
                        if (SectorSetId == 0 && CustomSectorId == 0)
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            MFIMsg.Confirm("<h3 class='text-center'></h3> You want to delete", "MFI360 Explorer", "Yes", "No").then(function () {
                                $scope.LoaderTableCustomSector = true;
                                var customSectorSetDeleteParam = { "SectorSetId": SectorSetId, "CustomSectorId": CustomSectorId };
                                var getData = CustomSectorSetDelete.Call(customSectorSetDeleteParam);
                                getData.then(function (response) {
                                    $scope.LoaderTableCustomSector = false;
                                    MFIMsg.AlertHtml("Custom sector deleted successfully", MFIAlertType.Success, "OK");
                                    $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;
                                    if (response.data.data.Data.IsDefault == true) {
                                        //$scope.SetName = "Default";
                                        //$scope.Default = true;
                                        $scope.SetName = "Undo";
                                        $scope.Default = false;
                                    }
                                    else {
                                        $scope.SetName = "Make Default";
                                        $scope.Default = true;
                                    }
                                    $scope.showAllCustomSector = false;
                                    $scope.showUpdateSector = false;
                                    $scope.showSave = false;
                                    $scope.showUpdate = false;
                                    $scope.showCompanyDetails = false;
                                    $scope.showSectorDetails = false;
                                    $scope.showCreateSector = true;
                                    $scope.showCreateDetails = false;
                                    $scope.showSelectList = false;
                                    $scope.showCompanyName = false;
                                    $scope.showSectorName = false;
                                    $scope.showCreateSector = false;
                                    if ($scope.LstCustomSectorSingleSetDetails.length == 0) {
                                        $scope.searchText = "";
                                        var getData = GetCustomSectorSetData.Call();
                                        getData.then(function (response) {
                                            $scope.LstCustomSectorSet = response.data.data.LstCustomSectorSet;
                                            $scope.LstBasicSelectionCriteria = response.data.data.LstBasicSelectionCriteria;
                                        },
                                            function (stu) {
                                                MFIMsg.AlertHtml("Custom Sector set loading failed.", MFIAlertType.Error, "OK");
                                            });
                                    }
                                },
                                    function (stu) {
                                        $scope.LoaderTableCustomSector = false;
                                        MFIMsg.AlertHtml("Set deletion failed.", MFIAlertType.Error, "OK");
                                    });
                            }, function () {
                            })
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to delete.", MFIAlertType.Information, "OK");
                        }
                    }

                    $scope.makeSetDefault = function (setId) {
                        if (setId == "--")
                            return;
                        if ($scope.Default == "Default")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            var defaultParam = { "SetId": setId, "IsDefault": $scope.Default };
                            var getData = DefaultCustomSectorSave.Call(defaultParam);
                            getData.then(function (response) {
                                if (response.data.data.Data.IsDefault == true) {
                                    //$scope.SetName = "Default";
                                    //$scope.Default = true;
                                    $scope.SetName = "Undo";
                                    $scope.Default = false;
                                }
                                else {
                                    $scope.SetName = "Make Default";
                                    //  $scope.Default = false;
                                    $scope.Default = true;
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Oops, an error occurred in make default.", MFIAlertType.Error, "OK");
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to set default.", MFIAlertType.Information, "OK");
                        }
                    }

                    $scope.customSectorSetSave = function (radioSelId) {
                        if ($scope.SectorSetName == "" || $scope.SectorSetName == null) {
                            MFIMsg.AlertHtml("Please enter set name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($.isNumeric($scope.SectorSetName) == true) {
                            MFIMsg.AlertHtml("Set name can't be numeric.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($scope.CustomSectorName == "" || $scope.CustomSectorName == null) {
                            MFIMsg.AlertHtml("Please enter sector name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($.isNumeric($scope.CustomSectorName) == true) {
                            MFIMsg.AlertHtml("Custom sector name can't be numeric.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($scope.LstComapnyNameSelect == null || $scope.LstComapnyNameSelect.length == 0 && $scope.IsCheckedCompany == true) {
                            MFIMsg.AlertHtml("Atleast select one company name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        if ($scope.LstSectorNameSelect == null || $scope.LstSectorNameSelect == 0 && $scope.IsCheckedSector == true) {
                            MFIMsg.AlertHtml("Atleast select one sector name.", MFIAlertType.Information, "OK");
                            return;
                        }
                        $scope.LoaderSaveUpdateCustomSector = true;
                        var customSectorUpdateParam = { "SectorSetId": $scope.SectorSetId, "SectorSetName": $scope.SectorSetName, "CustomSectorId": $scope.CustomSectorId, "BscId": $scope.BscId, "IsCompanyWise": $scope.IsCompanyWise, "CustomSectorName": $scope.CustomSectorName, "LstSectorNameSelectSave": $scope.LstSectorNameSelect, "LstCompanyNameSelectSave": $scope.LstComapnyNameSelect, "IsGeneric": $scope.IsGeneric };
                        var getData = CustomSectorSave.Call(customSectorUpdateParam);
                        getData.then(function (response) {
                            $scope.LoaderSaveUpdateCustomSector = false;
                            if (response.data.data != null) {
                                MFIMsg.AlertHtml("Data saved successfully.", MFIAlertType.Success, "OK");
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                                $scope.LstCustomSectorSingleSetDetails = response.data.data.LstCustomSectorSingleSetDetails;
                                $scope.showRadio = false;
                                if ($scope.IsCheckedCompany == true) {
                                    $scope.radioSelectionCmpnySectId = 1;
                                    $scope.radioSector = true;
                                }
                                else {
                                    $scope.radioSelectionCmpnySectId = 2;
                                    $scope.radioCompany = true;
                                }
                                $scope.BasicSelectionList = true;
                                $scope.selectionTwoId = 0;
                                $scope.SectorSetId = response.data.data.Data.SectorSetId;
                                if ($scope.IsCompanyWise == true) {
                                    if ($scope.LstComapnyNameSelect != null)
                                        $scope.LstComapnyNameSelect = [];
                                    $scope.showSectorName = false;
                                    $scope.showCompanyName = false;
                                    $scope.showSave = false;
                                    $scope.showCreateSector = false;
                                    $scope.showSaveUpdate = false;
                                    if (response.data.data.LstCompanyIdForDisable != null) {
                                        for (var i = 0; i < response.data.data.LstCompanyIdForDisable.length; i++) {
                                            for (var j = 0; j < $scope.LstCompanyMaster.length; j++) {
                                                if ($scope.LstCompanyMaster[j].CompanyId == response.data.data.LstCompanyIdForDisable[i]) {
                                                    $scope.LstCompanyMaster[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                else {
                                    $scope.showSectorName = false;
                                    $scope.showCompanyName = false;
                                    $scope.showSave = false;
                                    $scope.showCreateSector = false;
                                    $scope.showSaveUpdate = false;
                                    if ($scope.LstSectorNameSelect != null)
                                        $scope.LstSectorNameSelect = [];
                                    $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                    if (response.data.data.LstSectorIdForDisable != null) {
                                        for (var i = 0; i < response.data.data.LstSectorIdForDisable.length; i++) {
                                            for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                                if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorIdForDisable[i]) {
                                                    $scope.LstSectorMasterCrt[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        },
                            function (stu) {
                                $scope.LoaderSaveUpdateCustomSector = false;
                                MFIMsg.AlertHtml("Oops, an error occurred in data saving.", MFIAlertType.Error, "OK");
                            });
                    }

                    $scope.addInExisting = function (customSector, Id) {
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.radioSelectionCmpnySectId = 0;
                            $scope.showAllCustomSector = false;
                            $scope.showUpdateSector = false;
                            $scope.showSelectList = false;
                            $scope.showCompanyName = false;
                            $scope.showSectorName = false;
                            $scope.showSave = false;
                            $scope.showUpdate = false;
                            $scope.radioSector = false;
                            $scope.radioCompany = false;
                            $scope.showRadio = false;
                            $scope.IsSectorSetNameDisabled = true;

                            if (customSector.IsCompanyWise == true) {
                                $scope.AddCreateSector = "Add Company Wise";
                                $scope.radioSelectionCmpnySectId = 1;
                                $scope.selectionTwoId;
                                $scope.radioSector = true;
                                $scope.showSelectList = true;
                                $scope.LoaderTableEditAdd = true;
                                var sectorListParam = { "BscId": customSector.BscId, "SectorSetId": 0 };
                                var getData = GetSectorListDetails.Call(sectorListParam);
                                getData.then(function (response) {
                                    $scope.LoaderTableEditAdd = false;
                                    $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                    $scope.showCreateSector = true;
                                    $scope.showCreateDetails = true;
                                },
                                    function (stu) {
                                        $scope.LoaderTableEditAdd = false;
                                        MFIMsg.AlertHtml("Sector list loading failed.", MFIAlertType.Error, "OK");
                                    });
                            }
                            else {
                                $scope.AddCreateSector = "Add Sector Wise";
                                $scope.radioSelectionCmpnySectId = 2;
                                $scope.radioCompany = false;
                                $scope.LoaderTableEditAdd = true;
                                $scope.showCompanyName = false;
                                $scope.showRadio = false;
                                var sectorListParam = { "BscId": customSector.BscId, "SectorSetId": customSector.SectorSetId };
                                var getData = GetSectorListDetails.Call(sectorListParam);
                                getData.then(function (response) {
                                    $scope.LoaderTableEditAdd = false;
                                    if (response.data.data != null) {
                                        $scope.LstSectorMasterCrt = response.data.data.LstSectorMaster;
                                        $scope.showCompanyName = false;
                                        $scope.showSectorName = true;
                                        $scope.showSave = true;
                                        $scope.showUpdate = false;
                                        $scope.showSaveUpdate = true;
                                        if (response.data.data.LstSectorIdForDisable != null) {
                                            for (var i = 0; i < response.data.data.LstSectorIdForDisable.length; i++) {
                                                for (var j = 0; j < $scope.LstSectorMasterCrt.length; j++) {
                                                    if ($scope.LstSectorMasterCrt[j].SectorId == response.data.data.LstSectorIdForDisable[i]) {
                                                        $scope.LstSectorMasterCrt[j].IsDisable = true;
                                                    }
                                                }
                                            }
                                        }
                                        $scope.showCreateSector = true;
                                        $scope.showCreateDetails = true;
                                    }
                                },
                                    function (stu) {
                                        $scope.LoaderTableEditAdd = false;
                                        MFIMsg.AlertHtml("Sector list loading failed.", MFIAlertType.Error, "OK");
                                    });

                            }
                            $scope.selectionOneId = customSector.BscId;
                            $scope.SectorSetName = customSector.SectorSetName;
                            $scope.CustomSectorName = "";
                            $scope.SectorSetId = customSector.SectorSetId;
                            $scope.CustomSectorId = 0;
                            $scope.BscId = customSector.BscId;
                            $scope.IsCompanyWise = customSector.IsCompanyWise;
                            $scope.BasicSelectionList = true;
                            if ($scope.LstSectorNameSelect != null || $scope.LstSectorNameSelect == null)
                                $scope.LstSectorNameSelect = [];
                            if ($scope.LstComapnyNameSelect != null || $scope.LstComapnyNameSelect == null)
                                $scope.LstComapnyNameSelect = [];
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission.", MFIAlertType.Information, "OK");
                        }
                    }

                    $scope.isCollapsed = true;
                    $scope.toggleCollapse = function () {
                        $scope.isCollapsed = !$scope.isCollapsed;

                        $timeout(function () {
                            var toggleDiv = angular.element(document.querySelector('.toggleDiv2'));
                            var toggleHeight = angular.element(document.querySelector('.toggleHeight2'));
                            toggleDiv.slideToggle('fast', function () {
                                if (toggleDiv.css('display') === 'none') {
                                    toggleHeight.css('height', '300px');
                                } else {
                                    toggleHeight.css('height', '165px');
                                }
                            });
                        }, 0);
                    };
                    $scope.closeCustomSector = function () {
                        if (screen.width <= 767) {
                            angular.element('#customSectorDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#customSectorDetails').hide();
                        } else {
                            angular.element('#customSectorDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#customSectorDetails').hide();
                            });
                        }
                    };

                    $scope.toggleCustomSectorPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-customSector');
                        var $details = angular.element('#customSectorDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };

                }, 0);
            }
        };
    }
]);