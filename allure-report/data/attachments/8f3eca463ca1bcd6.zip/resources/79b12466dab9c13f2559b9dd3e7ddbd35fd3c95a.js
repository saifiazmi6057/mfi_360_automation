angular.module('editableDropdown', [])
.directive('editableDropdown', function() {
  return {
    restrict: 'E',
    require: 'ngModel',
    scope: {
      options: '=',
    },
    template: '<div> <div id="editddl" class="input-group dropdown" style="background-color: rgba(36, 41, 44, 0.9); border: rgba(23, 27, 30, 0.9) solid 1px">' +
      '<input type="text" id="txtsetname" onkeypress="openDDl()" placeholder="Type set name " class="form-control countrycode dropdown-toggle" ng-model="selected" data-toggle="dropdown">' +
      '<ul class="dropdown-menu scrollable-menu" role="menu">' +
    '<li ng-repeat="option in options|startWith :selected : \'name\'" ng-click="choose($event)" data-value="{{option.id}}" data-name="{{option.name}}">' +
        '{{option.name}}' +
        '</li>' + 
      '</ul>' +
      '<span role="button" class="input-group-addon dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="caret"></span></span>' +
    '</div></div>',
    link: function(scope, iElement, iAttrs, ngModelCtrl) {
      ngModelCtrl.$formatters.push(function(modelValue) {
        return {
          selected : modelValue,
        };
      });

      ngModelCtrl.$render = function() {
          if (!ngModelCtrl.$viewValue) ngModelCtrl.$viewValue = { selected: ''};
          scope.selected = ngModelCtrl.$viewValue.selected;
      };


      scope.$watch('selected', function() {
          ngModelCtrl.$setViewValue({ selected: scope.selected});
      });


      ngModelCtrl.$parsers.push(function(viewValue) {
          return viewValue.selected;
      });


    },
    controller: ['$scope', function($scope) {
       $scope.choose = function($event){
           $scope.selected = $event.target.getAttribute('data-name');
      }      
    }],
  };
});
