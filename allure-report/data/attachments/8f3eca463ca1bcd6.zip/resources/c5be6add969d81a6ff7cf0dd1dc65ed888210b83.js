SharedDeractives.directive('applicationSetting', ['$timeout', '$q', '$log', 'AllApplicationSetting', 'SaveApplicationSetting', '$filter', '$http', '$mdDialog', 'MFIMsg', 'ApiInfo', 'P2PPeriodDetails', 'SaveP2PPeriod', 'P2PperiodDelete', 'DeleteLogo', 'AllAdvanceSettings','LoadSchemeCodes',

    function ($timeout, $q, $log, AllApplicationSetting, SaveApplicationSetting, $filter, $http, $mdDialog, MFIMsg, ApiInfo, P2PPeriodDetails, SaveP2PPeriod, P2PperiodDelete, DeleteLogo, AllAdvanceSettings, LoadSchemeCodes) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '='
            },
            replace: false,

            templateUrl: '/Home/ApplicationSetting',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    $("#txtPeriodWisePeriod").bind('keypress', function (event) {
                        if (this.value.length >= 5)
                            return false;
                        return CheckNumeric(event, this.value);
                    });

                    $("#txtPeriodWiseNumber").bind('keypress', function (event) {
                        if (this.value.length >= 5)
                            return false;
                        return CheckNumeric(event, this.value);
                    });

                    $scope.Interval = {
                        'd': 'Day',
                        'ww': 'Week',
                        'mm': 'Month',
                        'yyyy': 'Year'
                    };
                    $scope.LstIntervalOrDateWise = [];
                    $scope.PeriodWisePeriod = "";
                    $scope.PeriodWiseNumber = "";
                    $scope.PeriodWiseSelectedInterval = "";
                    $scope.RadioSelectionIntervalWise = true;
                    $scope.tableShowIntervalDateWise = false;
                    $scope.showPeriodText = true;
                    $scope.showPeriodDate = false;
                    $scope.DayInterval = "Interval";
                    $scope.showInterval = true;
                    $scope.showDate = false;
                    $scope.IntervalDate = "";
                    $scope.PeriodDate = "";
                    $scope.IsPeriodWiseNumber = false;
                    $scope.IsPeriodWise = true;
                    $scope.PPMId = 0;
                    $scope.NoOfDays = 0;
                    $scope.LoaderP2P = false;
                    $scope.showAdd = true;
                    $scope.showUpdate = false;
                    $scope.MaxNavDate = "";
                    $scope.PeriodWiseName = "";
                    $scope.date = new Date();
                    var LogoName = "";
                    var ShowAdvanceSetting = {};
                    ShowAdvanceSetting.LstPlan = [];
                    var SelectedOtherDecimalValue = "";

                    $scope.SelectedNumberFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedAUMDecimalFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedReturnsDecimalFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedNavDecimalFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedOtherDecimalFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedRatiosDecimalFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedNoOfResultPerPage = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedBlankData = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedLandingPage = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedDateFormat = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedScroller = {
                        BscId: 0,
                        BscValue: ""
                    };
                    $scope.SelectedSectorLevel = {
                        BscId: 0,
                        BscValue: ""
                    };
                    var Selected = [];
                    var SelectedNumberFormat = [];
                    var SelectedAUMDecimalFormat = [];
                    var SelectedReturnsDecimalFormat = [];
                    var SelectedNavDecimalFormat = [];
                    var SelectedOtherDecimalFormat = [];
                    var SelectedRatioDecimalFormat = [];
                    var SelectedNoOfResultPerPage = [];
                    var SelectedBlankData = [];
                    var SelectedLandingPage = [];
                    var SelectedDateFormat = [];
                    var SelectedScroller = [];
                    var SelectedSectorLevel = [];

                    $scope.CreatedBy = "";
                    $scope.CreatedDate = "";
                    $scope.ModifiedBy = "";
                    $scope.ModifiedDate = "";
                    $scope.ReportingFormatLogoName = "";
                    $scope.LoaderAppSet = true;
                    $scope.hideLogo = true;
                    var _URL = window.URL || window.webkitURL;
                    $("#file").change(function (e) {
                        var file, img;


                        if ((file = this.files[0])) {
                            img = new Image();
                            img.onload = function () {
                                if (this.width < 165 || this.height < 60) {
                                MFIMsg.AlertHtml("Logo is not in correct dimension. Supported image size is 165 (width) x 60 (height) pixels", MFIAlertType.Information, "OK");
                                    $scope.hideLogo = true;
                                    // $scope.ReportingFormatLogoName = "";
                                    $("#file").val("");
                                    $scope.file = undefined;
                                }
                                // alert(this.width + " " + this.height);
                            };
                            //img.onerror = function () {
                            //    alert("not a valid file: " + file.type);
                            //};
                            img.src = _URL.createObjectURL(file);


                        }

                    });
                    var LoadSchemeCode = LoadSchemeCodes.Call();
                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await AllApplicationSetting.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('AllApplicationSetting', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function getData() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('AllApplicationSetting');
                        //if (data) {
                        //    // Parse and return the data from LocalStorage
                        //    return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//
                    //var getData = AllApplicationSetting.Call();
                    getData().then(function (response) {
                        $scope.LoaderAppSet = false;
                        //var bscCri = response.data.data.LstBasicSelectionCriteria;
                        var bscCri = response.LstBasicSelectionCriteria;
                        $scope.NumberFormatList = $filter('filter')(bscCri, { ScDescription: 'Number Format' });
                        $scope.AUMDecimalList = $filter('filter')(bscCri, { ScDescription: 'AUM Decimal Format' });
                        $scope.ReturnDecimalList = $filter('filter')(bscCri, { ScDescription: 'Returns Decimal Format' });
                        $scope.NavDecimalList = $filter('filter')(bscCri, { ScDescription: 'NAV Decimal Format' });
                        $scope.OtherDecimalList = $filter('filter')(bscCri, { ScDescription: 'Other Decimal Format' });
                        $scope.RatiosDecimalList = $filter('filter')(bscCri, { ScDescription: 'Ratios Decimal Format' });
                        $scope.NoOfResultPerPageList = $filter('filter')(bscCri, { ScDescription: 'No. Of Results per page' });
                        $scope.BlankDataList = $filter('filter')(bscCri, { ScDescription: 'Blank Data' });
                        $scope.LandingPageList = $filter('filter')(bscCri, { ScDescription: 'Landing Page' });
                        $scope.DateFormatList = $filter('filter')(bscCri, { ScDescription: 'Date Format' });
                        $scope.ScrollerList = $filter('filter')(bscCri, { ScDescription: 'Scroller (Fund Dashboard)' });
                        $scope.SectorLevelList = $filter('filter')(bscCri, { ScDescription: 'Sector Level' });
                        //$scope.Header = $filter('filter')(response.data.data.LstHeadervalue, { ScDescription: 'Reporting Format Header' });
                        //$scope.Footer = $filter('filter')(response.data.data.LstFootervalue, { ScDescription: 'Reporting Format Footer' });
                        $scope.Header = $filter('filter')(response.LstHeadervalue, { ScDescription: 'Reporting Format Header' });
                        $scope.Footer = $filter('filter')(response.LstFootervalue, { ScDescription: 'Reporting Format Footer' });

                        //var bscSel = response.data.data.LstBasicSelectionvalue;
                        var bscSel = response.LstBasicSelectionvalue;
                        $scope.SelectedNumberFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'Number Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Number Format' })[0].BscId : 0;
                        $scope.SelectedAUMDecimalFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'AUM Decimal Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'AUM Decimal Format' })[0].BscId : 0;
                        $scope.SelectedReturnsDecimalFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'Returns Decimal Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Returns Decimal Format' })[0].BscId : 0;
                        $scope.SelectedNavDecimalFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'NAV Decimal Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'NAV Decimal Format' })[0].BscId : 0;
                        $scope.SelectedOtherDecimalFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'Other Decimal Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Other Decimal Format' })[0].BscId : 0;
                        $scope.SelectedRatiosDecimalFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'Ratios Decimal Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Ratios Decimal Format' })[0].BscId : 0;
                        $scope.SelectedNoOfResultPerPage.BscId = $filter('filter')(bscSel, { ScDescription: 'No. Of Results per page' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'No. Of Results per page' })[0].BscId : 0;
                        $scope.SelectedBlankData.BscId = $filter('filter')(bscSel, { ScDescription: 'Blank Data' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Blank Data' })[0].BscId : 0;
                        $scope.SelectedLandingPage.BscId = $filter('filter')(bscSel, { ScDescription: 'Landing Page' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Landing Page' })[0].BscId : 0;
                        $scope.SelectedDateFormat.BscId = $filter('filter')(bscSel, { ScDescription: 'Date Format' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Date Format' })[0].BscId : 0;
                        $scope.SelectedScroller.BscId = $filter('filter')(bscSel, { ScDescription: 'Scroller (Fund Dashboard)' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Scroller (Fund Dashboard)' })[0].BscId : 0;
                        $scope.SelectedSectorLevel.BscId = $filter('filter')(bscSel, { ScDescription: 'Sector Level' }).length > 0 ? $filter('filter')(bscSel, { ScDescription: 'Sector Level' })[0].BscId : 0;

                        //var lstdata = response.data.data.LstBasicSelectionvalue;
                        var lstdata = response.LstBasicSelectionvalue;

                        var getData = AllAdvanceSettings.Call();
                        getData.then(function (response) {

                            $scope.details = response.data.data;



                            for (var i = 0; i < $scope.details.length; i++) {

                                for (var j = 0; j < lstdata.length; j++) {
                                    //if (lstdata[j].ScDescription == undefined) {
                                    //    continue
                                    //}
                                    if (lstdata[j].ScDescription == 'Sub Plan Selection') {
                                        if ($scope.details[i].BSCID == lstdata[j].BscId) {
                                            //var data = lstdata[j].BscId;
                                            var name = $scope.details[i].Option;
                                            if (name == "Non-Direct") {
                                                // document.getElementById("#rdDirect").selected = true;
                                                //Element("#rdDirect").ClassNames.add("active")
                                                document.getElementById("rdDirect").classList.remove("active");
                                                document.getElementById("rdAll").classList.remove("active");
                                                document.getElementById("rdNonDirect").classList.add("active");
                                            }
                                            if (name == "All") {
                                                document.getElementById("rdDirect").classList.remove("active");
                                                document.getElementById("rdAll").classList.add("active");
                                                document.getElementById("rdNonDirect").classList.remove("active");
                                            }
                                            // return;
                                        }
                                    }
                                }
                            }


                        },
                            function (stu) {
                                MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            });



                        //var setCreDetls = response.data.data.LstBasicSettingCreationDetails;
                        var setCreDetls = response.LstBasicSettingCreationDetails;
                        $scope.CreatedBy = setCreDetls.length > 0 ? setCreDetls[0].CreatedName : "----";
                        $scope.CreatedDate = setCreDetls.length > 0 ? setCreDetls[0].strcreatedDate : "----";

                        //var setModDetls = response.data.data.LstBasicSettingModifiedDetails;
                        var setModDetls = response.LstBasicSettingModifiedDetails;
                        $scope.ModifiedBy = setModDetls.length > 0 ? setModDetls[0].CreatedName : "----";
                        $scope.ModifiedDate = setModDetls.length > 0 ? setModDetls[0].strModifiedDate : "----";

                        $scope.LogInId = setModDetls[0].LogInId;

                        //var setLogoval = response.data.data.LstLogovalue;
                        var setLogoval = response.LstLogovalue;

                        if (setLogoval.length > 0) {
                            $scope.hideLogo = false;
                            LogoName = setLogoval[0].OfUniqueId + setLogoval[0].FileExtension;

                            $scope.ReportingFormatLogoName = "/Home/GetLogo?FileName=" + setLogoval[0].OfUniqueId + setLogoval[0].FileExtension;
                            //$scope.ReportingFormatLogoName = /*"../Content/ReportingFormatLogo/" +*/"http://localhost:57850/Home/GetLogo?FileName="+setLogoval[0].OfUniqueId + setLogoval[0].FileExtension;

                        }
                        else {
                            //$scope.ReportingFormatLogoName = "http://localhost:57850/Portfolio/Getlogo"
                            //  $scope.ReportingFormatLogoName = "http://localhost:57850/Home/GetLogo?FileName="

                        }

                        //$scope.MaxNavDate = response.data.data.MaxNavDate;
                        $scope.MaxNavDate = response.MaxNavDate;
                    },
                        function (stu) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                        });

                   
                    var param = { "IsPeriodWise": $scope.IsPeriodWise };
                    var getData = P2PPeriodDetails.Call(param);
                    getData.then(function (response) {
                        if (response.data.data != null) {
                            $scope.tableShowIntervalDateWise = true;
                            $scope.LstIntervalOrDateWise = response.data.data;
                        }

                    },
                        function (stu) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                        });
                    $scope.GetValueNumberFormat = function () {
                        if ($scope.SelectedNumberFormat != null) {
                            if ($scope.SelectedNumberFormat.BscId != undefined) {
                                if (SelectedNumberFormat.length > 0)
                                    SelectedNumberFormat = [];
                                SelectedNumberFormat.push($scope.SelectedNumberFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueAUMDecimal = function () {
                        if ($scope.SelectedAUMDecimalFormat != null) {
                            if ($scope.SelectedAUMDecimalFormat.BscId != undefined) {
                                if (SelectedAUMDecimalFormat.length > 0)
                                    SelectedAUMDecimalFormat = [];
                                SelectedAUMDecimalFormat.push($scope.SelectedAUMDecimalFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueReturnDecimal = function () {
                        if ($scope.SelectedReturnsDecimalFormat != null) {
                            if ($scope.SelectedReturnsDecimalFormat.BscId != undefined) {
                                if (SelectedReturnsDecimalFormat.length > 0)
                                    SelectedReturnsDecimalFormat = [];
                                SelectedReturnsDecimalFormat.push($scope.SelectedReturnsDecimalFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueNavDecimal = function () {
                        if ($scope.SelectedNavDecimalFormat != null) {
                            if ($scope.SelectedNavDecimalFormat.BscId != undefined) {
                                if (SelectedNavDecimalFormat.length > 0)
                                    SelectedNavDecimalFormat = [];
                                SelectedNavDecimalFormat.push($scope.SelectedNavDecimalFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueOtherDecimal = function () {
                        if ($scope.SelectedOtherDecimalFormat != null) {
                            if ($scope.SelectedOtherDecimalFormat.BscId != undefined) {
                                if (SelectedOtherDecimalFormat.length > 0)
                                    SelectedOtherDecimalFormat = [];
                                SelectedOtherDecimalFormat.push($scope.SelectedOtherDecimalFormat.BscId);
                                SelectedOtherDecimalValue = $scope.SelectedOtherDecimalFormat.BscValue;
                            }
                        }
                    }
                    $scope.GetValueRatiosDecimal = function () {
                        if ($scope.SelectedRatiosDecimalFormat != null) {
                            if ($scope.SelectedRatiosDecimalFormat.BscId != undefined) {
                                if (SelectedRatioDecimalFormat.length > 0)
                                    SelectedRatioDecimalFormat = [];
                                SelectedRatioDecimalFormat.push($scope.SelectedRatiosDecimalFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueNoOfResultPerPage = function () {
                        if ($scope.SelectedNoOfResultPerPage != null) {
                            if ($scope.SelectedNoOfResultPerPage.BscId != undefined) {
                                if (SelectedNoOfResultPerPage.length > 0)
                                    SelectedNoOfResultPerPage = [];
                                SelectedNoOfResultPerPage.push($scope.SelectedNoOfResultPerPage.BscId);
                            }
                        }
                    }
                    $scope.GetValueBlankData = function () {
                        if ($scope.SelectedBlankData != null) {
                            if ($scope.SelectedBlankData.BscId != undefined) {
                                if (SelectedBlankData.length > 0)
                                    SelectedBlankData = [];
                                SelectedBlankData.push($scope.SelectedBlankData.BscId);
                            }
                        }
                    }
                    $scope.GetValueLandingPage = function () {
                        if ($scope.SelectedLandingPage != null) {
                            if ($scope.SelectedLandingPage.BscId != undefined) {
                                if (SelectedLandingPage.length > 0)
                                    SelectedLandingPage = [];
                                SelectedLandingPage.push($scope.SelectedLandingPage.BscId);
                            }
                        }

                    }
                    $scope.GetValueDateFormat = function () {
                        if ($scope.SelectedDateFormat != null) {
                            if ($scope.SelectedDateFormat.BscId != undefined) {
                                if (SelectedDateFormat.length > 0)
                                    SelectedDateFormat = [];
                                SelectedDateFormat.push($scope.SelectedDateFormat.BscId);
                            }
                        }
                    }
                    $scope.GetValueScroller = function () {
                        if ($scope.SelectedScroller != null) {
                            if ($scope.SelectedScroller.BscId != undefined) {
                                if (SelectedScroller.length > 0)
                                    SelectedScroller = [];
                                SelectedScroller.push($scope.SelectedScroller.BscId);
                            }
                        }
                    }
                    $scope.GetValueSectorLevel = function () {
                        if ($scope.SelectedSectorLevel != null) {
                            if ($scope.SelectedSectorLevel.BscId != undefined) {
                                if (SelectedSectorLevel.length > 0)
                                    SelectedSectorLevel = [];
                                SelectedSectorLevel.push($scope.SelectedSectorLevel.BscId);
                            }
                        }
                    }






                    $scope.FunctNmae = function (Option) {

                        ShowAdvanceSetting.LstPlan = [];
                        // if (Option != "All") {
                        ShowAdvanceSetting.LstPlan.push(Option);
                        for (var i = 0; i < ShowAdvanceSetting.LstPlan.length; i++) {
                            if (Option == ShowAdvanceSetting.LstPlan[i]) {
                                for (var j = 0; j < $scope.details.length; j++) {
                                    if (Option == $scope.details[j].Option) {
                                        Selected.push($scope.details[j].BSCID);
                                    }
                                }
                            }
                        }

                    }

                    $scope.save = function () {
                        if ($scope.SelectedNumberFormat == null) {
                            MFIMsg.Alert("Please select number format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedAUMDecimalFormat == null) {
                            MFIMsg.Alert("Please select AUM decimal format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedReturnsDecimalFormat == null) {
                            MFIMsg.Alert("Please select returns decimal format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedNavDecimalFormat == null) {
                            MFIMsg.Alert("Please select NAV decimal format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedOtherDecimalFormat == null) {
                            MFIMsg.Alert("Please select other decimal format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedRatiosDecimalFormat == null) {
                            MFIMsg.Alert("Please select ratio decimal format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedNoOfResultPerPage == null) {
                            MFIMsg.Alert("Please select no of result per page ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedBlankData == null) {
                            MFIMsg.Alert("Please select blank data ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedLandingPage == null) {
                            MFIMsg.Alert("Please select landing page ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedDateFormat == null) {
                            MFIMsg.Alert("Please select date format ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedScroller == null) {
                            MFIMsg.Alert("Please select scroller ", "Error", "OK");
                            return;
                        }
                        if ($scope.SelectedSectorLevel == null) {
                            MFIMsg.Alert("Please select sector level ", "Error", "OK");
                            return;
                        }

                        if (SelectedNumberFormat.length > 0)
                            Selected.push(SelectedNumberFormat);
                        if (SelectedAUMDecimalFormat.length > 0)
                            Selected.push(SelectedAUMDecimalFormat);
                        if (SelectedReturnsDecimalFormat.length > 0)
                            Selected.push(SelectedReturnsDecimalFormat);
                        if (SelectedNavDecimalFormat.length > 0)
                            Selected.push(SelectedNavDecimalFormat);
                        if (SelectedOtherDecimalFormat.length > 0)
                            Selected.push(SelectedOtherDecimalFormat);
                        if (SelectedRatioDecimalFormat.length > 0)
                            Selected.push(SelectedRatioDecimalFormat);
                        if (SelectedNoOfResultPerPage.length > 0)
                            Selected.push(SelectedNoOfResultPerPage);
                        if (SelectedBlankData.length > 0)
                            Selected.push(SelectedBlankData);
                        if (SelectedLandingPage.length > 0)
                            Selected.push(SelectedLandingPage);
                        if (SelectedDateFormat.length > 0)
                            Selected.push(SelectedDateFormat);
                        if (SelectedScroller.length > 0)
                            Selected.push(SelectedScroller);
                        if (SelectedSectorLevel.length > 0)
                            Selected.push(SelectedSectorLevel);

                        var headerDes = $scope.Header.length > 0 ? $scope.Header[0].Description : "";
                        var footerDes = $scope.Footer.length > 0 ? $scope.Footer[0].Description : "";
                        var SelectedParam = { "BSCIds": Selected, "HeaderDescription": headerDes, "FooterDescription": footerDes };
                        if ($scope.file != undefined) {
                            var filenamevals = $scope.file.name.split(".");
                            if (filenamevals[1].toLowerCase() != "jpg" && filenamevals[1].toLowerCase() != "png") {
                                MFIMsg.Alert("Logo format should be jpg|png ", "Error", "OK");
                                return;
                            }
                        }
                        angular.element('#btnSaveappseting').attr("disabled", true);
                        var getData = SaveApplicationSetting.Call(SelectedParam);
                        getData.then(function (response) {
                            if (response.data.Success) {
                                localStorage.setItem("DecimalFormat_Pivot", SelectedOtherDecimalValue);
                            }
                            if ($scope.file != undefined) {
                                var filenamevals = $scope.file.name.split(".");
                                if (filenamevals[1].toLowerCase() != "jpg" && filenamevals[1].toLowerCase() != "png") {
                                    MFIMsg.Alert("Logo format should be jpg|png ", "Error", "OK");
                                    angular.element('#btnSaveappseting').attr("disabled", false);
                                    return;
                                }
                                var LogoParam = { "BSCIds": Selected, "HeaderDescription": headerDes, "FooterDescription": footerDes, "FileExtension": "." + filenamevals[1] };
                                var getLogoData = SaveApplicationSetting.Call(LogoParam);

                                getLogoData.then(function (response) {
                                    $http({
                                        method: 'POST',
                                        url: '/Home/UploadReportingFormatLogo',
                                        headers: {
                                            'Content-Type': undefined
                                        },
                                        transformRequest: function (data, headersGetter) {
                                            var formData = new FormData();
                                            angular.forEach(data, function (value, key) {
                                                formData.append(key, value);
                                            });
                                            return formData;
                                        },
                                        data: { "files": $scope.file, "Id": response.data.data.UniqueLogoID, "FileExtension": response.data.data.FileExtension }

                                    }).then(function successCallback(response) {
                                        if (!response.data.Status) {
                                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error, "OK");
                                            angular.element('#btnSaveappseting').attr("disabled", false);
                                            return;
                                        }
                                        angular.element('#btnSaveappseting').attr("disabled", false);
                                        Selected = [];
                                        //MFIMsg.Alert("Data and Logo saved successfully ", "Success", "OK");
                                        MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Success, "OK");
                                        $scope.hideLogo = false;
                                        $scope.ReportingFormatLogoName = "/Home/GetLogo?FileName=" + response.data.FileName;
                                        LogoName = response.data.FileName;
                                        // $scope.ReportingFormatLogoName = /*"../Content/ReportingFormatLogo/" +*/"http://localhost:57850/Home/GetLogo?FileName=" + response.data;
                                        $scope.date = new Date();
                                    },
                                        function errorCallback(response) {
                                            MFIMsg.AlertHtml("Oops, an error occurred while uploading logo !!!", MFIAlertType.Error, "OK");
                                            angular.element('#btnSaveappseting').attr("disabled", false);
                                        });
                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Logo Save failed ", MFIAlertType.Error, "OK");
                                        angular.element('#btnSaveappseting').attr("disabled", false);

                                    });
                            }
                            else {
                                localStorage.removeItem('AllApplicationSetting');
                                Selected = [];
                                MFIMsg.AlertHtml("Data Saved Successfully ", MFIAlertType.Success, "OK");
                                angular.element('#btnSaveappseting').attr("disabled", false);
                            }

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Save failed !!!", MFIAlertType.Error, "OK");
                                angular.element('#btnSaveappseting').attr("disabled", false);
                            });
                    }

                    var OptionsDateRange = {
                        showDropdowns: true,
                        autoApply: true,
                        locale: {
                            format: 'DD MMM YYYY'
                        }
                    };
                    var OptionsSingleDate = {
                        singleDatePicker: true,
                        showDropdowns: true,
                        autoApply: true,
                        locale: {
                            format: 'DD MMM YYYY'
                        },
                        drops: 'up'
                    };
                    function ApplyDateRange(start, end, label) {
                    }

                    function ApplySingleDate(start, end, label) {
                    }

                    angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                    angular.element('#IntervalDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                    OptionsSingleDate.maxDate = new Date($scope.IntervalDate);
                    angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);

                    $scope.IntervalWiseData = function () {
                        $scope.showAdd = true;
                        $scope.showUpdate = false;
                        $scope.LoaderP2P = true;
                        $scope.RadioSelectionIntervalWise = true;
                        $scope.RadioSelectionDateWise = false;
                        $scope.showPeriodText = true;
                        $scope.showPeriodDate = false;
                        $scope.DayInterval = "Interval";
                        $scope.showInterval = true;
                        $scope.showDate = false;
                        $scope.IsPeriodWiseNumber = false;
                        $scope.LstIntervalOrDateWise = [];
                        $scope.IsPeriodWise = true;
                        $scope.PeriodWisePeriod = "";
                        $scope.PeriodWiseNumber = "";
                        $scope.PeriodWiseSelectedInterval = "";
                        var param = { "IsPeriodWise": $scope.IsPeriodWise };
                        var getData = P2PPeriodDetails.Call(param);
                        getData.then(function (response) {
                            $scope.LoaderP2P = false;
                            if (response.data.data != null) {
                                $scope.tableShowIntervalDateWise = true;
                                $scope.LstIntervalOrDateWise = response.data.data;
                            }

                        },
                            function (stu) {
                                $scope.LoaderP2P = false;
                                MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            });
                    }

                    $scope.DateWiseData = function () {
                        $scope.showAdd = true;
                        $scope.showUpdate = false;
                        $scope.LoaderP2P = true;
                        $scope.RadioSelectionIntervalWise = false;
                        $scope.RadioSelectionDateWise = true;
                        $scope.showPeriodText = false;
                        $scope.showPeriodDate = true;
                        $scope.DayInterval = "Date";
                        $scope.showInterval = false;
                        $scope.showDate = true;
                        $scope.IsPeriodWiseNumber = true;
                        $scope.LstIntervalOrDateWise = [];
                        $scope.IsPeriodWise = false;
                        OptionsSingleDate.maxDate = new Date($scope.MaxNavDate);
                        angular.element('#IntervalDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                        var today = new Date($scope.MaxNavDate);
                        $scope.IntervalDate = today.toString("dd MMM yyyy");
                        $scope.PeriodDate = today.toString("dd MMM yyyy");
                        var date2 = new Date($scope.IntervalDate);
                        var date1 = new Date($scope.PeriodDate);
                        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                        $scope.PeriodWiseNumber = Math.ceil(timeDiff / (1000 * 3600 * 24));
                        $scope.IsPeriodWiseNumber = true;
                        var param = { "IsPeriodWise": $scope.IsPeriodWise };
                        var getData = P2PPeriodDetails.Call(param);
                        getData.then(function (response) {
                            $scope.LoaderP2P = false;
                            if (response.data.data != null) {
                                $scope.tableShowIntervalDateWise = true;
                                $scope.LstIntervalOrDateWise = response.data.data;
                            }

                        },
                            function (stu) {
                                $scope.LoaderP2P = false;
                                MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            });
                    }

                    $scope.addIntervalOrDateWise = function () {
                        if ($scope.RadioSelectionIntervalWise == true) {
                            if ($scope.PeriodWisePeriod == "") {
                                MFIMsg.Alert("Please enter period name", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseNumber == "") {
                                MFIMsg.Alert("Please enter number", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWisePeriod != $scope.PeriodWiseNumber) {
                                MFIMsg.Alert("Period and Number must be same", "Error", "OK");
                                return;
                            }
                            if ($scope.IntervalDate == "") {
                                MFIMsg.Alert("Please enter interval", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseSelectedInterval == "yyyy") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -365);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 365);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Year"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Years"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "mm") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -30);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 30);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Month"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Months"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "ww") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -7);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 7);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Week"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Weeks"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "d") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -1);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 1);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Day"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Days"
                            }
                            if ($scope.PeriodWiseNumber != "") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.PeriodWiseNumber = ($scope.PeriodWiseNumber * -1);
                            }
                            var param = { "PRMId": $scope.PPMId, "PeriodName": $scope.PeriodWiseName, "Number": $scope.PeriodWiseNumber, "Interval": $scope.PeriodWiseSelectedInterval, "IsPeriodWise": $scope.IsPeriodWise, "NoOfDays": $scope.NoOfDays };
                            var getData = SaveP2PPeriod.Call(param);
                            getData.then(function (response) {
                                if (response.data.data != null) {
                                    MFIMsg.Alert("Successfully created ", "Success", "OK");
                                    $scope.tableShowIntervalDateWise = true;
                                    $scope.LstIntervalOrDateWise = response.data.data;
                                    $scope.PeriodWisePeriod = "";
                                    $scope.PeriodWiseNumber = "";
                                    $scope.PeriodWiseSelectedInterval = "";
                                }
                                else {
                                    MFIMsg.Alert(response.data.Message + " ", "Success", "OK");
                                }

                            },
                                function (stu) {
                                    MFIMsg.Alert("Data fetch failed for interval wise !!!", "Error", "OK");
                                });

                        }

                        if ($scope.RadioSelectionDateWise == true) {
                            if ($scope.PeriodDate == $scope.IntervalDate) {
                                MFIMsg.Alert("Both period date and interval date are same ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodDate == "") {
                                MFIMsg.Alert("Please enter period name ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseSelectedInterval == "d") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -1);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 1);
                            }
                            if ($scope.PeriodWiseNumber != "") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.PeriodWiseNumber = ($scope.PeriodWiseNumber * -1);
                            }
                            $scope.PeriodWisePeriod = $scope.PeriodDate;
                            var param = { "PRMId": $scope.PPMId, "PeriodName": $scope.PeriodWisePeriod, "Number": $scope.PeriodWiseNumber, "Interval": $scope.PeriodWiseSelectedInterval, "IsPeriodWise": $scope.IsPeriodWise, "NoOfDays": $scope.NoOfDays };
                            var getData = SaveP2PPeriod.Call(param);
                            getData.then(function (response) {
                                if (response.data.data != null) {
                                    MFIMsg.Alert("Successfully created ", "Success", "OK");
                                    $scope.tableShowIntervalDateWise = true;
                                    $scope.LstIntervalOrDateWise = response.data.data;
                                    OptionsSingleDate.maxDate = new Date($scope.MaxNavDate);
                                    angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                                    OptionsSingleDate.maxDate = new Date($scope.MaxNavDate);
                                    angular.element('#IntervalDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                                    var today = new Date($scope.MaxNavDate);
                                    $scope.IntervalDate = today.toString("dd MMM yyyy");
                                    $scope.PeriodDate = today.toString("dd MMM yyyy");
                                    var date2 = new Date($scope.IntervalDate);
                                    var date1 = new Date($scope.PeriodDate);
                                    var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                                    $scope.PeriodWiseNumber = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                }
                                else {
                                    MFIMsg.Alert(response.data.Message + " ", "Success", "OK");
                                }

                            },
                                function (stu) {
                                    MFIMsg.Alert("Data fetch failed for date wise !!!", "Error", "OK");
                                });
                        }
                    }

                    $scope.updateIntervalOrDateWise = function () {
                        if ($scope.RadioSelectionIntervalWise == true) {
                            if ($scope.PeriodWisePeriod == "") {
                                MFIMsg.Alert("Please enter period name ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseNumber == "") {
                                MFIMsg.Alert("Please enter number ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWisePeriod != $scope.PeriodWiseNumber) {
                                MFIMsg.Alert("Period and Number must be same ", "Error", "OK");
                                return;
                            }
                            if ($scope.IntervalDate == "") {
                                MFIMsg.Alert("Please enter interval ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseSelectedInterval == "yyyy") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -365);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 365);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Year"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Years"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "mm") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -30);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 30);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Month"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Months"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "ww") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -7);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 7);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Week"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Weeks"
                            }
                            if ($scope.PeriodWiseSelectedInterval == "d") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -1);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 1);
                                if ($scope.PeriodWisePeriod <= 1)
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Day"
                                else
                                    $scope.PeriodWiseName = $scope.PeriodWisePeriod + " Days"
                            }
                            if ($scope.PeriodWiseNumber != "") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.PeriodWiseNumber = ($scope.PeriodWiseNumber * -1);
                            }
                            var param = { "PRMId": $scope.PPMId, "PeriodName": $scope.PeriodWiseName, "Number": $scope.PeriodWiseNumber, "Interval": $scope.PeriodWiseSelectedInterval, "IsPeriodWise": $scope.IsPeriodWise, "NoOfDays": $scope.NoOfDays };
                            var getData = SaveP2PPeriod.Call(param);
                            getData.then(function (response) {
                                if (response.data.data != null) {
                                    MFIMsg.Alert("Successfully updated ", "Success", "OK");
                                    $scope.tableShowIntervalDateWise = true;
                                    $scope.LstIntervalOrDateWise = response.data.data;
                                    $scope.PeriodWisePeriod = "";
                                    $scope.PeriodWiseNumber = "";
                                    $scope.PeriodWiseSelectedInterval = "";
                                    $scope.showAdd = true;
                                    $scope.showUpdate = false;
                                    $scope.PPMId = 0;
                                }
                                else {
                                    MFIMsg.Alert(response.data.Message + " ", "Success", "OK");
                                }

                            },
                                function (stu) {
                                    MFIMsg.Alert("Data fetch failed for interval wise !!!", "Error", "OK");
                                });

                        }

                        if ($scope.RadioSelectionDateWise == true) {
                            if ($scope.PeriodDate == $scope.IntervalDate) {
                                MFIMsg.Alert("Both period date and interval date are same ", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodDate == "") {
                                MFIMsg.Alert("Please enter period name !!!", "Error", "OK");
                                return;
                            }
                            if ($scope.PeriodWiseSelectedInterval == "d") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * -1);
                                else
                                    $scope.NoOfDays = ($scope.PeriodWiseNumber * 1);
                            }
                            if ($scope.PeriodWiseNumber != "") {
                                if ($scope.PeriodWiseNumber > 0)
                                    $scope.PeriodWiseNumber = ($scope.PeriodWiseNumber * -1);
                            }
                            $scope.PeriodWisePeriod = $scope.PeriodDate;
                            var param = { "PRMId": $scope.PPMId, "PeriodName": $scope.PeriodWisePeriod, "Number": $scope.PeriodWiseNumber, "Interval": $scope.PeriodWiseSelectedInterval, "IsPeriodWise": $scope.IsPeriodWise, "NoOfDays": $scope.NoOfDays };
                            var getData = SaveP2PPeriod.Call(param);
                            getData.then(function (response) {
                                if (response.data.data != null) {
                                    MFIMsg.Alert("Successfully updated ", "Success", "OK");
                                    $scope.tableShowIntervalDateWise = true;
                                    $scope.LstIntervalOrDateWise = response.data.data;
                                    OptionsSingleDate.maxDate = new Date($scope.MaxNavDate);
                                    angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                                    OptionsSingleDate.maxDate = new Date($scope.MaxNavDate);
                                    angular.element('#IntervalDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                                    var today = new Date($scope.MaxNavDate);
                                    $scope.IntervalDate = today.toString("dd MMM yyyy");
                                    $scope.PeriodDate = today.toString("dd MMM yyyy");
                                    var date2 = new Date($scope.IntervalDate);
                                    var date1 = new Date($scope.PeriodDate);
                                    var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                                    $scope.PeriodWiseNumber = Math.ceil(timeDiff / (1000 * 3600 * 24));
                                    $scope.showAdd = true;
                                    $scope.showUpdate = false;
                                    $scope.PPMId = 0;
                                }
                                else {
                                    MFIMsg.Alert(response.data.Message + " ", "Success", "OK");
                                }

                            },
                                function (stu) {
                                    MFIMsg.Alert("Data fetch failed for date wise !!!", "Error", "OK");
                                });
                        }
                    }

                    $scope.edit = function (data) {
                        $scope.showAdd = false;
                        $scope.showUpdate = true;
                        if ($scope.IsPeriodWise == true) {
                            var q = data.PeriodName.indexOf(" ");
                            var Period = data.PeriodName.substring(0, q);
                            $scope.PeriodWisePeriod = Period;
                            $scope.PeriodWiseNumber = Math.abs(data.Number);
                            $scope.PeriodWiseSelectedInterval = data.ShowInterval;
                            $scope.PPMId = data.PRMId;
                        }
                        else {
                            var date2 = new Date(data.PeriodName);
                            date2.setDate(date2.getDate() + (data.Number * -1));
                            OptionsSingleDate.maxDate = new Date(date2);
                            angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                            $scope.PeriodDate = data.PeriodName;
                            $scope.PeriodWiseNumber = data.Number;
                            $scope.IntervalDate = date2.toString("dd MMM yyyy");
                            $scope.PPMId = data.PRMId;
                        }

                    }

                    $scope.delete = function (data) {
                        if (data.IsPrime == true) {
                            MFIMsg.AlertHtml(WarningAlert + "You have no permission to delete prime period ", "Error", "OK");
                        }
                        else {
                            MFIMsg.Confirm("You want to delete", "MFI360 Explorer", "Yes", "No").then(function () {
                                $scope.PPMId = data.PRMId;
                                var param = { "PRMId": $scope.PPMId, "IsPeriodWise": $scope.IsPeriodWise };
                                var getData = P2PperiodDelete.Call(param);
                                getData.then(function (response) {
                                    if (response.data.data != null) {
                                        MFIMsg.AlertHtml("Successfully deleted ", MFIAlertType.Success, "OK");
                                        $scope.tableShowIntervalDateWise = true;
                                        $scope.LstIntervalOrDateWise = response.data.data;
                                        $scope.PeriodWisePeriod = "";
                                        $scope.PeriodWiseNumber = "";
                                        $scope.PeriodWiseSelectedInterval = "";
                                        $scope.PPMId = 0;
                                    }

                                },
                                    function (stu) {
                                        MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                                    });

                            }, function () {

                            })
                        }

                    }

                    $scope.intervalDateChange = function () {
                        OptionsSingleDate.maxDate = new Date($scope.IntervalDate);
                        angular.element('#PeriodDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                        var date2 = new Date($scope.IntervalDate);
                        var date1 = new Date($scope.PeriodDate);
                        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                        $scope.PeriodWiseNumber = Math.ceil(timeDiff / (1000 * 3600 * 24));
                        $scope.PeriodWiseSelectedInterval = "d";
                    }

                    $scope.periodDateChange = function () {
                        var date2 = new Date($scope.IntervalDate);
                        var date1 = new Date($scope.PeriodDate);
                        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
                        $scope.PeriodWiseNumber = Math.ceil(timeDiff / (1000 * 3600 * 24));
                        $scope.PeriodWiseSelectedInterval = "d";
                    }

                    $scope.closeAppSetting = function () {
                        var screenWidth = window.innerWidth;
                        if (screenWidth <= 767) {
                            $('#appSettingDetails').hide();
                            $("#settingContainer").show();
                        } else if (screenWidth >= 768 && screenWidth <= 980) {
                            $('#appSettingDetails').hide();
                        } else {
                            $('#appSettingDetails').delay(200).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                $('#appSettingDetails').hide();
                            });
                        }
                    };

                    $scope.toggleAppSettingPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = $('#expand-collapse-block');
                        var $details = $('#appSettingDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (window.innerWidth > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (window.innerWidth > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };


                    //$scope.FN_RemoveLogo = function () {
                    //    MFIMsg.Confirm("Do you want to remove the logo?", "", "Yes", "No").then(function () {
                    //        var obj = {};
                    //        obj.LoginId = $scope.LogInId;
                    //        var AsDeleteLogo = DeleteLogo.Call(obj);
                    //       // AsDeleteLogo.then(function (response) {
                    //       // MFIMsg.Alert("Logo deleted successfully", "Icra Message", "OK");
                    //        //    $scope.ViewClient.FN_Search();
                    //        //    $scope.GetClientAll();
                    //    },
                    //        function (stu) { debugger; alert("Logo not removed"); });
                    //},
                    //    function () { }


                    $scope.FN_RemoveLogo = function () {
                        MFIMsg.Confirm("Do you want to remove the logo?", "", "Yes", "No").then(function () {
                            //$scope.ViewClient.LstSearchData = [];
                            //var obj = {};
                            // $scope.LoginId = $scope.LogInId;
                            var AsDeleteLogo = DeleteLogo.Call();
                            AsDeleteLogo.then(function (response) {
                                if (response.data.Success == true) {

                                    $http({
                                        url: "/Home/DeleteLogo?FileName=" + LogoName,
                                        method: "POST"
                                    }).then(function successCallback(response) {
                                        MFIMsg.Alert("Logo deleted successfully", "Icra Message", "OK");
                                        $scope.hideLogo = true;
                                        $scope.ReportingFormatLogoName = "/Home/GetLogo?FileName=";
                                    });

                                    // &CurrentDate={{date}}
                                }

                                //$scope.ReportingFormatLogoName = "../Content/ReportingFormatLogo/no-logo.png" /*+ response.data*/ /*+ "?" + new Date()*/;
                            },
                                function (stu) { debugger; alert("Records gathering failed!"); });
                        },
                            //function () { }
                        );
                    }
                }, 0);
            }
        };
    }
]);