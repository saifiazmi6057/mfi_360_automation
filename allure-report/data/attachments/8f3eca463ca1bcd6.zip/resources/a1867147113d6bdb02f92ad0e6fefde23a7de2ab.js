SharedCommon.filter('startWith', function () {
    return function (items, char,keyname) {
        if (char != undefined)
        {
            var filtered = [];
            var prefixlen = char.length;
            var match = new RegExp(char, 'i');


            var keys = [];
            angular.forEach(items, function (item) {
                // debugger;
                var key = item[keyname];

                if (match.test(key.substring(0, prefixlen))) {
                    filtered.push(item);
                }
            });

            return filtered;
        }
        else
        {
            return items;
        }
    };
});
//SharedCommon.filter('filterFunctionn', function () {
//    return function (items, selectedMFName) {
//        if (!angular.isUndefinedOrNullOrEmpty(selectedMFName)) {
//            var filtered = [];
//            angular.forEach(items, function (item) {
//                if (item.MfId == selectedMFName.Id) {
//                    filtered.push(item);
//                }
//            });
//            return filtered;
//        }
//        else {
//            return items;
//        }
//    };
//});


