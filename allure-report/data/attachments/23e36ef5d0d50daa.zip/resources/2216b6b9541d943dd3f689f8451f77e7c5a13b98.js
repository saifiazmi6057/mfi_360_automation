SharedServices.service('GetdataForQuaterlyCompReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetQuaterlyCompReportData',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetDateListForQuaterlyCompReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetMaxPortMonth?IsQuaterly=' + obj,
            method: 'Get',
            //data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetAMCListForQuaterlyCompReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetForwardLookingData',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

// SharedServices.service('PortfolioOptimizationInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//     this.Call = function (obj) {  
//         return $http({
//             url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PortfolioOptimizationData',
//             method: 'POST',
//             data: $.param(obj)
//         });
//     }
// }]);

// SharedServices.service('PostDeleteSelectedSchemeList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//     this.Call = function (obj) {
//         return $http({
//             method: "POST",
//             url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PostDeleteSelectedSchemeList',
//             data: $.param(obj)
//         });
//     }
// }]);