//var ServiceStock = angular.module('ServiceStock', []);

//ServiceStock.config(BaseServiceConfig);

//--------------------- Stock Holding ---------------------
SharedServices.service('SearchCompanysData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (querysearch, stockExchange) {
        var data = {};
        data.Query = querysearch;
        data.Exchange = stockExchange;
        return $http({
            //url: 'http://localhost:56543/api/ApiStock/SearchCompanys?Query=' + querysearch + '&Exchange=' + stockExchange,
            url: ApiInfo.BaseApiUrl + 'ApiStock/SearchCompanysData',
            data: $.param(data),
            method: 'POST'
        });
    }

}]);

SharedServices.service('SearchCompanys', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (querysearch, stockExchange) {
        var data = {};
        data.Query = querysearch;
        data.Exchange = stockExchange;
        return $http({
            //url: 'http://localhost:56543/api/ApiStock/SearchCompanys?Query=' + querysearch + '&Exchange=' + stockExchange,
            url: ApiInfo.BaseApiUrl + 'ApiStock/SearchCompanys',
            data: $.param(data),
            method: 'POST'
        });
    }

}]);

SharedServices.service('GetCompanyStockDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (companyId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyStockDetails?companyId=' + companyId,
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetCompanyStockDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (groupCompanyId, companyId, ISIN, RecordId, SearchTypeSel) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyStockDetailsAdvance?grpCompanyId=' + groupCompanyId + '&companyId=' + companyId + '&SearchType=' + SearchTypeSel + '&RecordId=' + RecordId + '&ISIN=' + ISIN,
            method: 'GET'
        });
    }

}]);



//TODO URL
SharedServices.service('ExportStockDetailsToExcel', ['$http', 'ApiInfo', '$httpParamSerializerJQLike', function ($http, ApiInfo, $httpParamSerializerJQLike) {
    this.Call = function (companiesStockDetails) {
        return $http({
            method: 'post',
            url: ApiInfo.BaseApiUrl + 'ApiStock/StockLiqAnalysisDetailExport',
            data: $httpParamSerializerJQLike(companiesStockDetails),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }

}]);

//ServiceStock.service('AMCBasicDetails', ['$http', function ($http) {

//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: "", //url: 'http://localhost:56543/api/ApiAmc/AMCBasicDetails',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    }

//}]);
//--------------------- End Stock Holding ---------------------

//--------------------- Stock Holding Dashboard ---------------------
SharedServices.service('GetCompanyStockHolding', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (companyId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyStockHolding?companyId=' + companyId,
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetCompanyStockPriceForGraph', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (companyId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyStockPriceForGraph?companyId=' + companyId,
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetCompanyStockInvestment', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (companyId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyStockInvestment?companyId=' + companyId,
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetCompanyAMCHolding', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (companyId, period) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetCompanyAMCHolding?companyId=' + companyId + '&period=' + period,
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetFundHoldingDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (CompanyId, AMCId, FundPeriod) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiStock/GetFundHoldingDetails?companyId=' + CompanyId + '&AMCId=' + AMCId + "&FundPeriod=" + FundPeriod,
            method: 'GET'
        });
    }

}]);
//TODO URL
SharedServices.service('ExportAMCHoldingToExcel', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {
    this.Call = function (companiesAMCDetails) {
        return $http({
            method: 'post',
            url: '/Stock/ExportAMCHoldingToExcel',
            data: $httpParamSerializerJQLike(companiesAMCDetails),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }

}]);

//TODO URL
SharedServices.service('ExportFundsHoldingToExcel', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {
    this.Call = function (companiesFundsDetails) {
        return $http({
            method: 'post',
            url: '/Stock/ExportFundsHoldingToExcel',
            data: $httpParamSerializerJQLike(companiesFundsDetails),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }

}]);
//--------------------- End Stock Holding Dashboard ---------------------