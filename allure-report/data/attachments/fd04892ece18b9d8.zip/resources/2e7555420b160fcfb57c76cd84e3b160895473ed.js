SharedDeractives.directive('transposeTableDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetUserSelectedSchemes',
    'GetUserSetByLoginId', 'GetMyWatchListSchemes', 'MFIMsg', '$filter', 'GetSchemeSetByName', 'GetAllCompositeSchSettings',
    function ($http, $q, $timeout, ApiInfo, GetUserSelectedSchemes, GetUserSetByLoginId, GetMyWatchListSchemes, MFIMsg, $filter, GetSchemeSetByName, GetAllCompositeSchSettings) {
        return {
            restrict: 'AE',
            scope: {
                table: '=?',
                pagingRowNo: '=?'
            },
            template: `
            <div>
                <div class="table-responsive" id="tblTranspose">
                    <table  id="table_{{tableUUID}}" class="main-table table table-bordered">
                        <thead>
                            <tr ng-repeat="headerRow in table.Thead">
                                <th ng-if="header.IsHidden !== true" ng-repeat="header in headerRow" style="white-space: nowrap; text-align: center" colspan="{{::header.Colspan}}" rowspan="{{::header.Rowspan}}" ng-bind-html="(header.InnerHtml || header.Value)">
                                    
                                </th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr ng-repeat="Row in table.TbodySliced">
                                <td ng-if="cell.IsHidden !== true" ng-repeat="cell in Row" ng-style="cell.StyleProps" style="white-space: nowrap; text-align: {{cell.IsNumber ?  'center' : 'left'}}" colspan="{{::cell.Colspan}}" rowspan="{{::cell.Rowspan}}" ng-bind-html="(cell.InnerHtml || cell.Value)">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <section layout="row" layout-padding="" ng-show="paging.total>1">
                    <cl-paging flex cl-pages="paging.total" cl-steps="6" cl-page-changed="paging.onPageChanged()" cl-align="center center" cl-current-page="paging.current"></cl-paging>
                </section>
            </div>
            `,
            /**
             * 
             * @param { ScopeTransposeTable } $scope
             * @param {any} $element
             * @param {any} $attrs
             */
            link: function ($scope, $element, $attrs) {
                let str = `<thead /*md-virtual-repeat-container md-orient-horizontal=""*/>
                            <tr ng-repeat="headerRow in table.Thead">
                                <th /*md-virtual-repeat="header in headerRow" md-item-size="10"*/ /*md-on-demand="true"*/ ng-repeat="header in headerRow" colspan="{{::header.Colspan}}" rowspan="{{::header.Rowspan}}">
                                    {{::header.Value}}
                                </th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr /*md-virtual-repeat-container md-orient-horizontal=""*/ ng-repeat="Row in table.TbodySliced">
                                <td /*md-virtual-repeat="cell in Row" md-item-size="10"*/ /*md-on-demand="true"*/ ng-repeat="cell in Row" ng-style="cell.StyleProps" colspan="{{::cell.Colspan}}" rowspan="{{::cell.Rowspan}}">
                                    {{::cell.Value}}
                                </td>
                            </tr>
                        </tbody>`;
                const generateUUID = () => {
                    let
                        d = new Date().getTime(),
                        d2 = ((typeof performance !== 'undefined') && performance.now && (performance.now() * 1000)) || 0;
                    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
                        let r = Math.random() * 16;
                        if (d > 0) {
                            r = (d + r) % 16 | 0;
                            d = Math.floor(d / 16);
                        } else {
                            r = (d2 + r) % 16 | 0;
                            d2 = Math.floor(d2 / 16);
                        }
                        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
                    });
                };
                $scope.tableUUID = generateUUID();
                $scope.pagingRowNo = Math.max(20, $scope.pagingRowNo ?? ($scope.table?.Tbody?.length || 0));
                $scope.DataSet = {
                    /**
                     * @param {number} index
                     */
                    getItemAtIndex(index) {
                        return $scope.table.Tbody
                    }
                }
                InitPaging();
                $scope.$watch('table', (newVal, oldVal) => {
                    $scope.pagingRowNo = $scope.pagingRowNo || ($scope.table?.Tbody?.length || 0);
                    InitPaging();
                });
                function InitPaging() {
                    $scope.paging = {
                        total: Math.ceil(($scope.table?.Tbody?.length || 0) / $scope.pagingRowNo),
                        current: 1,
                        onPageChanged: () => {
                            const start = $scope.paging.startIndex();
                            ($scope.table ??= {}).TbodySliced = $scope.table?.Tbody?.slice(start, start + $scope.pagingRowNo) ?? [];
                            ModifyStartingHiddenCell();
                        },
                        startIndex: () => ($scope.paging.current - 1) * $scope.pagingRowNo,
                    }
                    $scope.paging.onPageChanged();
                }
                function ModifyStartingHiddenCell() {
                    if ($scope.paging.startIndex() === 0)
                        return;
                    for (let cellNo = 0; cellNo < ($scope.table.TbodySliced[0]?.length || 0); cellNo++) {
                        /** @type {Cell} */
                        const cell = $scope.table.TbodySliced[0][cellNo];
                        if (cell.IsHidden === true) {
                            const startingCell = FindStartingCell(cellNo);
                            cell.IsHidden = false;
                            cell.MadeVisibleForPaging = true;
                            cell.Value = startingCell.Value;
                            const [endingCell, rowNo] = FindEndingCell(cellNo);
                            cell.Rowspan = rowNo - $scope.paging.startIndex();
                            cell.Colspan = startingCell.Colspan;
                            cellNo += startingCell.Colspan - 1;
                        }
                    }
                }
                /**
                 * @param {number} cellNo
                 */
                function FindStartingCell(cellNo) {
                    for (let i = $scope.paging.startIndex() - 1; i >= 0; i--) {
                        if ($scope.table.Tbody[i][cellNo].IsHidden !== true) {
                            return $scope.table.Tbody[i][cellNo];
                        }
                    }
                }
                /**
                 * @param {number} cellNo
                 * @returns {[Cell, number]}
                 */
                function FindEndingCell(cellNo) {
                    let i = $scope.paging.startIndex() + 1;
                    for (; i < $scope.table.Tbody.length; i++) {
                        if ($scope.table.Tbody[i][cellNo].IsHidden !== true) {
                            return [$scope.table.Tbody[i][cellNo], i];
                        }
                    }
                    var Obj = {
                        Colspan
                            :
                            1,
                        Rowspan
                            :
                            1,
                        Value
                            :
                            ""
                    }
                    return [Obj, i];
                }
            }
        };
    }
]);
/** 
 * @typedef {Object} ScopeTransposeTable
 * @property {Table} table
 * @property {string} tableUUID
 * @property {PagingConfig} paging
 * @property {number} pagingRowNo
 * 
 * @typedef {Object} Cell
 * @property {string} Value
 * @property {string} InnerHtml
 * @property {string|false} ValueTrimmed
 * @property {string} Key
 * @property {StyleProps} StyleProps
 * @property {number} Colspan
 * @property {number} Rowspan
 * @property {boolean} IsHidden
 * @property {boolean} MadeVisibleForPaging
 *
 * @typedef {Object} Table
 * @property {TR[]}Thead
 * @property {TR[]}Tbody
 * @property {TR[]}TbodySliced
 * 
 * @typedef {Cell[]} TR
 * 
 * @typedef {Object.<string, string>} StyleProps
 * 
 * @typedef {Object} PagingConfig
 * @property {number} total
 * @property {number} current
 * @property {function(): void} onPageChanged
 * @property {function(): number} startIndex
 * 
 */