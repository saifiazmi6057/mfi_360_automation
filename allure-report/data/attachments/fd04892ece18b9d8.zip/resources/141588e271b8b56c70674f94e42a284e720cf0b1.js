
SharedServices.service('AllApplicationSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetBasicSettingsData',
            method: 'GET'
        });
    }
}]);

SharedServices.service('SaveApplicationSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SaveUserBasicSettings',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('AllAdvanceSettings', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetSubPlanList',
            method: 'GET'
        });
    }
}]);

SharedServices.service('P2PPeriodDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/P2PPeriodDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SaveP2PPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/SaveP2PPeriod',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('P2PperiodDelete', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/P2PperiodDelete',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('DeleteLogo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteLogo',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            dataType: "json"
        });
    }

}]);

SharedServices.service('LoadSchemeCodes', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiUserDashboard/LoadSchemeCodes',
            method: 'GET'
        });
    }
}]);

