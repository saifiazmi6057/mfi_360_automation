/* applicable for pie, pieNegative, PiChartT15B15, pieClickable ********data format [{ name: "Bond", y: 10.166, positive: true }]*
 * If all are positive then we can pass as [["Bond",10.166],["Bond",10.166]]** islegend should be false (for utility of pie chart)
 * **/
SharedDeractives.directive("pieChart", ['$parse', '$rootScope', function ($parse, $rootScope) {
    return {
        restrict: 'E',
        template: '<div></div>',
        scope: {
            dataplot: '=',
            specialprop: '=',
            charttitle: '=',
            titlechartstyle: '=',
            subtitle: '=',
            subtitlechartstyle: '=',
            isexport: '=',
            tooltipdecimalpoint: '=',
            islegend: '=',
            legendstyle: '=',
            credittext: '=',
            creditlink: '=',
            colorlist: '='

        },
        link: function (scope, element, attribute) {
            var drawChart = function () {
                //console.log("draw chart", scope.dataplot, scope.specialprop, scope.charttitle );
                var dataTmp = angular.copy(scope.dataplot);
                var decimalPoint = scope.tooltipdecimalpoint ? scope.tooltipdecimalpoint : 2;
                var CustomSeriesColors = ['#5341da', '#ff8c00', '#008000', '#1abb9c', '#ef5350', '#ba68c8', '#3226a6', '#b22222', '#007de4', '#ff8c00', '#1f4398'];
                Highcharts.setOptions({
                    colors: scope.colorlist ? scope.colorlist : CustomSeriesColors.reverse()
                });
                new Highcharts.chart(element[0], {
                    chart: {
                        type: 'pie',
                        backgroundColor: 'rgba(255, 255, 255, 0.0)',
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        //colors: CustomSeriesColors.reverse(),
                        options3d: {
                            enabled: true,
                            alpha: 45,
                            beta: 0
                        }
                    },
                    annotationsOptions: {
                        enabledButtons: false
                    },
                    title: {
                        text: scope.charttitle ? scope.charttitle : '',
                        style: {
                            fontSize: scope.titlechartstyle && scope.titlechartstyle.fontSize ? scope.titlechartstyle.fontSize : "25px",
                            fontFamily: scope.titlechartstyle && scope.titlechartstyle.fontFamily ? scope.titlechartstyle.fontFamily : "latoregular",
                            color: scope.titlechartstyle && scope.titlechartstyle.color ? scope.titlechartstyle.color : "blue",
                            fontWeight: scope.titlechartstyle && scope.titlechartstyle.fontWeight ? scope.titlechartstyle.fontWeight : "Normal"
                        }

                    },
                    subtitle: {
                        text: scope.subtitle ? scope.subtitle : "",
                        style: {
                            fontSize: scope.subtitlechartstyle && scope.subtitlechartstyle.fontSize ? scope.subtitlechartstyle.fontSize : "12px",
                            fontFamily: scope.subtitlechartstyle && scope.subtitlechartstyle.fontFamily ? scope.subtitlechartstyle.fontFamily : "latoregular",
                            color: scope.subtitlechartstyle && scope.subtitlechartstyle.color ? scope.subtitlechartstyle.color : "pink",
                            fontWeight: scope.subtitlechartstyle && scope.subtitlechartstyle.fontWeight ? scope.subtitlechartstyle.fontWeight : "lighter"
                        }
                    },

                    exporting: {
                        enabled: scope.isexport ? scope.isexport : false
                    },
                    credits: {
                        enabled: true,
                        text: scope.credittext ? scope.credittext : '',
                        href: scope.creditlink ? scope.creditlink : ''
                    },
                    tooltip: {
                        formatter: function () {
                            var val = this.point.positive != undefined ? (this.point.positive === true) ? this.y : this.y * (-1) : this.y;
                            return '<b>' + this.point.name + '</b>: <br />' + val.toFixed(decimalPoint) + ' %';
                        }
                        //pointFormat: '<b>{point.percentage:.' + scope.tooltipDecimalPoint + 'f}%</b>'
                        //pointFormat: '<b>{point.percentage:.3f}%</b>'
                    },

                    legend: {
                        enabled: scope.islegend ? scope.islegend : false,
                        align: scope.legendstyle && scope.legendstyle.align ? scope.legendstyle.align : "right",
                        verticalAlign: scope.legendstyle && scope.legendstyle.verticalAlign ? scope.legendstyle.verticalAlign : "bottom",
                        layout: scope.legendstyle && scope.legendstyle.layout ? scope.legendstyle.layout : "vertical",
                        itemStyle: {
                            fontSize: scope.legendstyle && scope.legendstyle.fontSize ? scope.legendstyle.fontSize : "13px",
                            fontFamily: scope.legendstyle && scope.legendstyle.fontFamily ? scope.legendstyle.fontFamily : "Roboto Condensed, sans-serif",
                            color: scope.legendstyle && scope.legendstyle.color ? scope.legendstyle.color : "green",
                            fontWeight: scope.legendstyle && scope.legendstyle.fontWeight ? scope.legendstyle.fontWeight : "bold",
                        },
                        Navigation: (scope.specialprop == undefined || scope.specialprop.legendNavigation == undefined) ? {} : scope.specialprop.legendNavigation,
                        symbolHeight: 12,
                        symbolWidth: 12,
                        symbolRadius: 2

                    },

                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                formatter: function () {
                                    var tmpVal = this.point.positive != undefined ? (this.point.positive === true) ? this.y : this.y * (-1) : this.y;
                                    return '<b>' + this.point.name + '</b>: <br />' + tmpVal.toFixed(decimalPoint) + ' %';
                                },
                                //color: 'black',
                                //style: {
                                //    font: '13px Trebuchet MS, Verdana, sans-serif'
                                //}
                            },
                            //dataLabels: {
                            //    enabled: true,
                            //    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                            //},
                            depth: 25,
                            showInLegend: scope.islegend ? scope.islegend : "",
                            size: scope.specialprop && scope.specialprop.size ? scope.specialprop.size : '',
                            //data: scope.dataplot,
                        },
                        series: {
                            cursor: 'pointer',
                            point: {
                                events: {
                                    click: function () {
                                        if (scope.specialprop.funname == "FNClickPoint") {
                                            $rootScope.$broadcast("cityWiseAUMPIEChartClick", event.point.name);
                                        }
                                    }
                                }
                            }
                            //events: {
                            //    click: function (e) {
                            //        if (scope.specialprop.funname == "FNClickPoint") {
                            //            $rootScope.$broadcast("cityWiseAUMPIEChartClick", event.point.name);
                            //            //FNClickPoint(event.point.name);
                            //        }
                            //    }
                            //}
                        }
                    },

                    series: [{
                        type: 'pie',
                        dataLabels: {
                            enabled: true,
                            connectorWidth: 1,
                            distance: 15,
                            //formatter: function () {
                            //    return '<b>' + this.point.name + '</b><br/> ' + Highcharts.numberFormat(this.percentage, scope.tooltipDecimalPoint) + '%'; //// this.percentage.toFixed(2) changes done by sourav rakshit
                            //}
                        },
                        data: scope.dataplot
                    }],
                });
                //CurrChart.reflow();

            }
            scope.$watch("dataplot", function (newValue) {
                if (scope.dataplot && scope.dataplot.length > 0) {
                    drawChart();
                }
                //chart.series[0].setData(newValue, true);
            }, true);
        }
    }
}]);