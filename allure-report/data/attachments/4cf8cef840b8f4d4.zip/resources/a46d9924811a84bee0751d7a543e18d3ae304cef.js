
SharedDeractives.directive('fundSelectionDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetUserSelectedFunds',
    'GetUserSetByLoginId','GetMyWatchListSchemes', 'FetchMyWatchListSelectedFunds', 'MFIMsg', '$filter',
    function ($http, $q, $timeout, ApiInfo, GetUserSelectedFunds, GetUserSetByLoginId, GetMyWatchListSchemes, FetchMyWatchListSelectedFunds, MFIMsg, $filter) {
        return {
            restrict: 'AE',
            scope: {
                lstMergedSchemes: '=',
                lstMfiSchemes: '=',
                lstMfiFunds: '=',
                userSetModel: '=',
                options: '=',
                toDate: '=',
                userSetSettings: '=',
                filterColumnNameValue: '=?',
                setfromSchemeDirective: '&',
                schemeSelectionInprocFunc: '=?'
            },
            templateUrl: '/CreditRatingMonitor/FundSelection',
            link: function ($scope, $element, $attrs) {
                $scope.filterColumnNameValue = $scope.filterColumnNameValue || '';
                $scope.divHeight = $attrs.divheight || "365px";
                $scope.isSelectAllDisabled = false;
                if (!angular.isUndefinedOrNullOrEmpty($attrs.isselectalldisabled && $attrs.isselectalldisabled.toUpperCase() == "TRUE"))
                    $scope.isSelectAllDisabled = true;

                $scope.TableHeightAll = $attrs.tableHeightscheme || "390px";

                $scope.IsSchemeAllChecked = false;
                $scope.IsUserSetShown = false;
                $scope.IsUploadSchemeShown = false;
                $scope.userSetModel = [];
                $scope.lstMergedSchemes = [];
                var ParrallelLstMergedSchemes = [];
                $scope.LstUserSetSchemes = $scope.options.LstUserSetSchemes;
                var filteredObj = { "filterColumnNameValue": $scope.filterColumnNameValue };
                var UserSelectedSchemes = GetUserSelectedFunds.Call(filteredObj);
                //var UserSchemeSets = GetUserSetByLoginId.Call();
                //var MyWatchListSchemes = GetMyWatchListSchemes.Call();
                $scope.LoaderSchemedirective = true;
                $q.all([
                    UserSelectedSchemes,
                    //UserSchemeSets,
                    //MyWatchListSchemes
                ]).then(function successCallback(response) {
                    $scope.options.LstSelectedSchemes = response[0].data.data == null ? [] : response[0].data.data;
                    //$scope.LstUserSetSchemes = response[1].data.data == null ? [] : response[1].data.data;
                    //$scope.options.LstMywatchListSchemes = response[2].data.data == null ? [] : response[2].data.data;

                    IterateSelctedSchemes($scope.options.LstSelectedSchemes);
                    $scope.SelectedId = "1";
                    $scope.LoaderSchemedirective = false;
                    if ($scope.options.LstSelectedSchemes.length == 0) {
                        MFIMsg.AlertHtml("Please select schemes  from Fund Screener");
                        $timeout(function () {
                            window.location = "/AMC/FundScreener";
                        }, 2000);
                    }
                });

                var UserSchemeSets = GetUserSetByLoginId.Call();
                var MyWatchListSchemes = FetchMyWatchListSelectedFunds.Call();

                UserSchemeSets.then(function successCallback(response) {
                    $scope.LstUserSetSchemes = response.data.data == null ? [] : response.data.data;
                },
                    function errorCallback(response) {
                    });
                MyWatchListSchemes.then(function successCallback(response) {
                    $scope.options.LstMywatchListSchemes = response.data.data == null ? [] : response.data.data;
                },
                    function errorCallback(response) {
                    });
                $scope.pagingStatus = {
                    PageSize: 500,
                    total: 1,
                    current: 1,
                    onPageChanged: () => { [$scope.pagingStatus, $scope.slicedLstMergedSchemes] = Paging($scope.lstMergedSchemes, $scope.pagingStatus.PageSize, $scope.pagingStatus, $scope.slicedLstMergedSchemes) },
                };
                $scope.TotalLstMergedSchemes = [];
                $scope.$watch('searchFilterSchemes', function (newValue) {
                    $scope.lstMergedSchemes = $filter('filter')($scope.TotalLstMergedSchemes, $scope.searchFilterSchemes);
                    $scope.pagingStatus.onPageChanged();
                }, true);
                var prevListLegth = -1;
                var prevHeight = null;
                $scope.$watch('lstMergedSchemes', function (newList) {
                    if (Array.isArray(newList) && (newList.length != prevListLegth)) {
                        prevListLegth = newList.length;
                        if (angular.isUndefinedOrNullOrEmpty(prevHeight))
                            prevHeight = Math.max(parseFloat($scope.divHeight.match(/\d+/)[0]) - 85, angular.element('#FundResult > tbody').height());
                        let [height, elementHeight] = [prevHeight + ($scope.IsUserSetShown ? -30 : 0) + (($scope.TotalLstMergedSchemes?.length || 0) > 500 ? -25 : 0), angular.element('#FundResult > tbody').height()];
                        if (Math.abs(height - prevHeight) > 5 || elementHeight != height) {
                            angular.element('#FundResult > tbody').height(height);
                        }
                    }
                }, true);
                function Paging(sourceRowLst, PageSize, pagingStatus, slicedRowLst) {
                    if (Array.isArray(sourceRowLst) && (sourceRowLst.length != prevListLegth)) {
                        prevListLegth = sourceRowLst.length;
                        if (angular.isUndefinedOrNullOrEmpty(prevHeight))
                            prevHeight = Math.max(parseFloat($scope.divHeight.match(/\d+/)[0]) - 85, angular.element('#FundResult > tbody').height());
                        let [height, elementHeight] = [prevHeight + ($scope.IsUserSetShown ? -30 : 0) + ((sourceRowLst?.length ?? 0) > 500 ? -25 : 0), angular.element('#FundResult > tbody').height()];
                        if (Math.abs(height - prevHeight) > 5 || elementHeight != height) {
                            angular.element("#FundResult > tbody").attr('style', 'height:' + height.toString() + "px!important");
                        }
                    }
                    if (!angular.isUndefinedOrNullOrEmpty(sourceRowLst) && sourceRowLst.length > 0) {
                        if ((sourceRowLst.length % PageSize) == 0) {
                            pagingStatus.total = Math.floor(sourceRowLst.length / PageSize);
                        }
                        else {
                            pagingStatus.total = Math.floor((sourceRowLst.length / PageSize) + 1);
                        }
                        slicedRowLst = sourceRowLst.slice((pagingStatus.current - 1) * PageSize, (pagingStatus.current * PageSize));
                    }
                    else {
                        slicedRowLst = [];
                    }
                    return [pagingStatus, slicedRowLst]
                };
                $scope.checkAssociatedSchemeCheckBox = function (idindex) {
                    setTimeout(function () {
                        angular.element("#Schmechk_" + idindex).trigger('click');
                    }, 0);
                };

                $scope.LoadSchemeSelections = function () {
                    $scope.isSchemeAllChecked = false;
                    $scope.IsUserSetShown = false;
                    $scope.IsUploadSchemeShown = false;
                    $scope.userSetModel = [];
                    $scope.lstMergedSchemes = [];
                    $scope.slicedLstMergedSchemes = [];
                    ParrallelLstMergedSchemes = [];
                    $scope.lstMfiSchemes = [];
                    $scope.LstUserSetSchemes = $scope.options.LstUserSetSchemes;
                    filteredObj = { "filterColumnNameValue": $scope.filterColumnNameValue };
                    $scope.redeemedSchemes = [];
                    UserSelectedSchemes = GetUserSelectedFunds.Call(filteredObj);
                    //let RefreshRedemed = GetRedeemedSchemes.Call();
                    //UserSchemeSets = GetUserSetByLoginId.Call();
                    //MyWatchListSchemes = GetMyWatchListSchemes.Call();
                    $scope.LoaderSchemedirective = true;
                    $q.all([
                        UserSelectedSchemes,
                        //UserSchemeSets,
                        //MyWatchListSchemes
                        //RefreshRedemed
                    ]).then(function successCallback(response) {
                        $scope.options.LstSelectedSchemes = response[0].data.data == null ? [] : response[0].data.data;
                        //$scope.LstUserSetSchemes = response[1].data.data == null ? [] : response[1].data.data;
                        //$scope.options.LstMywatchListSchemes = response[2].data.data == null ? [] : response[2].data.data;
                        $scope.redeemedSchemes = response[1]?.data?.data ?? [];
                        IterateSelctedSchemes($scope.options.LstSelectedSchemes);
                        let GetMaxDate = "";
                        if (!angular.isUndefinedOrNullOrEmpty($scope.options.LstSelectedSchemes) && $scope.options.LstSelectedSchemes.length > 0) {
                            GetMaxDate = $scope.options.LstSelectedSchemes[0].LatestNavDateFomatted;
                        }
                        $scope.toDate = GetMaxDate;
                        if ($scope.setfromSchemeDirective != undefined) {
                            $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                        }
                        $scope.SelectedId = "1";
                        $scope.LoaderSchemedirective = false;
                    });

                    UserSchemeSets = GetUserSetByLoginId.Call();
                    MyWatchListSchemes = GetMyWatchListSchemes.Call();
                    UserSchemeSets.then(function successCallback(response) {
                        $scope.LstUserSetSchemes = response.data.data == null ? [] : response.data.data;
                    },
                        function errorCallback(response) {
                        });
                    MyWatchListSchemes.then(function successCallback(response) {
                        $scope.options.LstMywatchListSchemes = response.data.data == null ? [] : response.data.data;
                    },
                        function errorCallback(response) {
                        });
                };

                $scope.chkRdoClick = function (event, selectedOption) {
                    $scope.IsUserSetShown = false;
                    $scope.IsUploadSchemeShown = false;
                    $scope.lstMfiSchemes = [];
                    $scope.lstMfiFunds = [];
                    angular.element("#FundResult > tbody").attr('style', 'height:120px!important');
                    if (selectedOption == "1") {
                        $scope.TableHeightAll = $attrs.tableHeightscheme || "320px";
                        $scope.lstMergedSchemes = [];
                        ParrallelLstMergedSchemes = [];
                        IterateSelctedSchemes($scope.options.LstSelectedSchemes);
                        var GetMaxDate = "";
                        if (!angular.isUndefinedOrNullOrEmpty($scope.options.LstSelectedSchemes) && $scope.options.LstSelectedSchemes.length > 0) {
                            GetMaxDate = $scope.options.LstSelectedSchemes[0].LatestNavDateFomatted;
                        }
                        $scope.toDate = GetMaxDate;
                        if ($scope.setfromSchemeDirective != undefined) {
                            $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                        }
                        // }
                    }
                    else if (selectedOption == "2") {
                        $scope.myMultiDropDown = "showMultiDropDown";
                        $scope.IsUserSetShown = true;
                        $scope.toDate = "";
                        //$scope.fromDate = "";
                        $scope.TableHeightAll = $attrs.tableHeightuserset || "286px";
                        $scope.lstMergedSchemes = [];
                        ParrallelLstMergedSchemes = [];
                        $scope.userSetModel = [];
                        $scope.MyEvents.onDeselectAll();//its working
                        var ht = angular.element("#FundResult > tbody").height() - 30;
                        angular.element("#FundResult > tbody").attr('style', 'height:' + ht.toString() + "px!important");
                    }
                    else if (selectedOption == "3") {
                        $scope.IsUploadSchemeShown = true;
                        $scope.toDate = "";
                        //$scope.fromDate = "";
                        $scope.lstMergedSchemes = [];
                        ParrallelLstMergedSchemes = [];
                        $("#UploadScheme").val('');
                    }
                    else if (selectedOption == "4") {
                        //$scope.fromDate = "";
                        $scope.TableHeightAll = $attrs.tableHeightwatchlist || "321px";
                        $scope.toDate = "";
                        $scope.lstMergedSchemes = [];
                        ParrallelLstMergedSchemes = [];
                        IterateSelctedSchemes($scope.options.LstMywatchListSchemes);
                        var GetMaxDate = "";
                        if (!angular.isUndefinedOrNullOrEmpty($scope.options.LstMywatchListSchemes) && $scope.options.LstMywatchListSchemes.length > 0) {
                            GetMaxDate = $scope.options.LstMywatchListSchemes[0].LatestNavDateFomatted;
                        }
                        $scope.toDate = GetMaxDate;
                        if ($scope.setfromSchemeDirective != undefined) {
                            $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                        }
                    }
                    $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                };

                function IterateSelctedSchemes(Schemes) {
                    angular.forEach(Schemes, function (value, index) {
                        var item = { Id: value.Id, Name: value.Name, IsChecked: value.IsChecked };
                        if (ParrallelLstMergedSchemes.indexOf(JSON.stringify(item)) == -1) {
                            ParrallelLstMergedSchemes.push(JSON.stringify(item));
                            $scope.lstMergedSchemes.push(item);
                        }
                    });
                    $scope.TotalLstMergedSchemes = $scope.lstMergedSchemes ?? [];
                    $scope.pagingStatus.onPageChanged();
                }
                function FindMaxDate(Schemes) {
                    var MaxNavdate = "";
                    angular.forEach(Schemes, function (value, index) {
                        var itemParsed = value;//JSON.parse(value);
                        if (MaxNavdate != "") {
                            if (new Date(itemParsed.LatestNavDate) > new Date(MaxNavdate))
                                MaxNavdate = itemParsed.LatestNavDate;
                        }
                        else {
                            MaxNavdate = itemParsed.LatestNavDate;
                        }
                    });
                    return MaxNavdate;
                }
                var CheckedUssIds = [];
                $scope.MyEvents = {
                    onItemSelect: function (item) {
                        $scope.LoaderSchemedirective = true;
                        CheckedUssIds.push(item.UssId);
                        angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                            value.IsDisabled = true;
                        });
                        $http({
                            method: 'GET',
                            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/GetFundsByUserSchemeSetId?USSId=' + item.UssId + "&CheckedUssIds=",
                            datatype: "json"
                        }).then(function successCallback(response) {

                            IterateSelctedSchemes(response.data.data);
                            $scope.lstMergedSchemes.sort(compare);
                            GetMaxDate = FindMaxDate($scope.lstMergedSchemes);
                            $scope.toDate = GetMaxDate;
                            $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                            if ($scope.setfromSchemeDirective != undefined) {
                                $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                            }
                            angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                value.IsDisabled = false;
                            });
                            $scope.LoaderSchemedirective = false;
                        },
                            function errorCallback(response) {
                                angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                    value.IsDisabled = false;
                                });
                                $scope.LoaderSchemedirective = false;
                            });
                    },
                    onItemDeselect: function (item) {
                        $scope.LoaderSchemedirective = true;
                        CheckedUssIds.splice(CheckedUssIds.indexOf(item.UssId), 1);
                        var SelctedUssIds = $.map(CheckedUssIds, function (option) {
                            return option.toString();
                        }).join(',');
                        angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                            value.IsDisabled = true;
                        });

                        $http({
                            method: 'GET',
                            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetSchemesByUserSchemeSetId?USSId=' + item.UssId + "&CheckedUssIds=" + SelctedUssIds,
                            datatype: "json",
                        }).then(function successCallback(response) {
                            $scope.lstMergedSchemes = [];
                            ParrallelLstMergedSchemes = [];
                            //var GetMaxDate = FindMaxDate($scope.lstMergedSchemes); //IterateSelctedSchemes(response.data.Schemes);
                            $scope.toDate = "";
                            if (CheckedUssIds.length > 0) {
                                IterateSelctedSchemes(response.data.data);
                                var GetMaxDate = "";
                                if (!angular.isUndefinedOrNullOrEmpty(response.data.data) && response.data.data.length > 0) {
                                    GetMaxDate = response.data.data[0].LatestNavDateFomatted;
                                }
                                $scope.toDate = GetMaxDate;
                            }
                            $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                            if ($scope.setfromSchemeDirective != undefined) {
                                $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                            }
                            angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                value.IsDisabled = false;
                            });
                            $scope.LoaderSchemedirective = false;
                        },
                            function errorCallback(response) {
                                angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                    value.IsDisabled = false;
                                });
                                $scope.LoaderSchemedirective = false;
                            }
                        );
                    },
                    onSelectAll: function () {
                        //alert($scope.UserSetModel.length);
                        $scope.LoaderSchemedirective = true;
                        CheckedUssIds = [];
                        angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                            value.IsDisabled = true;
                            CheckedUssIds.push(value.UssId);
                        });
                        $http({
                            method: 'GET',
                            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetSchemesByUserForAllSchemeSet',
                            datatype: "json",
                        }).then(function successCallback(response) {
                            $scope.lstMergedSchemes = [];
                            ParrallelLstMergedSchemes = [];
                            //$scope.fromDate = "";

                            //angular.forEach(response.data.Schemes, function (value, index) {
                            //    var item = JSON.stringify({ Id: value.Id, Name: value.Name, LatestNavDate: value.LatestNavDateFomatted, FundNature: value.FundNature });
                            //    if ($scope.LstMergedSchemes.indexOf(item) == -1) {
                            //        $scope.LstMergedSchemes.push(item);
                            //    }
                            //})
                            IterateSelctedSchemes(response.data.data);
                            var GetMaxDate = "";
                            if (!angular.isUndefinedOrNullOrEmpty(response.data.data) && response.data.data.length > 0) {
                                GetMaxDate = response.data.data[0].LatestNavDateFomatted;
                            }
                            $scope.toDate = GetMaxDate;
                            $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                            if ($scope.setfromSchemeDirective != undefined) {
                                $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                            }
                            angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                value.IsDisabled = false;
                            });
                            $scope.LoaderSchemedirective = false;
                        },
                            function errorCallback(response) {
                                angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                                    value.IsDisabled = false;
                                });
                                $scope.LoaderSchemedirective = false;
                            }
                        );
                    },
                    onDeselectAll: function () {
                        $scope.LoaderSchemedirective = true;
                        $scope.lstMergedSchemes = [];
                        ParrallelLstMergedSchemes = [];
                        CheckedUssIds = [];
                        $scope.userSetModel = [];
                        $scope.toDate = "";
                        //$scope.fromDate = "";
                        angular.forEach($scope.LstUserSetSchemes, function (value, index) {
                            value.IsChecked = false;
                        });
                        $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;

                        if ($scope.setfromSchemeDirective != undefined) {
                            $scope.setfromSchemeDirective({ Param: "MaxDate", Value: $scope.toDate });
                        }
                        $scope.LoaderSchemedirective = false;
                    }
                };

                function compare(a, b) {
                    const genreA = a.Name.toUpperCase();
                    const genreB = b.Name.toUpperCase();

                    let comparison = 0;
                    if (genreA > genreB) {
                        comparison = 1;
                    } else if (genreA < genreB) {
                        comparison = -1;
                    }
                    return comparison;
                }

                $scope.chkSchemeChecked = function (event, item, IsItemClickForCheck) {
                    // var itemindex = ParrallelLstMergedSchemes.indexOf(JSON.stringify(item));
                    var itemObject = JSON.parse(JSON.stringify(item));//JSON.parse(item);
                    IsItemClickForCheck = event.target.checked;
                    if (IsItemClickForCheck) {
                        item.IsChecked = true;
                        itemObject.IsChecked = false;
                        $scope.lstMfiSchemes.push(JSON.stringify(itemObject));
                        $scope.lstMfiFunds.push(itemObject);
                    }
                    else {
                        item.IsChecked = false;
                        var b = -1;
                        for (b = 0; b < $scope.lstMfiSchemes.length; b++)
                            if (JSON.parse($scope.lstMfiSchemes[b]).Id == item.Id)
                                break;
                        $scope.lstMfiSchemes.splice(b, 1);

                        var c = -1;
                        for (c = 0; c < $scope.lstMfiFunds.length; c++)
                            if ($scope.lstMfiFunds[c].Id == item.Id)
                                break;

                        $scope.lstMfiFunds.splice(c, 1);
                    }
                    $scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                    if ($scope.setfromSchemeDirective != undefined) {
                        $scope.setfromSchemeDirective({ Param: "CheckUncheckScheme", Value: item });
                    }
                };
                $scope.chkSchemeAllClick = function (event) {
                    //if (event.target.checked == true) {
                    if ($scope.IsSchemeAllChecked) {
                        $scope.lstMfiSchemes = [];
                        $scope.lstMfiFunds = [];

                        angular.forEach($scope.lstMergedSchemes, function (value) {
                            //var itemObject = JSON.parse(value);
                            //itemObject.IsChecked = true;
                            //var itemindex = $scope.lstMergedSchemes.indexOf(value);
                            //$scope.lstMergedSchemes[itemindex] = JSON.stringify(itemObject);

                            //$scope.lstMergedSchemes.splice(itemindex, 1);
                            //$scope.lstMergedSchemes.splice(itemindex, 0, JSON.stringify(itemObject));
                            value.IsChecked = true;
                            var ItemObject = JSON.parse(JSON.stringify(value));
                            ItemObject.IsChecked = false;
                            $scope.lstMfiSchemes.push(JSON.stringify(value));
                            $scope.lstMfiFunds.push(value);

                        });
                        angular.element("#frmPartialSchemeSelection input[id^='Schmechk_']").prop("checked", true);
                    }
                    else {
                        $scope.lstMfiSchemes = [];
                        $scope.lstMfiFunds = [];

                        angular.forEach($scope.lstMergedSchemes, function (value) {
                            //var itemObject = JSON.parse(value);
                            //itemObject.IsChecked = false;
                            //var itemindex = $scope.lstMergedSchemes.indexOf(value);
                            //$scope.lstMergedSchemes[itemindex] = JSON.stringify(itemObject);

                            //$scope.lstMergedSchemes.splice(itemindex, 1);
                            //$scope.lstMergedSchemes.splice(itemindex, 0, JSON.stringify(itemObject));
                            value.IsChecked = false;
                        });
                        angular.element("#frmPartialSchemeSelection input[id^='Schmechk_']").prop("checked", false);
                    }
                };
            }
        };
    }]);