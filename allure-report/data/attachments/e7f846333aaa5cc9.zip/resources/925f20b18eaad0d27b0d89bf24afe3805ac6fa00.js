SharedDeractives.directive('stressTestingDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetStressTestingDetailsAdvance',
    'GetStressTestingDates', 'MFIMsg', '$window',
    function ($http, $q, $timeout, ApiInfo, GetStressTestingDetailsAdvance, GetStressTestingDates, MFIMsg, $window) {

        return {
            restrict: 'AE',
            scope: {
                lstMfiSchemes: '=',
                selectedMutualFundModel: '=',
                setfromStressTestingDirective: '&',
                setfromMarketCapforLoader: '&',
                setSchemeAmc: '&'
            },
            templateUrl: '/PortfolioAnalysis/StressTestingAdvance',
            link: function ($scope, $element, $attrs) {
                $scope.PortfolioDateList = [];
                $scope.selectedPortDatesROM = [];
                $scope.IsSchemeChecked = true;
                $scope.IsAmcChecked = false;
                $scope.ExpRat = {};
                $scope.LstPeriodOptions = [];
                //$scope.StressPeriod = [];


                $scope.SetSchemeOrAmc = function (MarketCapTtpe) {
                    if (MarketCapTtpe == 'Scheme') {
                        $scope.IsSchemeChecked = true;
                        $scope.IsAmcChecked = false;
                        $scope.setSchemeAmc({ IsSchemeOrAmc: $scope.IsSchemeChecked });
                    }
                    else if (MarketCapTtpe == 'Amc') {
                        $scope.IsSchemeChecked = false;
                        $scope.IsAmcChecked = true;
                        $scope.setSchemeAmc({ IsSchemeOrAmc: $scope.IsSchemeChecked });
                    }
                };

                $scope.PortfolioPortion = "Both";
                $scope.SetPortfolioPortion = function (value) {
                    if (value == 1) {
                        $scope.PortfolioPortion = "FiftyPerPortfolio";
                    }
                    else if (value == 2) {
                        $scope.PortfolioPortion = "TwentyFivePerPortfolio";
                    }
                    else {
                        $scope.PortfolioPortion = "Both";
                    }
                    $scope.setLiquidity({ Liquidity: $scope.$scope.PortfolioPortion });
                }


                // Set the expressions
                $scope.ExpressionChanged = function ($event, ExpressionNumber) {
                    if (ExpressionNumber == 1) {
                        angular.element("#ExpRatExpression1").html(angular.element($event.target).text() + ' <span class="caret"></span>');
                        angular.element("#ExpRatExpression1").data('val', angular.element($event.target).data('val'));
                        $scope.ExpRat.Expression1 = angular.element($event.target).data('val');
                    }
                    else if (ExpressionNumber == 2) {
                        angular.element("#ExpRatExpression2").html(angular.element($event.target).text() + ' <span class="caret"></span>');
                        angular.element("#ExpRatExpression2").data('val', angular.element($event.target).data('val'));
                        $scope.ExpRat.Expression2 = angular.element($event.target).data('val');
                    }
                    else if (ExpressionNumber == 3) {
                        angular.element("#ExpRatExpression3").html(angular.element($event.target).text() + ' <span class="caret"></span>');
                        angular.element("#ExpRatExpression3").data('val', angular.element($event.target).data('val'));
                        $scope.ExpRat.Expression3 = angular.element($event.target).data('val');
                    }
                    else if (ExpressionNumber == 4) {
                        angular.element("#ExpRatExpression4").html(angular.element($event.target).text() + ' <span class="caret"></span>');
                        angular.element("#ExpRatExpression4").data('val', angular.element($event.target).data('val'));
                        $scope.ExpRat.Expression4 = angular.element($event.target).data('val');
                    }

                };


                $scope.UserSetsettingsPortDateforStressTesting = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: true,
                    ddltext: "Select Portfolio Period",
                    Keyprop: "MonthYear",
                    Valueprop: "MonthYear",
                };

                // Getting portfolio periods
                $scope.SwitchStressTestingTab = "IsloadedStressTestingTab";
                var getPortfolioDDLData = GetStressTestingDates.Call(20);
                $scope.LstPeriodOptions = [];
                getPortfolioDDLData.then(function (response) {
                    $scope.PortfolioDateList = response.data.data;
                    $scope.LstPeriodOptions = response.data.data.map(function (a) {
                        return JSON.parse(JSON.stringify(a));
                    });
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Failed to fetch portfolio date list.", MFIAlertType.Error, "OK");
                    });

                //function dateComparison(a, b) {
                //    const date1 = new Date(a)
                //    const date2 = new Date(b)

                //    return date1 - date2;
                //}

                var CollapseSelCriteria = function () {
                    angular.element("#DivStressTestingDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                };

                // Show Report Button Functionality-----------
                $scope.ShowStressTestingReport = function () {
                    // Getting Portfolio periods
                    $scope.ArrPortDatesforStressTesting = [];
                    $scope.selectedPortDatesROM.sort(function (a, b) {
                        let dateA = new Date(a.MonthYear);
                        let dateB = new Date(b.MonthYear);
                        return dateA - dateB;
                    });
                    angular.forEach($scope.selectedPortDatesROM, function (value, index) {
                        $scope.ArrPortDatesforStressTesting.push(value.MonthYear);
                    });
                    //Initializations
                    $scope.LstSelectedMFISchemes = [];
                    $scope.MFIds = [];


                    //$scope.PortDatesStress({ param1: $scope.ArrPortDatesforStressTesting });
                    // Getting Category Id
                    var CategoryId = angular.element("#drpCategory").val();

                    // Getting the expression types and their values
                    var LiquidityExpression = angular.element("#ExpRatExpression1").data('val');
                    var LiquidityExpressionPercentage = angular.element("#txtInput1").val();
                    var LiquidityExpressionPercentageFrom = angular.element("#fromValue1").val();
                    var LiquidityExpressionPercentageTo = angular.element("#toValue1").val();
                    var InvestorExpression = angular.element("#ExpRatExpression2").data('val');
                    var InvestorExpressionPercentage = angular.element("#txtInput2").val();
                    var InvestorExpressionPercentageFrom = angular.element("#fromValue2").val();
                    var InvestorExpressionPercentageTo = angular.element("#toValue2").val();
                    var TrailingPeExpression = angular.element("#ExpRatExpression3").data('val');
                    var TrailingPeExpressionPercentage = angular.element("#txtInput3").val();
                    var TrailingPeExpressionPercentageFrom = angular.element("#fromValue3").val();
                    var TrailingPeExpressionPercentageTo = angular.element("#toValue3").val();
                    var PtrExpression = angular.element("#ExpRatExpression4").data('val');
                    var PtrExpressionPercentage = angular.element("#txtInput4").val();
                    var PtrExpressionPercentageFrom = angular.element("#fromValue4").val();
                    var PtrExpressionPercentageTo = angular.element("#toValue4").val();

                    if (LiquidityExpression != "" && LiquidityExpression != "Default") {
                        if (LiquidityExpression != "Between") {
                            if (LiquidityExpressionPercentage == "") {
                                MFIMsg.AlertHtml("Please provide Stress Test and Liquidity filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                        else {
                            if (LiquidityExpressionPercentageFrom == "" || LiquidityExpressionPercentageTo == "") {
                                MFIMsg.AlertHtml("Please provide Stress Test and Liquidity filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                    }
                    if (InvestorExpression != "" && InvestorExpression != "Default") {
                        if (InvestorExpression != "Between") {
                            if (InvestorExpressionPercentage == "") {
                                MFIMsg.AlertHtml("Please provide Top 10 Investors filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                        else {
                            if (InvestorExpressionPercentageFrom == "" || InvestorExpressionPercentageTo == "") {
                                MFIMsg.AlertHtml("Please provide Top 10 Investors filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                    }
                    if (TrailingPeExpression != "" && TrailingPeExpression != "Default") {
                        if (TrailingPeExpression != "Between") {
                            if (TrailingPeExpressionPercentage == "") {
                                MFIMsg.AlertHtml("Please provide Portfolio Trailing PE filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                        else {
                            if (TrailingPeExpressionPercentageFrom == "" || TrailingPeExpressionPercentageTo == "") {
                                MFIMsg.AlertHtml("Please provide Portfolio Trailing PE filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                    }
                    if (PtrExpression != "" && PtrExpression != "Default") {
                        if (PtrExpression != "Between") {
                            if (PtrExpressionPercentage == "") {
                                MFIMsg.AlertHtml("Please provide Portfolio Turnover Ratio filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                        else {
                            if (PtrExpressionPercentageFrom == "" || PtrExpressionPercentageTo == "") {
                                MFIMsg.AlertHtml("Please provide Portfolio Turnover Ratio filter value.", MFIAlertType.Information, "OK");
                                return;
                            }
                        }
                    }

                    if ($scope.IsSchemeChecked) {

                        //Getting selected schemes Ids
                        if ($scope.lstMfiSchemes.length == 0) {
                            MFIMsg.AlertHtml("User have to select atleast one scheme.", MFIAlertType.Information, "OK");
                            return;
                        }

                        angular.forEach($scope.lstMfiSchemes, function (value) {
                            var item = JSON.parse(value).Id;
                            $scope.LstSelectedMFISchemes.push(item)
                        });

                        if ($scope.ArrPortDatesforStressTesting.length == 0) {
                            MFIMsg.AlertHtml("Please select portfolio periods", MFIAlertType.Information);
                            return false;
                        }

                        if ($scope.ArrPortDatesforStressTesting.length > 12) {
                            MFIMsg.AlertHtml("Cannot select more than 12 periods.", MFIAlertType.Information);
                            return false;
                        }

                        //var Element = document.getElementById("DivStressTestingDetails");
                        //if (Element != null) {
                        //    Element.style.visibility = 'hidden';      // Hide

                        //}

                        CollapseSelCriteria();

                        $scope.StressTestingInput = {
                            SchemeIds: $scope.LstSelectedMFISchemes,
                            AmcIds: $scope.MFIds,
                            IsSchemeWise: true,
                            IsAmcWise: false,
                            CategoryId: CategoryId,
                            PortfolioPeriod: $scope.ArrPortDatesforStressTesting,
                            StressTestLiqAt: $scope.PortfolioPortion,
                            LiquidityExpression: LiquidityExpression,
                            LiquidityExpressionPercentage: LiquidityExpressionPercentage,
                            LiquidityExpressionPercentageFrom: LiquidityExpressionPercentageFrom,
                            LiquidityExpressionPercentageTo: LiquidityExpressionPercentageTo,
                            InvestorExpression: InvestorExpression,
                            InvestorExpressionPercentage: InvestorExpressionPercentage,
                            InvestorExpressionPercentageFrom: InvestorExpressionPercentageFrom,
                            InvestorExpressionPercentageTo: InvestorExpressionPercentageTo,
                            TrailingPeExpression: TrailingPeExpression,
                            TrailingPeExpressionPercentage: TrailingPeExpressionPercentage,
                            TrailingPeExpressionPercentageFrom: TrailingPeExpressionPercentageFrom,
                            TrailingPeExpressionPercentageTo: TrailingPeExpressionPercentageTo,
                            PtrExpression: PtrExpression,
                            PtrExpressionPercentage: PtrExpressionPercentage,
                            PtrExpressionPercentageFrom: PtrExpressionPercentageFrom,
                            PtrExpressionPercentageTo: PtrExpressionPercentageTo
                        };

                        $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "STRESSTESTING" });

                        var StressTestingDetails = GetStressTestingDetailsAdvance.Call($scope.StressTestingInput);
                        StressTestingDetails.then(function (response) {
                            if (response.data != null && response.data.Success == false) {
                                if (response.data.Message != "")
                                    MFIMsg.Alert(response.data.Message);
                                else
                                    MFIMsg.Alert("Warning!! internal error occurred.");
                                scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                                return false;
                            }

                            //if (response.data != null) {
                            //    if (Element != null)
                            //        Element.style.visibility = 'visible';
                            //    //MFIMsg.AlertHtml("Report generated.", MFIAlertType.Success);


                            //}
                            //else {
                            //    //MFIMsg.AlertHtml("No data found.", MFIAlertType.Error);
                            //    $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            //    return false;
                            //}

                            //$scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            var StressTestingOutput = response.data;
                            if ($scope.setfromStressTestingDirective != undefined) {
                                // Sending data to the main js(PortfolioAnalysisAdvance.js) page
                                $scope.setfromStressTestingDirective({ StressTestingInput: $scope.StressTestingInput, StressTestingOutput: StressTestingOutput });
                            }

                        },
                            function errorCallback(response) {
                                MFIMsg.Alert("Waning!! Internal error occurred.");
                                $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            });
                    }

                    else {
                        // Getting selected mutual fund Ids
                        if ($scope.selectedMutualFundModel.length == 0) {
                            MFIMsg.AlertHtml("Please select Mutual Fund(s).", MFIAlertType.Information);
                            return false;
                        }
                        angular.forEach($scope.selectedMutualFundModel, function (option) {
                            var itemMF = JSON.parse(option);
                            $scope.MFIds.push(itemMF.Id);
                        });

                        if (CategoryId == 0) {
                            MFIMsg.AlertHtml("Please select Category", MFIAlertType.Information);
                            return false;
                        }

                        if ($scope.ArrPortDatesforStressTesting.length == 0) {
                            MFIMsg.AlertHtml("Please select portfolio periods", MFIAlertType.Information);
                            return false;
                        }

                        //var Element = document.getElementById("DivStressTestingDetails");
                        //if (Element != null) 
                        //    Element.style.visibility = 'hidden';      // Hide
                        
                        CollapseSelCriteria();

                        $scope.StressTestingInput = {
                            SchemeIds: $scope.LstSelectedMFISchemes,
                            AmcIds: $scope.MFIds,
                            IsSchemeWise: false,
                            IsAmcWise: true,
                            CategoryId: CategoryId,
                            PortfolioPeriod: $scope.ArrPortDatesforStressTesting,
                            StressTestLiqAt: $scope.PortfolioPortion,
                            LiquidityExpression: LiquidityExpression,
                            LiquidityExpressionPercentage: LiquidityExpressionPercentage,
                            LiquidityExpressionPercentageFrom: LiquidityExpressionPercentageFrom,
                            LiquidityExpressionPercentageTo: LiquidityExpressionPercentageTo,
                            InvestorExpression: InvestorExpression,
                            InvestorExpressionPercentage: InvestorExpressionPercentage,
                            InvestorExpressionPercentageFrom: InvestorExpressionPercentageFrom,
                            InvestorExpressionPercentageTo: InvestorExpressionPercentageTo,
                            TrailingPeExpression: TrailingPeExpression,
                            TrailingPeExpressionPercentage: TrailingPeExpressionPercentage,
                            TrailingPeExpressionPercentageFrom: TrailingPeExpressionPercentageFrom,
                            TrailingPeExpressionPercentageTo: TrailingPeExpressionPercentageTo,
                            PtrExpression: PtrExpression,
                            PtrExpressionPercentage: PtrExpressionPercentage,
                            PtrExpressionPercentageFrom: PtrExpressionPercentageFrom,
                            PtrExpressionPercentageTo: PtrExpressionPercentageTo
                        };

                        $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "STRESSTESTING" });
                        var StressTestingDetails = GetStressTestingDetailsAdvance.Call($scope.StressTestingInput);
                        StressTestingDetails.then(function (response) {
                            if (response.data != null && response.data.Success == false) {
                                if (response.data.Message != "")
                                    MFIMsg.Alert(response.data.Message);
                                else
                                    MFIMsg.Alert("Warning!! internal error occurred.");
                                $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                                return false;
                            }
                            //if (response.data != null) {
                            //    if (Element != null)
                            //        Element.style.visibility = 'visible';
                            //    //MFIMsg.AlertHtml("Report generated.", MFIAlertType.Success);


                            //}
                            //else {
                            //    //MFIMsg.AlertHtml("No data found.", MFIAlertType.Error);
                            //    $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            //    return false;
                            //}
                            //$scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            var StressTestingOutput = response.data;
                            if ($scope.setfromStressTestingDirective != undefined) {
                                // Sending data to the main js(PortfolioAnalysisAdvance.js) page
                                $scope.setfromStressTestingDirective({ StressTestingInput: $scope.StressTestingInput, StressTestingOutput: StressTestingOutput });
                            }

                        },
                            function errorCallback(response) {
                                MFIMsg.Alert("Waning!! Internal error occurred.");
                                $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "STRESSTESTING" });
                            });
                    }

                };

                $scope.Reset = function () {
                    $window.location.reload();
                }


            }
        };
    }]);