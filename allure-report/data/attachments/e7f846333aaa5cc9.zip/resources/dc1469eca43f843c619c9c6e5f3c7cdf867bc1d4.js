//var FilterPortfolio = angular.module('FilterPortfolio', []);

SharedCommon.filter('SectorWiseAllocationFilter', function ($filter)
{
    return function (items, scope) {
   //   debugger;
        var filtered = [];
        if (scope == null || scope == "")
        {
            filtered = items;
        }
        else
        {
            filtered = $filter('filter')(items, { SectorName: scope }, true)
        }

        return filtered;
    };
});