loginLayoutapp.controller("SignInCntr", ['$scope', '$http', 'MFIMsg', function ($scope, $http, MFIMsg) {
    // MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
    $scope.CallMFIMsgAlert = function (msg, alerttype) {
        MFIMsg.AlertHtml(msg, alerttype);
    };
    if (!angular.isUndefinedOrNullOrEmpty(angular.element("#UIMessage").val())) {
        MFIMsg.AlertHtml(angular.element("#UIMessage").val(), MFIAlertType.Information);
    }
}]);
$(document).keydown(function (e) {
    if (e.which === 123) {
        return false;
    }
});
$(document).ready(function () {
    //$("#signup-button").click(function () {
    //    $("#user_options-forms").removeClass("login-click");
    //    $("#user_options-forms").addClass("signup-click");
    //});
    //$("#login-button").click(function () {
    //    $("#user_options-forms").removeClass("signup-click");
    //    $("#user_options-forms").addClass("login-click");
    //});
    //$("#login-button1").click(function () {
    //    $("#user_options-forms").removeClass("signup-click");
    //    $("#user_options-forms").addClass("login-click");
    //});
    //ICRA.ShowMessage("UIMessage");

    //$('#BtnSubmit').click(function (event) {
    //    if ($('#TxtUserId').val() == "") {
    //        //angular.element('#divSignIn').scope().AngularFunction();
    //        angular.element('#divSignIn').scope().CallMFIMsgAlert('Please provide valid user id', MFIAlertType.Information);
    //        //OpenAlert('Please provide valid user id');
    //        return false;
    //    }
    //    if ($('#TxtPwd').val() == "") {
    //        //OpenAlert('Please provide the correct password');
    //        angular.element('#divSignIn').scope().CallMFIMsgAlert('Please provide the correct password', MFIAlertType.Information);
    //        return false;
    //    }
    //    var logintoken = $('#logintoken').val();
    //    var valConfirmpwd = $('#TxtPwd').val();
    //    var valEmailId = $('#TxtUserId').val();
    //    valConfirmpwd = EncryptString(valConfirmpwd + logintoken);
    //    valEmailId = EncryptString(valEmailId)
    //    $('#Password').val(valConfirmpwd);
    //    $('#Email').val(valEmailId);
    //    $('#TxtPwd').val("");
    //    $('#TxtUserId').val("");
    //    return true;
    //});
    
        $('#BtnSubmit').click(async function (event) {
            event.preventDefault(); // Prevent form submission until encryption is done

            if ($('#TxtUserId').val() === "") {
                angular.element('#divSignIn').scope().CallMFIMsgAlert('Please provide valid user id', MFIAlertType.Information);
                return false;
            }

            if ($('#TxtPwd').val() === "") {
                angular.element('#divSignIn').scope().CallMFIMsgAlert('Please provide the correct password', MFIAlertType.Information);
                return false;
            }

            const logintoken = $('#logintoken').val();
            const valConfirmpwdRaw = $('#TxtPwd').val();
            const valEmailIdRaw = $('#TxtUserId').val();

            try {
                const encryptedPwd = await encryptData(valConfirmpwdRaw + logintoken, logintoken);
                const encryptedEmail = await encryptData(valEmailIdRaw, logintoken);
                const toBase64 = buffer => btoa(String.fromCharCode(...buffer));

                $('#Password').val(toBase64(encryptedPwd.cipherText));
                $('#PassSalt').val(toBase64(encryptedPwd.salt));
                $('#PassIV').val(toBase64(encryptedPwd.iv));
                $('#Email').val(toBase64(encryptedEmail.cipherText));
                $('#EmailSalt').val(toBase64(encryptedEmail.salt));
                $('#EmailIV').val(toBase64(encryptedEmail.iv));
                $('#TxtPwd').val("");
                $('#TxtUserId').val("");
                
                $('#FrmLogin').submit();

            } catch (err) {
                angular.element('#divSignIn').scope().CallMFIMsgAlert('Encryption failed: ' + err.message, MFIAlertType.Error);
                return false;
            }
        });


});
function FN_email_submit() {
    var EmailId = $("#txtEmail").val();
    if (EmailId != '' && EmailId != undefined && EmailId != null) {
        $('#txtEmail').val(EmailId);
        $("#FrmLogin").attr('action', '/ManageAccount/ForgotPassword');
        getresponse = grecaptcha.getResponse();
        if (getresponse != null && getresponse != "")
            $("#FrmLogin").submit();
        else {
            grecaptcha.reset();
            angular.element('#divSignIn').scope().CallMFIMsgAlert('Please validate the CAPTCHA', MFIAlertType.Information);
        }
    }
    else {
        grecaptcha.reset();
        angular.element('#divSignIn').scope().CallMFIMsgAlert('Please provide valid user id', MFIAlertType.Information);
    }
}
$(function () {
    $("#ClickForgot").click(function () {
        $(this).hide();
        $("#forgot").slideDown("fast");
        $("#login").slideUp("fast");
    })
    $("#back_to_login").click(function () {
        $("#ClickForgot").slideDown("fast");
        $("#forgot").slideUp("fast");
        $("#login").slideDown("fast");
    })

})