
SharedServices.service('GetPortfolioDDL', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (i) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/GetPortfolioDDL?year='+i,
            method: 'GET'
        });
    }

}]);


SharedServices.service('GetMultipleSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/GetMultipleSet',
            method: 'GET'
        });
    }

}]);



SharedServices.service('FetchPopularStockDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/FetchPopularStockDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostRowDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/PostRowDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetMFIPlan_sector', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/GetMFIPlan_sector',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetCustomizedPlan_sector', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPopularStocks/GetCustomizedPlan_sector',
            method: 'GET'
        });
    }

}]);