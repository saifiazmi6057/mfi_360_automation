SharedServices.service('PostWatchList', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/PostWatchList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostWatchListSchDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/PostWatchListSchDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);