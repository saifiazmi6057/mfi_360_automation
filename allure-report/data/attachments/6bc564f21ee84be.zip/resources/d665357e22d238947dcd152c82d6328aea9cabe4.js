SharedDeractives.directive('copytoClipboard', function () {
    return {
        restrict: 'A',
        scope: {
            tableId: '@'
        },
        link: function(scope,Element,Table) {

            Element.on('click', function () {
                let table = document.querySelector('#'+scope.tableId);
                selectNode(table);
                document.execCommand('copy');
                let select = window.getSelection()
                select.removeAllRanges()
               // alert("Copied Succesfully");
                function selectNode(node) {
                    let range = document.createRange();
                    range.selectNodeContents(node)
                    let select = window.getSelection()
                    select.removeAllRanges()
                    select.addRange(range)
                }

            })

        }
    };
});