

var creditText = "Source: MFI360 Explorer";
//var creditLink = "https://mfi360.icrainsights.com";
var creditLink = "#";

function GenerateGraph(charttype, containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, CustomColors, tooltipDecimalPoint, IsPercent) {

    var CustomSeriesColors = ['#5341da', '#ff8c00', '#008000', '#1abb9c', '#ef5350', '#ba68c8', '#3226a6', '#b22222', '#007de4', '#1f4398'];

    if (charttype == 'bar') {
        BarGraph(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'barGp') {

        barGroup(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'barclick') {
        Highcharts.setOptions({
            colors: CustomColors
        });
        BarGraphClicakble(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'pie') {
        //   debugger;
        Highcharts.setOptions({
            colors: CustomSeriesColors.reverse()
        });

        PiChart(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    //PieChartIncludeNegativeValue
    if (charttype == 'pieNegative') {
        //   debugger;
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });

        PieChartIncludeNegativeValue(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    //PiChartT15B15
    if (charttype == 'PiChartT15B15') {
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });

        PiChartT15B15(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'pieClickable') {
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });
        PiChartClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'donutChartClickable') {
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });

        DonutChartClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'donut') {

        DonutChart(containerid, dataplot, xcategoriey, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'donut3d') {
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });
        donut3d(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'donut3dNeg') {
        var CustSeriesColors = ['#ff8c00', '#008000', '#1abb9c', '#ef5350', '#ba68c8', '#3226a6', '#b22222', '#d8b83f', '#16d620', '#990099', '#b77322', '#dd4477'];
        Highcharts.setOptions({
            colors: CustSeriesColors
        });
        donut3dNegative(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'barnegative') {

        Barnegative(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'stackedcol') {

        Highcharts.setOptions({
            colors: CustomSeriesColors
        });

        Stackcol(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'colnegative') {

        Highcharts.setOptions({
            colors: CustomColors,
            lang: {
                thousandsSep: ','
            }
        });
        //https://jsfiddle.net/gh/get/library/pure/highcharts/highcharts/tree/master/samples/highcharts/demo/columnrange/
        //https://www.highcharts.com/docs/chart-and-series-types/x-range-series
        colnagetive(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'colnegativeEconomy') {

        Highcharts.setOptions({
            colors: CustomColors,
            lang: {
                thousandsSep: ','
            }
        });
        //https://jsfiddle.net/gh/get/library/pure/highcharts/highcharts/tree/master/samples/highcharts/demo/columnrange/
        //https://www.highcharts.com/docs/chart-and-series-types/x-range-series
        colnagetiveEconomy(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    //

    if (charttype == 'columnrange') {

        Highcharts.setOptions({
            colors: CustomColors,
            lang: {
                thousandsSep: ','
            }
        });

        columnrange(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'colClickable') {

        Highcharts.setOptions({
            colors: CustomSeriesColors
        });
        colClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'fixedplacement') {

        FixedPlacement(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'bubble3D') {

        bubble3D(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'bubble3DRiskReturn') {

        bubble3DRiskReturn(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'dual') {

        dualchart(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'nav') {
        CustomSeriesColors = CustomColors;
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });
        // navWithOutRebase(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);

        nav(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint, CustomSeriesColors, IsPercent);
    }
    if (charttype == 'navWithOutRebase') {
        //  CustomSeriesColors = CustomColors;
        Highcharts.setOptions({
            colors: CustomSeriesColors
        });
        navWithOutRebase(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint, CustomSeriesColors);
    }
    if (charttype == 'LineChartIrregularInterval') {
        LineChartIrregularInterval(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle);
    }
    if (charttype == 'tree') {
        tooltipDecimalPoint = tooltipDecimalPoint || 4;
        TreeMap(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
    if (charttype == 'heat') {

        HeatMap(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'flag') {

        Flahchart(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop);
    }
    if (charttype == 'colgrp') {
        var CustomColors23 = ["#4286f4", "#1fa32c", "#ff7200", "#ff5800", "#23c6c8", "#dd4477", "#840b42", "#b77322", "#16d620", "#3366cc", "#dc3912", "#990099", "#0099c6",
            "#d8b83f", "#66aa00", "#b82e2e", "#316395", "#aaaa11", "#e67300", "#8b0707", "#329262", "#202262", "#1a4915"];
        var CustomColors98 = ['#9acd32', '#f5deb3', '#d02090', '#ee82ee', '#40e0d0', '#d8bfd8', '#d2b48c', '#4682b4', '#708090', '#6a5acd', '#87ceeb', '#a0522d', '#f4a460', '#fa8072', '#8b4513', '#4169e1', '#bc8f8f', '#663399', '#a020f0', '#b0e0e6', '#dda0dd', '#ffc0cb', '#ffefd5', '#db7093', '#afeeee', '#98fb98', '#eee8aa', '#db7093', '#da70d6', '#6b8e23', '#fdf5e6', '#000080', '#ffe4b5', '#f5fffa', '#191970', '#c71585', '#48d1cc', '#00fa9a', '#7b68ee', '#3cb371', '#9370db', '#ba55d3', '#0000cd', '#66cdaa', '#66cdaa', '#b03060', '#ff00ff', '#faf0e6', '#32cd32', '#b0c4de', '#778899', '#8470ff', '#87cefa', '#20b2aa', '#ffb6c1', '#d3d3d3', '#fafad2', '#f08080', '#add8e6', '#eedd82', '#7cfc00', '#e6e6fa', '#f0e68c', '#cd5c5c', '#ff69b4', '#adff2f', '#bebebe', '#daa520', '#f8f8ff', '#dcdcdc', '#228b22', '#fffaf0', '#b22222', '#696969', '#9400d3', '#00ced1', '#2f4f4f', '#483d8b', '#8fbc8f', '#e9967a', '#9932cc', '#ff8c00', '#556b2f', '#bdb76b', '#006400', '#b8860b', '#6495ed', '#ff7f50', '#d2691e', '#5f9ea0', '#deb887', '#a52a2a', '#8a2be2', '#ffebcd', '#000000', '#f5f5dc', '#faebd7', '#f0f8ff'];
        var BarColors = [];
        var startNo = 0;
        var slab = 5;
        var endNo = slab;
        BarColors = CustomColors98.slice(startNo, 5);
        //for (i = 0; i < xcategoriey.length; i++) {
        //    BarColors[i] = CustomColors98.slice(startNo, endNo);
        //    startNo = startNo + slab;
        //    endNo = startNo + slab;
        //}
        //specialprop.colors = BarColors;
        Highcharts.setOptions({
            //colors: CustomColors98,
            lang: {
                thousandsSep: ','
            }
        });

        colgrp(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint);
    }
}

function dualchart(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {
    Highcharts.chart('dual', {
        chart: {
            // zoomType: 'xy'
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }

        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        xAxis: [{
            categories: xcategoriey,
            crosshair: true,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
        }],
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value}' + specialprop.ypformat,
                //style: {
                //    color: Highcharts.getOptions().colors[1]
                //}
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            title: {
                text: ytextPrimary,
                //style: {
                //    color: Highcharts.getOptions().colors[1]
                //}
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        }, { // Secondary yAxis
            title: {
                text: ytextSecondary,
                //style: {
                //    color: Highcharts.getOptions().colors[0]
                //}
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                format: '{value}' + specialprop.ysformat,
                //style: {
                //    color: Highcharts.getOptions().colors[0]
                //}
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            opposite: true
        }],
        tooltip: {
            shared: true
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: [{
            name: ytextSecondary,
            type: 'column',
            yAxis: 1,
            data: dataplot.Secondary,
            tooltip: {
                valueSuffix: specialprop.ysformat
            }

        }, {
            name: ytextPrimary,
            type: 'spline',
            data: dataplot.Primary,
            tooltip: {
                valueSuffix: specialprop.ypformat
            }
        }]
    });
}

function bubble3D(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, legendspecial) {
    Highcharts.chart(containerid, {

        chart: {
            type: 'bubble',
            plotBorderWidth: 1,
            zoomType: 'xy',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },

        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }

        },
        exporting: {
            enabled: isexport
        },
        xAxis: {
            gridLineWidth: 1,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },

        yAxis: {
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            startOnTick: false,
            endOnTick: false
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: dataplot

    });
}
function bubble3DRiskReturn(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary,
    ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend,
    yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, XAxisMin, XAxisMax, YAxisMin, YAxisMax, XCrossing, YCrossing,
    FirstPartAnnotationText, SecondPartAnnotationText, ThirdPartAnnotationText, FourthPartAnnotationText,
    specialprop, SpanYaxistitle, tooltipDecimalPointx, tooltipDecimalPointy, legendspecial) {

    var FirstFourthAnnotationXvalue = (XCrossing - XAxisMin) / 2;
    var SecondThirdAnnotationXvalue = (XAxisMax - XCrossing) / 2;
    var FirstSecondAnnotationYvalue = (YAxisMax - YCrossing) / 8;
    var ThirdFourthAnnotationYValue = (YCrossing - YAxisMin) / 8;
    // debugger;
    //alert(XAxisMin*(200));
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'bubble',
            plotBorderWidth: 1,
            zoomType: 'xy',
            // backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        annotations: [{
            xValue: XCrossing - FirstFourthAnnotationXvalue,
            yValue: YAxisMax - FirstSecondAnnotationYvalue,
            title: {
                text: FirstPartAnnotationText,
                style: {
                    align: legendstyle.align
                },
            }
        },
        {
            xValue: XCrossing + SecondThirdAnnotationXvalue,
            yValue: YAxisMax - FirstSecondAnnotationYvalue,
            title: {
                text: SecondPartAnnotationText,
                style: {
                    align: legendstyle.align
                },
            }
        },
        {
            xValue: XCrossing + SecondThirdAnnotationXvalue,
            yValue: YAxisMin + ThirdFourthAnnotationYValue,
            title: {
                text: ThirdPartAnnotationText,
                style: {
                    align: legendstyle.align
                },
            }
        },
        {
            xValue: XCrossing - FirstFourthAnnotationXvalue,
            yValue: YAxisMin + ThirdFourthAnnotationYValue,
            title: {
                text: FourthPartAnnotationText,
                style: {
                    align: legendstyle.align
                },
            }
        },
        ],

        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }

        },
        exporting: {
            enabled: isexport
        },
        xAxis: {
            gridLineWidth: 1,
            crossing: YCrossing,
            min: XAxisMin,
            max: XAxisMax,
            opposite: true,//it is mandatory
            //zeroCrossing: true,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                },
                align: 'middle',
                //YAxisMin * (280)
            }
        },

        yAxis: {
            crossing: XCrossing,
            min: YAxisMin,
            max: YAxisMax,
            title: {
                text: ytextPrimary,
                //x: 0,
                //y: 0,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                },
                align: 'middle',
                // x: XAxisMin * (180)
            },
            startOnTick: false,
            endOnTick: false
        },
        plotOptions: {
            bubble: {
                minSize: 3,
                maxSize: 20,
                tooltip: {
                    headerFormat: '<b>{series.name}</b><br>',
                    pointFormat: '{point.x:.' + tooltipDecimalPointx + 'f}, {point.y:.' + tooltipDecimalPointy + 'f}'

                }
            }
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: dataplot

    });
    //setTimeout(function () {
    //    var ytitle = $("#" + containerid + " .highcharts-plot-background").attr("y");
    //    var xtitle = $("#" + containerid + " .highcharts-plot-background").attr("x");
    //    $("#" + containerid +" .highcharts-xaxis ").find(".highcharts-axis-title").attr("y", ytitle - 10);
    //    var Ypos = parseFloat($("#" + containerid +" .highcharts-yaxis ").find(".highcharts-axis-title").attr("y"));
    //    //var FixedPos = 230;
    //    //var MarginPos = 0;
    //    //if (Ypos < FixedPos) {
    //    //    MarginPos = FixedPos - Ypos;
    //    //}
    //    //else
    //    //    Ypos = 230;
    //    //$("#" + containerid +" .highcharts-yaxis ").find(".highcharts-axis-title").attr("y", -(Ypos + parseFloat(ytitle) + MarginPos));
    //    var MarginPos = Ypos - parseFloat(xtitle);
    //    $("#" + containerid + " .highcharts-yaxis ").find(".highcharts-axis-title").attr("y", -(Ypos + MarginPos -40));
    //}, 100);

    CurrChart.reflow();
    setTimeout(function () {
        //var ytitle = $("#" + containerid + " .highcharts-plot-background").attr("y");
        //$("#" + containerid + " .highcharts-xaxis ").find(".highcharts-axis-title").attr("y", ytitle - 10);
        var YChartTitle = $("#" + containerid + " .highcharts-yaxis ").find(".highcharts-axis-title");
        var chartHeight = parseFloat($("#" + containerid + " .highcharts-background").attr("height")) / 2 + 10;
        YChartTitle.attr("x", -chartHeight);
        YChartTitle.attr("y", "20");
        YChartTitle.attr("transform", "translate(0, 0) rotate(270 0 0)");
        if (SpanYaxistitle != null || SpanYaxistitle != '' || SpanYaxistitle != undefined) {
            $("#" + SpanYaxistitle).attr("x", -chartHeight);
            $("#" + SpanYaxistitle).attr("y", "20");
            YChartTitle.hide();
        }
        ////$("." + "highcharts-bubble-series").click(function () {
        ////    //var ytitle = $("#" + containerid + " .highcharts-plot-background").attr("y");
        ////    //$("#" + containerid + " .highcharts-xaxis ").find(".highcharts-axis-title").attr("y", ytitle - 10);
        ////     YChartTitle = $("#" + containerid + " .highcharts-yaxis ").find(".highcharts-axis-title");
        ////    chartHeight = parseFloat($("#" + containerid + " .highcharts-background").attr("height")) / 2 + 10;
        ////    YChartTitle.attr("x", -chartHeight);
        ////    YChartTitle.attr("y", "20");
        ////    YChartTitle.attr("transform", "translate(0, 0) rotate(270 0 0)");
        ////});
    }, 100);
    setTimeout(function () {
        if (legendspecial != null || legendspecial != '' || legendspecial != undefined) {
            $legend = $(legendspecial);
            var html = "";
            $.each(dataplot, function (j, data) {
                html = html + '<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0;"><div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"><div class="symbol" style="background-color:' + data.color + '25;border:' + data.color + ' solid 1px;"></div></div> <div class="col-lg-11 col-md-11 col-sm-12 col-xs-12"><div class="serieName" id="" style="font-size: 12px;line-height: 14px; padding-top:3px">' + data.name + '</div></div></div>';
            });
            $legend.html(html);
        }
    }, 100);
}

function FixedPlacement(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {
    Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },
        yAxis: [{
            min: 0,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        }, {
            title: {
                text: ytextSecondary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            opposite: true
        }],

        exporting: {
            enabled: isexport
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        tooltip: {
            shared: true
        },
        plotOptions: {
            column: {
                grouping: false,
                shadow: false,
                borderWidth: 0
            }
        },
        series: dataplot
    });
}

function colClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        exporting: {
            enabled: isexport
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },
        yAxis: {
            // min: 0,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },

        plotOptions: {
            series: {
                allowPointSelect: true,
                cursor: 'pointer',
                events: {
                    click: function (event) {
                        alert();

                    }
                }
            }
        },
        series: dataplot
    });

    CurrChart.reflow();
}
function colnagetive(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var IsNegetaiveValExists = dataplot.length > 0 && dataplot[0].data.length > 0 ? dataplot[0].data.some(v => v < 0) : false;

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht

        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        //exporting: {
        //    enabled: isexport,
        //    chartOptions: {
        //        buttons: {
        //            contextButton: {
        //                verticalAlign: top,
        //                width: 24,
        //                x: -10,
        //                y: 0
        //            }
        //        }
        //    }

        //},
        //legend: {
        //    enabled: islegend,
        //    align: legendstyle.align,
        //    verticalAlign: legendstyle.verticalAlign,
        //    layout: legendstyle.layout,
        //    itemStyle: {
        //        fontSize: legendstyle.fontSize,
        //        fontFamily: legendstyle.fontFamily,
        //        color: legendstyle.color,
        //        fontWeight: legendstyle.fontWeight,
        //    }
        //
        //},


        exporting: {
            enabled: isexport,
            chartOptions: {
                legend: {
                    enabled: islegend,
                    align: legendstyle.align,
                    verticalAlign: legendstyle.verticalAlign,
                    layout: legendstyle.layout,
                    itemStyle: {
                        fontSize: legendstyle.fontSize,
                        fontFamily: legendstyle.fontFamily,
                        color: legendstyle.color,
                        fontWeight: legendstyle.fontWeight,
                    }
                },
                buttons: {
                    contextButton: {
                        //verticalAlign: center,
                        width: 30,
                        x: -10,
                        y: -100
                    }
                }
            }
        },




        //tooltip: {
        //    pointFormat: '<b>{point.percentage:.' + tooltipDecimalPoint + 'f}%</b>'
        //    //pointFormat: '<b>{point.percentage:.3f}%</b>'
        //},
        tooltip: {
            pointFormat: (!(specialprop.ShowTooltipValueOnly == undefined || specialprop.ShowTooltipValueOnly == null)) ? specialprop.ShowTooltipValueOnly == true ? '{point.y:,.' + tooltipDecimalPoint + 'f}' :
                '{series.name}: <b>{point.y:,.' + tooltipDecimalPoint + 'f}</b><br/>' : '{series.name}: <b>{point.y:,.' + tooltipDecimalPoint + 'f}</b>' + ((specialprop.notShowPerSign == undefined || specialprop.notShowPerSign == null || specialprop.notShowPerSign == false) ? '%' : '')
        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black',
                }
            }
        },
        yAxis: {
            min: IsNegetaiveValExists == true ? undefined : 0,
            //max: IsNegetaiveValExists==true?0:undefined,
            //max: parseInt(specialprop.yAxisMax),
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black'
                }
            }
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        plotOptions: {
            series: {
                //  allowPointSelect: (specialprop.allowPointSelect == null) ? false : true,
                cursor: 'pointer',
                events: {
                    click: function (e) {

                        if (specialprop.funname == "AMCmaturity") {
                            FnAMCmaturity(event.point.category);
                        }


                    }
                }
            }
        },
        series: dataplot
    });

    CurrChart.reflow();
}

function colnagetiveEconomy(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var IsNegetaiveValExists = dataplot.length > 0 && dataplot[0].data.length > 0 ? dataplot[0].data.some(v => v < 0) : false;

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht

        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        //exporting: {
        //    enabled: isexport,
        //    chartOptions: {
        //        buttons: {
        //            contextButton: {
        //                verticalAlign: top,
        //                width: 24,
        //                x: -10,
        //                y: 0
        //            }
        //        }
        //    }

        //},
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },


        exporting: {
            enabled: isexport,
            chartOptions: {
                legend: {
                    enabled: islegend,
                    align: legendstyle.align,
                    verticalAlign: legendstyle.verticalAlign,
                    layout: legendstyle.layout,
                    itemStyle: {
                        fontSize: legendstyle.fontSize,
                        fontFamily: legendstyle.fontFamily,
                        color: legendstyle.color,
                        fontWeight: legendstyle.fontWeight,
                    }
                },
                buttons: {
                    contextButton: {
                        //verticalAlign: center,
                        width: 30,
                        x: -10,
                        y: -100
                    }
                }
            }
        },




        //tooltip: {
        //    pointFormat: '<b>{point.percentage:.' + tooltipDecimalPoint + 'f}%</b>'
        //    //pointFormat: '<b>{point.percentage:.3f}%</b>'
        //},
        tooltip: {
            pointFormat: (!(specialprop.ShowTooltipValueOnly == undefined || specialprop.ShowTooltipValueOnly == null)) ? specialprop.ShowTooltipValueOnly == true ? '{point.y:,.' + tooltipDecimalPoint + 'f}' :
                '{series.name}: <b>{point.y:,.' + tooltipDecimalPoint + 'f}</b><br/>' : '{series.name}: <b>{point.y:,.' + tooltipDecimalPoint + 'f}</b>' + ((specialprop.notShowPerSign == undefined || specialprop.notShowPerSign == null || specialprop.notShowPerSign == false) ? '%' : '')
        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                rotation: xcategoriey.length > 5 ? xcategoriey[0].toString().length == 6 ? xcategoriey.length < 15 ? 0 : (-90) : (-90) : 0,
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black',
                }
            }
        },
        yAxis: {
            min: IsNegetaiveValExists == true ? undefined : 0,
            //max: IsNegetaiveValExists==true?0:undefined,
            //max: parseInt(specialprop.yAxisMax),
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black'
                }
            }
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        plotOptions: {
            series: {
                //  allowPointSelect: (specialprop.allowPointSelect == null) ? false : true,
                cursor: 'pointer',
                events: {
                    click: function (e) {

                        if (specialprop.funname == "AMCmaturity") {
                            FnAMCmaturity(event.point.category);
                        }


                    }
                }
            }
        },
        series: dataplot
    });

    CurrChart.reflow();
}


function columnrange(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'columnrange',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht,
            inverted: true
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        //series: [{
        //    name: 'Temperatures',
        //    data: [
        //        [-9.9, 10.3],
        //        [-8.6, 8.5],
        //        [-10.2, 11.8],
        //        [-1.7, 12.2],
        //        [-0.6, 23.1],
        //        [3.7, 25.4],
        //        [6.0, 26.2],
        //        [6.7, 21.4],
        //        [3.5, 19.5],
        //        [-1.3, 16.0],
        //        [-8.7, 9.4],
        //        [-9.0, 8.6]
        //    ]
        //}],
        series: dataplot,
        annotationsOptions: {
            enabledButtons: false
        },
        exporting: {
            enabled: isexport,
            chartOptions: {
                legend: {
                    enabled: islegend,
                    align: legendstyle.align,
                    verticalAlign: legendstyle.verticalAlign,
                    layout: legendstyle.layout,
                    itemStyle: {
                        fontSize: legendstyle.fontSize,
                        fontFamily: legendstyle.fontFamily,
                        color: legendstyle.color,
                        fontWeight: legendstyle.fontWeight,
                    }
                },
                buttons: {
                    contextButton: {
                        //verticalAlign: center,
                        width: 30,
                        x: -10,
                        y: -100
                    }
                }
            }
        },
        tooltip: {
            formatter: function () {
                var s = '';
                var h = new Date(this.point.high);
                var l = new Date(this.point.low);

                var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var hDate = months[h.getMonth()] + ' ' + h.getDate() + ' ,' + h.getFullYear();
                var lDate = months[l.getMonth()] + ' ' + l.getDate() + ' ,' + l.getFullYear();
                s = s + '<span style="color:#839557">' + lDate + ' to ' + hDate + '</span><br /><br />';
                return s;
            }
            // return Highcharts.dateFormat(this.x);
        },
        xAxis: {
            //categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            //    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black'
                }
            },
            //   min: specialprop.Xmin,

        },
        yAxis: {
            //min: 0,
            //max: parseInt(specialprop.yAxisMax),
            type: specialprop.yAxisType,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black'
                }
            }
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        plotOptions: {
            series: {
                //  allowPointSelect: (specialprop.allowPointSelect == null) ? false : true,
                pointWidth: 10,
                cursor: 'pointer',
            },
        }
    });

    CurrChart.reflow();
}

function barGroup(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'bar',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        xAxis: [
            { //--- Primary yAxis
                categories: xcategoriey.reverse(),
                title: {
                    text: xtextPrimary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                }
            }, { //--- Secondary yAxis
                title: {
                    text: xtextSecondary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                },
                opposite: true
            }],

        yAxis: {
            min: 0,
            title: {
                text: ytextPrimary,
                align: 'middle',
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }

            },
            labels: {
                //  overflow: 'justify'
            }
        },
        tooltip: {
            enabled: true,
            //pointFormat: '<b>{point.y:.' + tooltipDecimalPoint + 'f}</b>'
            //pointFormat: '<b>{point.x},{point.y:.' + tooltipDecimalPoint + 'f}</b>'

        },
        plotOptions: {
            series: {
                maxPointWidth: specialprop.maxPointWidth,
                events: {
                    click: function (event) {
                        if (specialprop.FundName == "MultiplePortfolioSectorFilter") {
                            FNSectorFilter(event.point.category);
                        }
                    }
                }
            },
            bar: {
                dataLabels: {
                    // enabled: false
                }
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        series: dataplot.reverse()
    });
    CurrChart.reflow();

}

function Stackcol(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },
        yAxis: {
            // min: 0,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            stackLabels: {
                enabled: false,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            //pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'+'%'
            pointFormat: '{series.name}: {point.y}',
            //formatter: function () {
            //    //return '<b>' + this.point.name + '</b>:<b>' + this.percentage.toFixed(2) + '</b>' + '%';
            //    return '<b>' + this.key + '</b> : <b>' + this.y + '</b>' + '%';
            //}
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                dataLabels: {
                    enabled: false,
                    color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
                }
            }
        },
        series: dataplot
    });
    CurrChart.reflow();
}

function Barnegative(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {


    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'bar',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        xAxis: [{
            categories: xcategoriey,
            reversed: false,
            labels: {
                step: 1
            },
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }

        }, { // mirror axis on right side
            opposite: true,
            reversed: false,
            categories: xcategoriey,
            linkedTo: 0,
            labels: {
                step: 1
            },
            title: {
                text: xtextSecondary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        }],
        yAxis: {
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                formatter: function () {
                    return Math.abs(this.value) + '%';
                }
            }
        },

        plotOptions: {
            series: {
                stacking: 'normal'
            }
        },

        tooltip: {
            formatter: function () {
                return '<b>' + this.series.name + ', age ' + this.point.category + '</b><br/>' +
                    'Population: ' + Highcharts.numberFormat(Math.abs(this.point.y), 0);
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: dataplot
    });
    CurrChart.reflow();

}

function donut3d(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            options3d: {
                enabled: true,
                alpha: 55
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        tooltip: {
            //   pointFormat: '<b>{point.percentage:.2f}%</b>'
            formatter: function () {
                //  debugger;
                return '<b>' + this.key + '</b> : <b>' + this.y + '</b>' + '%';
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                showInLegend: islegend,
                innerSize: 100,
                depth: 45,
                size: specialprop.size,
            },
            series: {
                cursor: 'pointer',
                events: {
                    click: function (event) {

                        if (specialprop.funname == "AMCPortfolioDetails") {
                            FnPortfolioDetails(event.point.name);
                        }
                        if (specialprop.funname == "AMCmaturity") {
                            SetPieAMCmaturity(event.point.name);
                        }
                    }
                }
            }
        },

        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: [{
            data: dataplot,
            type: 'pie',
            dataLabels: {
                enabled: true,
                connectorWidth: 1,
                distance: 15,
                formatter: function () {
                    return '<b>' + this.point.name + '</b>:<br/>' + this.percentage.toFixed(2) + '%';
                }
            }
        }]
        //series: [{
        //    // name: 'Delivered amount',
        //    data: dataplot

        //}]
    });

    CurrChart.reflow();

}

function donut3dNegative(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var OrginalData = [[]];
    // OrginalData = specialprop.Orginaldata;
    for (var i = 0; i < specialprop.Orginaldata.length; i += 1) {
        var TextVal = [];
        TextVal.push(specialprop.Orginaldata[i][0]);
        TextVal.push(specialprop.Orginaldata[i][1]);
        TextVal.push(specialprop.Orginaldata[i][2]);
        TextVal.push(true);
        OrginalData.push(TextVal);
    }

    //commented by syed
    //for (var i = 0; i < specialprop.Orginaldata.length; i += 1) {
    //    var TextVal = [];
    //    TextVal.push(specialprop.Orginaldata[i][0]);
    //    var tempVal = specialprop.Orginaldata[i][1];

    //    if (tempVal > 0) {
    //        TextVal.push(specialprop.Orginaldata[i][1]);
    //        TextVal.push(specialprop.Orginaldata[i][2]);
    //        TextVal.push(true);
    //    } else {
    //        TextVal.push(4 + specialprop.Orginaldata[i][1]);
    //        TextVal.push(specialprop.Orginaldata[i][2]);
    //        TextVal.push(false);
    //    }





    //    OrginalData.push(TextVal);
    //}
    //----------end comment
    //debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht,
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        //tooltip: {
        //    pointFormat: '<b>{point.percentage:.'+ tooltipDecimalPoint +'f}%</b>'
        //    //pointFormat: '<b>{point.percentage:.3f}%</b>'
        //},

        tooltip: {
            formatter: function () {
                var Valrr;
                var IsPos = true;
                for (var i = 0; i < OrginalData.length; i++) {
                    if (this.point.name == OrginalData[i][0]) {
                        //debugger;
                        IsPos = OrginalData[i][2];// changed by syed from 3 to 2
                        Valrr = OrginalData[i][1];
                        break;
                    }
                }
                var val = IsPos ? Valrr : Valrr * (-1);
                return '<b>' + this.point.name + '</b>: ' + val + '%';
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            },
            symbolHeight: 12,
            symbolWidth: 12,
            symbolRadius: 2

        },

        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 45,
                showInLegend: islegend,
                size: specialprop.size,
                data: dataplot,
                innerSize: 100
            },
            series: {
                cursor: 'pointer',
                events: {
                    click: function (e) {
                        if (specialprop.funname == "AMCmaturity") {
                            SetPieAMCmaturity(event.point.name);
                        }
                        if (specialprop.funname == "FNClickPoint") {
                            FNClickPoint(event.point.name);
                        }
                    }
                }
            }
        },

        series: [{
            type: 'pie',
            dataLabels: {
                enabled: true,
                connectorWidth: 1,
                distance: 15,
                formatter: function () {

                    // return '<b>' + this.point.name + '</b><br/> ' + Highcharts.numberFormat(this.percentage, tooltipDecimalPoint) + '%'; //// this.percentage.toFixed(2) changes done by sourav rakshit

                    var Valrr;
                    // debugger;
                    var IsPos = true;
                    for (var i = 0; i < OrginalData.length; i++) {
                        if (this.point.name == OrginalData[i][0]) {
                            //debugger;
                            IsPos = OrginalData[i][2];//changed by syed from 3 to 2
                            Valrr = OrginalData[i][1];
                            break;
                        }
                        //else if (this.point.name == OrginalData[i].name) {
                        //    IsPos = OrginalData[i].y > 0 ? true : false;
                        //    Valrr = OrginalData[i].y;
                        //    debugger;
                        //    break;
                        //}
                    }

                    var val = IsPos ? Valrr : Valrr * (-1);
                    return '<b>' + this.point.name + '</b>: ' + val + '%';

                }
            }
        }],
    });

    CurrChart.reflow();
}

function DonutChart(containerid, dataplot, versionsData, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {
    // Create the chart
    var CurrChart = Highcharts.chart('donutcontainer', {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                shadow: false,
                center: ['50%', '50%']
            }
        },
        tooltip: {
            valueSuffix: '%'
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        series: [{
            name: 'Browsers',
            data: dataplot,
            size: '60%',
            dataLabels: {
                formatter: function () {
                    return this.y > 5 ? this.point.name : null;
                    //  return  this.point.name ;
                },
                color: '#ffffff',
                distance: -30
            }
        }, {
            name: 'Versions',
            data: versionsData,
            size: '80%',
            innerSize: '60%',
            dataLabels: {
                formatter: function () {
                    // display only if larger than 1
                    //  debugger;
                    return this.y > 1 ? '<div style="color:' + this.color + ';">' + this.point.name + '</div><b> : </b>' + this.y + '%' : null;
                }
            }
        }]
    });

    CurrChart.reflow();
}

function PiChart(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {

    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht,
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        tooltip: {
            pointFormat: '<b>{point.percentage:.' + tooltipDecimalPoint + 'f}%</b>'
            //pointFormat: '<b>{point.percentage:.3f}%</b>'
        },

        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            },
            Navigation: specialprop.legendNavigation == undefined ? {} : specialprop.legendNavigation,
            symbolHeight: 12,
            symbolWidth: 12,
            symbolRadius: 2

        },

        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 25,
                showInLegend: islegend,
                size: specialprop.size,
                data: dataplot,
            },
            series: {
                cursor: 'pointer',
                events: {
                    click: function (e) {
                        if (specialprop.funname == "AMCmaturity") {
                            SetPieAMCmaturity(event.point.name);
                        }
                        if (specialprop.funname == "FNClickPoint") {
                            FNClickPoint(event.point.name);
                        }
                    }
                }
            }
        },

        series: [{
            type: 'pie',
            dataLabels: {
                enabled: true,
                connectorWidth: 1,
                distance: 15,
                formatter: function () {
                    return '<b>' + this.point.name + '</b><br/>' + Highcharts.numberFormat(this.percentage, tooltipDecimalPoint) + '%'; //// this.percentage.toFixed(2) changes done by sourav rakshit
                }
            }
        }],
    });

    CurrChart.reflow();

}

function PieChartIncludeNegativeValue(containerid, dataplot, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var OrginalData = [[]];
    // OrginalData = specialprop.Orginaldata;
    for (var i = 0; i < specialprop.Orginaldata.length; i += 1) {
        var TextVal = [];
        TextVal.push(specialprop.Orginaldata[i][0]);
        TextVal.push(specialprop.Orginaldata[i][1]);
        TextVal.push(specialprop.Orginaldata[i][2]);
        TextVal.push(true);
        OrginalData.push(TextVal);
    }
    //debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht,
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        //tooltip: {
        //    pointFormat: '<b>{point.percentage:.'+ tooltipDecimalPoint +'f}%</b>'
        //    //pointFormat: '<b>{point.percentage:.3f}%</b>'
        //},

        tooltip: {
            formatter: function () {
                var Valrr;
                var IsPos = true;
                for (var i = 0; i < OrginalData.length; i++) {
                    if (this.point.name == OrginalData[i][0]) {
                        //debugger;
                        IsPos = OrginalData[i][2];
                        Valrr = OrginalData[i][1];
                        break;
                    }
                }
                var val = IsPos ? Valrr : Valrr * (-1);
                return '<b>' + this.point.name + '</b>: ' + val + '%';
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            },
            symbolHeight: 12,
            symbolWidth: 12,
            symbolRadius: 2

        },

        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 25,
                showInLegend: islegend,
                size: specialprop.size,
                data: dataplot,
            },
            series: {
                cursor: 'pointer',
                events: {
                    click: function (e) {
                        if (specialprop.funname == "AMCmaturity") {
                            SetPieAMCmaturity(event.point.name);
                        }
                        if (specialprop.funname == "FNClickPoint") {
                            FNClickPoint(event.point.name);
                        }
                    }
                }
            }
        },

        series: [{
            type: 'pie',
            dataLabels: {
                enabled: true,
                connectorWidth: 1,
                distance: 15,
                formatter: function () {

                    // return '<b>' + this.point.name + '</b><br/> ' + Highcharts.numberFormat(this.percentage, tooltipDecimalPoint) + '%'; //// this.percentage.toFixed(2) changes done by sourav rakshit

                    var Valrr;
                    // debugger;
                    var IsPos = true;
                    for (var i = 0; i < OrginalData.length; i++) {
                        if (this.point.name == OrginalData[i][0]) {
                            //debugger;
                            IsPos = OrginalData[i][2];
                            Valrr = OrginalData[i][1];
                            break;
                        }
                        //else if (this.point.name == OrginalData[i].name) {
                        //    IsPos = OrginalData[i].y > 0 ? true : false;
                        //    Valrr = OrginalData[i].y;
                        //    debugger;
                        //    break;
                        //}
                    }

                    var val = IsPos ? Valrr : Valrr * (-1);
                    return '<b>' + this.point.name + '</b>: ' + val + '%';

                }
            }
        }],
    });

    CurrChart.reflow();
}

function DonutChartClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    // debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 45
            },

            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: 340,
            width: 540,
            events: {
                //drilldown: function (e) {
                //     debugger;
                //},
                drillup: function (e) {
                    RemoveHdnCredit();
                    //  debugger;
                }
            }

        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },

        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45
            },

            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.y:.' + tooltipDecimalPoint + 'f}%'
                },
                events: {
                    click: function (e) {
                        //  debugger;
                        //  alert(e.point.name);
                        AddHdnCredit(e.point.name);
                    }
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> <br/>'
        },
        series: dataplot,
        drilldown: {
            series: ycategoriey
        }
    });

    CurrChart.reflow();

}

function PiChartClickable(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    // debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'pie',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: 340,
            width: 540,
            events: {
                //drilldown: function (e) {
                //     debugger;
                //},
                drillup: function (e) {
                    RemoveHdnCredit();
                    //  debugger;
                }
            }

        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }

        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },

        plotOptions: {
            series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.y:.' + tooltipDecimalPoint + 'f}%'
                },
                events: {
                    click: function (e) {
                        //  debugger;
                        //  alert(e.point.name);
                        AddHdnCredit(e.point.name);
                    }
                }
            }
        },

        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> <br/>'
        },
        series: dataplot,
        drilldown: {
            series: ycategoriey
        }
    });

    CurrChart.reflow();

}

function BarGraph(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    //debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'bar',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        xAxis: [
            { //--- Primary yAxis
                categories: xcategoriey,
                title: {
                    text: xtextPrimary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                }
            }, { //--- Secondary yAxis
                title: {
                    text: xtextSecondary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                },
                opposite: true
            }],

        yAxis: {
            min: 0,
            title: {
                text: ytextPrimary,
                align: 'middle',
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }

            },
            labels: {
                //  overflow: 'justify'
            }
        },
        tooltip: {
            enabled: true,
            pointFormat: (specialprop != null && specialprop.PercentSign != null) ? '<b>{point.y:.' + tooltipDecimalPoint + 'f} ' + specialprop.PercentSign + '</b>' : '<b>{point.y:.' + tooltipDecimalPoint + 'f}</b>'
            // pointFormat: '<b>{point.x:.' + tooltipDecimalPoint + 'f}</b>'


        },
        plotOptions: {
            series: {
                maxPointWidth: specialprop.maxPointWidth
            },
            bar: {
                dataLabels: {
                    // enabled: false
                }
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        series: dataplot
    });
    CurrChart.reflow();

}

function BarGraphClicakble(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    // debugger;
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'bar',
            // backgroundColor: 'rgba(255, 255, 255, 0.1)'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        xAxis: [
            { //--- Primary yAxis
                categories: xcategoriey,
                title: {
                    text: xtextPrimary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                },
                labels: {
                    style: {
                        color: specialprop.Xlablecolor
                    }
                }
            }, { //--- Secondary yAxis
                categories: [1, 2, 3, 4, 5],
                title: {
                    text: xtextSecondary,
                    style: {
                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: yxchartstyle.color,
                        fontWeight: yxchartstyle.fontWeight
                    }
                },
                opposite: true
            }],

        yAxis: {
            min: 0,
            title: {
                text: ytextPrimary,
                align: 'middle',
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }

            },
            labels: {
                style: {
                    color: specialprop.Xlablecolor,

                }
            }
        },
        tooltip: {
            enabled: true,
            pointFormat: '<b>{point.y:.' + tooltipDecimalPoint + 'f}</b>'
        },
        plotOptions: {
            series: {
                maxPointWidth: specialprop.maxPointWidth,


                events: {
                    click: function (event) {
                        //debugger;
                        var a = event.point.index;
                        sectordetails(a);
                    }
                }
            },
            bar: {
                dataLabels: {
                    // enabled: false
                }
            }
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }
        },
        navigation: {
            buttonOptions: {
                verticalAlign: 'top',
                y: -10,
                x: 10
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        series: dataplot
    });
    CurrChart.reflow();

}

function nav(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint, CustomSeriesColors, IsPercent) {

    Highcharts.setOptions({
        lang: {
            rangeSelectorZoom: ''
        },
    });

    var CurrChart = Highcharts.stockChart({

        chart: {
            renderTo: containerid,
            height: specialprop.ht
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            },
            symbolHeight: 20,
            symbolWidth: 30,
            symbolRadius: 2
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        exporting: {
            enabled: isexport,
            sourceWidth: 800,
            sourceHeight: 400,
            // scale: 1,
            //  width: 1200
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        navigator: {
            enabled: specialprop.navigator
        },
        rangeSelector: {
            buttons: specialprop.navbutton,
            selected: specialprop.selected,
            inputEnabled: specialprop.inputEnabled,
            inputDateParser: function (value) {
                //  debugger;
                value = value.split('-');
                return Date.UTC(
                    parseInt(value[2]),
                    parseInt(value[1]) - 1,
                    parseInt(value[0])
                );
            },
            inputDateFormat: '%d-%m-%Y',
            inputEditDateFormat: '%d-%m-%Y',
            enabled: specialprop.inputEnabled
        },
        yAxis: {
            title: {
                min: 0,
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                formatter: function () {
                    return (this.value > 0 ? ' + ' : '') + this.value + '%';
                },

                style: {
                    color: '#666666',
                    //fontSize: '12px',
                    fontWeight: 'bold',
                    color: 'black'
                }
            },
            plotLines: [{
                value: 0,
                width: 2,
                color: 'silver'
            }]
        },
        plotOptions: {
            series: {
                //compare: angular.isUndefined(specialprop.ValueType) ? 'percent' : specialprop.ValueType,// 'percent',
                compare: (IsPercent == undefined || IsPercent == true) ? 'percent' : specialprop.ValueType,//undefined,
                showInNavigator: true,
                compareStart: angular.isUndefined(specialprop.ValueType) ? true : false,// true,
                //pointStart: dataplot[0].data[0][0],
                gapSize: 0,
                //dataGrouping: {
                //    enabled: false
                //}

            }
        },
        tooltip: {
            valueDecimals: tooltipDecimalPoint,
            shared: true,
            formatter: function () {
                var s = '';
                var d = new Date(this.x);
                var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var navdate = days[d.getDay()] + ' ,' + months[d.getMonth()] + ' ' + d.getDate() + ' ,' + d.getFullYear();
                s = s + '<span style="color:#839557">' + navdate + '</span><br /><br />';
                var ValueIndex = 2
                if (specialprop.IsRebaseRequired == false) {
                    ValueIndex = 1
                }
                var dataIndex = 0;
                for (var i = 0; i < this.points.length; i++) {
                    if (this.points[i] != undefined) {
                        while (this.points[i].point.series.name != dataplot[dataIndex].name) {
                            dataIndex++;
                        }
                    }
                    for (var k = 0; k < dataplot[dataIndex].data.length; k++) {
                        if (this.x === dataplot[dataIndex].data[k][0]) {
                            if (this.points[i] != undefined) {
                                if (specialprop.perOnly == false) {
                                    s = s + '<span style="color:' + this.points[i].color + '">' + this.points[i].point.series.name + '</span>: <b>'
                                        + (dataplot[dataIndex].data[k][ValueIndex].toString() == -1 ? "N/A" :
                                            $.isNumeric(dataplot[dataIndex].data[k][ValueIndex].toString()) ? parseFloat(dataplot[dataIndex].data[k][ValueIndex]).toFixed(tooltipDecimalPoint) :
                                                dataplot[dataIndex].data[k][ValueIndex].toString()
                                        )
                                        + '</b>' + (specialprop.IsTooltipWithChangeRequired == false || angular.isUndefined(this.points[i].point.change) ? "<br />" : ' (' + this.points[i].point.change.toFixed(tooltipDecimalPoint) + '%)<br />');
                                }
                                else {
                                    if (!angular.isUndefined(specialprop.ValueType) && specialprop.ValueType == 'Value') {
                                        s = s + '<span style="color:' + this.points[i].color + '">' + this.points[i].point.series.name + '</span>: <b>' +
                                            '</b>' + (specialprop.IsTooltipWithChangeRequired == false ? "<br />" : ' (' + ($.isNumeric(dataplot[dataIndex].data[k][ValueIndex].toString()) ? parseFloat(dataplot[dataIndex].data[k][ValueIndex]).toFixed(tooltipDecimalPoint) + '%)<br />' :
                                                dataplot[dataIndex].data[k][ValueIndex].toString() + '%)<br />'));
                                    }
                                    else {

                                        s = s + '<span style="color:' + this.points[i].color + '">' + this.points[i].point.series.name + '</span>: <b>' +
                                            '</b>' + (specialprop.IsTooltipWithChangeRequired == false ? "<br />" : ' (' + this.points[i].point.change.toFixed(tooltipDecimalPoint) + '%)<br />');
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
                return s;
            }
        },
        series: dataplot,
        exporting: {
            chartOptions: {
                legend: {
                    enabled: true,
                    itemStyle: { fontFamily: "Arial", fontSize: '8px' }
                },
                buttons: {
                    contextButton: {
                        verticalAlign: top,
                        width: 24,
                        x: -10,
                        y: 0
                    }
                }
            }
        },
    }, function (chart) {
        // apply the date pickers
        setTimeout(function () {
            if (chart != null && typeof (chart) != undefined && chart.options != null && typeof (chart.options) != undefined) {
                $('input.highcharts-range-selector', $("#" + chart.options.chart.renderTo))
                    .datepicker({
                        format: "dd-mm-yyyy",
                        todayBtn: "linked",
                        orientation: "auto left",
                        autoclose: true,
                        todayHighlight: true
                    });
                $('input.highcharts-range-selector', $("#" + chart.options.chart.renderFrom))
                    .datepicker({
                        format: "dd-mm-yyyy",
                        todayBtn: "linked",
                        orientation: "auto left",
                        autoclose: true,
                        todayHighlight: true
                    });
            }
        }, 0);
    });

    //var rangeSelector = $('input.highcharts-range-selector');
    //var inputMin = rangeSelector.filter('[name=min]');
    //var inputMax = rangeSelector.filter('[name=max]');
    $("[name=min]").val("01 Mar 2017");
    $("[name=max]").val("01 Mar 2018");


    // Set the datepicker's date format



    CurrChart.reflow();
    // CurrChart.redraw();

}

function formatDate(d) {
    date = new Date(d)
    var dd = date.getDate();
    var mm = date.getMonth() + 1;
    var yyyy = date.getFullYear();
    if (dd < 10) { dd = '0' + dd }
    if (mm < 10) { mm = '0' + mm };
    return d = dd + '/' + mm + '/' + yyyy
}

function navWithOutRebase(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {

    Highcharts.setOptions({
        lang: {
            rangeSelectorZoom: ''
        },

    });
    var CurrChart = Highcharts.stockChart({

        chart: {
            renderTo: containerid,
            height: specialprop.ht
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        exporting: {
            enabled: isexport,
            sourceWidth: 800,
            sourceHeight: 400,
            // scale: 1,
            //  width: 1200
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        navigator: {
            enabled: specialprop.navigator
        },
        rangeSelector: {
            buttons: specialprop.navbutton,
            selected: specialprop.selected,
            inputEnabled: specialprop.inputEnabled,
            //inputDateFormat: '%d-%m-%Y',
            //inputEditDateFormat: '%d-%m-%Y',
            inputDateParser: function (value) {
                value = value.split('-');
                return Date.UTC(
                    parseInt(value[2]),
                    parseInt(value[1]) - 1,
                    parseInt(value[0])
                );
            }
        },
        yAxis: {
            title: {
                min: 0,
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
            labels: {
                formatter: function () {
                    //return (this.value > 0 ? ' + ' : '') + this.value + '%';
                    return (this.value > 0 ? ' + ' : '') + this.value;
                }
            },
            plotLines: [{
                value: 0,
                width: 2,
                color: 'silver'
            }]
        },
        plotOptions: {
            series: {
                //compare: 'percent',
                compare: 'Value',
                showInNavigator: true
            }
        },
        tooltip: {
            valueDecimals: tooltipDecimalPoint,
            shared: true,
            //  backgroundColor: '#FCFFC5',

            formatter: function () {
                var s = '';

                var d = new Date(this.x);
                //debugger;
                var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var navdate = days[d.getDay()] + ' ,' + months[d.getMonth()] + ' ' + d.getDate() + ' ,' + d.getFullYear();

                s = s + '<span style="color:#839557">' + navdate + '</span><br /><br />';
                //  debugger;
                for (var i = 0; i < dataplot.length; i++) {
                    for (var k = 0; k < dataplot[i].data.length; k++) {
                        if (this.x === dataplot[i].data[k][0]) {
                            s = s + '<span style="color:' + this.points[i].color + '">' + dataplot[i].name + '</span>: <b>'
                                + (dataplot[i].data[k][1].toString() == -1 ? "N/A" : dataplot[i].data[k][1].toFixed(tooltipDecimalPoint))
                                + ((specialprop.HideCngPer == undefined || specialprop.HideCngPer == null || specialprop.HideCngPer == false) ? '</b> (' + this.points[i].point.change.toFixed(tooltipDecimalPoint) + '%)<br />' : "");
                            break;
                        }
                    }
                }
                return s;
            }
        },
        series: dataplot,
        exporting: {
            chartOptions: {
                legend: {
                    enabled: true,
                    itemStyle: { fontFamily: "Arial", fontSize: '8px' }
                },
            }
        },
    },
        function (chart) {
            //setTimeout(function () {
            //    $('input.highcharts-range-selector', $('#' + chart.options.chart.renderTo)).datepicker({
            //        //------Previous
            //        //format: 'dd-mm-yy',
            //        //autoclose: true,
            //        //// minViewMode: 1

            //        //-------Mutualfund
            //        //dateFormat: 'yy-mm-dd',
            //        //changeMonth: true,
            //        //changeYear: true,
            //        //maxDate: -2
            //        format: "dd/mm/yyyy",
            //       // todayBtn: "linked",
            //        orientation: "auto left",
            //        autoclose: true,
            //        todayHighlight: true
            //    }).on('changeDate', function () {
            //        this.onchange();
            //        this.onblur();
            //    });
            //}, 0);

            setTimeout(function () {
                //var rangeSelector = $('#container input.highcharts-range-selector');
                var rangeSelector = $('input.highcharts-range-selector', $('#' + chart.options.chart.renderTo));
                rangeSelector.datepicker({
                    autoclose: true,
                    todayHighlight: true
                });

                var inputMin = rangeSelector.filter('[name=min]');
                var inputMax = rangeSelector.filter('[name=max]');

                inputMin.datepicker().on("changeDate", function (event) {
                    console.log(inputMin.datepicker("getDate"));
                    console.log(inputMin.datepicker("getUTCDate"));
                    this.onchange();
                    this.onblur();
                });
            }, 1000);
        }
    );


    CurrChart.reflow();
    // CurrChart.redraw();

}

function LineChartIrregularInterval(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle) {

    Highcharts.chart(containerid, {
        chart: {
            type: 'spline'
        },
        annotationsOptions: {
            enabledButtons: false
        },
        title: {
            text: chartTitle
        },
        subtitle: {
            text: subtitle
        },
        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: { // don't display the dummy year
                month: '%e. %b',
                year: '%b'
            },
            title: {
                text: xtextPrimary
            }
        },
        yAxis: {
            title: {
                text: ytextPrimary
            },
            //min: 0,
            //softMin: 0,
            //softMax: 1,
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br>',
            pointFormat: '{point.x:%e. %b}: {point.y:.4f} m'
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        plotOptions: {
            spline: {
                marker: {
                    enabled: true
                }
            }
        },

        series: dataplot
    });
}

function TreeMap(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    // debugger;
    var CurrChart = Highcharts.chart(containerid, {
        colorAxis: {
            minColor: '',
            maxColor: '#5341da'
        },
        chart: {
            type: 'treemap',
            //backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.height,
            // width:635
            options3d: {
                enabled: false,
                alpha: 45,
                beta: 0
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        legend: {
            enabled: islegend || false,
        },
        series: [{
            events: {
                click: function (e) {
                    // debugger;

                    if (specialprop.funname == "FMasset") {
                        AssetAllocationDetails(e.point.id, e.point.NameToDisplay);
                    }
                    if (specialprop.funname == "FMsector") {
                        SectorAllocationDetails(e.point.id, e.point.name);
                    }
                    if (specialprop.funname == "FMRating") {
                        RatingAllocationDetails(e.point.id, e.point.NameToDisplay);
                    }
                    if (specialprop.funname == "AMCSector") {
                        SectorAllocationDetails(e.point.id, e.point.name);
                    }



                }
            },
            type: "treemap",
            layoutAlgorithm: 'squarified',
            allowDrillToNode: true,
            alternateStartingDirection: true,
            levelIsConstant: false,
            dataLabels: {
                enabled: false
            },

            levels: [{
                level: 1,
                layoutAlgorithm: 'sliceAndDice',
                dataLabels: {
                    enabled: true,
                    style: {
                        // fontSize: '12px',
                        //// fontWeight: 'bold',
                        // cursor: 'pointer'

                        fontSize: yxchartstyle.fontSize,
                        fontFamily: yxchartstyle.fontFamily,
                        color: '#FFFFFF',
                        fontWeight: yxchartstyle.fontWeight,
                        textOutline: '0px'
                    },
                    //shadow: false
                }
            }],

            data: dataplot
        }],

        tooltip: {
            valueDecimals: tooltipDecimalPoint,
            //  valuePrefix: 'INR ',
            valueSuffix: '%'
        },
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
    });
    CurrChart.reflow();
    CurrChart.redraw();

}

function HeatMap(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {

    Highcharts.chart(containerid, {

        chart: {
            type: 'heatmap',
            marginTop: 40,
            marginBottom: 80,
            plotBorderWidth: 1,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        annotationsOptions: {
            enabledButtons: false
        },

        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        //subtitle: {
        //    text: subtitle
        //},
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        xAxis: {
            categories: xcategoriey,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },

        yAxis: {
            categories: ycategoriey,
            //  title: ytextPrimary,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },

        colorAxis: {
            min: 0,
            minColor: '#FFFFFF',
            maxColor: Highcharts.getOptions().colors[0]
        },

        legend: {
            align: 'right',
            layout: 'vertical',
            margin: 0,
            verticalAlign: 'top',
            y: 25,
            symbolHeight: 280
        },

        //legend: {
        //    enabled: islegend,
        //    align: legendstyle.align,
        //    verticalAlign: legendstyle.verticalAlign,
        //    layout: legendstyle.layout,
        //    itemStyle: {
        //        fontSize: legendstyle.fontSize,
        //        fontFamily: legendstyle.fontFamily,
        //        color: legendstyle.color,
        //        fontWeight: legendstyle.fontWeight,
        //    }

        //},
        tooltip: {
            formatter: function () {
                return '<b>' + this.series.xAxis.categories[this.point.x] + '</b> sold <br><b>' +
                    this.point.value + '</b> items on <br><b>' + this.series.yAxis.categories[this.point.y] + '</b>';
            }
        },

        series: [{
            name: 'Sales per employee',
            borderWidth: 1,
            data: dataplot,
            dataLabels: {
                enabled: true,
                color: '#000000'
            }
        }]

    });
}

function Flahchart(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop) {


    Highcharts.stockChart(containerid, {

        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }

        },
        annotationsOptions: {
            enabledButtons: false
        },
        exporting: {
            enabled: isexport
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        navigator: {
            enabled: specialprop.navigator
        },
        rangeSelector: {
            buttons: specialprop.navbutton,
            selected: specialprop.selected,
            inputEnabled: specialprop.inputEnabled
        },

        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },

        yAxis: {
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },

        series: dataplot
    },
        function (chart) {

            // apply the date pickers
            setTimeout(function () {
                $('input.highcharts-range-selector', $(chart.container).parent()).datepicker({
                    dateFormat: 'yy-mm-dd',
                    changeMonth: true,
                    changeYear: true,
                    maxDate: -2
                });
            }, 0);
        }
    );

}

function colgrp(containerid, dataplot, ycategoriey, xcategoriey, ytextPrimary, ytextSecondary, xtextPrimary, xtextSecondary, chartTitle, subtitle, isexport, islegend, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, specialprop, tooltipDecimalPoint) {
    var CurrChart = Highcharts.chart(containerid, {
        chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            height: specialprop.ht
        },
        //colors: specialprop.colors,
        title: {
            text: chartTitle,
            style: {
                fontSize: titlechartstyle.fontSize,
                fontFamily: titlechartstyle.fontFamily,
                color: titlechartstyle.color,
                fontWeight: titlechartstyle.fontWeight
            }
        },
        subtitle: {
            text: subtitle,
            style: {
                fontSize: subtitlechartstyle.fontSize,
                fontFamily: subtitlechartstyle.fontFamily,
                color: subtitlechartstyle.color,
                fontWeight: subtitlechartstyle.fontWeight
            }
        },
        annotationsOptions: {
            enabledButtons: false
        },
        exporting: {
            enabled: isexport
        },
        legend: {
            enabled: islegend,
            align: legendstyle.align,
            verticalAlign: legendstyle.verticalAlign,
            layout: legendstyle.layout,
            itemStyle: {
                fontSize: legendstyle.fontSize,
                fontFamily: legendstyle.fontFamily,
                color: legendstyle.color,
                fontWeight: legendstyle.fontWeight,
            }
        },
        tooltip: {
            followPointer: false,
            shadow: false,
            positioner: function (labelWidth, labelHeight, point) {
                return {
                    x: (point.plotX - labelWidth / 2) > 0 ? (point.plotX - labelWidth / 2) : 0,
                    y: 0
                };
            },
            headerFormat: '<div style="height:200px; overflow-y:scroll; pointer-events: all !important;"><span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.' + tooltipDecimalPoint + 'f}</b></td></tr>',
            footerFormat: '</table></div>',
            shared: true,
            useHTML: true
        },
        xAxis: {
            categories: xcategoriey,
            crosshair: true,
            title: {
                text: xtextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            }
        },
        yAxis: {
            // min: 0,
            title: {
                text: ytextPrimary,
                style: {
                    fontSize: yxchartstyle.fontSize,
                    fontFamily: yxchartstyle.fontFamily,
                    color: yxchartstyle.color,
                    fontWeight: yxchartstyle.fontWeight
                }
            },
        },
        credits: {
            enabled: true,
            text: creditText,
            href: creditLink
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            },
            series: {
                colorByPoint: false,
                //dataLabels: {
                //    enabled: true
                //}
            }
        },

        series: dataplot
    });

    CurrChart.reflow();
}