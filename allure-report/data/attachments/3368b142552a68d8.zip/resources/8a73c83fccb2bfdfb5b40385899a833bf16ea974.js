SharedDeractives.directive('dirFundDashboardPortfolio',
    ['GetFundPortfolio', 'GetLatestPortMonths', 'MFIMsg', '$filter', function (GetFundPortfolio, GetLatestPortMonths, MFIMsg, $filter) {
        return {
            //restrict: 'E',
            scope: { schemeId: "=", natureName: "=", fundId: "=", loginId: "=", userBasicSettings: "=" },
            templateUrl: function (elem, attrs) {
                return "/FundDashboard/GetPortfolioHTML"
            },
            controller: function ($scope, $http) {
                var CustomColors4Portpolio = ["#4b5de4", "#d8b83f", "#ff5800", "#23c6c8", "#ed5565", "#009688"];
                var yxchartstyle = { "fontSize": "13px", "fontFamily": "Roboto Condensed, sans-serif", "color": "rgb(75,93,228)", "fontWeight": "bold" };
                var titlechartstyle = { "fontSize": "25px", "fontFamily": "Roboto Condensed, sans-serif", "color": "blue", "fontWeight": "bold" };
                var subtitlechartstyle = { "fontSize": "12px", "fontFamily": "Roboto Condensed, sans-serif", "color": "pink", "fontWeight": "lighter" };
                var legendstyle = { "fontSize": "13px", "fontFamily": "Roboto Condensed, sans-serif", "color": "green", "fontWeight": "bold", "align": "center", "verticalAlign": "bottom", "layout": "horizontal" };
                var piespecialprop = { "size": 270 };
                var dualspecialprop = { "ypformat": " °C", "ysformat": " mm" };
                var navspecialprop = { "selected": 2, "navigator": true, "inputEnabled": true };
                var chartstyle = { "fontSize": "13px", "fontFamily": "Roboto Condensed, sans-serif", "color": "black", "fontWeight": "bold" };
                var barspecialprop = { "maxPointWidth": 15, "Xlablecolor": "black" };
                var decimalPlaces = parseInt($scope.userBasicSettings.NavDecimalFormat);
                $scope.FDPortfolio = {};
                var RatingData = [];
                ////alert($scope.userBasicSettings.NavDecimalFormat);
                //  debugger;
                var PageCount = $scope.userBasicSettings.ResultPerPage.split('-').length > 0 ?
                    $scope.userBasicSettings.ResultPerPage.split('-')[1] : $scope.userBasicSettings.ResultPerPage;
                $scope.FundAllRating = function () {

                    $scope.FundDashboard.Rating = null;
                    $('#DvRating').hide();
                };
                $scope.ActivePortDate = {};
                $scope.FN_FeatchPortfolio = function () {
                    if ($scope.schemeId != 0) {

                        $scope.FDPortfolio.Loader = true;

                        var PortDate = null;
                        if (angular.isUndefinedOrNull($scope.ActivePortDate.MonthYearId) == false) {
                            PortDate = $scope.ActivePortDate.MonthYearId;
                        }

                        var FundPortfolio = GetFundPortfolio.Call($scope.schemeId, $scope.fundId, PortDate, 3, 5, $scope.userBasicSettings.Sector_Level);
                        FundPortfolio.then(function (response) {
                            if (response.data.Success == false) {
                                MFIMsg.AlertHtml("Error in fetching portfolio", MFIAlertType.Error, "OK");
                                $scope.FDPortfolio.Loader = false;
                                return false;
                            }
                            $scope.FDPortfolio = response.data.data;
                            //send to FundCtrl
                            $scope.$emit('notification', { Data: $scope.FDPortfolio.StrPortDate, Msg: "Portfolio", });
                            $scope.FDPortfolio.FN_E2ETop10Holding = function () {
                                window.open("/FundDashboard/ExportToExcelE2ETop10Holding?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };

                            $scope.FDPortfolio.FN_E2EDetailsPortfolio = function () {
                                window.open("/FundDashboard/ExportToExcelDtlPortfolio?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };

                            $scope.FDPortfolio.FN_E2ETopSector = function () {
                                window.open("/FundDashboard/ExportToExcelTopSector?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };
                            $scope.FDPortfolio.FN_E2EWhatsIn = function () {
                                window.open("/FundDashboard/ExportToExcelWhatsIn?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };
                            $scope.FDPortfolio.FN_E2EWhatsOut = function () {
                                window.open("/FundDashboard/ExportToExcelWhatsOut?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };
                            $scope.FDPortfolio.FN_E2ERating = function () {
                                window.open("/FundDashboard/ExportToExcelRatingAllocation?FundId=" + $scope.fundId + "&PortDate=" + $scope.FDPortfolio.StrPortDate + "&SectorLevel=" + $scope.userBasicSettings.Sector_Level);
                            };

                            $scope.FDPortfolio.GrpEq = false;
                            $scope.FDPortfolio.GrpDb = false;

                            if (($scope.natureName == 'Equity') || ($scope.natureName == 'Speciality') || ($scope.natureName == 'Balanced') ||
                                ($scope.natureName == 'ETF') || ($scope.natureName == 'Fund of Funds') ||
                                ($scope.natureName == 'Dynamic/Asset Allocation') || ($scope.natureName == 'Hybrid')
                                || ($scope.natureName == 'Solution Oriented') || ($scope.natureName == 'Other')) {
                                $scope.FDPortfolio.GrpEq = true;
                            }

                            if (($scope.natureName == 'Speciality') || ($scope.natureName == 'Balanced') ||
                                ($scope.natureName == 'Dynamic/Asset Allocation') || ($scope.natureName == 'Debt') ||
                                ($scope.natureName == 'Gilt') || ($scope.natureName == 'Liquid') || ($scope.natureName == 'Hybrid')
                                 || ($scope.natureName == 'Solution Oriented') ) {
                                $scope.FDPortfolio.GrpDb = true;
                            }
                            
                            $scope.FDPortfolio.LstPortfolioDetailsSpecificNo = response.data.data.LstTop10Holding;

                            $scope.FDPortfolio.MonthYearId = $scope.FDPortfolio.PortDate;
                            $scope.ActivePortDate = { 
                                MonthYearId: $scope.FDPortfolio.MonthYearId
                            };
                            //Asset allocation
                            if ($scope.FDPortfolio.GrpEq == true) {
                                var Model_FundDashboardPortfolio = $scope.FDPortfolio.LstAssetAllocation;
                                var PlotDataAssetAllocation = [[]];
                                for (var i = 0; i < Model_FundDashboardPortfolio.length; i += 1) {
                                    var TextVal = [];
                                    TextVal.push(Model_FundDashboardPortfolio[i].CompanyNatureName);

                                    if (parseFloat(Model_FundDashboardPortfolio[i].Value) >= 0) {
                                        TextVal.push(Model_FundDashboardPortfolio[i].Value);
                                        TextVal.push(true);
                                    }
                                    else {
                                        TextVal.push(parseFloat(parseFloat(Model_FundDashboardPortfolio[i].Value) * -1));
                                        TextVal.push(false);
                                    }

                                    //TextVal.push(Model_FundDashboardPortfolio[i].Value);
                                    PlotDataAssetAllocation.push(TextVal);
                                }


                                PlotDataAssetAllocation.shift();

                                navspecialprop.Orginaldata = PlotDataAssetAllocation;
                                //GenerateGraph('pie', 'ChartAssetAllocation', PlotDataAssetAllocation.sort(), '', '', '', '', '', '', '', '', true, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4Portpolio, $scope.userBasicSettings.OtherDecimal);
                                GenerateGraph('donut3dNeg', 'ChartAssetAllocation', PlotDataAssetAllocation.sort(), '', '', '', '', '', '', '', '', true, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4Portpolio);
                            }
                            //end Asset allocation
                            // Instrument Allocation
                            if ($scope.FDPortfolio.GrpDb == true) {
                                var Model_FD_Ins_Allocation = $scope.FDPortfolio.LstInstrumentAllocation;
                                var PlotDataInsAllocation = [[]];
                                for (var i = 0; i < Model_FD_Ins_Allocation.length; i += 1) {
                                    var TextVal = [];
                                    TextVal.push(Model_FD_Ins_Allocation[i].InstrumentName);
                                    //TextVal.push(Model_FD_Ins_Allocation[i].Value);
                                    //  debugger;
                                    if (parseFloat(Model_FD_Ins_Allocation[i].Value) >= 0) {
                                        TextVal.push(Model_FD_Ins_Allocation[i].Value);
                                        TextVal.push(true);
                                    }
                                    else {
                                        TextVal.push(parseFloat(parseFloat(Model_FD_Ins_Allocation[i].Value) * -1));
                                        TextVal.push(false);
                                    }
                                    PlotDataInsAllocation.push(TextVal);
                                }
                                // debugger;
                                PlotDataInsAllocation.shift();
                                navspecialprop.Orginaldata = PlotDataInsAllocation;
                                GenerateGraph('pieNegative', 'ChartInstrumentAllocation', PlotDataInsAllocation.sort(), '', '', '', '', '', '', '', '', true, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4Portpolio, $scope.userBasicSettings.OtherDecimal);
                            }

                            //end instrument
                            // M-Cap
                            if ($scope.FDPortfolio.GrpEq == true) {
                                var Model_FD_MarketCap = $scope.FDPortfolio.LstMarketCap;
                                var PlotDataMarketCap = [[]];
                                for (var i = 0; i < Model_FD_MarketCap.length; i += 1) {
                                    var TextVal = [];
                                    TextVal.push(Model_FD_MarketCap[i].MarketSlap);
                                    TextVal.push(Model_FD_MarketCap[i].MCap);
                                    PlotDataMarketCap.push(TextVal);
                                }
                                //  debugger;
                                PlotDataMarketCap.shift();
                                GenerateGraph('pie', 'ChartMarketCapitalisation', PlotDataMarketCap, '', '', '', '', '', '', '', '', true, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4Portpolio, $scope.userBasicSettings.OtherDecimal);
                                //GenerateGraph('donut3d', 'ChartMarketCapitalisation', PlotDataMarketCap, '', '', '', '', '', '', '', '', false, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4Portpolio);
                            }
                            //end M-cap
                            // Avg-Mach
                            
                            if ($scope.FDPortfolio.GrpDb == true) {
                                var Model_FD_AvgMach = $scope.FDPortfolio.LstAverageMaturity;
                                var PlotDataAvgMach = [[]];
                                var ticks = [];
                                var points = [];
                                //for (var i = 0; i < Model_FD_AvgMach.length; i += 1) {
                                //    var TextVal = [];
                                //    TextVal.push(Model_FD_AvgMach[i].MonthYear);
                                //    TextVal.push(Model_FD_AvgMach[i].AvgMat);
                                //    PlotDataAvgMach.push(TextVal);
                                //}


                                for (var i = 0; i < Model_FD_AvgMach.length; i += 1) {
                                    var TextVal = [];
                                    ticks.push(Model_FD_AvgMach[i].MonthYear);
                                    points.push(parseInt(Model_FD_AvgMach[i].AvgMat));
                                    // PlotDataAvgMach.push(TextVal);
                                }

                                PlotDataAvgMach.shift();
                                //  debugger;
                                var bardataplot = [{
                                    name: '',
                                    data: points
                                }];
                                // debugger;
                                GenerateGraph('bar', 'ChartAverageMaturity', bardataplot, '', ticks, 'Average Maturity (in Days)', '', '', '', '', '', true, false, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, barspecialprop, CustomColors4Portpolio, 0);

                            }

                            //end Avg-Mach

                            //Pagination Top 10 Holding

                            $scope.lst = [];
                            var pageCnt = 1;
                            $scope.lst = $scope.FDPortfolio.LstPortfolioDetails.slice(0, PageCount);
                            if (($scope.FDPortfolio.LstPortfolioDetails.length % PageCount) == 0) {
                                pageCnt = $scope.FDPortfolio.LstPortfolioDetails.length / PageCount;
                            }
                            else {
                                pageCnt = parseInt(($scope.FDPortfolio.LstPortfolioDetails.length / PageCount)) + 1;
                            }
                            $scope.paging = {
                                total: pageCnt,
                                current: 1,
                                onPageChanged: loadPages,
                            };
                            $scope.currentPage = $scope.paging.current;

                            function loadPages() {

                                $scope.lst = $scope.FDPortfolio.LstPortfolioDetails.slice(($scope.paging.current - 1) * PageCount, ($scope.paging.current * PageCount));
                                $scope.currentPage = $scope.paging.current;
                            }

                            //end Pagination Top 10 Holding
                            //Pagination Detailed Portfolio

                            $scope.FDPortfolioCurrentPage = 0;
                            $scope.lstFDPortfolio = [];
                            //debugger;
                            var FDPortfolioPageCnt = 1;
                            var PageSize4TopHolding = 5;
                            $scope.lstFDPortfolio = $scope.FDPortfolio.LstPortfolioDetailsSpecificNo.slice(0, PageSize4TopHolding);

                            if (($scope.FDPortfolio.LstPortfolioDetailsSpecificNo.length % PageSize4TopHolding) == 0) {
                                FDPortfolioPageCnt = $scope.FDPortfolio.LstPortfolioDetailsSpecificNo.length / PageSize4TopHolding;
                            }
                            else {
                                FDPortfolioPageCnt = parseInt(($scope.FDPortfolio.LstPortfolioDetailsSpecificNo.length / PageSize4TopHolding)) + 1;
                            }
                            $scope.pagingFDPortfolio = {
                                total: FDPortfolioPageCnt,
                                current: 1,
                                onPageChanged: FDPortfolioloadPages,
                            };
                            $scope.FDPortfolioCurrentPage = $scope.pagingFDPortfolio.current;

                            function FDPortfolioloadPages() {
                                //debugger;
                                $scope.lstFDPortfolio = $scope.FDPortfolio.LstPortfolioDetailsSpecificNo.slice(($scope.pagingFDPortfolio.current - 1) * PageSize4TopHolding, ($scope.pagingFDPortfolio.current * PageSize4TopHolding));
                                $scope.FDPortfolioCurrentPage = $scope.pagingFDPortfolio.current;
                            }

                            //end Pagination Detailed Portfolio

                            //Pagination Whats in

                            $scope.FDWhatsInCurrentPage = 0;
                            $scope.lstWhatsIn = [];

                            var FDWhatsInPageCnt = 1;
                            var PageSize = PageCount;
                            $scope.lstWhatsIn = $scope.FDPortfolio.LstNewEntryPortfolioDetails.slice(0, PageSize);

                            if (($scope.FDPortfolio.LstNewEntryPortfolioDetails.length % PageSize) == 0) {
                                FDWhatsInPageCnt = $scope.FDPortfolio.LstNewEntryPortfolioDetails.length / PageSize;
                            }
                            else {
                                FDWhatsInPageCnt = parseInt(($scope.FDPortfolio.LstNewEntryPortfolioDetails.length / PageSize)) + 1;
                            }
                            $scope.pagingWhatsIn = {
                                total: FDWhatsInPageCnt,
                                current: 1,
                                onPageChanged: FDWhatsInloadPages,
                            };
                            $scope.FDWhatsInCurrentPage = $scope.pagingWhatsIn.current;

                            function FDWhatsInloadPages() {

                                $scope.lstWhatsIn = $scope.FDPortfolio.LstNewEntryPortfolioDetails.slice(($scope.pagingWhatsIn.current - 1) * PageSize, ($scope.pagingWhatsIn.current * PageSize));
                                $scope.FDWhatsInCurrentPage = $scope.pagingWhatsIn.current;
                            }

                            //end Pagination Whats in

                            //Pagination Whats out

                            $scope.FDWhatsOutCurrentPage = 0;
                            $scope.lstWhatsOut = [];

                            var FDWhatsOutPageCnt = 1;
                            var PageSize = PageCount;
                            $scope.lstWhatsOut = $scope.FDPortfolio.LstExitPortfolioDetails.slice(0, PageSize);

                            if (($scope.FDPortfolio.LstExitPortfolioDetails.length % PageSize) == 0) {
                                FDWhatsOutPageCnt = $scope.FDPortfolio.LstExitPortfolioDetails.length / PageSize;
                            }
                            else {
                                FDWhatsOutPageCnt = parseInt(($scope.FDPortfolio.LstExitPortfolioDetails.length / PageSize)) + 1;
                            }
                            $scope.pagingWhatsOut = {
                                total: FDWhatsOutPageCnt,
                                current: 1,
                                onPageChanged: FDWhatsOutloadPages,
                            };
                            $scope.FDWhatsOutCurrentPage = $scope.pagingWhatsOut.current;

                            function FDWhatsOutloadPages() {

                                $scope.lstWhatsOut = $scope.FDPortfolio.LstExitPortfolioDetails.slice(($scope.pagingWhatsOut.current - 1) * PageSize, ($scope.pagingWhatsOut.current * PageSize));
                                $scope.FDWhatsOutCurrentPage = $scope.pagingWhatsOut.current;
                            }

                            //end Pagination Whats out
                            $scope.RatngcurrentPage = 0;
                            $scope.lstRatingDetail = [];
                            RatingData = $scope.FDPortfolio.LstRatingWiseAllocation;
                            var pageCnt = 1;
                            //   debugger;
                            if (($scope.FDPortfolio.LstRatingWiseAllocation.length % PageCount) == 0) {
                                pageCnt = Math.floor($scope.FDPortfolio.LstRatingWiseAllocation.length / PageCount);
                            }
                            else {
                                pageCnt = Math.floor(($scope.FDPortfolio.LstRatingWiseAllocation.length / PageCount) + 1);
                            }
                            $scope.pagingRtng = {
                                total: pageCnt,
                                current: 1,
                                onPageChanged: loadPagesRating,
                            };


                            $scope.lstRatingDetail = $scope.FDPortfolio.LstRatingWiseAllocation.slice(($scope.pagingRtng.current - 1) * PageSize, ($scope.pagingRtng.current * PageSize));

                            $scope.RatngcurrentPage = $scope.pagingRtng.current;

                            function loadPagesRating() {

                                console.log('Current page is : ' + $scope.pagingRtng.current);

                                $scope.lstRatingDetail = $scope.FDPortfolio.LstRatingWiseAllocation.slice(($scope.pagingRtng.current - 1) * PageSize, ($scope.pagingRtng.current * PageSize));

                                $scope.RatngcurrentPage = $scope.pagingRtng.current;
                            }
                            if ($scope.FDPortfolio.GrpDb == true)
                            {

                                //var yxchartstyle = { "fontSize": "13px", "fontFamily": "latoregular", "color": "black", "fontWeight": "bold" };
                                //var legendstyle = { "fontSize": "13px", "fontFamily": "latoregular", "color": "black", "fontWeight": "bold", "align": "center", "verticalAlign": "bottom", "layout": "horizontal" };
                                //var titlechartstyle = { "fontSize": "25px", "fontFamily": "latoregular", "color": "blue", "fontWeight": "bold" };
                                //var subtitlechartstyle = { "fontSize": "12px", "fontFamily": "latoregular", "color": "pink", "fontWeight": "lighter" };
                                var clrlstSector = ["#4b5de4", "#d8b83f", "#ff5800", "#23c6c8", "#ed5565", "#009688"];
                                //end of rating allocation
                                var pieParentdata = GetPieFormatParentData($scope.FDPortfolio.PieChartdata.PieParentData);
                                var pieChilddata = GetPieFormatChildData($scope.FDPortfolio.PieChartdata.PieChildData);
                                var colpropPieAum = { "ht": 280, };
                                GenerateGraph('donutChartClickable', 'CreditQualitycontainer', pieParentdata, pieChilddata, null, '', '', '', '', '', '', false, false, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, colpropPieAum, clrlstSector, $scope.userBasicSettings.OtherDecimal);
                            }
                            $scope.FDPortfolio.Loader = false;

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Error in fetching portfolio", MFIAlertType.Error, "OK");
                            });
                    }
                };
                function GetPieFormatParentData(dataplot) {
                    //    debugger;

                    var parentmaindata = [];
                    var x = {};
                    x.name = 'Rating';
                    x.colorByPoint = true;
                    x.data = [];

                    if (dataplot != null) {

                        var tt = [];
                        for (var i = 0; i < dataplot.length; i += 1) {
                            var tt1 = {};
                            tt1.id = dataplot[i].ID;
                            tt1.name = dataplot[i].Name;
                            tt1.y = dataplot[i].Value;
                            tt1.drilldown = dataplot[i].DrillDown;

                            tt.push(tt1);
                        }

                        x.data = tt;
                        parentmaindata.push(x);

                        return parentmaindata;
                    }
                    else {
                        return null;
                    }

                }


                function GetPieFormatChildData(dataplot) {
                    // debugger;
                    if (dataplot != null) {

                        var tt = [];
                        for (var i = 0; i < dataplot.length; i += 1) {
                            var tt1 = {};
                            tt1.id = dataplot[i].DrillDown;
                            tt1.data = [[]];
                            for (var j = 0; j < dataplot[i].DrillDownValues.length; j += 1) {
                                var plot = []
                                plot.push(dataplot[i].DrillDownValues[j].Key, dataplot[i].DrillDownValues[j].Value);
                                tt1.data.push(plot);
                            }

                            tt1.data.shift();
                            tt.push(tt1);
                        }

                        return tt;
                    }
                    else {
                        return null;
                    }

                }
                
                $scope.FN_FeatchPortfolio();
                var LatestPortMonths = GetLatestPortMonths.Call($scope.fundId, 6);
                LatestPortMonths.then(function (response) {
                    //  debugger;
                    if (response.data.Success) {
                        $scope.LstLatestPortMonths = response.data.data;
                        if ($scope.LstLatestPortMonths.length>0)
                            $scope.FN_FeatchPortfolio();
                        else
                            MFIMsg.AlertHtml("Portfolio not found for the selected fund", MFIAlertType.Information, "OK");
                    }
                    else {
                        MFIMsg.AlertHtml("Error in fetching latest portfolio", MFIAlertType.Error, "OK");
                    }
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Error in fetching latest portfolio", MFIAlertType.Error, "OK");
                    });
                $scope.$watch('FundDashboard.Rating', function (newValue, oldValue) {
                    if (newValue != oldValue) {
                        if (newValue == null) {
                            $scope.FundDashboard.RatingTableData = RatingData;
                        }
                        else {
                            var substring = "~";
                            if (newValue.indexOf(substring) == -1)//level 0
                            {
                                $scope.FundDashboard.RatingTableData = $filter('filter')(RatingData, { RatingSubSetName: newValue});
                            }
                            else//level 1
                            {
                                var fields = newValue.split('~');
                                $scope.FundDashboard.RatingTableData = $filter('filter')(RatingData, { RatingSubSetName: fields[1] });
                            }
                        }
                        //Pagination
                        $scope.CreditcurrentPage = 0;
                        $scope.lstCredit = [];
                        var pageCnt = 1;

                        if (($scope.FundDashboard.RatingTableData.length % 10) == 0) {
                            pageCnt = Math.floor($scope.FundDashboard.RatingTableData.length / 10);
                        }
                        else {
                            pageCnt = Math.floor(($scope.FundDashboard.RatingTableData.length / 10) + 1);
                        }
                        $scope.pagingRtng = {
                            total: pageCnt,
                            current: 1,
                            onPageChanged: loadPagesRating,
                        };

                        $scope.lstRatingDetail = $scope.FundDashboard.RatingTableData.slice(($scope.pagingRtng.current - 1) * 10, ($scope.pagingRtng.current * 10));
                        $scope.RatngcurrentPage = $scope.pagingRtng.current;
                        function loadPagesRating() {
                            //console.log('Current page is : ' + $scope.Creditpaging.current);
                            $scope.lstRatingDetail = $scope.FundDashboard.RatingTableData.slice(($scope.pagingRtng.current - 1) * 10, ($scope.pagingRtng.current * 10));
                            $scope.RatngcurrentPage = $scope.pagingRtng.current;
                        }
                        //end pagination
                    }
                });
            }
        }
    }]);