!function () {
    "use strict";
    function ClPagingDirective() {
        return {
            restrict: "EA",
            scope: {
                clPages: "=",
                clAlign: "@",
                clAlignModel: "=",
                clPageChanged: "&",
                clCurrentPage: "=",
                index: "=",
            },
            controller: ClPagingController,
            controllerAs: "vm",
            template: [
                '<div layout="row" layout-align="{{ clAlign || clAlignModel }}">',
                '<md-button class="md-icon-button md-raised {{ (vm.index - 1 > 0) ? \'md-warn\' : \'\'}}" aria-label="First" ng-click="vm.gotoPrev()" ng-disabled="!(vm.index - 1 > 0)">{{ vm.first }}</md-button>',
                '<md-button class="md-icon-button md-raised {{ (vm.index < clPages) ? \'md-warn\' : \'\'}}" aria-label="Last" ng-click="vm.gotoNext()" ng-disabled="!(vm.index < clPages)">{{ vm.last }}</md-button>',
                "</div>"].join("")
        }
    }
    function ClPagingController($scope) {
        var vm = this;
        vm.first = "<",
            vm.last = ">",
            vm.index = 0,
            vm.gotoPrev = function () {
                vm.index -= 1;
                $scope.clCurrentPage = vm.index;
            }
            vm.gotoNext = function () {
                vm.index += 1,
                $scope.clCurrentPage = vm.index;
            }
            ,
            $scope.$watch("clCurrentPage", function (value) {
                vm.index = value,
                    $scope.clPageChanged()
            }),
            $scope.$watch("clPages", function () {
                vm.index = 1;
                $scope.clCurrentPage = vm.index;
            });
    }
    var app = angular.module("cl.paging-extn", []);
    app.directive("clPagingExtn", ClPagingDirective),
        ClPagingDirective.$inject = [],
        ClPagingController.$inject = ["$scope"]
}();

//index: {{vm.index}}  clPages: {{clPages}}  GoToPrev: {{vm.index - 1 > 0}} GoToNext: {{vm.index < clPages}}
