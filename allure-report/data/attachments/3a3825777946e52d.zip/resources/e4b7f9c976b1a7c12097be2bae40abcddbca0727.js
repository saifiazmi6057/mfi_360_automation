SharedDeractives.directive('ratingSet', ['$timeout', '$q', '$log', 'GetRatingSetsData', 'GetSingleRatingSetdetails', 'RatingSetsDelete', 'GetCompositRatingDetails', 'MakeDefaultRatingSet', 'SaveSetandCustomRatingName', 'SaveRatingsData', 'MFIMsg', '$filter',
    function ($timeout, $q, $log, GetRatingSetsData, GetSingleRatingSetdetails, RatingSetsDelete, GetCompositRatingDetails, MakeDefaultRatingSet, SaveSetandCustomRatingName, SaveRatingsData, MFIMsg, $filter) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '='
            },
            replace: false,
            templateUrl: '/Home/RatingSets',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    $scope.divshow = false;
                    $scope.divshowtable = true;
                    $scope.divshowAllRating = false;
                    $scope.selectedId = null;
                    $scope.radioSelectionId;
                    $scope.SetName = "";
                    $scope.RatingSetName = "";
                    $scope.Default;
                    //$scope.LstColor = ["Red", "Pink", "Blue", "Gray"];
                    $scope.LstColor = ["#1b847d", "#a0700f", "#1e5205", "#a22409", "#0e6ba0", "#3339FF", "#7e0684", "#FF33A2", "#FFD433"];
                    $scope.AddUpdate = "";
                    $scope.Gen = false;
                    $scope.editcreate = "";
                    $scope.RatingSetName = "";
                    $scope.RatingSubSetName = "";
                    $scope.RatingSetId = 0;
                    $scope.RatingSubSetId = 0;
                    $scope.LstRatingIdSelect = [];
                    $scope.LstRatingIdForDisable = [];
                    $scope.LstRating = [];
                    $scope.radioClassId = "";
                    $scope.LoaderRatingSearch = true;
                    $scope.radioSelectedId = "";
                    $scope.searchRatingText = "";
                    $scope.showAdd = false;
                    $scope.IsSetNameDisable = false;
                    $scope.IsCreateNew = "";
                    $scope.IsExist = "";
                    $scope.divshowRatings = false;
                    $scope.UserLogInId = "";
                    $scope.CreatedLogInId = "";
                    $scope.LstRatingWithOutFilter = [];

                    var getData = GetRatingSetsData.Call();

                    getData.then(function (response) {
                        $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                        $scope.IsTrial = response.data.data.IsTrial;

                        $scope.LoaderRatingSearch = false;
                        if (response.data.data.LstRatingSingleSetDetails != null) {
                            $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                            if (response.data.data.Data.IsDefault == true) {
                                //$scope.SetName = "Default";
                                //$scope.Default = true;
                                $scope.SetName = "Undo";
                                $scope.Default = false;
                            }
                            else {
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                            }
                            if (response.data.data.Data.IsGeneric == true) {
                                $scope.Gen = true;
                            }
                            else {
                                $scope.Gen = false;
                            }
                            $scope.divshowAllRating = false;
                            $scope.UserLogInId = response.data.data.UserLogInId;
                            $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                        }
                    },
                        function (stu) {
                            $scope.LoaderRatingSearch = false;
                            MFIMsg.AlertHtml("Rating set loading failed", MFIAlertType.Error);
                        });

                    $scope.getClassForDefault = function (IsDefault) {
                        if (IsDefault)
                            return "label label-primary";
                        else
                            return "label label-warning";
                    }

                    //$scope.getClass = function (radioSelectionId) {
                    //    if (radioSelectionId == 0)
                    //        return $scope.LstColor[0];
                    //    else if (radioSelectionId == 1)
                    //        return $scope.LstColor[1];
                    //    else if (radioSelectionId == 2)
                    //        return $scope.LstColor[2];
                    //    else if (radioSelectionId == 3)
                    //        return $scope.LstColor[3];
                    //}

                    //$scope.getClassForCheckbox = function (radioSelectionId, IsChecked) {
                    //    if (radioSelectionId == 0 && IsChecked == true)
                    //        return $scope.LstColor[0];
                    //    else if (radioSelectionId == 1 && IsChecked == true)
                    //        return $scope.LstColor[1];
                    //    else if (radioSelectionId == 2 && IsChecked == true)
                    //        return $scope.LstColor[2];
                    //    else if (radioSelectionId == 3 && IsChecked == true)
                    //        return $scope.LstColor[3];
                    //}

                    $scope.queryRatingSearch = queryRatingSearch;
                    $scope.selectedRatingItemChange = selectedRatingItemChange;
                    $scope.searchRatingTextChange = searchRatingTextChange;
                    //$scope.selectedItem = $scope.LstRatingSet;

                    function queryRatingSearch(query) {
                        var results = query ? $scope.LstRatingSet.filter(createFilterFor(query)) : $scope.LstRatingSet;
                        return results;
                    }

                    function searchRatingTextChange(text) {
                        $log.info('Text changed to ' + text);
                    }

                    $scope.FnCleanTextRating = function () {
                        $scope.searchRatingText = '';
                        $scope.ShowClearButtonRating = false;
                    }

                    function selectedRatingItemChange(item) {
                        if (item != undefined) {
                            $scope.ShowClearButtonRating = true;
                            var ratingsetParam = { "SetId": item.Id };
                            var getData = GetSingleRatingSetdetails.Call(ratingsetParam);
                            $scope.LoaderRatingTable = true;
                            getData.then(function (response) {
                                $scope.LoaderRatingTable = false;
                                $scope.divshow = false;
                                $scope.divshowRatings = false;
                                $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                                if (response.data.data.Data.IsDefault == true) {
                                    //$scope.SetName = "Default";
                                    //$scope.Default = true;
                                    $scope.SetName = "Undo";
                                    $scope.Default = false;
                                }
                                else {
                                    $scope.SetName = "Make Default";
                                    $scope.Default = true;
                                }
                                if (response.data.data.Data.IsGeneric == true) {
                                    $scope.Gen = true;
                                }
                                else {
                                    $scope.Gen = false;
                                }
                                $scope.divshowAllRating = false;
                                $scope.UserLogInId = response.data.data.UserLogInId;
                                $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Single custom set details fetched failed from search selection", MFIAlertType.Error);
                                });
                        }
                        $log.info('Item changed to ' + JSON.stringify(item));
                    }

                    function createFilterFor(query) {
                        var lowercaseQuery = angular.lowercase(query);

                        return function filterFn(state) {
                            return (angular.lowercase(state.Name).indexOf(lowercaseQuery) === 0);
                        };

                    }

                    $scope.createNew = function (ratName) {

                        $scope.divshowAllRating = false;
                        $scope.divshow = true;
                        $scope.RatingSetName = ratName;
                        $scope.RatingSubSetName = null;
                        $scope.RatingSetId = 0;
                        $scope.RatingSubSetId = 0;
                        $scope.AddUpdate = "Add";
                        $scope.editcreate = "Create Rating";
                        $scope.IsGeneric = false;
                        //$scope.showAdd = false;
                        $scope.IsSetNameDisable = false;
                        $scope.divshowRatings = true;
                        $scope.IsExist = false;
                        var getData = GetRatingSetsData.Call();
                        $scope.LoaderAllRating = true;
                        $scope.LoaderCreationSection = true;
                        $scope.showAdd = false;
                        $scope.showUpdate = false;
                        $scope.LstRatingIdSelect = [];
                        getData.then(function (response) {
                            $scope.LstRating = response.data.data.LstRating;
                            $scope.LoaderAllRating = false;
                            $scope.LoaderCreationSection = false;
                        },
                            function (stu) {
                                $scope.LoaderAllRating = false;
                                $scope.LoaderCreationSection = false;
                                $scope.divshow = false;
                                $scope.divshowRatings = false;
                                MFIMsg.AlertHtml("Ratings loading failed", MFIAlertType.Error);
                            });
                    }

                    //$scope.createNewFrmSearch = function (ratName) {
                    //    $scope.divshowAllRating = false;
                    //    $scope.divshow = true;
                    //    $scope.RatingSetName = ratName;
                    //    $scope.RatingSubSetName = null;
                    //    $scope.RatingSetId = 0;
                    //    $scope.RatingSubSetId = 0;
                    //    $scope.AddUpdate = "Add";
                    //    $scope.editcreate = "Create Rating";
                    //    $scope.IsGeneric = false;
                    //    //$scope.showAdd = false;
                    //    $scope.IsSetNameDisable = false;
                    //    $scope.divshowRatings = true;
                    //    $scope.IsExist = false;
                    //    var getData = GetRatingSetsData.Call();
                    //    $scope.LoaderAllRating = true;
                    //    $scope.LoaderCreationSection = true;
                    //    getData.then(function (response) {
                    //        $scope.LstRating = response.data.data.LstRating;
                    //        $scope.LoaderAllRating = false;
                    //        $scope.LoaderCreationSection = false;
                    //    },
                    //        function (stu) {
                    //            $scope.LoaderAllRating = false;
                    //            $scope.LoaderCreationSection = false;
                    //            $scope.divshow = false;
                    //            $scope.divshowRatings = false;
                    //            MFIMsg.AlertHtml("Ratings loading failed !!! !!!", "Error", "OK");
                    //        });
                    //}

                    $scope.edit = function (instruset) {
                        if (instruset.RatingSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.RatingSetName = instruset.RatingSetName;
                            $scope.RatingSubSetName = instruset.RatingSubSetName;
                            $scope.RatingSetId = instruset.RatingSetId;
                            $scope.RatingSubSetId = instruset.RatingSubSetId;
                            $scope.IsGeneric = $scope.Gen;
                            //$scope.IsTrial = $scope.IsTrial;
                            $scope.divshow = true;
                            $scope.AddUpdate = "Update";
                            $scope.editcreate = "Update Rating";
                            $scope.showAdd = false;
                            $scope.showUpdate = true;
                            $scope.IsSetNameDisable = true;
                            $scope.divshowRatings = false;
                            $scope.divshowAllRating = false;
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }

                    }

                    $scope.removeRow = function (InsSubId, RatingSetId) {
                        if (InsSubId == 0 && RatingSetId == 0)
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            MFIMsg.Confirm("You want to delete", "MFI360 Explorer", "Yes", "No").then(function () {
                                var delParam = { "RatingSetId": RatingSetId, "RatingSubId": InsSubId };
                                var getDelData = RatingSetsDelete.Call(delParam);

                                getDelData.then(function (response) {
                                    MFIMsg.AlertHtml("Rating sets deleted successfully", MFIAlertType.Success);
                                    $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                                    $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                                    $scope.divshowAllRating = false;
                                    $scope.divshow = false;
                                    if ($scope.LstRatingSingleSetDetails.length == 0) {
                                        $scope.searchRatingText = "";
                                        var getData = GetRatingSetsData.Call();
                                        getData.then(function (response) {
                                            $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                                        },
                                            function (stu) {
                                                MFIMsg.AlertHtml("Rating set loading failed", MFIAlertType.Error);
                                            });
                                    }

                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Rating sets deletion failed", MFIAlertType.Error);
                                    });

                            }, function () {
                            })


                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to delete", MFIAlertType.Information);
                        }

                    }

                    $scope.editSingleRow = function (setId, setSubId, SubSetName, id, setName) {
                        if ($scope.search != "" && $scope.search != undefined)
                            $scope.search.RatingName = "";
                        $scope.radioClassId = id;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.LoaderCustomRating = true;
                            $scope.LoaderAllRating = true;
                            $scope.divshow = false;
                            $scope.divshowRatings = false;
                            $scope.divshowAllRating = true;
                            var ratingDetailParam = { "RatingSetId": setId, "RatingSubSetId": setSubId, "RatingSubSetName": SubSetName/*.Replace("\"", "")*/, "IsCreateNew": $scope.IsCreateNew };
                            var getData = GetCompositRatingDetails.Call(ratingDetailParam);
                            getData.then(function (response) {
                                $scope.LoaderCustomRating = false;
                                $scope.LoaderAllRating = false;
                                if ($scope.LstRatingIdSelect == null)
                                    $scope.LstRatingIdSelect = [];
                                $scope.LstRatingIdSelect = response.data.data.LstRatingId;
                                $scope.LstRatingIdForDisable = response.data.data.LstRatingIdForDisable;
                                $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                                $scope.RatingSetId = setId;
                                $scope.RatingSubSetId = setSubId;
                                $scope.RatingSubSetName = SubSetName;
                                $scope.LstRating = response.data.data.LstRating;
                                $scope.divshowAllRating = true;
                                $scope.RatingSetName = setName;
                                $scope.LstRatingSetSubSet = response.data.data.LstRatingSetSubSet;

                                if (response.data.data.LstRatingId != null) {
                                    for (var i = 0; i < response.data.data.LstRatingId.length; i++) {
                                        for (var j = 0; j < $scope.LstRating.length; j++) {
                                            if ($scope.LstRating[j].RatingIds.length > 1) {
                                                for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                    if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingId[i]) {
                                                        $scope.LstRating[j].IsChecked = true;
                                                        $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                                    }
                                                }

                                            }
                                            else {
                                                if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingId[i]) {
                                                    $scope.LstRating[j].IsChecked = true;
                                                    $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                                }
                                            }
                                        }
                                    }
                                }
                                if (response.data.data.LstRatingIdForDisable != null) {
                                    for (var i = 0; i < response.data.data.LstRatingIdForDisable.length; i++) {
                                        for (var j = 0; j < $scope.LstRating.length; j++) {
                                            if ($scope.LstRating[j].RatingIds.length > 1) {
                                                for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                    if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingIdForDisable[i]) {
                                                        $scope.LstRating[j].IsDisable = true;
                                                    }
                                                }
                                            }
                                            else {
                                                if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingIdForDisable[i]) {
                                                    $scope.LstRating[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }
                                }
                                var incr = 0;
                                angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                    value.IsChecked = value.RatingSubSetId == setSubId ? true : false;
                                    value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                    incr++;
                                });
                                incr = 0;
                                $scope.LstRatingWithOutFilter = $scope.LstRating;
                                $("#RatingAll").addClass("btn btn-success btn-xs active");
                                $("#RatingSelected").removeClass("btn btn-success btn-xs active");
                                $("#RatingUnselected").removeClass("btn btn-success btn-xs active");
                                $("#RatingSelected").addClass("btn btn-success btn-xs");
                                $("#RatingUnselected").addClass("btn btn-success btn-xs");
                            },
                                function (stu) {
                                    $scope.LoaderCustomRating = false;
                                    $scope.LoaderAllRating = false;
                                    $scope.divshowAllRating = false;
                                    MFIMsg.AlertHtml("Single custom set details fetched failed", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }
                    }

                    $scope.getData = function (setId, setSubId, SubSetName, id) {
                        if ($scope.search != "" && $scope.search != undefined)
                            $scope.search.RatingName = "";
                        $scope.radioClassId = id;
                        $scope.LoaderCustomRating = true;
                        $scope.LoaderAllRating = true;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        $scope.divshow = false;
                        var ratingDetailParam = { "RatingSetId": setId, "RatingSubSetId": setSubId, "RatingSubSetName": SubSetName/*.Replace("\"", "")*/ };
                        var getData = GetCompositRatingDetails.Call(ratingDetailParam);
                        getData.then(function (response) {
                            $scope.LoaderCustomRating = false;
                            $scope.LoaderAllRating = false;
                            if ($scope.LstRatingIdSelect == null)
                                $scope.LstRatingIdSelect = [];
                            $scope.LstRatingIdSelect = response.data.data.LstRatingId;
                            $scope.LstRatingIdForDisable = response.data.data.LstRatingIdForDisable;
                            $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                            $scope.RatingSetId = setId;
                            $scope.RatingSubSetId = setSubId;
                            $scope.RatingSubSetName = SubSetName;
                            $scope.LstRating = response.data.data.LstRating;
                            $scope.divshowAllRating = true;
                            $scope.LstRatingSetSubSet = response.data.data.LstRatingSetSubSet;

                            if (response.data.data.LstRatingId != null) {
                                for (var i = 0; i < response.data.data.LstRatingId.length; i++) {
                                    for (var j = 0; j < $scope.LstRating.length; j++) {
                                        if ($scope.LstRating[j].RatingIds.length > 1) {
                                            for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingId[i]) {
                                                    $scope.LstRating[j].IsChecked = true;
                                                    $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                                }
                                            }

                                        }
                                        else {
                                            if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingId[i]) {
                                                $scope.LstRating[j].IsChecked = true;
                                                $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                            }
                                        }
                                    }
                                }
                            }
                            if (response.data.data.LstRatingIdForDisable != null) {
                                for (var i = 0; i < response.data.data.LstRatingIdForDisable.length; i++) {
                                    for (var j = 0; j < $scope.LstRating.length; j++) {
                                        if ($scope.LstRating[j].RatingIds.length > 1) {
                                            for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingIdForDisable[i]) {
                                                    $scope.LstRating[j].IsDisable = true;
                                                }
                                            }
                                        }
                                        else {
                                            if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingIdForDisable[i]) {
                                                $scope.LstRating[j].IsDisable = true;
                                            }
                                        }
                                    }
                                }
                            }
                            var incr = 0;
                            angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                value.IsChecked = value.RatingSubSetId == setSubId ? true : false;
                                value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                incr++;
                            });
                            incr = 0;
                            $scope.LstRatingWithOutFilter = $scope.LstRating;
                            $("#RatingAll").addClass("btn btn-success btn-xs active");
                            $("#RatingSelected").removeClass("btn btn-success btn-xs active");
                            $("#RatingUnselected").removeClass("btn btn-success btn-xs active");
                            $("#RatingSelected").addClass("btn btn-success btn-xs");
                            $("#RatingUnselected").addClass("btn btn-success btn-xs");
                        },
                            function (stu) {
                                $scope.LoaderCustomRating = false;
                                $scope.LoaderAllRating = false;
                                MFIMsg.AlertHtml("Single custom set details fetched failed", MFIAlertType.Information);
                            });
                    }

                    $scope.makeSetDefault = function (setId, SubSetName, id) {
                        if (SubSetName == "--")
                            return;
                        if ($scope.Default == "Default")
                            return;
                        if ($scope.Gen == true || $scope.UserLogInId == $scope.CreatedLogInId) {
                            var setDefaultParam = { "SetId": setId, "IsDefault": $scope.Default };
                            var getDefaultData = MakeDefaultRatingSet.Call(setDefaultParam);
                            getDefaultData.then(function (response) {
                                if (response.data.data == null) {
                                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                                }
                                else {
                                    if (response.data.data.Data.IsDefault == true) {
                                        //$scope.SetName = "Default";
                                        //$scope.Default = true;
                                        $scope.SetName = "Undo";
                                        $scope.Default = false;
                                    }
                                    else {
                                        $scope.SetName = "Make Default";
                                        $scope.Default = true;
                                    }
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Default creation error", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to set default", MFIAlertType.Information);
                        }
                    }

                    $scope.saveSetAndCustomRatingName = function (op) {
                        if (op == 'Add') {
                            var matchincr = 0;
                            angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                if (value.RatingSubSetName == $scope.RatingSubSetName) {
                                    matchincr++;
                                }
                            });
                            if (matchincr >= 1) {
                                MFIMsg.AlertHtml("Custom rating name already exist", MFIAlertType.Information);
                                return;
                            }
                            $scope.RatingSubSetId = 0;
                        }
                        else {
                            var matchincr = 0;
                            angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                if (value.RatingSubSetName == $scope.RatingSubSetName && value.RatingSubSetId != $scope.RatingSubSetId) {
                                    matchincr++;
                                }
                            });
                            if (matchincr >= 1) {
                                MFIMsg.AlertHtml("Custom rating name already exist", MFIAlertType.Information);
                                return;
                            }
                        }
                        if ($scope.RatingSetName == "" || $scope.RatingSetName == null) {
                            MFIMsg.AlertHtml("Please enter set name", MFIAlertType.Information);
                            return;
                        }
                        if ($scope.RatingSubSetName == "" || $scope.RatingSubSetName == null) {
                            MFIMsg.AlertHtml("Please enter custom Rating name", MFIAlertType.Information);
                            return;
                        }
                        var setParam = { "RatingSetName": $scope.RatingSetName, "RatingSubSetName": $scope.RatingSubSetName, "RatingSetId": $scope.RatingSetId, "RatingSubSetId": $scope.RatingSubSetId, "IsGeneric": $scope.IsGeneric };
                        var getSetData = SaveSetandCustomRatingName.Call(setParam);

                        getSetData.then(function (response) {
                            $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                            $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                            if ($scope.RatingSetId == 0) {
                                MFIMsg.AlertHtml("Rating set created successfully", MFIAlertType.Success);
                            }
                            else {
                                if (op == 'Add')
                                    MFIMsg.AlertHtml("Custom rating created successfully", MFIAlertType.Success);
                                else
                                    MFIMsg.AlertHtml("Rating set updated successfully", MFIAlertType.Success);
                                var incr = 0;
                                angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                    value.IsChecked = value.RatingSubSetId == $scope.radioSelectedId ? true : false;
                                    value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                });
                                incr = 0;
                            }
                            $scope.RatingSetName = null;
                            $scope.RatingSubSetName = null;
                            $scope.IsGeneric = false;
                            $scope.divshow = false;
                            if (response.data.data.Data.IsGeneric == true) {
                                $scope.Gen = true;
                            }
                            else {
                                $scope.Gen = false;
                            }
                            $scope.SetName = "Make Default";
                            $scope.Default = true;
                            $scope.UserLogInId = response.data.data.UserLogInId;
                            $scope.CreatedLogInId = response.data.data.CreatedLogInId;

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Rating set create or update error", MFIAlertType.Error);
                            });
                    }

                    $scope.RatingSave = function () {
                        var ratingSaveParam = { "RatingSetId": $scope.RatingSetId, "RatingSubSetId": $scope.RatingSubSetId, "LstRatingIdSelectSave": $scope.LstRatingIdSelect, "RatingSubSetName": $scope.RatingSubSetName, "IsCreationSet": false, "IsExist": $scope.IsExist };
                        var getRatingSaveData = SaveRatingsData.Call(ratingSaveParam);
                        getRatingSaveData.then(function (response) {
                            if ($scope.search != "" && $scope.search != undefined)
                                $scope.search.RatingName = "";
                            MFIMsg.AlertHtml("Rating set created successfully", MFIAlertType.Success);
                            if ($scope.LstRatingIdSelect == null)
                                $scope.LstRatingIdSelect = [];
                            if (response.data.data.LstRatingId != null)
                                $scope.LstRatingIdSelect = response.data.data.LstRatingId;
                            if (response.data.data.LstRatingIdForDisable != null)
                                $scope.LstRatingIdForDisable = response.data.data.LstRatingIdForDisable;
                            if (response.data.data.LstRatingSetSubSet != null)
                                $scope.LstRatingSetSubSet = response.data.data.LstRatingSetSubSet;
                            $scope.LstRatingSingleSetDetails = $scope.LstRatingSingleSetDetails;
                            if (response.data.data.LstRating != null)
                                $scope.LstRating = response.data.data.LstRating;
                            $scope.divshowAllRating = true;
                            if (response.data.data.LstRatingId != null) {
                                for (var i = 0; i < response.data.data.LstRatingId.length; i++) {
                                    for (var j = 0; j < $scope.LstRating.length; j++) {
                                        if ($scope.LstRating[j].RatingIds.length > 1) {
                                            for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingId[i]) {
                                                    $scope.LstRating[j].IsChecked = true;
                                                    $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioClassId] };
                                                }
                                            }
                                        }
                                        else {
                                            if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingId[i]) {
                                                $scope.LstRating[j].IsChecked = true;
                                                $scope.LstRating[j].CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioClassId] };
                                            }
                                        }

                                    }
                                }
                            }
                            if (response.data.data.LstRatingIdForDisable != null) {
                                for (var i = 0; i < response.data.data.LstRatingIdForDisable.length; i++) {
                                    for (var j = 0; j < $scope.LstRating.length; j++) {
                                        if ($scope.LstRating[j].RatingIds.length > 1) {
                                            for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingIdForDisable[i]) {
                                                    $scope.LstRating[j].IsDisable = true;
                                                }
                                            }
                                        }
                                        else {
                                            if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingIdForDisable[i]) {
                                                $scope.LstRating[j].IsDisable = true;
                                            }
                                        }

                                    }
                                }
                            }
                            var incr = 0;
                            angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                                value.IsChecked = value.RatingSubSetId == $scope.radioSelectedId ? true : false;
                                value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                incr++;
                            });
                            incr = 0;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Rating saved failed", MFIAlertType.Error);
                            });


                    }

                    $scope.toggleSelection = function (id, IsDisable) {
                        if (IsDisable == false) {
                            if ($scope.LstRatingIdSelect == null)
                                $scope.LstRatingIdSelect = [];
                            angular.forEach(id, function (value) {
                                var index = $scope.LstRatingIdSelect.indexOf(value);
                                if (index == -1) {
                                    $scope.LstRatingIdSelect.push(value);
                                    angular.forEach($scope.LstRating, function (value) {
                                        if (value.RatingId == value)
                                            value.CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioClassId] };
                                    });
                                }
                                else {
                                    $scope.LstRatingIdSelect.splice(index, 1);
                                    angular.forEach($scope.LstRating, function (value) {
                                        if (value.RatingId == value)
                                            value.CheckBoxTextColor = { "color": "black" };
                                    });
                                }
                            });

                        }
                    }

                    $scope.createInExistingSet = function (setId, setSubId, SubSetName, id, setName) {
                        $scope.radioClassId = id;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.editcreate = "Add Rating";
                            $scope.IsCreateNew = true;
                            $scope.divshow = true;
                            $scope.showAdd = false;
                            $scope.showUpdate = false;
                            $scope.divshowAllRating = false;
                            $scope.divshowRatings = true;
                            $scope.LoaderCreationSection = true;
                            $scope.LoaderAllRating = true;
                            $scope.IsGeneric = $scope.Gen;
                            $scope.IsExist = true;
                            var ratingDetailParam = { "RatingSetId": setId, "RatingSubSetId": setSubId, "RatingSubSetName": SubSetName, "IsCreateNew": $scope.IsCreateNew };
                            var getData = GetCompositRatingDetails.Call(ratingDetailParam);
                            getData.then(function (response) {
                                $scope.LoaderAllRating = false;
                                $scope.LoaderCreationSection = false;
                                $scope.LstRatingIdSelect = [];
                                $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                                $scope.RatingSetId = setId;
                                $scope.RatingSubSetId = "";
                                $scope.RatingSubSetName = "";
                                $scope.LstRating = response.data.data.LstRating;
                                $scope.divshowRatings = true;
                                $scope.divshow = true;
                                $scope.IsSetNameDisable = true;
                                $scope.RatingSetName = setName;

                                if (response.data.data.LstRatingIdForDisable != null) {
                                    for (var i = 0; i < response.data.data.LstRatingIdForDisable.length; i++) {
                                        for (var j = 0; j < $scope.LstRating.length; j++) {
                                            if ($scope.LstRating[j].RatingIds.length > 1) {
                                                for (var c = 0; c < $scope.LstRating[j].RatingIds.length; c++) {
                                                    if ($scope.LstRating[j].RatingIds[c] == response.data.data.LstRatingIdForDisable[i]) {
                                                        $scope.LstRating[j].IsDisable = true;
                                                    }
                                                }
                                            }
                                            else {
                                                if ($scope.LstRating[j].RatingIds[0] == response.data.data.LstRatingIdForDisable[i]) {
                                                    $scope.LstRating[j].IsDisable = true;
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                                function (stu) {
                                    $scope.LoaderAllRating = false;
                                    $scope.LoaderCreationSection = false;
                                    $scope.divshow = false;
                                    $scope.divshowRatings = false;
                                    MFIMsg.AlertHtml("Custom set creation details fetched failed", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }
                    }

                    $scope.RatingCreateSave = function () {
                        if ($scope.RatingSubSetName == "" || $scope.RatingSubSetName == null) {
                            MFIMsg.AlertHtml("Please enter custom Rating name", MFIAlertType.Information);
                            return;
                        }
                        var matchincr = 0;
                        angular.forEach($scope.LstRatingSingleSetDetails, function (value) {
                            if (value.RatingSubSetName == $scope.RatingSubSetName) {
                                matchincr++;
                            }
                        });
                        if (matchincr >= 1) {
                            MFIMsg.AlertHtml("Custom rating name already exist", MFIAlertType.Information);
                            return;
                        }
                        $scope.RatingSubSetId = 0;
                        var ratingSaveParam = { "RatingSetName": $scope.RatingSetName, "RatingSetId": $scope.RatingSetId, "RatingSubSetId": $scope.RatingSubSetId, "LstRatingIdSelectSave": $scope.LstRatingIdSelect, "RatingSubSetName": $scope.RatingSubSetName, "IsCreationSet": true, "IsGeneric": $scope.IsGeneric, "IsExist": $scope.IsExist };
                        var getRatingSaveData = SaveRatingsData.Call(ratingSaveParam);
                        getRatingSaveData.then(function (response) {
                            if (response.data.Message == "Success") {
                                MFIMsg.AlertHtml("Rating saved successfully", MFIAlertType.Success);
                                $scope.LstRatingSingleSetDetails = response.data.data.LstRatingSingleSetDetails;
                                $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                                $scope.RatingSetName = null;
                                $scope.RatingSubSetName = null;
                                $scope.IsGeneric = false;
                                $scope.divshow = false;
                                $scope.divshowRatings = false;
                                if (response.data.data.Data.IsGeneric == true) {
                                    $scope.Gen = true;
                                }
                                else {
                                    $scope.Gen = false;
                                }
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                                $scope.UserLogInId = response.data.data.UserLogInId;
                                $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                                $scope.LstRatingIdSelect = [];
                                $scope.searchRatingText = "";
                                var getData = GetRatingSetsData.Call();
                                getData.then(function (response) {
                                    $scope.LstRatingSet = response.data.data.LstRatingSetSubSet;
                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Rating set loading failed", MFIAlertType.Information);
                                    });
                            }
                            else {
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);
                            }

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Rating creation failed", MFIAlertType.Error);
                            });
                    }

                    $scope.FnSetFilterRating = function (selection) {
                        if (selection == 'All')
                            $scope.LstRating = $scope.LstRatingWithOutFilter;
                        if (selection == 'Selected')
                            $scope.LstRating = $filter('filter')($scope.LstRatingWithOutFilter, { IsChecked: true }, true);
                        if (selection == 'Unselected')
                            $scope.LstRating = $filter('filter')($scope.LstRatingWithOutFilter, { IsChecked: false, IsDisable: false }, true);
                    }

                    $scope.isCollapsed = true;
                    $scope.toggleCollapse = function () {
                        $scope.isCollapsed = !$scope.isCollapsed;

                        $timeout(function () {
                            var toggleDiv = angular.element(document.querySelector('.toggleDiv1'));
                            var toggleHeight = angular.element(document.querySelector('.toggleHeight1'));
                            toggleDiv.slideToggle('fast', function () {
                                if (toggleDiv.css('display') === 'none') {
                                    toggleHeight.css('height', '300px');
                                } else {
                                    toggleHeight.css('height', '165px');
                                }
                            });
                        }, 0);
                    };
                    $scope.closeRatingSet = function () {
                        if (screen.width <= 767) {
                            angular.element('#ratingSetDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#ratingSetDetails').hide();
                        } else {
                            angular.element('#ratingSetDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#ratingSetDetails').hide();
                            });
                        }
                    };

                    $scope.toggleRatingSetPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-ratingset');
                        var $details = angular.element('#ratingSetDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };

                }, 0);
            }
        };
    }
]);