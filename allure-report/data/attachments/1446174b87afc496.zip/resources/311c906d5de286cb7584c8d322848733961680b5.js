//SharedServices.service('GetIndexPerformanceReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/ShowIndexPerfomanceReturn',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    }

//}]);
SharedServices.service('GetIndexPerformanceReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/ShowIndexPerfomanceReturn',
            headers: { 'Content-Type': undefined },//headers: { 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: obj,//$.param(obj),//for post large data
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetUserParameterSetIndexByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/GetUserParameterSetIndexByLoginId',
            params: obj
        });
    }
}]);
SharedServices.service('SaveUserParameterSetIndexByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/SaveUserParameterSetIndexByLoginId',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('RemoveUserParameterSetIndexById', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/RemoveUserParameterSetIndexById',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetIndexPerformanceReturnfromService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiIndexPerformance/GetIndexPerformanceReturnfromService?Token='+ obj,
            params: obj
        });
    }
}]);