SharedServices.service('FetchSIPCalculationDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj, isService) {
        var url = isService == true ? 'FetchSIPCalculationDetailsServiceAdvance' : 'FetchSIPCalculationDetails';
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSIPCalculator/' + url,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('FetchPeriodWiseSIPCalculationDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj, RepGenUid) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiSIPCalculator/FetchPeriodWiseSIPCalculationDetails?TabName=' + obj + '&Guid=' + RepGenUid,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            /*data: $.param(obj),*/
            /*dataType: "json"*/
        });
    }
}]);

SharedServices.service('GetShowSIPFromService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiSIPCalculator/ShowSIPOutputForService',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);