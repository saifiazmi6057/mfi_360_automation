SharedDeractives.directive('customScroll', function () {
    return {
        restrict: 'A',
        scope: {
            config: '&customScroll'
        },
        link: function postLink(scope, iElement, iAttrs, controller, transcludeFn) {
            var config = scope.config();            
            var elem = iElement.mCustomScrollbar({
                autoHideScrollbar: true,
                theme: "minimal-dark",
                advanced: {
                    updateOnImageLoad: true
                },
                scrollButtons: {
                    enable: true
                }
            });
            // the live options object
            //var mObject = elem.data('mCS');
           // $log.debug('elem: ', mObject.opt);
        }
    };
});