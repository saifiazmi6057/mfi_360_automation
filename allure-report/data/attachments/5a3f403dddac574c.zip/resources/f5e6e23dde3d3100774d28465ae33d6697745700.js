//var FilterAMC = angular.module('FilterAMC', []);

SharedCommon.filter('NatureAllocationFilter', function ($filter)
{
    return function (items, scope) {
   //   debugger;
        var filtered = [];
        if (scope == null || scope == "")
        {
            filtered = items;
        }
        else
        {
           
            filtered = $filter('filter')(items, { Nature: scope })
        }

        return filtered;
    };
});


SharedCommon.filter('SectorWiseAllocationFilter', function ($filter) {
    return function (items, scope) {
        //   debugger;
        var filtered = [];

        if (scope == null || scope == "") {
            filtered = items;
        }
        else {           
                filtered = $filter('filter')(items, { SectorName: scope })           
        }
        return filtered;
    };
});

SharedCommon.filter('CreditQualityFilter', function ($filter) {
    return function (items, level1, level2, IsExactMatch) {
        if (IsExactMatch == null || IsExactMatch == undefined)
            IsExactMatch = true;
        if (level1 == undefined)
            level1 = null;
        if (level2 == undefined)
            level2 = null;
        //   debugger;
        var filtered = [];
        //if (level1 != null)
        //{
        //    filtered = $filter('filter')(items, { Ratingset: level1 })
        //}
        //if (level2 != null) {
        //    filtered = $filter('filter')(items, { Instrument: level2 })
        //}
        if (level1 != null && level2 == null) {
            filtered = $filter('filter')(items, { Ratingset: level1 }, IsExactMatch);
        }
        if (level2 != null && level1 == null) {
            filtered = $filter('filter')(items, { Instrument: level2 }, IsExactMatch);
        }
        if (level2 != null && level1 != null) {
            filtered = $filter('filter')(items, { Ratingset: level1, Instrument: level2 }, IsExactMatch);
        }
        
        return filtered;
    };
});

