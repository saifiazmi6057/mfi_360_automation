function CheckNumericorFloat(event, val) {
    var regex = new RegExp("^[0-9.]+");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
        event.preventDefault();
        return false;
    }
    if (key == '.' && val.indexOf('.') > -1) {
        event.preventDefault();
        return false;
    }
    return true;
}
function CheckNumeric(event, val) {
    var regex = new RegExp("^[0-9]+");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) {
        event.preventDefault();
        return false;
    }
    return true;
}
var MFIAlertType = { Success: 1, Error: 2, Information: 3, Warning: 4 };
var SuccessAlert =
    '<div class="sa">' +
    '<div class="sa-success" >' +
    '<div class="sa-success-tip"></div>' +
    '<div class="sa-success-long"></div>' +
    '<div class="sa-success-placeholder"></div>' +
    '<div class="sa-success-fix"></div>' +
    '</div >' +
    '</div >';
    //'<h3 class="text-center">Success</h3>';

var ErrorAlert =
    '<div class="sa">' +
    '<div class="sa-error">' +
    '<div class="sa-error-x">' +
    '<div class="sa-error-left"></div>' +
    '<div class="sa-error-right"></div>' +
    '</div>' +
    '<div class="sa-error-placeholder"></div>' +
    '<div class="sa-error-fix"></div>' +
    '</div>' +
    '</div>';
    //'<h3 class="text-center">Error</h3>';

var WarningAlert = '<div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>';
var GeneralAlert = '<div class="swal2-icon swal2-warning general swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">i</span></div>';


var SharedCommon = angular.module('SharedCommon', ['ngMessages']);
var SharedServices = angular.module('SharedServices', ['SharedCommon']);
var SharedDeractives = angular.module('SharedDeractives', ['SharedCommon']);

//var CommonServiceConfig = function ($routeProvider,$httpProvider) {
//    $httpProvider.defaults.cache = false;
//    $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
//    $httpProvider.defaults.headers.get = {};
//    $httpProvider.defaults.headers.post = {};
//    $httpProvider.defaults.headers.common['Content-Type'] = "application/x-www-form-urlencoded";

//}

//var BaseServiceConfig = function ($routeProvider, $httpProvider) {
//    debugger;
//    $httpProvider.defaults.cache = false;
//    if (!$httpProvider.defaults.headers.get) {
//        $httpProvider.defaults.headers.get = {};
//    }
//    // disable IE ajax request caching
//    $httpProvider.defaults.headers.common['Content-type'] = 'application/x-www-form-urlencoded';
//    $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
//    $httpProvider.defaults.headers.get = {};
//    $httpProvider.defaults.headers.post = {};
//    if (angular.element('input[name="__RequestVerificationToken"]').length > 0)
//        $httpProvider.defaults.headers.common['RequestVerificationToken'] = angular.element('input[name="__RequestVerificationToken"]').val();

//    $httpProvider.defaults.headers.common["ApiToken"] = "";

//};
//SharedServices.config(BaseServiceConfig);


SharedCommon.factory("MFIMsg", ['$mdDialog', function ($mdDialog) {
    var ObjMsg = {};

    ObjMsg.Alert = function (Content, Title, OkText, IsSuccess, ParentSelector, clickOutsideToClose) {
        IsSuccess = IsSuccess || true;
        $mdDialog.show(
            $mdDialog.alert()
                .parent(angular.element(document.querySelector((ParentSelector === undefined ? "body" : ParentSelector))))
                .clickOutsideToClose(clickOutsideToClose === undefined ? true : clickOutsideToClose)
                .title(Title === undefined ? "MFI360 Explorer " : "MFI360 Explorer ")
                .textContent(Content)
                .ok(OkText === undefined ? "OK" : OkText)
        );
    };
    ObjMsg.AlertHtml = function (Content, AlertType, OkText, ParentSelector, disableParentScroll, clickOutsideToClose) {
        var conHTML = "";
        var oktext = angular.isUndefinedOrNullOrEmpty(OkText) ? "OK" : OkText;
        $mdDialog.show({
            controller: function ($scope, $sce) {
                conHTML = AlertType == MFIAlertType.Success ? SuccessAlert :
                    AlertType == MFIAlertType.Warning ? WarningAlert :
                        AlertType == MFIAlertType.Information ? GeneralAlert : ErrorAlert;
                $scope.msg = $sce.trustAsHtml(conHTML + Content);
                $scope.closeDialog = function () {
                    $mdDialog.hide();
                };
            },
            //template: '<div>{{msg}}</div>',
            template: '<md-dialog>' +
                '<md-dialog-content class="md-dialog-content">' +
                '<div class="ribbon"> <h3>MFI360 Explorer</h3></div> ' +
                '<div class="md-dialog-content-body">' +
                '<div ng-bind-html="msg" style="max-height:300px;overflow:auto;"></div>' +
                '</div>' +
                '  </md-dialog-content>' +
                '<md-dialog-actions>' +
                ' <button class="md-primary md-confirm-button md-button md-autofocus md-ink-ripple md-default-theme" type="button" ' +
                ' ng-click="closeDialog()"> ' + oktext + ' </button>' +
                '</md-dialog-actions>' +
                '</md-dialog>',
            //parent: angular.element(document.querySelector((ParentSelector === undefined ? "body" : ParentSelector))),
            parent: angular.isUndefinedOrNullOrEmpty(ParentSelector) ? angular.element(document.body) : angular.element(ParentSelector),
            clickOutsideToClose: false,
            disableParentScroll: disableParentScroll === undefined || disableParentScroll === null ? true : disableParentScroll//it will work if you pass id of parent and false together,see reference  $scope.SaveClientSubscription function of CreateRatingTrackerClientSubscription.js 
            //fullscreen: false
        });
    };
    ObjMsg.Confirm = function (Content, Title, OkText, CancleText, ParentSelector) {//function (Content, Title = "MFI360 Explorer", OkText = "Ok", CancleText = "Cancel") {
        var dialog = $mdDialog.confirm()
            .parent(angular.element(document.querySelector((ParentSelector === undefined ? "body" : ParentSelector))))
            .title((Title === undefined ? "MFI360 Explorer " : "MFI360 Explorer "))
            .htmlContent(
            '<div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>' +
            '<h3 class="text-center">Are you sure?</h3>'
            + Content)
            //.textContent(Content)
            .ok((OkText === undefined ? "OK" : OkText))
            .cancel((CancleText === undefined ? "Cancel" : CancleText));

        return $mdDialog.show(dialog);
    };

    ObjMsg.AlertHtmlWithRes = function (Content, Title, OkText, ParentSelector) {//function (Content, Title = "TRACKER", OkText = "Ok", CancleText = "Cancel") {
        var dialog = $mdDialog.alert()
            .parent(angular.element(document.querySelector((ParentSelector === undefined ? "body" : ParentSelector))))
            .title((Title === undefined ? "MFI360 Explorer " : "MFI360 Explorer "))
            .htmlContent(
                '<div class="swal2-icon swal2-warning swal2-animate-warning-icon" style="display: flex;"><span class="swal2-icon-text">!</span></div>' +
                '<h3 class="text-center">&nbsp;</h3>'
                + Content)
            //.textContent(Content)
            .ok((OkText === undefined ? "OK" : OkText))
            //.cancel((CancleText === undefined ? "Cancel" : CancleText));

        return $mdDialog.show(dialog);
    };

    ObjMsg.AlertHtmlWithRes2 = function (Content, Title, OkText, ParentSelector) {//function (Content, Title = "TRACKER", OkText = "Ok", CancleText = "Cancel") {
        var dialog = $mdDialog.alert()
            .parent(angular.element(document.querySelector((ParentSelector === undefined ? "body" : ParentSelector))))
            .title((Title === undefined ? "MFI360 Explorer " : "MFI360 Explorer "))
            .htmlContent(
                SuccessAlert
                + Content)
            //.textContent(Content)
            .ok((OkText === undefined ? "OK" : OkText))
        //.cancel((CancleText === undefined ? "Cancel" : CancleText));

        return $mdDialog.show(dialog);
    };

    return ObjMsg;
}]);


