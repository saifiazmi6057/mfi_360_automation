//angular.module('portfolioOverlapDirective', [])
SharedDeractives.directive('portfolioOverlap', ['$timeout', '$q', '$log','FilterFundCategory', function ($timeout, $q, $log, FilterFundCategory) {
        return {
            restrict: 'AE',            
            scope: {
                extraSettings: '=',
                selectedItem: '=',
                amcList: '=',
                fundNaturelist: '=',
                fundSubnaturelist: '=',
                fundList: '='
            },
            replace: false,
            templateUrl: '/Portfolio/SelectionHeader', 
            link: function ($scope, $element, $attrs)
            {
                $scope.IsHeaderShown = !angular.isUndefinedOrNullOrEmpty($attrs.isHeaderShown) &&  $attrs.isHeaderShown.toString().toUpperCase()=="FALSE"?false:true;
                $scope.SelectedAMC = {};
                $scope.SelectedNature = {};
                $scope.SelectedSubNature = {};
                if ($scope.selectedItem) {
                    $scope.HederFundname = $scope.selectedItem.FundName;
                }
                $scope.ShowClearButton = true;
                $scope.GetFund = function (type)
                {
                  //  debugger;
                    var AMCID = null;
                    var NatureID = null;
                    var SubNatureID = null;
                    if (type == "AMC") {
                        $scope.SelectedNature  = null;
                        $scope.SelectedSubNature = null;
                    }
                    else if (type == "Nature") {
                        $scope.SelectedSubNature = null;
                    }
                    if ($scope.SelectedAMC != null || $scope.SelectedAMC != undefined)
                    {
                        if ($scope.SelectedAMC != null)
                        {
                            AMCID = $scope.SelectedAMC.AMCId;
                        }
                        else
                        {
                            AMCID = null;
                        }
                    }
                    if ($scope.SelectedNature != null || $scope.SelectedNature != undefined)
                    {
                        if ($scope.SelectedNature != null)
                        {
                            NatureID = $scope.SelectedNature.NatureID;
                        }
                        else
                        {
                            NatureID = null;
                        }
                       
                    }
                    if ($scope.SelectedSubNature != null || $scope.SelectedSubNature != undefined)
                    {
                        
                        if ($scope.SelectedSubNature != null)
                        {
                            SubNatureID = $scope.SelectedSubNature.SubNatureID;
                        }
                        else
                        {
                            SubNatureID = null;
                        }
                    }
                    if (AMCID === undefined)
                    {
                        AMCID = null;
                    }
                    if (NatureID === undefined) {
                        NatureID = null;
                    }
                    if (SubNatureID === undefined) {
                        SubNatureID = null;
                    }
                    var FilterParam = { "AMCID": AMCID, "NatureID": NatureID, "SubNatureID": SubNatureID};
                    $scope.LoaderHeader = true;
                    var FilterData = FilterFundCategory.Call(FilterParam);

                    FilterData.then(function (response) {
                      //  debugger;
                       
                        var f = response.data.data;
                        $scope.fundList = f.FundList;
                        $scope.fundNaturelist = f.NatureList;
                        $scope.fundSubnaturelist = f.SubNatureList;
                        $scope.LoaderHeader = false;
                        $scope.searchText = null;
                        if ($scope.selectedItem != null)
                        {
                            $scope.selectedItem.FundID = null;
                            $scope.selectedItem.FundName = null;
                        }

                    },
                        function (stu) {
                            alert("Records gathering failed! from FilterFundCategory");
                            $scope.LoaderHeader = false;
                        });
                }
                ///////
           
              //  $scope.Funds = loadAll();
                $scope.querySearch = querySearch;
                $scope.selectedItemChange = selectedItemChange;
                $scope.searchTextChange = searchTextChange;
                $scope.searchFocus = function (item) {
                    Console.log(item)
                }
                function querySearch(query)
                {
                    if ($scope.fundList == null)
                    {
                        $scope.fundList = [];
                        return;
                    }
                    var results = query ? $scope.fundList.filter(createFilterFor(query)) : $scope.fundList;
                   
                    return results;
                }

                function searchTextChange(text)
                {
                   
                    //this section for implements tooltips
                    $timeout(function () {
                        angular.element(".md-autocomplete-suggestions li").hover(function () {
                            $(this)[0].setAttribute('data-toggle', 'tooltip');
                            $(this)[0].setAttribute('data-placement', 'bottom');
                            $(this)[0].setAttribute('title', $(this)[0].innerText);                    
                        });
                    }, 1000);
                }
                $scope.FnCleanText = function ()
                {
                    $scope.searchText = '';
                    $scope.ShowClearButton = false;
                }
                function selectedItemChange(item, callObj)
                {
                  //  debugger;
                    if (item !== undefined) {
                        $scope.selectedItem.FundID = item.FundID;
                        $scope.selectedItem.FundName = item.FundName;
                        $scope.HederFundname = item.FundName;
                        $scope.ShowClearButton = true;
                    }
                    //$log.info('Call From ' + callObj+' Item changed to ' + JSON.stringify(item));
                }

                function createFilterFor(query)
                {
                    var lowercaseQuery = angular.lowercase(query);

                    return function filterFn(fund)
                    {
                        return (angular.lowercase(fund.FundName).indexOf(lowercaseQuery) != -1);
                    };
                }
               

            }
        };
    }]);
