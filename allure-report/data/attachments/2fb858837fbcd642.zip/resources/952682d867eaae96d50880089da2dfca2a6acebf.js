SharedServices.service('GetMarketCapSlabByMonthYear', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolioAnalysis/FetchMarketCapSlabByMonthYear',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetMarketCapDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowMarketCapReport',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetDetailedPortfolioDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var Url = 'ApiPortfolioAnalysis/ShowDetailedPortfolioDetails';
        if (IsService == true)
            Url = 'ApiPortfolioAnalysis/MakeServiceRequestDetailedPortfolioDetails';
        return $http({
            url: ApiInfo.BaseApiUrl + Url,// 'ApiPortfolioAnalysis/ShowDetailedPortfolioDetails',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetShowDetailedPortfolioFromService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowDetailedPortfolioFromService',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);


SharedServices.service('GetDetailedPortfolioDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var Url = 'ApiPortfolioAnalysis/ShowDetailedPortfolioDetailsAdvance';
        if (IsService == true)
            Url = 'ApiPortfolioAnalysis/MakeServiceRequestDetailedPortfolioDetails';
        return $http({
            url: ApiInfo.BaseApiUrl + Url,//'ApiPortfolioAnalysis/ShowDetailedPortfolioDetailsAdvance',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetCompositeDetailedPortfolioDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var Url = 'ApiPortfolioAnalysis/ShowCompositeDetailedPortfolioDetailsAdvance';
        if (IsService == true)
            Url = 'ApiPortfolioAnalysis/MakeServiceRequestDetailedPortfolioDetails';
        return $http({
            url: ApiInfo.BaseApiUrl + Url,//'ApiPortfolioAnalysis/ShowDetailedPortfolioDetailsAdvance',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetDetailedPortfolioFortnightlyDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj, IsService) {
        var Url = 'ApiPortfolioAnalysis/ShowDetailedPortfolioDetailsAdvance';
        if (IsService == true)
            Url = 'ApiPortfolioAnalysis/MakeServiceRequestDetailedPortfolioDetails';
        return $http({
            url: ApiInfo.BaseApiUrl + Url,//'ApiPortfolioAnalysis/ShowDetailedPortfolioDetailsAdvance',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('PivotPortfolioData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/PivotPortfolioData',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('PivotTradeData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/PivotTradeData',
            //data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('PivotCompanyPortfolio', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/PivotCompanyPortfolio',
            //data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('DetailedCompanyDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowCompanyPortfolioDetails',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetFortnightyPortfolioDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowFortnightyPortfolioDetails',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetTradeAnalysisDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowTradeAnalysisDetails',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetTradeAnalysisDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowTradeAnalysisDetailsAdvance',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetPortfolioChangeDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/FetchPortfolioChangeDetails',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetPortfolioChangeDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/FetchPortfolioChangeDetailsAdvance',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetPEClassificationDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowPEClassificationReport',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]); 
SharedServices.service('GetCustomMarketCapSlabByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetCustomMarketCapSlabByLoginId',
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetCustomPEClassificationSlabByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetCustomPEClassificationSlabByLoginId',
            method: 'GET'
        });
    }
}]);
SharedServices.service('SaveCustomMarketCapSlab', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/SaveCustomMarketCapSlab',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('SaveCustomPEClassificationSlab', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/SaveCustomPEClassificationSlab',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('RemoveCustomMarketCapSlab', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/RemoveCustomMarketCapSlab',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('RemoveCustomPEClassificationSlab', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/RemoveCustomPEClassificationSlab',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetAllNiftyBSEMFIIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        if (angular.isUndefinedOrNullOrEmpty(obj)) {
            obj = { isDiscardRestrictedIndex: false };
        }
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetAllNiftyBSEMFIIndex',
            params: obj
        });
    }

}]);
SharedServices.service('GetLatestTradeDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetLatestTradeDate',
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetAllRiskOMeterType', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetAllRiskOMeterType',
            method: 'GET'
        });
    }
}]);
SharedServices.service('ShowRisKOMerterReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/ShowRisKOMerterReport',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAllPRCType', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetAllPRCType',
            method: 'GET'
        });
    }
}]);


SharedServices.service('GetStressTestingDetailsAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Input) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/FetchStressTestingDetailsAdvance',
            data: $.param(Input),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetMergerSchemeDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchMergerSchemeDetails',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetTransactionDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchTransactionDetails',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetNewFormatDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchNewFormatDetails',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAllSebiSchemeSubNature', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllSebiSchemeSubNature',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAllInstitution', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllInstitution',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetOldFormatInstiDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchOldFormatInstiDetails',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetOldFormatAmfiDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchOldFormatAmfiDetails',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAllNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllNatureList',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAllSubNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/FetchAllSubNatureList',
            data: $.param(obj),
            method: 'POST'
        });
    }
}]);