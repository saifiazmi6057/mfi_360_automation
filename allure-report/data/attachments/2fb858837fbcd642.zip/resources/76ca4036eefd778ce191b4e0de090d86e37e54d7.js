SharedDeractives.directive('returnSetting', ['$timeout', '$q', '$log', 'MFIMsg', 'GetReturnSettingdata', 'GetSetDetails', 'SavecustomizesetData', 'GetSetDeleteinfo',
    function ($timeout, $q, $log, MFIMsg, GetReturnSettingdata, GetSetDetails, SavecustomizesetData, GetSetDeleteinfo) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '=',
                logInId:'='
            },
            replace: false,
            templateUrl: '/Home/ReturnSetting',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    //debugger;
                    $scope.InfoLoader = true;
                    $scope.cusset = [];
                    $scope.IsSameUser = false;
                    $scope.IsOwnUserLogin = false;
                    $scope.IsEntirePannelDisable = false;

                    $scope.creationBy;
                    $scope.creationOn;
                    $scope.ModifyBy;
                    $scope.ModifyOn;
                    $scope.Dvgenpersonal = false;
                    $scope.delshow = false;
                    $scope.setid = 0;
                    $scope.setindex = 0;
                    $scope.IsDefaultdisabled;

                    /// for disable button 

                    $scope.IsPersonalCheck = false;


                    $scope.IsOneYearRtnCheck = false; // FnreturnTyp(1)
                    $scope.IsCheckAllPeriodss = false; // FnreturnTyp(0)
                    $scope.IsNormalizeReturns = false; // 
                    $scope.IsNavpickingAlgo = false; // Fnnavdisable
                    $scope.IsSameMomFbothDays = false; // Fnnavpick(1)
                    $scope.IsNavMomFdiffDate = false; // Fnnavpick(0)
                    $scope.IsNavTypeCheck = false;
                    $scope.IsTrialUser = false;

                    //$scope.IsNavTypeCheck = false;
                    //$scope.IsDataConventionCheck = false;
                    //$scope.IsReturnTypeLessThanCheck = false;
                    //$scope.IsGtOneYearRtnCheck = false;
                    //$scope.IsReturnTypeGraterThanCheck = false;




                    $scope.gencls;
                    $scope.personalcls;
                    $scope.cusset.Generic = false;
                    $scope.cusset.Personal = false;
                    $scope.cusset.ReturnPeriodOneYear = false;// "returnboth";//
                    $scope.cusset.ReturnPeriodAll = false;
                    $scope.cusset.Navchk = false;


                    

                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await GetReturnSettingdata.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('GetReturnSettingdata', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function AllReturnSettingdata() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('GetReturnSettingdata');
                        //if (data) {
                            // Parse and return the data from LocalStorage
                            //return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//

                    //var AllReturnSettingdata = GetReturnSettingdata.Call();

                    AllReturnSettingdata().then(function (response) {
                        $timeout(function () {
                            $scope.InfoLoader = false;
                            //debugger; 
                            //$scope.cusset = response.data.data;
                            $scope.cusset = response;
                            $scope.selected = $scope.cusset.Data.SetName;
                            //$scope.IsTrialUser = response.data.data.IsTrial;
                            $scope.IsTrialUser = response.IsTrial;
                        }, 10);

                    },
                        function errorCallback(response) {

                            MFIMsg.Alert("Records gathering from GetReturnSetting data!!", "Error", "OK");
                            $scope.InfoLoader = false;
                        });






                    $scope.$watch('selected', function (newValue, oldValue, scope) {
                        //debugger;
                        $scope.IsOwnUserLogin = false;
                        if ($scope.IsTrialUser == true) {

                            $scope.IsTrial = true;
                        } else {
                            $scope.IsTrial = false;
                        }
                        if (newValue != undefined) {
                            $scope.cusset.Data.SetName = $scope.selected;
                            $scope.cusset.Data.Name = $scope.selected;
                            //debugger;
                            var resultObject = $scope.search($scope.cusset.Data.SetName, $scope.cusset.LstSetName);

                            if (resultObject == -1) {
                                $scope.creationDetails = "";
                                //$scope.IsSameUser = false;
                                //////$scope.Dvgenpersonal = false;
                                $scope.delshow = false;
                                //$scope.cusset.Data.IsDefault = false;
                                $scope.IsDefaultdisabled = false;
                                //////$scope.cusset.Generic = false;
                                //////$scope.cusset.Personal = false;
                                $scope.cusset.ReturnPeriodOneYear = false;
                                $scope.cusset.ReturnPeriodAll = false;
                                $scope.cusset.Navchk = false;
                                $scope.cusset.navpicksame = false;
                                $scope.cusset.navpickdiff = false;
                                $scope.cusset.Data.NavAlgoCurrentDate = "";
                                $scope.cusset.Data.NavAlgoPrevDate = "";
                                $scope.cusset.Data.NavAlgoBothDate = "";

                                $scope.creationBy = null;
                                $scope.creationOn = null;

                                $scope.ModifyBy = null;
                                $scope.ModifyOn = null;
                                //Reset();

                                $scope.IsOneYearRtnCheck = false; // FnreturnTyp(1)
                                $scope.IsCheckAllPeriodss = false; // FnreturnTyp(0)
                                $scope.IsNormalizeReturns = false; // 
                                $scope.cusset.Data.IsNormalizeReturns = false;
                                $scope.IsNavpickingAlgo = false; // Fnnavdisable
                                $scope.IsSameMomFbothDays = false; // Fnnavpick(1)
                                $scope.IsNavMomFdiffDate = false; // Fnnavpick(0)
                                $scope.IsNavTypeCheck = false;
                                $scope.IsPersonalCheck = false;


                                $('#DvNavType').removeClass('disable_toggle_group');
                                $('#DvDataConven').removeClass('disable_toggle_group');
                                $('#DvInvestType').removeClass('disable_toggle_group');
                                $('#chkOneYear').removeClass('disable_toggle_group');
                                $('#chkAllPeriods').removeClass('disable_toggle_group');
                                $('#chkNormalizedreturn').removeClass('disable_toggle_group');
                                $('#inlineCheckbox3').removeClass('disable_toggle_group');
                                $('#chksamemovement').removeClass('disable_toggle_group');
                                $('#chkdifferentmovement').removeClass('disable_toggle_group');

                                $('#DdlLessThan').removeClass('disable_toggle_group');
                                $('#DdlLessThan').removeAttr('disabled');
                                $('#NavAlgoBothDate').removeClass('disable_toggle_group');
                                $('#DdlGraterThan').removeClass('disable_toggle_group');
                                $('#DdlGraterThan').removeAttr('disabled');
                                $('#selectGross').removeClass('disable_toggle_group');
                                $('#selectGross').removeAttr('disabled');


                                $('#btnreset').show();

                                $scope.IsSameUser = false;

                            }
                            else {
                                ////debugger;


                                $scope.creationBy = $scope.cusset.LstSetName[resultObject].createdbyName;
                                $scope.creationOn = $scope.cusset.LstSetName[resultObject].strcreatedOn;

                                $scope.ModifyBy = $scope.cusset.LstSetName[resultObject].ModifybyName;
                                $scope.ModifyOn = $scope.cusset.LstSetName[resultObject].strModifyOn;

                                $scope.delshow = true;
                                $scope.setid = $scope.cusset.LstSetName[resultObject].id;
                                $scope.setindex = resultObject;
                                //debugger;
                                // Change by Arka
                                if (($scope.cusset.Data.SetName == "ICRA Analytics (ICRON) Default Set") || ($scope.cusset.Data.SetName == "Sebi Equity Set") || ($scope.cusset.Data.SetName == "Sebi Debt Set")) {
                                    $scope.IsSameUser = true;
                                    $scope.DisableAllControl();

                                }
                                // Ends here
                                $scope.IsDefaultdisabled = ($scope.cusset.LstSetName[resultObject].createdbyId == $scope.cusset.LoginId ? $scope.cusset.LstSetName[resultObject].IsDefault : false);

                                if ($scope.cusset.LoginId == $scope.cusset.LstSetName[resultObject].createdbyId || $scope.cusset.IsAdmin == true) {
                                    ////debugger;
                                    $scope.IsOwnUserLogin = true;
                                    $scope.DisableAllControl();
                                    if ($scope.cusset.LstSetName[resultObject].IsDefault == true) {
                                        $('#btndelete').hide();
                                    }
                                    else {
                                        $('#btndelete').show();
                                        $scope.IsSameUser = false;
                                    }
                                }
                                else {
                                    $('#btndelete').hide();
                                    $('#btnreset').hide();
                                    //$scope.IsSameUser = true;
                                    $scope.DisableAllControl();
                                }


                                var SetDetailsdata = GetSetDetails.Call($scope.cusset.LstSetName[resultObject].id);

                                SetDetailsdata.then(function (response) {

                                    var a = response.data.data;
                                    $scope.IsTrial = false;
                                    $scope.cusset.Data.SetName = a.Data.SetName;
                                    $scope.cusset.Data.ReturnTypeBoth = a.Data.ReturnTypeBoth;
                                    $scope.cusset.Data.ReturnTypeLessThan = a.Data.ReturnTypeLessThan;
                                    $scope.cusset.Data.ReturnTypeGraterThan = a.Data.ReturnTypeGraterThan;

                                    if (a.ReturnPeriod == "returnboth") {
                                        $scope.cusset.ReturnPeriodOneYear = true;
                                        $scope.cusset.ReturnPeriodAll = false;
                                    }
                                    else {
                                        $scope.cusset.ReturnPeriodOneYear = false;
                                        $scope.cusset.ReturnPeriodAll = true;
                                    }
                                    //$scope.cusset.ReturnPeriodOneYear = a.ReturnPeriod == "returnboth" ? true : false;
                                    $scope.cusset.isReturnActive = a.isReturnActive;
                                    $scope.cusset.investertype = a.investertype;
                                    $scope.cusset.gross = a.gross;
                                    if (a.Genmodel == "1") {
                                        $('#btndelete').hide();
                                        $scope.cusset.Generic = true;
                                        $scope.cusset.Personal = false;
                                        if ($scope.IsOwnUserLogin != true) {
                                            $scope.IsPersonalCheck = true;
                                        }
                                    }
                                    else {
                                        $scope.cusset.Generic = false;
                                        $scope.cusset.Personal = true;
                                        $scope.IsPersonalCheck = false;
                                        $('#btndelete').show();
                                    }
                                    //$scope.cusset.Generic = a.Genmodel == "1" ? true : false;

                                    if ($scope.cusset.Generic == true) {
                                        $scope.gencls = 'btn btn-info btn-xs active';
                                        $scope.personalcls = 'btn btn-info btn-xs';
                                    }
                                    else {
                                        $scope.gencls = 'btn btn-info btn-xs';
                                        $scope.personalcls = 'btn btn-info btn-xs active';
                                    }

                                    $scope.cusset.isnavActive = a.isnavActive;

                                    $scope.cusset.Navchk = a.Navchk;

                                    if ($scope.cusset.Navchk == false) {
                                        $('#navdiv *').prop('disabled', true);
                                    }
                                    $scope.cusset.Data.NavAlgoCurrentDate = a.Data.NavAlgoCurrentDate;
                                    $scope.cusset.Data.NavAlgoPrevDate = a.Data.NavAlgoPrevDate;
                                    $scope.cusset.Data.NavAlgoBothDate = a.Data.NavAlgoBothDate;
                                    $scope.cusset.Data.NavType = a.Data.NavType;

                                    if (a.navpick == "navboth") {
                                        $scope.cusset.navpicksame = true;
                                        $scope.cusset.navpickdiff = false;
                                    }
                                    else {
                                        $scope.cusset.navpicksame = false;
                                        $scope.cusset.navpickdiff = true;
                                    }
                                    //$scope.cusset.navpicksame = a.navpick == "navboth" ? true : false;
                                    $scope.cusset.dateconvention = a.dateconvention;

                                    $scope.cusset.Data.IsNormalizeReturns = a.Data.IsNormalizeReturns;
                                    $scope.cusset.Data.IsDefault = a.Data.IsDefault;
                                    $scope.Dvgenpersonal = true;

                                },
                                    function errorCallback(response) {
                                        MFIMsg.Alert("Records gathering from GetSetDetails data!!", "Error", "OK");
                                        $scope.InfoLoader = false;
                                    });


                            }

                        }
                    });

                    $scope.savedata = function () {
                        ////debugger;
                        if (($scope.cusset.Generic == undefined && $scope.cusset.Personal == undefined) || ($scope.cusset.Generic == false && $scope.cusset.Personal == false)) {
                            MFIMsg.Alert("Please select Type.", "Info", "OK");

                            return false;
                        }

                        if ($scope.cusset.Data.SetName == null || $scope.cusset.Data.SetName == "") {
                            //  alert($scope.cusset.Data.SetName);
                            MFIMsg.Alert("Please enter set name..", "Info", "OK");

                            return false;

                        }

                        // Arka 
                        //if (($scope.cusset.Data.SetName == "ICRA Analytics (ICRON) Default Set") || ($scope.cusset.Data.SetName == "Sebi Equity Set") || ($scope.cusset.Data.SetName == "Sebi Debt Set")) {
                        //    //  $scope.delshow = false;
                        //    MFIMsg.Alert("This set cannot be updated", "Info", "OK");

                        //    return false;

                        //}

                        if (($scope.cusset.ReturnPeriodOneYear == undefined && $scope.cusset.ReturnPeriodAll == undefined) || ($scope.cusset.ReturnPeriodOneYear == false && $scope.cusset.ReturnPeriodAll == false)) {
                            MFIMsg.Alert("Please select Return Type.", "Info", "OK");

                            return false;
                        }


                        if ($scope.cusset.Navchk == undefined || $scope.cusset.Navchk == false) {
                            MFIMsg.Alert("Please select NAV Picking Algorithim.", "Info", "OK");

                            return false;
                        }

                        if ($scope.cusset.Navchk == true) {
                            if (($scope.cusset.navpicksame == undefined && $scope.cusset.navpickdiff == undefined) || ($scope.cusset.navpicksame == false && $scope.cusset.navpickdiff == false)) {
                                MFIMsg.AlertHtml("Please select one of the Algorithim option.", MFIAlertType.Information, "OK");

                                return false;
                            }
                            // changes by arka
                            if ($scope.cusset.navpicksame == true) {//"navboth") {
                                if ($scope.cusset.Data.NavAlgoBothDate == null || $scope.cusset.Data.NavAlgoBothDate == "") {

                                    MFIMsg.Alert("Please enter Both Dates.", "Info", "OK");

                                    return false;
                                }
                                if (!areAllIntegers($scope.cusset.Data.NavAlgoBothDate)) {
                                    MFIMsg.AlertHtml("Please enter Both Dates in correct format (in comma separated)", MFIAlertType.Information, "OK");
                                    return false;
                                }
                            }
                            else {
                                if ($scope.cusset.Data.NavAlgoCurrentDate == null || $scope.cusset.Data.NavAlgoCurrentDate == "") {

                                    MFIMsg.Alert("Please enter Current Date", "Info", "OK");

                                    return false;
                                }
                                if ($scope.cusset.Data.NavAlgoPrevDate == null || $scope.cusset.Data.NavAlgoPrevDate == "") {
                                    MFIMsg.Alert("Please enter Previous Date", "Info", "OK");
                                    return false;
                                }
                            }

                        }
                        if ($scope.cusset.ReturnPeriodOneYear == true) {
                            $scope.cusset.Data.ReturnTypeBoth = null;

                        }
                        else {
                            $scope.cusset.Data.ReturnTypeLessThan = null;
                            $scope.cusset.Data.ReturnTypeGraterThan = null;
                        }

                        if ($scope.cusset.dateconvention == "Standard") {
                            $scope.cusset.Data.ReturnType = true;
                        }
                        else {
                            $scope.cusset.Data.ReturnType = false;
                        }

                        if ($scope.cusset.gross == "Default") {
                            $scope.cusset.Data.DividendType = $scope.cusset.investertype;
                        }
                        else {
                            $scope.cusset.Data.DividendType = $scope.cusset.investertype + '~' + $scope.cusset.gross;
                        }

                        if ($scope.cusset.Generic == true) {
                            $scope.cusset.Data.Isgen = true;
                        }
                        else {
                            $scope.cusset.Data.Isgen = false;

                        }
                        $scope.InfoLoader = true;
                        var Savecustomizeset = SavecustomizesetData.Call($scope.cusset.Data);

                        Savecustomizeset.then(function (response) {
                            $scope.InfoLoader = false;
                            //     ////debugger;
                            var newset = response.data.data;
                            localStorage.removeItem('GetReturnSettingdata');
                            if (newset.createdbyName != null && newset.createdbyName != "") {

                                if (newset.IsDefault == true) {
                                    var a = $scope.makeFalseIsDefault($scope.cusset.LoginId, $scope.cusset.LstSetName);
                                    if (a != -1) {
                                        $scope.cusset.LstSetName[a].IsDefault = false;
                                        $scope.IsDefaultdisabled = true;
                                    }
                                }

                                $scope.cusset.LstSetName.push(newset);


                                $scope.creationBy = newset.createdbyName;
                                $scope.creationOn = newset.strcreatedOn;
                                MFIMsg.Alert("Data Saved Successfully", "Success", "OK");

                            }
                            else {
                                if ($scope.cusset.Data.IsDefault == true) {

                                    var b = $scope.makeFalseIsDefault($scope.cusset.LoginId, $scope.cusset.LstSetName);
                                    if (b != -1) {
                                        $scope.cusset.LstSetName[b].IsDefault = false;
                                        $scope.IsDefaultdisabled = true;
                                    }
                                    var c = $scope.search($scope.cusset.Data.SetName, $scope.cusset.LstSetName);
                                    if (c != -1) {
                                        $scope.cusset.LstSetName[c].IsDefault = true;


                                    }
                                }
                                //update modifyid;

                                var k = $scope.search(newset.name, $scope.cusset.LstSetName);
                                if (k != -1) {
                                    $scope.cusset.LstSetName[k].ModifyId = newset.ModifyId;
                                    $scope.cusset.LstSetName[k].ModifybyName = newset.ModifybyName;
                                    $scope.cusset.LstSetName[k].strModifyOn = newset.strModifyOn;
                                }

                                $scope.ModifyBy = newset.ModifybyName;

                                $scope.ModifyOn = newset.strModifyOn;
                                MFIMsg.Alert("Data Updated Successfully", "Success", "OK");
                                $scope.InfoLoader = false;
                            }
                            Reset();
                        },
                            function errorCallback(response) {
                                MFIMsg.Alert("Oops, an error occurred Savecustomizeset!!", "Error", "OK");
                                $scope.InfoLoader = false;
                            });

                    };


                    $scope.Fnnavdisable = function () {
                        //  alert($scope.cusset.navpick);
                        //  alert($scope.Navchk);
                        $scope.cusset.navpicksame = false;
                        $scope.cusset.navpickdiff = false;
                        if ($scope.cusset.Navchk == true) {
                            $('#navdiv').find('*').prop('disabled', false);
                            if ($scope.cusset.navpicksame == false) {// "navboth") {
                                $('#NavAlgoCurrentDate').prop('disabled', true);
                                $('#NavAlgoPrevDate').prop('disabled', true);
                            }
                            else {

                                $('#NavAlgoBothDate').prop('disabled', true);
                            }
                        }
                        else {
                            $('#navdiv').find('*').prop('disabled', true);
                            //$('#chksamemovement').prop('disabled', true);
                            //$('#chkdifferentmovement').prop('disabled', true);                        
                            $scope.cusset.Data.NavAlgoCurrentDate = "";
                            $scope.cusset.Data.NavAlgoPrevDate = "";
                            $scope.cusset.Data.NavAlgoBothDate = "";

                        }

                    };


                    $scope.Fnnavpick = function (id) {
                        if ($scope.cusset.Navchk == undefined || $scope.cusset.Navchk == false) {
                            $scope.cusset.navpicksame = false;
                            $scope.cusset.navpickdiff = false;
                            return false;
                        }

                        if (id == 1) {
                            $scope.cusset.navpicksame = true;
                            $scope.cusset.navpickdiff = false;
                        }
                        else {
                            $scope.cusset.navpicksame = false;
                            $scope.cusset.navpickdiff = true;
                        }
                        if ($scope.cusset.navpicksame == true) {// "navboth") {
                            $scope.cusset.isnavActive = false;
                            $scope.cusset.Data.NavAlgoCurrentDate = "";
                            $scope.cusset.Data.NavAlgoPrevDate = "";
                        }
                        else {
                            $scope.cusset.isnavActive = true;
                            $scope.cusset.Data.NavAlgoBothDate = "";
                        }
                    };

                    $scope.FnreturnTyp = function (id) {
                        //   alert($scope.cusset.ReturnPeriod);
                        if (id == 1) {
                            $scope.cusset.ReturnPeriodOneYear = true;
                            $scope.cusset.ReturnPeriodAll = false;
                        }
                        else {
                            $scope.cusset.ReturnPeriodAll = true;
                            $scope.cusset.ReturnPeriodOneYear = false;
                        }

                        if ($scope.cusset.ReturnPeriodOneYear == true) {
                            $scope.cusset.isReturnActive = true;
                        }
                        else {
                            $scope.cusset.isReturnActive = false;

                        }
                    };

                    $scope.Reset = Reset;

                    function Reset() {

                        //if (($scope.cusset.Data.SetName == "ICRA Analytics (ICRON) Default Set") || ($scope.cusset.Data.SetName == "Sebi Equity Set") || ($scope.cusset.Data.SetName == "Sebi Debt Set")) {
                        //    //  $scope.delshow = false;
                        //    MFIMsg.Alert("This set cannot be reset", "Info", "OK");

                        //    return false;

                        //}

                        $scope.cusset.Data.SetName = "";
                        $scope.cusset.Data.ReturnTypeBoth = "Absolute";
                        $scope.cusset.Data.ReturnTypeLessThan = "Simple Annualized";
                        $scope.cusset.Data.ReturnTypeGraterThan = "Compound Annualized";
                        $scope.cusset.gross = "Default";
                        $scope.cusset.isnavActive = true;//
                        $scope.cusset.navpicksame = false;// "navdif";//
                        $scope.cusset.navpickdiff = false;// "navdif";//
                        $scope.cusset.ReturnPeriodOneYear = false;// "returnboth";//
                        $scope.cusset.ReturnPeriodAll = false;
                        $scope.cusset.isReturnActive = true; //
                        $scope.cusset.Generic = false;//
                        $scope.cusset.Personal = false;
                        if ($scope.cusset.Generic == true) {
                            $scope.gencls = 'btn btn-info btn-xs active';
                            $scope.personalcls = 'btn btn-info btn-xs';
                        }
                        else {
                            $scope.gencls = 'btn btn-info btn-xs';
                            $scope.personalcls = 'btn btn-info btn-xs active';
                        }

                        $scope.cusset.Data.NavType = "Reinvest";
                        $scope.cusset.dateconvention = "Standard";
                        $scope.cusset.investertype = "Individual/HUF";
                        $scope.cusset.Data.NavAlgoCurrentDate = "";
                        $scope.cusset.Data.NavAlgoPrevDate = "";
                        $scope.cusset.Data.NavAlgoBothDate = "";
                        $scope.cusset.Data.IsNormalizeReturns = false;
                        $scope.creationDetails = "";
                        $scope.selected = "";
                        $scope.cusset.Data.IsDefault = false;
                        $scope.cusset.Navchk = false;
                        $('#NavAlgoCurrentDate').prop('disabled', true);
                        $('#NavAlgoPrevDate').prop('disabled', true);
                        $('#btnreset').show();
                    }
                    $scope.DisableAllControl = function () {
                        if ($scope.IsOwnUserLogin == false || (($scope.cusset.Data.SetName == "ICRA Analytics (ICRON) Default Set") || ($scope.cusset.Data.SetName == "Sebi Equity Set") || ($scope.cusset.Data.SetName == "Sebi Debt Set"))) {
                            $scope.IsEntirePannelDisable = true;

                            /// Disabling I-Check
                            $scope.IsOneYearRtnCheck = true; // FnreturnTyp(1)
                            $scope.IsCheckAllPeriodss = true; // FnreturnTyp(0)
                            $scope.IsNormalizeReturns = true; // 
                            $scope.IsNavpickingAlgo = true; // Fnnavdisable
                            $scope.IsSameMomFbothDays = true; // Fnnavpick(1)
                            $scope.IsNavMomFdiffDate = true; // Fnnavpick(0)
                            $scope.IsNavTypeCheck = true;

                            /// Disabling Toggle
                            $('#DvNavType').addClass('disable_toggle_group');
                            $('#DvDataConven').addClass('disable_toggle_group');
                            $('#DvInvestType').addClass('disable_toggle_group');
                            $('#chkOneYear').addClass('disable_toggle_group');
                            $('#chkAllPeriods').addClass('disable_toggle_group');
                            $('#chkNormalizedreturn').addClass('disable_toggle_group');
                            $('#inlineCheckbox3').addClass('disable_toggle_group');
                            $('#chksamemovement').addClass('disable_toggle_group');
                            $('#chkdifferentmovement').addClass('disable_toggle_group');

                            $('#DdlLessThan').addClass('disable_toggle_group');
                            $('#DdlLessThan').attr('disabled', 'disabled');
                            $('#NavAlgoBothDate').addClass('disable_toggle_group');

                            $('#DdlGraterThan').addClass('disable_toggle_group');
                            $('#DdlGraterThan').attr('disabled', 'disabled');
                            $('#selectGross').addClass('disable_toggle_group');
                            $('#selectGross').attr('disabled', 'disabled');

                            $('#btndelete').hide();
                            $('#btnreset').hide();
                            //$scope.IsSameUser = false;

                        } else {
                            $scope.IsOneYearRtnCheck = false; // FnreturnTyp(1)
                            $scope.IsCheckAllPeriodss = false; // FnreturnTyp(0)
                            $scope.IsNormalizeReturns = false; // 
                            $scope.IsNavpickingAlgo = false; // Fnnavdisable
                            $scope.IsSameMomFbothDays = false; // Fnnavpick(1)
                            $scope.IsNavMomFdiffDate = false; // Fnnavpick(0)
                            $scope.IsNavTypeCheck = false;
                            $scope.IsPersonalCheck = false;


                            $('#DvNavType').removeClass('disable_toggle_group');
                            $('#DvDataConven').removeClass('disable_toggle_group');
                            $('#DvInvestType').removeClass('disable_toggle_group');
                            $('#chkOneYear').removeClass('disable_toggle_group');
                            $('#chkAllPeriods').removeClass('disable_toggle_group');
                            $('#chkNormalizedreturn').removeClass('disable_toggle_group');
                            $('#inlineCheckbox3').removeClass('disable_toggle_group');
                            $('#chksamemovement').removeClass('disable_toggle_group');
                            $('#chkdifferentmovement').removeClass('disable_toggle_group');

                            $('#DdlLessThan').removeClass('disable_toggle_group');
                            $('#DdlLessThan').removeAttr('disabled');
                            $('#NavAlgoBothDate').removeClass('disable_toggle_group');
                            $('#DdlGraterThan').removeClass('disable_toggle_group');
                            $('#DdlGraterThan').removeAttr('disabled');
                            $('#selectGross').removeClass('disable_toggle_group');
                            $('#selectGross').removeAttr('disabled');

                            $('#btndelete').show();
                            $('#btnreset').show();
                            $scope.IsSameUser = false;

                        }


                    }
                    $scope.FnOpenUpSaveButton = function () {
                        if ($scope.cusset.Data.IsDefault == true) {
                            $scope.IsSameUser = false;
                        } else {
                            if ($scope.cusset.IsAdmin == true || $scope.IsOwnUserLogin == true) {
                                $scope.IsSameUser = false;
                            } else {
                                $scope.IsSameUser = true;
                            }
                        }
                    }
                    $scope.modalclose = function () {
                        $scope.Reset();
                        $('#myModal1').modal('hide');
                    };


                    function areAllIntegers(str) {
                        // Split the string by commas
                        const values = str.split(',');

                        // Check if every value is an integer
                        return values.every(value => Number.isInteger(Number(value)));
                    }


                    $scope.FnchoseGen = function (id) {
                        //   ////debugger;
                        //$scope.cusset.Genmodel = id;  
                        $scope.cusset.Generic = false;
                        $scope.cusset.Personal = false;
                        if ($scope.IsPersonalCheck == false) {
                            if (id == 1)
                                $scope.cusset.Generic = true;
                            else
                                $scope.cusset.Personal = true;
                        } else {

                            $scope.cusset.Generic = true;
                            if ($scope.IsOwnUserLogin) {
                                $scope.cusset.Personal = true;
                            }
                        }
                    };

                    $scope.FnchoseNavtyp = function (id) {


                        if ($scope.IsNavTypeCheck == true) {

                            return;
                        } else { $scope.cusset.Data.NavType = id; }

                    };


                    $scope.FnchoseDataConvention = function (id) {

                        $scope.cusset.dateconvention = id;
                    };


                    $scope.FnchoseInvestorType = function (id) {

                        $scope.cusset.investertype = id;
                    };


                    $scope.fnDel = function () {
                        //  alert($scope.setid);

                        var SetDeleteinfodata = GetSetDeleteinfo.Call($scope.setid);
                        ////debugger;

                        if (($scope.cusset.Data.SetName == "ICRA Analytics (ICRON) Default Set") || ($scope.cusset.Data.SetName == "Sebi Equity Set") || ($scope.cusset.Data.SetName == "Sebi Debt Set")) {
                            //  $scope.delshow = false;
                            MFIMsg.Alert("This set cannot be deleted", "Info", "OK");

                            return false;

                        }

                        SetDeleteinfodata.then(function (response) {
                            localStorage.removeItem('GetReturnSettingdata');
                            OpenAlert(" set :" + $scope.cusset.Data.SetName + " deleted successfully");
                            //  if (response.data == true) {
                            //    //debugger;
                            $scope.cusset.LstSetName.splice($scope.setindex, 1);
                            $scope.Reset();
                            //   }

                        },
                            function errorCallback(response) {

                                OpenAlert("Oops, an error occurred SetDeleteinfodata!!!");
                            });





                    };

                    $scope.openDDl = function () {
                        angular.element('#editddl').addClass('input-group dropdown open');
                    };
                    $scope.search = function (nameKey, myArray) {
                        return myArray.findIndex(item => item.name === nameKey);
                    };

                    $scope.makeFalseIsDefault = function (LoginId, myArray) {
                        return myArray.findIndex(item => item.createdbyId === LoginId && item.IsDefault === true);
                    };
                    $scope.closeReturnSetting = function () {
                        if (screen.width <= 767) {
                            angular.element('#returnSettingDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#returnSettingDetails').hide();
                        } else {
                            angular.element('#returnSettingDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#returnSettingDetails').hide();
                            });
                        }
                    };

                    $scope.toggleReturnSettingPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-return');
                        var $details = angular.element('#returnSettingDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };


                }, 0);
         
            }
        };
    }
]);


