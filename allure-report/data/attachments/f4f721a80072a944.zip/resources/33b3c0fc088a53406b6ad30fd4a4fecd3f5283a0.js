
var OptionsSingleDate = {
    singleDatePicker: true,
    showDropdowns: true,
    autoApply: true,
    //autoUpdateInput: false,
    locale: {
        format: 'DD MMM YYYY'
    }
};

myApp.controller("CustomReportCtrl", ['$scope', '$http', '$filter', '$q', '$timeout', '$mdDialog', 'MFIMsg', 'ScheduleCustomReport', 'Fetchallreports', 'ScheduleReportsdetls', 'GenRepOntheFly', 'PostMakeGroupOfInputParamters', 'GetExcel', 'DeleteExistingSchedule', 'ChangeRptPresnttation', 'Gethistory', 'GetlatestExcel', 'UploadDividendFile', 'GetMaxNavDate', 'UploadEmailConfigFile',
    function ($scope, $http, $filter, $q, $timeout, $mdDialog, MFIMsg, ScheduleCustomReport, Fetchallreports, ScheduleReportsdetls, GenRepOntheFly, PostMakeGroupOfInputParamters, GetExcel, DeleteExistingSchedule, ChangeRptPresnttation, Gethistory, GetlatestExcel, UploadDividendFile, GetMaxNavDate, UploadEmailConfigFile) {
        $scope.msg = "Mymsg";
        $scope.TriggerType = "";
        $scope.example = {
            value: new Date(2025, 1, 1, 12, 30)
        };
        $scope.example1 = {
            value: new Date(2025, 1, 1, 12, 30)
        };
        $scope.example2 = {
            value: new Date(2025, 1, 1, 12, 30)
        };
        $('#datetimepicker3').datetimepicker({
            format: 'HH:mm'
        });
        $('#datetimepicker4').datetimepicker({
            format: 'HH:mm'
        });
        $('#datetimepicker5').datetimepicker({
            format: 'HH:mm'
        });
        $scope.LstScheduleReptDtls = [];
        $scope.selectedAllMonths = [];
        $scope.selectedAlldates = [];
        $scope.selectedAlldays = [];
        $scope.dailytriggertime = "";
        $scope.weeklytriggertime = "";
        $scope.monthlytriggertime = "";
        $scope.History = [];
        $scope.ShowHistory = [];
        $scope.ShowModal = false;
        $scope.LoaderSearch = false;
        $scope.Circularloader = false;
        $scope.UserSetsettingsMonths = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: false,
            showMultiCheckAll: false,
            ddltext: "Select Month",
            Keyprop: "Month",
            Valueprop: "Month",
        };
        $scope.UserSetsettingsdates = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: false,
            showMultiCheckAll: false,
            ddltext: "Select Dates",
            Keyprop: "date",
            Valueprop: "date",
        };
        $scope.UserSetsettingsweekdays = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: false,
            showMultiCheckAll: false,
            ddltext: "Select Days",
            Keyprop: "day",
            Valueprop: "day",
        };

        $scope.LstAllMonths = [{
            Month: "January"
        },
        {
            Month: "February"
        },
        {
            Month: "March"
        },
        {
            Month: "April"
        },
        {
            Month: "May"
        },
        {
            Month: "June"
        },
        {
            Month: "July"
        },
        {
            Month: "August"
        },
        {
            Month: "September"
        },
        {
            Month: "October"
        },
        {
            Month: "November"
        },
        {
            Month: "December"
        },
        ];
        $scope.LstAlldates = [];
        for (var i = 1; i <= 31; i++) {
            let obj = {
                date: i
            }
            $scope.LstAlldates.push(obj);
        }
        $scope.LstAlldays = [
            {
                day: "Sunday"
            },
            {
                day: "Monday"
            },
            {
                day: "Tuesday"
            },
            {
                day: "Wednesday"
            },
            {
                day: "Thursday"
            },
            {
                day: "Friday"
            },
            {
                day: "Saturday"
            },
        ]
        $scope.DownloadLatestReport = function (data) {
            data.Circularloader = true;
            var file = GetlatestExcel.Call(data.CustomReportId);
            file.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response?.data?.Success)) {
                    let guid = response?.data?.data;
                    window.open('/report/DownloadExcelCusRptBuilder?ReportGenerationUId=' + guid)
                    data.Circularloader = false;
                }
            },
                function errorCallback(response) {
                    data.Circularloader = false;
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");

                });
        }

        $scope.ReportAsOn = "";


        let data = GetMaxNavDate.Call();
        data.then(function successCallback(response) {
            if (!angular.isUndefinedOrNull(response.data.data)) {
                $scope.MaxNavDate = response.data.data;
            }
        },
            function errorCallback(response) {
                MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
            });
        $timeout(function () {
            function ApplySingleDate(start, end, lable) {
            }
            OptionsSingleDate.startDate = $scope.MaxNavDate;
            OptionsSingleDate.maxDate = $scope.MaxNavDate;
            angular.element('#ReportAsOnDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
        }, 500)
        
        
        

        $scope.DownloadReport = function (data) {
            var Obj = {
                CustomReptId: data.CustomReptId,
                Guid: data.Guid,
            }
            data.Circularloader = true;
            var file = GetExcel.Call(Obj);
            file.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response?.data?.Success)) {
                    window.open('/report/DownloadExcelCusRptBuilder?ReportGenerationUId=' + data.Guid)
                    data.Circularloader = false;
                }
            },
                function errorCallback(response) {
                    data.Circularloader = false;
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });

        }
        $scope.UploadClientFiles = function (ReportName) {
            if ($('#fileControl' + ReportName).val() == "") {

                MFIMsg.AlertHtml("Please choose any file..", MFIAlertType.Warning);
                $scope.LoaderFrGrid = false;
                return;
            }
            var tempScope = angular.element(document.getElementById('fileControl' + ReportName)).scope();
            var JSONDATA = {
                "files": tempScope.file,
                "ClientName": ReportName
            };
            var UploadFile = UploadDividendFile.Call(JSONDATA);
            UploadFile.then(function successCallback(response) {
                if (response.data != null && response.data.Success == true) {
                    $('#fileControl1').val('');
                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Success);
                }
                else {

                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);

                }
            },
                function errorCallback(response) {
                    $scope.LoaderFrGrid = false;
                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);
                });
        };
        $scope.DownloadUploader = function (ReportName) {
            window.open('/report/DownloadCustomUploader?ReportName=' + ReportName)
        }
        $scope.ScheduleReport = function (data) {

            //<md-button class="md-primary md-raised" ng-click="showTabDialog($event)" >
            //    Tab Dialog
            //</md-button>
            console.log(data);
            localStorage.removeItem("Schedulingitem_CustomReportId")
            localStorage.setItem("Schedulingitem_CustomReportId", data?.CustomReportId)

            localStorage.removeItem("Schedulingitem_LstCombinationSets")
            localStorage.setItem("Schedulingitem_LstCombinationSets", data?.LstCombinationSets?.length)

            localStorage.removeItem("Schedulingitem_ReportName")
            localStorage.setItem("Schedulingitem_ReportName", data?.ReportName)

            localStorage.removeItem("Schedulingitem_reportType")
            localStorage.setItem("Schedulingitem_reportType", data?.ReportType)

            localStorage.removeItem("Schedulingitem_isconfig")
            localStorage.setItem("Schedulingitem_isconfig", data?.IsConfig)

            $scope.LstScheduleReptDtls = [];
            var Dtls = ScheduleReportsdetls.Call(data?.CustomReportId);
            Dtls.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response?.data?.data)) {
                    $scope.LstScheduleReptDtls = response?.data?.data
                }
            },
                function errorCallback(response) {
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });

            var x = document.getElementById("exampleModal");
            x.style.display = "block";
        }
        $scope.ConfigReport = function (id) {
            window.open("/Report/CustomReport_Config?ReportId=" + id);
        }

        $scope.GenReport = function (data) {
            console.log(data)
            var obj = {
                ReportId: data.CustomReportId,
                ReportType: data.ReportType,
                Combsets: data.LstCombinationSets,
                ReportDate: $scope.ReportAsOn,
            }
            $scope.LoaderSearch = true;
            var Data = GenRepOntheFly.Call(obj);
            Data.then(function successCallback(response) {
                if (response.data.Success) {
                    $scope.LoaderSearch = false;
                    MFIMsg.AlertHtml(response.data?.Message, MFIAlertType.Success, "OK");
                }
                else {
                    $scope.LoaderSearch = false;
                    MFIMsg.AlertHtml(response?.data?.Message, MFIAlertType.Error, "OK");
                }
                //if (!angular.isUndefinedOrNull(response.data.data)) {
                //    console.log(response.data.data);
                //    MFIMsg.AlertHtml(response.data.Messege, MFIAlertType.Success, "OK");
                //}
            },
                function errorCallback(response) {
                    $scope.LoaderSearch = false;
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });
        }
        function getConfigaration() {

        }
        $scope.GetHistory = function (His) {
            document.getElementById("historypanel").style.display = "block";
            $scope.LoaderSearch = true;
            // $scope.History = [];
            $scope.ShowHistory = [];
            var data = Gethistory.Call(His.CustomReportId);
            data.then(function successCallback(response) {
                if (response.data.Success) {
                    // $scope.History = response.data.data;
                    $scope.ShowHistory = response.data.data;
                    if (($scope.ShowHistory.length % PageSize) == 0) {
                        ReportPageCnt = Math.floor($scope.ShowHistory.length / PageSize);
                    }
                    else {
                        ReportPageCnt = Math.floor(($scope.ShowHistory.length / PageSize) + 1);
                    }
                    $scope.pagingReport.total = ReportPageCnt;
                    $scope.pagingReport.current = 1;
                    loadReport();

                    $scope.LoaderSearch = false;
                }
                else {
                    $scope.LoaderSearch = false;
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                }

            },
                function errorCallback(response) {
                    $scope.LoaderSearch = false;
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });

        };



        $scope.Scheduler = function () {
            if ($scope.TriggerType == "Daily") {
                MakemonthlysectionInvisible();
                MakeweeklysectionInvisible();
                MakeDailysectionvisible();
            }
            else if ($scope.TriggerType == "Weekly") {
                MakemonthlysectionInvisible();
                Makeweeklysectionvisible();
                MakeDailysectionInvisible();
            }
            else if ($scope.TriggerType == "Monthly") {
                Makemonthlysectionvisible();
                MakeweeklysectionInvisible();
                MakeDailysectionInvisible();
            }
        }
        $scope.ScheduleReports = [];
        function GetAllReports() {
            let data = Fetchallreports.Call();
            data.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response.data.data)) {
                    console.log(response.data.data);
                    $scope.ScheduleReports = response.data.data;
                }
            },
                function errorCallback(response) {
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });
        }
        $scope.GetScheduledatetime = function () {
            //var isCombinationsetexists = localStorage.getItem("Schedulingitem_LstCombinationSets");
            //if (isCombinationsetexists == undefined || isCombinationsetexists == null || Number(isCombinationsetexists) == 0) {
            //    MFIMsg.AlertHtml("Please select Combination Set through Configuartion", MFIAlertType.Information);
            //    return;
            //}
            //// document.getElementById("datetimepicker5val")?.value = "";
            //// document.getElementById("datetimepicker3val")?.value = "";
            //// document.getElementById("datetimepicker4val")?.value = "";
            ////$scope.selectedAlldates = [];
            ////$scope.selectedAlldays = [];
            //var Reportdataobj = {};
            //var Obj = {
            //    Isdaily: false,
            //    IsMonthly: false,
            //    IsWeekly: false,
            //    Daily: {
            //        TriggerTime: ""
            //    },
            //    Monthly: {
            //        LstMonths: [],
            //        LstDates: [],
            //        TriggerTime: ""
            //    },
            //    Weekly: {
            //        LstDays: [],
            //        TriggerTime: ""
            //    },
            //    ReportName: "",
            //    ReportType: "",
            //    ReportId: ""
            //    //Reportdata: Reportdataobj

            //};
            //if ($scope.TriggerType == "" || $scope.TriggerType == null || $scope.TriggerType == undefined) {
            //    MFIMsg.AlertHtml("Please select frequency Type", MFIAlertType.Information);
            //    return;
            //}
            //if ($scope.TriggerType == "Daily") {
            //    var Dailytriggertime = document.getElementById("datetimepicker5val")?.value;
            //    if (Dailytriggertime == "" || Dailytriggertime == null || Dailytriggertime == undefined) {
            //        MFIMsg.AlertHtml("Please select Daily Trigger Time", MFIAlertType.Information);
            //        return;
            //    }
            //    if ($scope.LstScheduleReptDtls.findIndex(x => x.reportTime == Dailytriggertime) != -1) {
            //        MFIMsg.AlertHtml("Entry Already Exist", MFIAlertType.Information);
            //        return;
            //    }
            //    Obj.Isdaily = true;
            //    Obj.Daily.TriggerTime = Dailytriggertime;
            //}
            //else if ($scope.TriggerType == "Weekly") {
            //    if ($scope.selectedAlldays.length == 0) {
            //        MFIMsg.AlertHtml("Please select Trigger Day/Days", MFIAlertType.Information);
            //        return;
            //    }
            //    var Weeklytriggertime = document.getElementById("datetimepicker3val")?.value;
            //    if (Weeklytriggertime == "" || Weeklytriggertime == null || Weeklytriggertime == undefined) {
            //        MFIMsg.AlertHtml("Please select Weekly Trigger Time", MFIAlertType.Information);
            //        return;
            //    }
            //    let actual = $scope.LstScheduleReptDtls.filter(x => x.ReportFrequency == "Weekly").map(x => x.days).join(',');
            //    let passed = $scope.selectedAlldays.map(x => x.day).join(',');
            //    if (checkDays(actual, passed)) {
            //        MFIMsg.AlertHtml("Entry  Already Exist", MFIAlertType.Information);
            //        return;
            //    }
            //    Obj.IsWeekly = true;
            //    Obj.Weekly.TriggerTime = Weeklytriggertime;
            //    Obj.Weekly.LstDays = $scope.selectedAlldays;
            //}
            //else if ($scope.TriggerType == "Monthly") {

            //    if ($scope.selectedAlldates.length == 0) {
            //        MFIMsg.AlertHtml("Please select Trigger Date/Dates", MFIAlertType.Information);
            //        return;
            //    }
            //    var Monthlytriggertime = document.getElementById("datetimepicker4val")?.value;
            //    if (Monthlytriggertime == "" || Monthlytriggertime == null || Monthlytriggertime == undefined) {
            //        MFIMsg.AlertHtml("Please select Monthly Trigger Time", MFIAlertType.Information);
            //        return;
            //    }

            //    var Datess = $scope.selectedAlldates.reduce((dates, date) => {
            //        dates.push(date.date);
            //        return dates;
            //    }, [])
            //    var Monthss = $scope.selectedAllMonths.reduce((dates, date) => {
            //        dates.push(date.Month);
            //        return dates;
            //    }, [])
            //    let actual = $scope.LstScheduleReptDtls.filter(x => x.ReportFrequency == "Monthly").map(x => x.dates).join(',');
            //    let passed = Datess.join(',');
            //    if (checkDays(actual, passed)) {
            //        MFIMsg.AlertHtml("Entry  Already Exist", MFIAlertType.Information);
            //        return;
            //    }
            //    Obj.IsMonthly = true;
            //    Obj.Monthly.TriggerTime = Monthlytriggertime;
            //    Obj.Monthly.LstMonths = Monthss;
            //    Obj.Monthly.LstDates = Datess;


            //}
            //Obj.ReportId = Number(localStorage.getItem("Schedulingitem_CustomReportId"))
            //Obj.ReportName = localStorage.getItem("Schedulingitem_ReportName")
            //Obj.ReportType = localStorage.getItem("Schedulingitem_reportType")
            //let data = ScheduleCustomReport.Call(Obj);
            //data.then(function successCallback(response) {
            //    if (!angular.isUndefinedOrNull(response.data.Success)) {
            //        MFIMsg.AlertHtml("Rules Applied Successfully", MFIAlertType.Success, "OK");
            //    }
            //    if (!response?.data?.Success) {
            //        MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error, "OK");

            //    }
            //},
            //    function errorCallback(response) {
            //        MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
            //    });

            ////


            var isCombinationsetexists = localStorage.getItem("Schedulingitem_LstCombinationSets");
            var isConfig = localStorage.getItem("Schedulingitem_isconfig");
            if (isConfig=="true") {
                if (isCombinationsetexists == undefined || isCombinationsetexists == null || Number(isCombinationsetexists) == 0) {
                    alert("Please select Combination Set through Configuartion");
                    return;
                }
            }
            
            // document.getElementById("datetimepicker5val")?.value = "";
            // document.getElementById("datetimepicker3val")?.value = "";
            // document.getElementById("datetimepicker4val")?.value = "";
            //$scope.selectedAlldates = [];
            //$scope.selectedAlldays = [];
            var Reportdataobj = {};
            var Obj = {
                Isdaily: false,
                IsMonthly: false,
                IsWeekly: false,
                Daily: {
                    TriggerTime: ""
                },
                Monthly: {
                    LstMonths: [],
                    LstDates: [],
                    TriggerTime: ""
                },
                Weekly: {
                    LstDays: [],
                    TriggerTime: ""
                },
                ReportName: "",
                ReportType: "",
                ReportId: ""
                //Reportdata: Reportdataobj

            };
            if ($scope.TriggerType == "" || $scope.TriggerType == null || $scope.TriggerType == undefined) {
                alert("Please select frequency Type");
                return;
            }
            if ($scope.TriggerType == "Daily") {
                var Dailytriggertime = document.getElementById("datetimepicker5val")?.value;
                if (Dailytriggertime == "" || Dailytriggertime == null || Dailytriggertime == undefined) {
                    alert("Please select Daily Trigger Time");
                    return;
                }
                if ($scope.LstScheduleReptDtls.findIndex(x => x.reportTime == Dailytriggertime) != -1) {
                    alert("Entry Already Exist");
                    return;
                }
                Obj.Isdaily = true;
                Obj.Daily.TriggerTime = Dailytriggertime;
            }
            else if ($scope.TriggerType == "Weekly") {
                if ($scope.selectedAlldays.length == 0) {
                    alert("Please select Trigger Day/Days");
                    return;
                }
                var Weeklytriggertime = document.getElementById("datetimepicker3val")?.value;
                if (Weeklytriggertime == "" || Weeklytriggertime == null || Weeklytriggertime == undefined) {
                    alert("Please select Weekly Trigger Time");
                    return;
                }
                let actual = $scope.LstScheduleReptDtls.filter(x => x.ReportFrequency == "Weekly").map(x => x.days).join(',');
                let passed = $scope.selectedAlldays.map(x => x.day).join(',');
                if (checkDays(actual, passed)) {
                    alert("Entry  Already Exist");
                    return;
                }
                Obj.IsWeekly = true;
                Obj.Weekly.TriggerTime = Weeklytriggertime;
                Obj.Weekly.LstDays = $scope.selectedAlldays;
            }
            else if ($scope.TriggerType == "Monthly") {

                if ($scope.selectedAlldates.length == 0) {
                    alert("Please select Trigger Date/Dates");
                    return;
                }
                var Monthlytriggertime = document.getElementById("datetimepicker4val")?.value;
                if (Monthlytriggertime == "" || Monthlytriggertime == null || Monthlytriggertime == undefined) {
                    alert("Please select Monthly Trigger Time");
                    return;
                }

                var Datess = $scope.selectedAlldates.reduce((dates, date) => {
                    dates.push(date.date);
                    return dates;
                }, [])
                var Monthss = $scope.selectedAllMonths.reduce((dates, date) => {
                    dates.push(date.Month);
                    return dates;
                }, [])
                let actual = $scope.LstScheduleReptDtls.filter(x => x.ReportFrequency == "Monthly").map(x => x.dates).join(',');
                let passed = Datess.join(',');
                if (checkDays(actual, passed)) {
                    MFIMsg.AlertHtml("Entry  Already Exist", MFIAlertType.Information);
                    return;
                }
                Obj.IsMonthly = true;
                Obj.Monthly.TriggerTime = Monthlytriggertime;
                Obj.Monthly.LstMonths = Monthss;
                Obj.Monthly.LstDates = Datess;


            }
            Obj.ReportId = Number(localStorage.getItem("Schedulingitem_CustomReportId"))
            Obj.ReportName = localStorage.getItem("Schedulingitem_ReportName")
            Obj.ReportType = localStorage.getItem("Schedulingitem_reportType")
            let data = ScheduleCustomReport.Call(Obj);
            data.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response.data.Success)) {
                    MFIMsg.AlertHtml("Rules Applied Successfully", MFIAlertType.Success, "OK");
                }
                if (!response?.data?.Success) {
                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error, "OK");

                }
            },
                function errorCallback(response) {
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });
        }
        function checkDays(actual, passed) {
            const actualDays = new Set(actual.split(','));
            const passedDays = new Set(passed.split(','));

            // Check if any of the days in passedDays are present in actualDays
            for (let day of passedDays) {
                if (actualDays.has(day)) {
                    return true;
                }
            }
            return false;
        }
        function MakeDailysectionvisible() {
            document.getElementById("dailyschedule").style.display = "block";
            //$scope.selectedAlldays = [];
            //$scope.selectedAlldates = [];
            //$scope.LstAlldays = $scope.LstAlldays.forEach(x => x.IsChecked = false);
            //$scope.LstAlldates = $scope.LstAlldates.forEach(x => x.IsChecked = false);
        }
        function MakeDailysectionInvisible() {
            document.getElementById("dailyschedule").style.display = "none";
        }
        function Makeweeklysectionvisible() {
            document.getElementById("weeklyscheduledates").style.display = "block";
            document.getElementById("weeklyschedule").style.display = "block";
            //$scope.selectedAlldays = [];
            //$scope.LstAlldays.forEach(x => x.IsChecked = false);
            //$scope.LstAlldates.forEach(x => x.IsChecked = false);

            //$scope.selectedAlldates = [];
        }
        function MakeweeklysectionInvisible() {
            document.getElementById("weeklyscheduledates").style.display = "none";
            document.getElementById("weeklyschedule").style.display = "none";
        }
        function Makemonthlysectionvisible() {
            document.getElementById("monthlyscheduledates").style.display = "block";
            //document.getElementById("monthlyschedule").style.display = "block";
            document.getElementById("monthlyscheduletime").style.display = "block";
            //$scope.selectedAlldays = [];
            //$scope.selectedAlldates = [];
            //$scope.LstAlldays.forEach(x => x.IsChecked = false);
            //$scope.LstAlldates.forEach(x => x.IsChecked = false);
        }
        function MakemonthlysectionInvisible() {
            document.getElementById("monthlyscheduledates").style.display = "none";
            //document.getElementById("monthlyschedule").style.display = "none";
            document.getElementById("monthlyscheduletime").style.display = "none";

        }
        GetAllReports();

        //// Sequenceee

        $scope.Sequencedata = [];
        $scope.Params = [];
        $scope.Groupeddatas = [];
        $scope.GroupeddataSubdatapoints = [];
        $scope.SelectedGroupeddatas = [];
        $scope.SelectedGroupeddataSubdatapoints = [];
        $scope.Groupeddatassettings = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true,
            ddltext: "GroupedDataPoints",
            Keyprop: "ParamterSubGrpName",
            Valueprop: "ParamterSubGrpName",
        };
        $scope.datapointssettings = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true,
            ddltext: "DataPoints",
            Keyprop: "DatapointName",
            Valueprop: "DatapointName",
        };
        $scope.groupeddataevents = {
            onItemSelect: function (item) {
                // debugger;
                //-------
                var arr = $scope.Groupeddatas.find(x => x.ParamterSubGrpName == item.ParamterSubGrpName)?.ParamterSubgrouppeddatapoints;
                $scope.GroupeddataSubdatapoints = [...$scope.GroupeddataSubdatapoints, ...arr];
            },
            onItemDeselect: function (item) {
                //-------------
                var Itemtoexclude = $scope.Groupeddatas.find(x => x.ParamterSubGrpName == item.ParamterSubGrpName)?.ParamterSubgrouppeddatapoints.map(p => p.DatapointName);
                var total = $scope.GroupeddataSubdatapoints;
                $scope.GroupeddataSubdatapoints = total.filter(item => !Itemtoexclude.includes(item.DatapointName));
            },
            onSelectAll: function () {
                //---------------
                $scope.GroupeddataSubdatapoints = [];
                $scope.GroupeddataSubdatapoints = $scope.Groupeddatas.map(x => x.ParamterSubgrouppeddatapoints).flat();
            },
            onDeselectAll: function () {
                //---------------------
                $scope.GroupeddataSubdatapoints = [];
            }

        }

        $scope.datapointevents = {
            onItemSelect: function (item) {
                // debugger;
                //-------
            },
            onItemDeselect: function (item) {
                //-------------

            },
            onSelectAll: function () {
                //---------------

            },
            onDeselectAll: function () {
                //---------------------

            }

        }
        $scope.ReportSequence = function (Data) {
            var Obj = {
                LstCombSetMaster: Data.LstCombinationSets
            };
            let data = PostMakeGroupOfInputParamters.Call(Obj);
            data.then(function successCallback(response) {
                if (!angular.isUndefinedOrNull(response.data.Success)) {
                    $scope.Sequencedata = response.data.data;
                    $scope.Params = $scope.Sequencedata.map(par => ({ ParameterName: par.ParameterName, ParameterId: par.ParameterId }))
                }
            },
                function errorCallback(response) {
                    MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                });
        }

        $scope.ParamSelection = function (param) {
            $scope.Groupeddatas = $scope.Sequencedata.find(x => x.ParameterName == param.ParameterName)?.ParameterSubgroup.map(p => p)
        }
        $scope.selectScheduleClick = function (data, ischecked) {

            $scope.LstScheduleReptDtls.forEach(x => {
                if (x.id == data.id) {
                    if (ischecked) {
                        x.ischecked = true;
                    }
                    else {
                        x.ischecked = false;
                    }
                }
            })
            if ($scope.LstScheduleReptDtls.every(x => x.ischecked == true)) {
                $scope.IsallSchedulechecked = true;
            }
            else {
                $scope.IsallSchedulechecked = false;

            }
        }
        $scope.selectallschedules = function () {
            if ($scope.IsallSchedulechecked) {
                $scope.LstScheduleReptDtls.forEach(x => x.ischecked = true);
            }
            else {
                $scope.LstScheduleReptDtls.forEach(x => x.ischecked = false);
            }
        }
        $scope.DeleteExistingSchedule = function () {
            let ids = $scope.LstScheduleReptDtls.filter(x => x.ischecked == true).map(p => p.id);
            if (ids.length <= 0) {
                alert("Please Select at least one existing schedule to delete!!");
                return;
            }
            //MFIMsg.Confirm("Are you Sure You want to delete existing schedule?", "MFI360 Explorer", "Ok", "Cancel").then(function successCallback(response) {
            //    var Id = {
            //        "DelIds": ids
            //    };
            //    var deletecomb = DeleteExistingSchedule.Call(Id);
            //    deletecomb.then(function (response) {
            //        if (response.data.Success) {
            //            MFIMsg.AlertHtmlWithRes2("Existing Schedule deleted successfully", MFIAlertType.Success, "OK").then(function () {
            //                window.location.reload();
            //            });
            //        }
            //        else {
            //            //MFIMsg.Alert(response.data.Message != null ? response.data.Message : "Cannot delete data !!!");
            //            MFIMsg.AlertHtml(response.data.Message != null ? response.data.Message : "Cannot delete data", MFIAlertType.Information);
            //        }
            //    },
            //        function errorCallback(response) {
            //            $scope.LoaderCommonCompositeIndex = false;
            //            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
            //        });
            //});
            if (confirm("Are you Sure You want to delete existing schedule?") == true) {
                var Id = {
                    "DelIds": ids
                };
                var deletecomb = DeleteExistingSchedule.Call(Id);
                deletecomb.then(function (response) {
                    if (response.data.Success) {
                        showAlertWithCallback('Existing Schedule deleted successfully!', function () {
                            window.location.reload();
                        });
                    }
                    else {
                        //MFIMsg.Alert(response.data.Message != null ? response.data.Message : "Cannot delete data !!!");
                        alert(response.data.Message != null ? response.data.Message : "Cannot delete data");
                    }
                },
                    function errorCallback(response) {
                        $scope.LoaderCommonCompositeIndex = false;
                        alert("Oops, an error occurred");
                    });
            }
            else {
                return;
            }

        }


        function showAlertWithCallback(message, callback) {
            alert(message);
            if (callback && typeof callback === 'function') {
                callback();
            }
        }

        $scope.toggleOptions = function (data) {
            var rptprsnt = ChangeRptPresnttation.call($scope.IsParameterWiseRept, data.CustomReportId);
            rptprsnt.then(function (response) {
                if (response.data.Success) {
                    MFIMsg.AlertHtml("Report Presentation Type Chnaged Successfully!!", MFIAlertType.Information);
                }
                else {
                    //MFIMsg.Alert(response.data.Message != null ? response.data.Message : "Cannot delete data !!!");
                    MFIMsg.AlertHtml(response.data.Message != null ? response.data.Message : "Cannot able to Update Presenrarion Type", MFIAlertType.Error);
                }
            },
                function errorCallback(response) {
                    $scope.LoaderCommonCompositeIndex = false;
                    MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                });
        }

        var ReportPageCnt = 1;
        var PageSize = 10;

        $scope.pagingReport = {
            total: ReportPageCnt,
            current: 1,
            onPageChanged: loadReport,
        };
        function loadReport() {
            $scope.History = $scope.ShowHistory.slice(($scope.pagingReport.current - 1) * PageSize, ($scope.pagingReport.current * PageSize));
            $scope.currentPageReport = $scope.pagingReport.current;
        }


        $scope.UploadEmailConfiguration = function (ReportName) {
            if ($('#emailConfig' + ReportName).val() == "") {

                MFIMsg.AlertHtml("Please choose any file..", MFIAlertType.Warning);
                $scope.LoaderFrGrid = false;
                return;
            }
            var tempScope = angular.element(document.getElementById('emailConfig' + ReportName)).scope();
            var JSONDATA = {
                "files": tempScope.file,
                "ClientName": ReportName
            };
            var UploadEmailConfig = UploadEmailConfigFile.Call(JSONDATA);
            UploadEmailConfig.then(function successCallback(response) {
                if (response.data != null && response.data.Success == true) {
                    $('#emailConfig1').val('');
                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Success);
                }
                else {

                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);

                }
            },
                function errorCallback(response) {
                    $scope.LoaderFrGrid = false;
                    MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);
                });
        };
        $scope.DownloadTemplateExcel = function (ReportName) {
            window.open('/report/DownloadEmailConfigTemplate');
        }
    }
]);