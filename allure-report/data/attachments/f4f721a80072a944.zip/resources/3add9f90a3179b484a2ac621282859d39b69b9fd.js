SharedServices.service('AllAdvanceSettings', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetSubPlanList',
            method: 'GET'
        });
    }
}]);

SharedServices.service('SaveAdvanceSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/SaveUserBasicSettings',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('AllApplicationSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetBasicSettingsData',
            method: 'GET'
        });
    }
}]);