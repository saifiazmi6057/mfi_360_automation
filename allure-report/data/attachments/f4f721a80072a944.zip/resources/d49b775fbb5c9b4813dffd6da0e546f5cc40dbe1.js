SharedDeractives.directive('dirFundDashboardReturn', ['GetTopFundReturn', 'GetTopFundIndexReturn', 'CategoryAvgReturn', 'GetYearlyReturn', 'GetSEBIFormatReturn', 'GetRollingReturnGraphData', 'GetRollingReturnData', 'GetFetchUserBasicSettings', 'MFIMsg',
    function (GetTopFundReturn, GetTopFundIndexReturn, CategoryAvgReturn, GetYearlyReturn, GetSEBIFormatReturn, GetRollingReturnGraphData, GetRollingReturnData, GetFetchUserBasicSettings, MFIMsg) {
        return {
            //restrict: 'E',
            scope: { schemeId: "=", loginId: "=", indexId: "=", additionalIndexId: "=", isSuitableIndex:"=",fundName:"=",suitableIndex:"=" },
            templateUrl: function (elem, attrs) {
                //
                return "/FundDashboard/GetReturnHTML"
            },
            controller: function ($scope, $http, $q) {

                var CustomColors4Ratio = ["#4b5de4", "#d8b83f", "#ff5800", "#23c6c8", "#ed5565", "#009688"];
                var navbutton4p2p = [
                    {
                        type: 'month',
                        count: 1,
                        text: '1M'
                    },
                    {
                        type: 'month',
                        count: 6,
                        text: '6M'
                    }, {
                        type: 'year',
                        count: 1,
                        text: '1Y'
                    },
                    {
                        type: 'all',
                        text: 'All'
                    }];

                var navspecialprop4p2p = {
                    "selected": 4, "inputEnabled": false, "navbutton": navbutton, "navigator": false
                };
                var CustomColors4p2p = ["#4b5de4", "#d8b83f", "#ff5800", "#23c6c8", "#ed5565", "#009688"];
                var yxchartstyle = { "fontSize": "13px", "fontFamily": "latoregular", "color": "rgb(75,93,228)", "fontWeight": "bold" };
                var titlechartstyle = { "fontSize": "25px", "fontFamily": "latoregular", "color": "blue", "fontWeight": "Normal" };
                var subtitlechartstyle = { "fontSize": "12px", "fontFamily": "latoregular", "color": "pink", "fontWeight": "lighter" };
                var legendstyle = { "fontSize": "13px", "fontFamily": "latoregular", "color": "green", "fontWeight": "bold", "align": "center", "verticalAlign": "bottom", "layout": "horizontal" };
                var navspecialprop = { "selected": 4, "navigator": true, "inputEnabled": false, "navbutton": navbutton, "IsRebaseRequired": false, IsTooltipWithChangeRequired: true,"ValueType":'Value', "IscompareStart": true  };
                $scope.FDReturn = {};
                $scope.FDReturn.IsYearlySchRtnFound = false;
                $scope.FDReturn.SchemeName = "";
                $scope.FDReturn.p2pLoader = true;
                $scope.FDReturn.RollingReturndataLoader = true;
                $scope.FDReturn.CalanderReturnLoader = true;
                $scope.FDReturn.RollingReturnLoader = true;
                $scope.FDReturn.SEBIReturnLoader = true;
               // $scope.FDReturn.MaxYearlyRtnCnt = 0;

                $scope.FDReturn.FNE2EP2PReturn = function () {
                    window.open("/FundDashboard/ExportToExcelP2PReturn?LoginId=" + $scope.loginId + "&SchemeId=" + $scope.schemeId + "&IndexId=" + $scope.indexId + "&AdditionalIndexId=" + $scope.additionalIndexId);
                };
                $scope.FDReturn.FNE2ERollingReturn = function () {
                    var Disclaimer = "* Parameter for Rolling frequency 1 month and Rolling period 1 month"
                    window.open("/FundDashboard/ExportToExcelRollingReturn?LoginId=" + $scope.loginId + "&SchemeId=" + $scope.schemeId + "&IndexId=" + $scope.indexId + "&AdditionalIndexId=" + $scope.additionalIndexId + "&Disclaimer=" + Disclaimer);
                };
                $scope.FDReturn.FNE2EYearlyReturn = function () {
                    window.open("/FundDashboard/ExportToExcelYearlyReturn?LoginId=" + $scope.loginId + "&SchemeId=" + $scope.schemeId + "&IndexId=" + $scope.indexId + "&AdditionalIndexId=" + $scope.additionalIndexId);
                };
                $scope.FDReturn.FNSebiFormatReturn = function () {
                    window.open("/FundDashboard/ExportToExcelSEBIReturn?LoginId=" + $scope.loginId + "&SchemeId=" + $scope.schemeId);
                };

                if ($scope.schemeId != 0) {
                    var SchIds = [];
                    SchIds.push($scope.schemeId);

                    var IndexIds = [];

                    IndexIds.push(parseInt($scope.indexId));
                  //  IndexIds.push($scope.additionalIndexId);

                    var TopFundReturn = GetTopFundReturn.Call(SchIds);
                    var TopFundIndexReturn = GetTopFundIndexReturn.Call(IndexIds);
                    var CategoryAvg = CategoryAvgReturn.Call(SchIds);


                    $q.all(
                        [TopFundReturn,
                            TopFundIndexReturn,
                               CategoryAvg]
                    ).then(function (response) {

                        $scope.FDReturn.lstTopFund = [];
                        for (p = 0; p < response.length; p++) {
                            for (v = 0; v < response[p].data.data.length; v++) {
                                $scope.FDReturn.lstTopFund.push(response[p].data.data[v]);
                            }
                        }
                        var IndIndex = -1;
                        for (v = 0; v < $scope.FDReturn.lstTopFund.length; v++) {
                            if ($scope.FDReturn.lstTopFund[v].SchemeId == $scope.indexId) {
                                IndIndex = v;
                                break;
                            }
                        }
                        if (IndIndex != -1) {
                            if ($scope.isSuitableIndex == true)
                                $scope.FDReturn.lstTopFund[IndIndex].SchemeName = "Suitable Index: " + $scope.FDReturn.lstTopFund[IndIndex].SchemeName;
                            else
                                $scope.FDReturn.lstTopFund[IndIndex].SchemeName = "Benchmark: " + $scope.FDReturn.lstTopFund[IndIndex].SchemeName;
                        }

                        $scope.$emit('notification', { Data: $scope.FDReturn.lstTopFund, Msg: "P2PReturn", IndexIds: IndexIds });
                        $scope.FDReturn.p2pLoader = false;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching top fund return.", MFIAlertType.Error, "OK");
                        });
                    var ObjRollingParam = {};
                    ObjRollingParam.SchemeId = $scope.schemeId;
                    ObjRollingParam.IndexId = $scope.indexId;
                    ObjRollingParam.AdditionalIndexId = null;
                    var RollingReturn = GetRollingReturnData.Call(ObjRollingParam);
                    RollingReturn.then(function (response) {
                        $scope.FDReturn.LstRollingReturn = response.data.data;
                        var IndYearlyIndex = -1;
                        for (v = 0; v < $scope.FDReturn.LstRollingReturn.length; v++) {
                            if ($scope.FDReturn.LstRollingReturn[v].Id == $scope.indexId) {
                                IndYearlyIndex = v;
                                break;
                            }
                        }
                        if (IndYearlyIndex != -1) {
                            if ($scope.isSuitableIndex == true)
                                $scope.FDReturn.LstRollingReturn[IndYearlyIndex].Name = "Suitable Index: " + $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name;
                            else
                                $scope.FDReturn.LstRollingReturn[IndYearlyIndex].Name = "Benchmark: " + $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name;
                        }

                        $scope.FDReturn.RollingReturndataLoader = false;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching rolling return.", MFIAlertType.Error, "OK");
                        });
                    var YearlyReturn = GetYearlyReturn.Call($scope.schemeId, 5, IndexIds, $scope.loginId);
                    YearlyReturn.then(function (response) {
                        $scope.FDReturn.LstYearlyRtn = response.data.data;

                        var IndYearlyIndex = -1;
                        for (v = 0; v < $scope.FDReturn.LstYearlyRtn.length; v++) {
                            if ($scope.FDReturn.LstYearlyRtn[v].Id == $scope.indexId) {
                                IndYearlyIndex = v;
                                break;
                            }
                        }
                        if (IndYearlyIndex != -1) {
                            if ($scope.isSuitableIndex == true)
                                $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name = "Suitable Index: " + $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name;
                            else
                                $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name = "Benchmark: " + $scope.FDReturn.LstYearlyRtn[IndYearlyIndex].Name;
                        }

                        $scope.FDReturn.CalanderReturnLoader = false;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching yearly return.", MFIAlertType.Error, "OK");
                        });

                    var SEBIFormatReturn = GetSEBIFormatReturn.Call($scope.schemeId, null);
                    SEBIFormatReturn.then(function (response) {
                        $scope.FDReturn.ObjSEBIFormatReturn = response.data.data;

                        var SebiSchemeIndexId = 0;
                        var IsIndexMatched = false;
                        for (v = 0; v < $scope.FDReturn.ObjSEBIFormatReturn.LstReturn.length; v++) {
                            if ($scope.FDReturn.ObjSEBIFormatReturn.LstReturn[v].SchemeIndexId == $scope.indexId) {
                                SebiSchemeIndexId = v;
                                IsIndexMatched = true;
                                break;
                            }
                        }
                        if (IsIndexMatched == true) {
                            if ($scope.isSuitableIndex == true)
                                $scope.FDReturn.ObjSEBIFormatReturn.LstReturn[SebiSchemeIndexId].SchemeIndexName = "Suitable Index: " + $scope.FDReturn.ObjSEBIFormatReturn.LstReturn[SebiSchemeIndexId].SchemeIndexName;
                            else
                                $scope.FDReturn.ObjSEBIFormatReturn.LstReturn[SebiSchemeIndexId].SchemeIndexName = "Benchmark: " + $scope.FDReturn.ObjSEBIFormatReturn.LstReturn[SebiSchemeIndexId].SchemeIndexName;
                        }
                        $scope.FDReturn.SEBIReturnLoader = false;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching SEBI format return.", MFIAlertType.Error, "OK");
                        });
                    // debugger;
                    $scope.FDReturn.UserBasicSettings = {};
                    var FetchUserBasicSettings = GetFetchUserBasicSettings.Call();
                    FetchUserBasicSettings.then(function (response) {
                        $scope.FDReturn.UserBasicSettings = response.data.data;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching user basic setting.", MFIAlertType.Error, "OK");
                        });
                    

                    var RollingData = GetRollingReturnGraphData.Call(ObjRollingParam);
                    RollingData.then(function (response) {
                        ////
                        var data = response.data.data;
                        $scope.AsOnDate = data[0].StrReturnDate;
                        //var Model_FundDashboardReturn =@Html.Raw(Newtonsoft.Json.JsonConvert.SerializeObject(Model.RollingGraphData, Newtonsoft.Json.Formatting.Indented));
                        //var data = Model_FundDashboardReturn;
                        var tt = [[]];
                        for (var i = 0; i < data.length; i += 1) {

                            var tt1 = {};
                            tt1.name = data[i].Name;

                            var points = [];

                            for (var j = 0; j < data[i].ValueAndDate.length; j += 1) {
                                var res = data[i].ValueAndDate[j].Date.split("-");
                                points.push([Date.UTC(res[0], res[1] - 1, res[2]), data[i].ValueAndDate[j].Value, data[i].ValueAndDate[j].Value]);
                                //var resjj = data[i].ValueAndDate[j].Date.split("-");
                            }
                            tt1.data = points;
                            tt1.pointStart = Date.UTC(2018, 0, 15),
                            tt.push(tt1);
                        }
                        tt.shift();
                        //  debugger;
                        GenerateGraph('nav', 'DvRolingGraph', tt, '', '', 'Absolute Change (In %)', '', '', '', '', '', true, true, yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, navspecialprop, CustomColors4p2p, $scope.FDReturn.UserBasicSettings.ReturnDecimalFormat); //navspecialprop4p2p
                        $scope.FDReturn.RollingReturnLoader = false;
                    },
                        function (stu) {

                            MFIMsg.AlertHtml("Error in fetching rolling return.", MFIAlertType.Error, "OK");
                        });


                }
            }
        }
    }]);