SharedServices.service('AgingAnalysisInvestorClassification', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAgingAnalysis/GetAgingAnalysisInvestorClassification',
            method: 'GET'
        });
    }

}]);

SharedServices.service('AgingAnalysisTenure', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAgingAnalysis/GetAgingAnalysisTenure',
            method: 'GET'
        });
    }

}]);

SharedServices.service('AgingAnalysisReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAgingAnalysis/AgingAnalysisReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetAgingAnalysisDates', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (Years) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAgingAnalysis/GetAgingAnalysisDates?Years=' + Years
        });
    }

}]);
