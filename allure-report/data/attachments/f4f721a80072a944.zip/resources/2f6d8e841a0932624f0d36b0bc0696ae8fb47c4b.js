SharedDeractives.directive('entryExitDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'MFIMsg',  
    function ($http, $q, $timeout, ApiInfo, MFIMsg) {
        return {
            restrict: 'AE',
            scope: {
                LstMFISchemes: '=',
                //setfromEntryExitDirective: '&'
                setSchemeAmc: '&',
                selectedMutualFundModel: '=',
                setMaxDate:'=',
                setMinDate: '=',
                setEntryExitExpresion: '&',
                setAllInputData:'&'
            },
            templateUrl: '/NavIndex/EntryExitLoad',
            link: function ($scope, $element, $attrs) {

                function ApplyDateRange(start, end, label) {
                }
                function PerApplyDateRange(start, end, label) {
                }
                function ApplySingleDate(start, end, label) {
                }
                var dateOffset = (24 * 60 * 60 * 1000) * 1;
                var fromDate = new Date($scope.setMaxDate);
                var startDate = new Date(fromDate.setTime(fromDate.getTime() - dateOffset));
                var OptionsDateRange = {
                    //minDate: new Date(),
                    //maxDate: new Date(),
                    showDropdowns: true,
                    //autoUpdateInput: false,
                    autoApply: true,
                    locale: {
                        format: 'DD MMM YYYY'
                    },
                    startDate: startDate,
                    minDate: $scope.setMinDate,
                    maxDate: $scope.setMaxDate,
                    endDate: $scope.setMaxDate,
                    opens: 'left'
                };
                var PerOptionsDateRange = {
                    //minDate: new Date(),
                    //maxDate: new Date(),
                    showDropdowns: true,
                    //autoUpdateInput: false,
                    autoApply: true,
                    locale: {
                        format: 'DD MMM YYYY'
                    },
                    startDate: startDate,
                    minDate: $scope.setMinDate,
                    maxDate: $scope.setMaxDate,
                    endDate: $scope.setMaxDate,
                    opens: 'left'
                };
                var OptionsSingleDate = {
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoApply: true,
                    //autoUpdateInput: false,
                    locale: {
                        format: 'DD MMM YYYY'
                    },
                    minDate: $scope.setMinDate,
                    maxDate: $scope.setMaxDate,
                    endDate: $scope.setMaxDate
                };

                angular.element('#EntryExitDateRange').daterangepicker(PerOptionsDateRange, PerApplyDateRange);
                angular.element('#EntryExitToDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                $scope.LstLoadType = [];
                var Input = [];
                Input.selectRange=[];
                 $scope.index = 1;
                $scope.LstLoadType.push({ Index: $scope.index,Loadtype:"",Expression:"",Val:"",FromVal:"",ToVal:""})
                $scope.EntryExit.LoadType = "Entry";
                $scope.IsSchemeChecked = true;
                $scope.IsAmcChecked = false;
                $scope.EntryExit.Expression = [];
                $scope.SetSchemeOrAmc = function (type) {
                    //var Input = [];
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                   // Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType = $scope.EntryExit.LoadType;
                    //Input.Expression = $scope.EntryExit.Expression;
                    //Input.LoadVal = $scope.EntryExit.val;
                    //Input.LoadFromVal = $scope.EntryExit.FromVal;
                    //Input.EntryExit.ToVal = $scope.EntryExit.ToVal;
                    if (type == "Scheme") {
                       
                        $scope.IsSchemeChecked = true;
                        $scope.IsAmcChecked = false;
                        $scope.AmcNature = false;
                        $("#lblAmc").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblAmc").blur();
                            $("#lblScheme").addClass("btn btn-success btn-sm active");
                        }, 0);
                        $scope.setSchemeAmc({ IsSchemeOrAmc: $scope.IsSchemeChecked });
                        $scope.setAllInputData({ input: Input });
                    }
                    else if (type == "Amc") {
                        $scope.NetAssetDis = true;
                    
                        //$scope.IsIndustryWise = true;
                        $scope.IsSchemeChecked = false;
                        $scope.IsAmcChecked = true;
                        $scope.AmcNature = true;
                        $("#lblScheme").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblScheme").blur();
                            $("#lblAmc").addClass("btn btn-success btn-sm active");
                        }, 0);
                        $scope.setSchemeAmc({ IsSchemeOrAmc: $scope.IsSchemeChecked });
                        
                        $scope.setAllInputData({ input: Input });
                    }
                };

                $scope.EntryextExpressionChanged = function ($event, indx) {
                    angular.element("#EntryExitExpression" + indx).html(angular.element($event.target).text() + ' <span class="caret"></span>');
                    angular.element("#EntryExitExpression" + indx).data('val', angular.element($event.target).data('val'));
                    $scope.EntryExit.Expression[indx] = angular.element($event.target).data('val');
                   
                    $scope.EntryExit.val[indx] = "";
                    //var Input = [];
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                   // Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType = $scope.EntryExit.LoadType;
                    //Input.selectRange.splice(indx, 1);
                    //Input.selectRange.push({
                    //    loadtype: $("#selectload" + indx).val(),
                    //    loadExpr: $scope.EntryExit.Expression[indx],
                    //    value: $("#txtentrextval" + indx).val(),
                    //    Fromvalue: $("#fromValue" + indx).val(),
                    //    Tovalue: $("#toValue" + indx).val()

                    //});
                    if (!angular.isUndefinedOrNullOrEmpty(Input.selectRange[indx])) {
                        //Input.selectRange.splice(indx, 1);
                        angular.forEach(Input.selectRange, function (value, key) {
                            if (indx == key) {
                                value.loadtype = $("#selectload" + indx).val();
                                value.loadExpr = !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx] : "" : "";
                                value.value = $("#txtentrextval" + indx).val();
                                value.Fromvalue = $("#fromValue" + indx).val();
                                value.Tovalue = $("#toValue" + indx).val();

                            }

                        });
                    }
                    else {
                        Input.selectRange.push({
                            loadtype: $("#selectload" + indx).val(),
                            loadExpr: $scope.EntryExit.Expression[indx],
                            value: $("#txtentrextval" + indx).val(),
                            Fromvalue: $("#fromValue" + indx).val(),
                            Tovalue: $("#toValue" + indx).val()
                        });
                    }
                    $scope.setAllInputData({ input: Input });

                };

                $scope.Loadtype = function (indx) {
                   // $scope.LoadType = loadtype;                   
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                    //Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType = $scope.EntryExit.LoadType;
                    if (!angular.isUndefinedOrNullOrEmpty(Input.selectRange[indx])) {
                        //Input.selectRange.splice(indx, 1);
                        angular.forEach(Input.selectRange, function (value, key) {
                            if (indx == key) {
                                value.loadtype = $("#selectload" + indx).val();
                                value.loadExpr = !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx] : "" : "";
                                value.value = $("#txtentrextval" + indx).val();
                                value.Fromvalue = $("#fromValue" + indx).val();
                                value.Tovalue = $("#toValue" + indx).val();
                         
                            }
                       
                        }); 
                    }
                    else {
                        Input.selectRange.push({
                            loadtype: $("#selectload" + indx).val(),
                            loadExpr: $scope.EntryExit.Expression[indx],
                            value: $("#txtentrextval" + indx).val(),
                            Fromvalue: $("#fromValue" + indx).val(),
                            Tovalue: $("#toValue" + indx).val()
                        });
                    }
                    //Input.selectRange.splice(indx, 1);
                    //Input.selectRange.push({
                    //    loadtype: $("#selectload"+indx ).val() ,
                    //    loadExpr: !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx]:"":"",
                    //    value: $("#txtentrextval" + indx).val(),
                    //    Fromvalue: $("#fromValue" + indx).val(),
                    //    Tovalue: $("#toValue" + indx).val()})
                    //Input.Expression = $scope.EntryExit.Expression;
                    //Input.LoadVal = $scope.EntryExit.val;
                    //Input.LoadFromVal = $scope.EntryExit.FromVal;
                    //Input.ToVal = $scope.EntryExit.ToVal;
                    $scope.setAllInputData({ input: Input });
                }
                $scope.SetLoadType = function (ldtype) {                   
                    $scope.EntryExit.LoadType= ldtype;
                   
                    if (ldtype == "Entry") {
                        angular.element("#lblEntry").removeClass("btn btn-success btn-sm");
                        angular.element("#lblEntry").addClass("btn btn-success btn-sm active");
                        angular.element("#lblExit").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblExit").addClass("btn btn-success btn-sm");
                        angular.element("#lblBoth").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblBoth").addClass("btn btn-success btn-sm");
                    }
                    else if (ldtype == "Exit") {
                        angular.element("#lblExit").removeClass("btn btn-success btn-sm");
                        angular.element("#lblExit").addClass("btn btn-success btn-sm active");
                        angular.element("#lblEntry").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblEntry").addClass("btn btn-success btn-sm");
                        angular.element("#lblBoth").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblBoth").addClass("btn btn-success btn-sm");
                    }
                    else {
                        angular.element("#lblBoth").removeClass("btn btn-success btn-sm");
                        angular.element("#lblBoth").addClass("btn btn-success btn-sm active");
                        angular.element("#lblExit").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblExit").addClass("btn btn-success btn-sm");
                        angular.element("#lblEntry").removeClass("btn btn-success btn-sm active");
                        angular.element("#lblEntry").addClass("btn btn-success btn-sm");
                    }
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                   // Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType= $scope.EntryExit.LoadType;
                    
                   
                    
                    //if (!angular.isUndefinedOrNullOrEmpty(Input.selectRange[indx])) {
                    //    //Input.selectRange.splice(indx, 1);
                    //    angular.forEach(Input.selectRange, function (value, key) {
                    //        if (indx == key) {
                    //            value.loadtype = $("#selectload" + indx).val();
                    //            value.loadExpr = !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx] : "" : "";
                    //            value.value = $("#txtentrextval" + indx).val();
                    //            value.Fromvalue = $("#fromValue" + indx).val();
                    //            value.Tovalue = $("#toValue" + indx).val();

                    //        }

                    //    });
                    //}
                    //else {
                    //    Input.selectRange.push({
                    //        loadtype: $("#selectload" + indx).val(),
                    //        loadExpr: $scope.EntryExit.Expression[indx],
                    //        value: $("#txtentrextval" + indx).val(),
                    //        Fromvalue: $("#fromValue" + indx).val(),
                    //        Tovalue: $("#toValue" + indx).val()
                    //    });
                    //}
                    $scope.setAllInputData({ input: Input });
                }
                $scope.SetDatechange = function () {
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                    // Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType = $scope.EntryExit.LoadType;
                    $scope.setAllInputData({ input: Input });
                }
                $scope.SetInputdata = function (indx) {
                    //var Input = [];

                  
                    Input.IsSI = $scope.EntryExit.IsSI;
                    Input.DateRange = $scope.EntryExit.DateRange;
                   // Input.ToDate = $scope.EntryExit.ToDate;
                    Input.LoadType = $scope.EntryExit.LoadType;
                    //if (!angular.isUndefinedOrNullOrEmpty(Input.selectRange[indx])) {
                    //    Input.selectRange.splice(indx, 1);
                    //}
                    //Input.selectRange.push({
                    //    loadtype: $("#selectload" + indx).val(),
                    //    loadExpr: !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx] : "" : "",
                    //    value: $("#txtentrextval" + indx).val(),
                    //    Fromvalue: $("#fromValue" + indx).val(),
                    //    Tovalue: $("#toValue" + indx).val()
                    //})

                    if (!angular.isUndefinedOrNullOrEmpty(Input.selectRange[indx])) {
                        //Input.selectRange.splice(indx, 1);
                        angular.forEach(Input.selectRange, function (value, key) {
                            if (indx == key) {
                                value.loadtype = $("#selectload" + indx).val();
                                value.loadExpr = !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression) ? !angular.isUndefinedOrNullOrEmpty($scope.EntryExit.Expression[indx]) ? $scope.EntryExit.Expression[indx] : "" : "";
                                value.value = $("#txtentrextval" + indx).val();
                                value.Fromvalue = $("#fromValue" + indx).val();
                                value.Tovalue = $("#toValue" + indx).val();

                            }

                        });
                    }
                    else {
                        Input.selectRange.push({
                            loadtype: $("#selectload" + indx).val(),
                            loadExpr: $scope.EntryExit.Expression[indx],
                            value: $("#txtentrextval" + indx).val(),
                            Fromvalue: $("#fromValue" + indx).val(),
                            Tovalue: $("#toValue" + indx).val()
                        });
                    }
                    $scope.setAllInputData({ input: Input });
                }


                $scope.AddLoadType = function () {
                   
                    if ($scope.LstLoadType.length < 2 && $scope.EntryExit.LoadType == "Both") {
                        $scope.index = $scope.index + 1;
                        $scope.LstLoadType.push({ Index: $scope.index, Loadtype: "", Expression: "", Val: "", FromVal: "", ToVal: "" })
                    }
                    else {
                        MFIMsg.AlertHtml("Can not add new row as load type selected " + $scope.EntryExit.LoadType, MFIAlertType.Information);
                        return false;
                    }
                }
                $scope.DeleteAttr = function (indx) {

                    if ($scope.LstLoadType.length == 2) {
                        Input.selectRange.splice(indx, 1);
                        $scope.LstLoadType.splice(indx, 1);
                    }
                }
                }
            }
     
    }]);