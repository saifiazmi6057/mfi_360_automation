
//var serviceFundDashboard = angular.module('serviceFundDashboard', ['SharedCommon']);

//SharedServices.config(BaseServiceConfig);

SharedServices.service('GetFinancialInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (fundLst,years,dataFor) {
        //alert(ApiInfo.BaseApiUrl);
        var data2push = { "MFFundIds": fundLst, "FinYear": years, "SelectedFinType": dataFor };

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAmcFinancial/GetAmcFinancialByFundYear',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(data2push),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAllFinancialYear', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        //alert(ApiInfo.BaseApiUrl);
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAmcFinancial/GetAllFinancialYear',
            method: 'GET'
        });
    }
}]);


/////  Excel Export //////

SharedServices.service('ExportDataToExcel', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {

    this.Call = function (dtLst, xlSname) {
        //alert(ApiInfo.BaseApiUrl);
        var data2push = { "xlsData": dtLst, "xlsName": xlSname };

        return $http({
            method: 'post',
            url: '/AmcFinancial/ExportToExcel',
            data: $httpParamSerializerJQLike(data2push),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }
}]);