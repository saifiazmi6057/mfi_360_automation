SharedServices.service('RemoveFundScreenerPageSelection', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/RemoveFundScreenerPageSelectionAdv'
            // headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    };
}]);

SharedServices.service('AllActiveSchimes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/AllActiveSchimesAdv',
            method: 'GET',
        });
    };
}]);

SharedServices.service('AllselectedSchimes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/AllselectedSchimes',
            method: 'GET',
        });
    };
}]);

SharedServices.service('GetRatingList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/GetRatingListAdv',
            method: 'GET',
        });
    }
}]);

SharedServices.service('GetAdvanceSearchParams', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl +'/ApiFundScreener/GetAdvanceSearchParamsAdv',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('SearchSchemesBasic', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/SearchSchemesBasicAdv',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('SearchSchemesAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    //debugger;
    this.Call = function (obj) {

        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/SearchSchemesAdvanceAdv',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('SearchSchemePageInitial', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Count,Isredeemed) {
       // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/SearchSchemePageInitialAdv?Count= ' + Count + "&Isredeemed=" + Isredeemed,
            method: 'GET',
           // data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetSchemesByName', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Str) {
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/GetSchemesByNameAdv?StrScheme=' + Str,
            method: 'GET',
            // data: $.param(obj)
        });
    }
}]);


SharedServices.service('GetSchemesByNameForRedeem', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Str) {
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/GetSchemesByNameForRedeem?StrScheme=' + Str,
            method: 'GET',
            // data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetFundsByName', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Str) {
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/GetFundsByNameAdv?StrFund=' + Str,
            method: 'GET',
            // data: $.param(obj)
        });
    };
}]);

SharedServices.service('PageSelectionFundScreener', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/PageSelectionFundScreenerAdv',
            method: 'POST'
            //data: $.param(obj)
        });
    };
}]);

SharedServices.service('SaveFundScreenerPageSelection', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/SaveFundScreenerPageSelectionAdv',
            method: 'POST',
            data: $.param(obj)
        });
    };
}]);

//PageSelectionFundScreener



//SharedServices.service('AppPeriodList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//    //debugger;
//    this.Call = function (IsApp) {

//        return $http({
//            url: ApiInfo.BaseApiUrl + 'ApiFundScreener/AppPeriodList',
//            method: 'POST',
//            data: $.param(IsApp)
//        });
//    }
//}]);