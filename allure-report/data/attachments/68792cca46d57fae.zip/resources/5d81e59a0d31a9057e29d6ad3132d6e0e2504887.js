SharedDeractives.directive('tooltipLoader', ['$http', function () {
    return function (scope, element, attrs) {
        element.tooltip({
            trigger: "hover",
            //placement: "top",
            delay: { show: 500, hide: 0 }
        });
    };
}]);
