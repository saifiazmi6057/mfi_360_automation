

SharedServices.service('getDailyAUMDateRange', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/getDailyAUMDateRange',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('GetAMCOrFundList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAMCOrFundList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAUMMonitorDetailsOnLoad', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAllAUMMonitorDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('GetAUMMonitorDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAUMMonitorDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetQAAUMMovementGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchQAAUMMovementGraphData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAAUMMovementGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAAUMMovementGraphData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAUMMovementGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAUMMovementGraphData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetDailyMovementGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchDailyMovementGraphData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAUMMonitorDashboardData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/FetchAUMMonitorDashboardData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);



SharedServices.service('GetAMFIStrutureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetAMFIStrutureList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            //dataType: "json"
        });
    }
}]);

SharedServices.service('GetAMFINatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetAMFINatureList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAUMPotfolioDates', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Years) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRating/GetAllPotfolioDates?Years=' + Years,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetAMFIAUMDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetAMFIAUMDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
/// Get NatureAA /////////////////////////////////////////////////////////////////////
SharedServices.service('GetNatureListAA', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetNatureListAA',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetT15B15FundCascading', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        var CatIdsInputEntity = {};
        CatIdsInputEntity.CatIds = obj;
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAumMonitorDetails/GetT15B15FundCascading',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(CatIdsInputEntity),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAUMFundList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // debugger;
    this.Call = function (AMCId, NatureId, SubNatureId, StructureIds, MFId, FundId, OptionId, StructureID) {
        //  debugger;
        var AMCIds = [];
        var ArrStructureId = [];
        var MFIds = [];
        // debugger;
        if (angular.isUndefinedOrNullOrEmpty(AMCId) == false) {
            AMCIds.push(AMCId);
        }
        if (angular.isUndefinedOrNullOrEmpty(StructureIds) == false) {
            //if (StructureIds != null && typeof (StructureIds) != undefined && StructureIds.length > 0) {
            ArrStructureId = StructureIds;
        }
        if (angular.isUndefinedOrNullOrEmpty(MFId) == false) {
            //if (MFId != null && typeof (MFId) != undefined) {
            //MFIds.push(MFId);
            MFIds = MFId;
        }
        var ViewFundInputEntity = {};
        ViewFundInputEntity.AMCId = AMCIds;
        ViewFundInputEntity.NatureId = NatureId;
        ViewFundInputEntity.SubNatureID = SubNatureId;
        ViewFundInputEntity.StructureIds = ArrStructureId;
        ViewFundInputEntity.MFId = MFIds;
        ViewFundInputEntity.FundId = FundId;
        //ViewFundInputEntity.StructureID = 2;
        ViewFundInputEntity.StructureID = StructureID;
        ViewFundInputEntity.OptionId = OptionId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FundList',
            data: $.param(ViewFundInputEntity),
            method: 'POST'
        });
    }
}]);