//var mdlFundDashboard = angular.module('mdlfundDashboard', []);

SharedDeractives.directive('dirAmcFinancialPL',
    ['MFIMsg', 'GetFinancialInfo',
        function (MFIMsg, GetFinancialInfo) {
            return {
                //restrict: 'E',
                scope: { amcList: "=", yearList: "=" },
                templateUrl: function (elem, attrs) {
                    // //
                    return "/AmcFinancial/GetPlsHTML"
                },
                controller: function ($scope, $http) {
                    //
                    $scope.AmcFinancialpL = "";
                    $scope.isPagedataExist = false;
                    $scope.NewsDetails = "";
                    $scope.AmcFpL = {};
                    /// for header
                    $scope.AmcFpLYearHeader = [];
                    $scope.AmcFpLFundNameHeader = [];

                    $scope.AmcFpLLineItemData = [];

                    $scope.AmcFpL.InfoLoader = true;

                    if ($scope.amcList.length > 0 && $scope.yearList.length > 0) {
                        var dtFinancialInfo = GetFinancialInfo.Call($scope.amcList, $scope.yearList, 0);
                        dtFinancialInfo.then(function (response) {
                            ////debugger;
                            var tempDt = response.data.data;
                            var tempArr = [];
                            var tempFundNm = [];


                            $scope.AmcFpL = tempDt;
                            tempDt.forEach(function (item, index) {
                                if (tempArr.indexOf(item.FinYear) == -1) {
                                    tempArr.push(item.FinYear);
                                    var getFunds = $.grep(tempDt, function (n, i) {
                                        return n.FinYear == item.FinYear;
                                    });

                                    getFunds.forEach(function (fitem, findex) {
                                        if (tempFundNm.indexOf(fitem.MFFundName) < 0) {
                                            tempFundNm.push(fitem.MFFundName);
                                            $scope.AmcFpLFundNameHeader.push({ "fname": fitem.MFFundName });
                                        }
                                    });

                                    $scope.AmcFpLYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                                }
                            });
                            console.log($scope.AmcFpLYearHeader);

                            var tempLineItem = [];
                            var HeaderItem = [];

                            tempDt.forEach(function (liItem, liIndex) {
                                var tempLineIVal = [];
                                /// setting up parent line item to push
                                //if (tempLineItem.indexOf(liItem.HeadderLineItem) == -1) {
                                //    tempLineItem.push(liItem.HeadderLineItem);
                                //};

                                /// setting up child line item to push
                                if (tempLineItem.indexOf(liItem.ChildLineItemName) == -1) {
                                    tempLineItem.push(liItem.ChildLineItemName);

                                    var lDataa = $.grep(tempDt, function (n, i) {
                                        return n.ChildLineItemName == liItem.ChildLineItemName;
                                    });

                                    lDataa.forEach(function (ditem, dindex) {
                                        tempLineIVal.push(ditem.ChildItemValue.toString());
                                    })
                                    if (HeaderItem.indexOf(liItem.HeadderLineItem) == -1) {

                                        HeaderItem.push(liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem);

                                        $scope.AmcFpLLineItemData.push({ "lIname": (liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem), dValue: [], className: "clsHDLineItem" });
                                    }
                                    $scope.AmcFpLLineItemData.push({ "lIname": liItem.ChildLineItemName, dValue: tempLineIVal, className: "clsLineItem" });
                                };

                                //$scope.AmcFpLYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                            });


                            $scope.AmcFpL.InfoLoader = false;
                            console.log($scope.AmcFpLLineItemData);


                        }, function (stu) {
                            MFIMsg.Alert("Error in fetching financial data for PL", "ICRA Analytics", "OK");
                            $scope.AmcFpL.InfoLoader = false;
                        });
                    }




                }
            }
        }
    ]);

SharedDeractives.directive('dirAmcFinancialBalenceSheet',
    ['MFIMsg', 'GetFinancialInfo',
        function (MFIMsg, GetFinancialInfo) {
            return {
                //restrict: 'E',
                scope: { amcList: "=", yearList: "=" },
                templateUrl: function (elem, attrs) {
                    // //
                    return "/AmcFinancial/GetBsHTML"
                },
                controller: function ($scope, $http) {
                    //
                    $scope.AmcFinancialBalenceSheet = "";
                    $scope.isPagedataExist = false;
                    $scope.NewsDetails = "";
                    $scope.AmcFBalenceSheet = {};
                    $scope.AmcFBalenceSheet.InfoLoader = true;

                    /// for header
                    $scope.AmcFBalenceSheetYearHeader = [];
                    $scope.AmcFBalenceSheetFundNameHeader = [];

                    $scope.AmcFBalenceSheetLineItemData = [];
                    $scope.AmcFin = {};
                    $scope.AmcFin.InfoLoader = true;

                    if ($scope.amcList.length > 0 && $scope.yearList.length > 0) {
                        var dtFinancialInfo = GetFinancialInfo.Call($scope.amcList, $scope.yearList, 1);
                        dtFinancialInfo.then(function (response) {
                            ////debugger;
                            var tempDt = response.data.data;
                            var tempArr = [];
                            var tempFundNm = [];


                            $scope.AmcFpL = tempDt;
                            tempDt.forEach(function (item, index) {
                                if (tempArr.indexOf(item.FinYear) == -1) {
                                    tempArr.push(item.FinYear);
                                    var getFunds = $.grep(tempDt, function (n, i) {
                                        return n.FinYear == item.FinYear;
                                    });

                                    getFunds.forEach(function (fitem, findex) {
                                        if (tempFundNm.indexOf(fitem.MFFundName) < 0) {
                                            tempFundNm.push(fitem.MFFundName);
                                            $scope.AmcFBalenceSheetFundNameHeader.push({ "fname": fitem.MFFundName });
                                        }
                                    });

                                    $scope.AmcFBalenceSheetYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                                }
                            });


                            var tempLineItem = [];
                            var HeaderItem = [];

                            tempDt.forEach(function (liItem, liIndex) {
                                var tempLineIVal = [];
                                /// setting up parent line item to push
                                //if (tempLineItem.indexOf(liItem.HeadderLineItem) == -1) {
                                //    tempLineItem.push(liItem.HeadderLineItem);
                                //};

                                /// setting up child line item to push
                                if (tempLineItem.indexOf(liItem.ChildLineItemName) == -1) {
                                    tempLineItem.push(liItem.ChildLineItemName);

                                    var lDataa = $.grep(tempDt, function (n, i) {
                                        return n.ChildLineItemName == liItem.ChildLineItemName;
                                    });

                                    lDataa.forEach(function (ditem, dindex) {
                                        tempLineIVal.push(ditem.ChildItemValue.toString());
                                    })
                                    if (HeaderItem.indexOf(liItem.HeadderLineItem) == -1) {

                                        HeaderItem.push(liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem);

                                        $scope.AmcFBalenceSheetLineItemData.push({ "lIname": (liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem), dValue: [], className: "clsHDLineItem" });
                                    }
                                    $scope.AmcFBalenceSheetLineItemData.push({ "lIname": liItem.ChildLineItemName, dValue: tempLineIVal, className: "clsLineItem" });
                                };

                                //$scope.AmcFpLYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                            });


                            $scope.AmcFin.InfoLoader = false;
                            console.log($scope.AmcFBalenceSheetLineItemData);


                        }, function (stu) {
                            MFIMsg.Alert("Error in fetching financial data for balance sheet", "ICRA Analytics", "OK");
                            $scope.AmcFin.InfoLoader = false;
                        });
                    }


                }
            }
        }
    ]);

SharedDeractives.directive('dirAmcFinancialRatio',
    ['MFIMsg', 'GetFinancialInfo',
        function (MFIMsg, GetFinancialInfo) {
            return {
                //restrict: 'E',
                scope: { amcList: "=", yearList: "=" },
                templateUrl: function (elem, attrs) {
                    // //
                    return "/AmcFinancial/GetRatioHTML"
                },
                controller: function ($scope, $http) {
                    //
                    $scope.AmcFinancialRatio = "";
                    $scope.isPagedataExist = false;
                    $scope.NewsDetails = "";
                    $scope.AmcFRatio = {};
                    $scope.AmcFRatio.InfoLoader = true;


                    /// for header
                    $scope.AmcFRatioYearHeader = [];
                    $scope.AmcFRatioFundNameHeader = [];

                    $scope.AmcFRatioLineItemData = [];

                    if ($scope.amcList.length > 0 && $scope.yearList.length > 0) {
                        var dtFinancialInfo = GetFinancialInfo.Call($scope.amcList, $scope.yearList, 2);
                        dtFinancialInfo.then(function (response) {
                            ////debugger;
                            var tempDt = response.data.data;
                            var tempArr = [];
                            var tempFundNm = [];


                            $scope.AmcFpL = tempDt;
                            tempDt.forEach(function (item, index) {
                                if (tempArr.indexOf(item.FinYear) == -1) {
                                    tempArr.push(item.FinYear);
                                    var getFunds = $.grep(tempDt, function (n, i) {
                                        return n.FinYear == item.FinYear;
                                    });

                                    getFunds.forEach(function (fitem, findex) {
                                        if (tempFundNm.indexOf(fitem.MFFundName) < 0) {
                                            tempFundNm.push(fitem.MFFundName);
                                            $scope.AmcFRatioFundNameHeader.push({ "fname": fitem.MFFundName });
                                        }
                                    });

                                    $scope.AmcFRatioYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                                }
                            });


                            var tempLineItem = [];
                            var HeaderItem = [];

                            tempDt.forEach(function (liItem, liIndex) {
                                var tempLineIVal = [];
                                /// setting up parent line item to push
                                //if (tempLineItem.indexOf(liItem.HeadderLineItem) == -1) {
                                //    tempLineItem.push(liItem.HeadderLineItem);
                                //};

                                /// setting up child line item to push
                                if (tempLineItem.indexOf(liItem.ChildLineItemName) == -1) {
                                    tempLineItem.push(liItem.ChildLineItemName);

                                    var lDataa = $.grep(tempDt, function (n, i) {
                                        return n.ChildLineItemName == liItem.ChildLineItemName;
                                    });

                                    lDataa.forEach(function (ditem, dindex) {
                                        tempLineIVal.push(ditem.ChildItemValue.toString());
                                    })
                                    if (HeaderItem.indexOf(liItem.HeadderLineItem) == -1) {

                                        HeaderItem.push(liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem);

                                        $scope.AmcFRatioLineItemData.push({ "lIname": (liItem.HeadderLineItem == null ? "No Header" : liItem.HeadderLineItem), dValue: [], className: "clsHDLineItem" });
                                    }
                                    $scope.AmcFRatioLineItemData.push({ "lIname": liItem.ChildLineItemName, dValue: tempLineIVal, className: "clsLineItem" });
                                };

                                //$scope.AmcFpLYearHeader = [{ "year": item.FinYear, "spans": tempFundNm.length, "fundNames": tempFundNm }];

                            });



                            console.log($scope.AmcFRatioLineItemData);
                            $scope.AmcFRatio.InfoLoader = false;


                        }, function (stu) {
                            MFIMsg.Alert("Error in fetching financial data for Ratio", "ICRA Analytics", "OK");
                            $scope.AmcFRatio.InfoLoader = false;
                        });

                    }


                }
            }
        }
    ]);
