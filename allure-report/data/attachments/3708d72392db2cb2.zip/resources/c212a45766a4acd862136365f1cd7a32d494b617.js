SharedServices.service('GetAUM', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetAUM?StrState=' + obj,
            method: 'GET',
        });
    }
}]);
SharedServices.service('GetAllAAUM', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetAllAAUM',
            method: 'POST',
            data: $.param(obj)

        });
    }
}]);

SharedServices.service('GetStateWiseAAUM', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetStateWiseAAUM',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetCityGroupWiseAAUM', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetCityGroupWiseAAUM',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('PostStateWithCategoryWiseAAUM', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/PostStateWithCategoryWiseAAUM',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetAumSummery', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetAumSummery',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('GetAAUMPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAverageAum/GetAAUMPeriod',
            method: 'GET',
        });
    }
}]);