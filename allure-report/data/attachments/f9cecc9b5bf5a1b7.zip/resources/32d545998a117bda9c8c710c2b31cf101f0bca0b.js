SharedServices.service('GetAllCompositeIndexRec', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllCompositeIndexSettings',
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostModifyCompositeIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostModifyCompositeIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostSearchCompositeIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostSearchCompositeIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostDeleteCompositeIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostDeleteCompositeIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostCompositeIndexDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostCompositeIndexDetailRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostAddCompositeIndexDetailRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCompositeIndexDetailRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostAddCompositeIndexRecord', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCompositeIndexRecord',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);