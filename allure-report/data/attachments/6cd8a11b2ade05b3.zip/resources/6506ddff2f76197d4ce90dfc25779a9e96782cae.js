SharedServices.service('ChnageSchemeCode', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/ChnageSchemeCode',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetAllCompositeSchSettings', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetAllCompositeSch',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetSchemeSetByName', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetSchemeSetByName',
            method: 'GET'
        });
    }
}]);

SharedServices.service('SchemeSetData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/SchemeSetData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('SearchSchemeCodeBysearchText', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/SearchSchemeCodeBysearchText',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('ChnageSchemeCode', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/ChnageSchemeCode',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('CheckSchemeSetNameExists', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/CheckSchemeSetNameExists',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('CreateSchemeSetDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/CreateSchemeSetDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('DeleteSchemeSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/CompositeSchemeSetDelete',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('IsAccessibleforActiveuser', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonData/IsApplicableForAdvancefeature',
            method: 'GET'
        });
    }
}]);