SharedServices.service('ForwardLookingYesService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetForwardLookingData',
            method: 'GET'
        });
    }
}]);

SharedServices.service('PortfolioOptimizationInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PortfolioOptimizationData',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('PostDeleteSelectedSchemeList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PostDeleteSelectedSchemeList',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetListSaveSets', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetListSaveSets',
        });
    }
}]);

///Risklist
SharedServices.service('GetRisklist', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetAllRiskType',
        });
    }
}]);
///End Risklist

SharedServices.service('PostDeleteParamDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetDeleteParamDetails?ParamId=' + obj,
            //data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetFundDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetFundDetails?ParamId=' + obj,
            //data: $.param(obj)
        });
    }
}]);

SharedServices.service('PostParamDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PostParamDetails',
            data: $.param(obj)
        });
    }
}]);

//SharedServices.service('RemoveUserParameterSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (obj) {
//        return $http({
//            method: "get",
//            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/PostDeleteSelectedSchemeList'
//        });
//    }

//}]);
//SharedServices.service('GetSchemeCodes', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiMFIUrl + 'ApiCommonExplorer/FetchSchemeCodes',
//            data: $.param(obj),
//            dataType: "json"
//        });
//    }
//}]);


SharedServices.service('ptoptimizationFundDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FetchFundDetails',
            method: 'POST',
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('GetParamlistDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiPTOOptimization/GetParamDetails',
            params: obj
        });
    }
}]);
//SharedServices.service('GetSchemeObjective', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (SchemeId) {
//        return $http({
//            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSchemeObjective?SchemeId=' + SchemeId,//+ '&LoginId=' + LoginId,
//            method: 'GET'
//        });
//    }
//}]);


///// Get AMC /////////////////////////////////////////////////////////////////
SharedServices.service('GetIssuer', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFMasterList',
            //data: $.param(obj),
            method: 'GET'
        });
    }
}]);
/// Get Nature /////////////////////////////////////////////////////////////////////
SharedServices.service('GetNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetNatureList',
            //url: '',
            method: 'GET'
        });
    }

}]);
////// Get subnature ///////////////////////////////////////////////////////////////
SharedServices.service('SubNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrNatureID) {
        var obj = {};
        if (ArrNatureID == undefined) {
            // obj.ArrNatureID = null;
        }
        else {
            obj.ArrNatureID = ArrNatureID;
        }
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/SubNatureList',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

//// Get Fund /////////////////////////////////////////////////////////////////////
SharedServices.service('GetFundList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // debugger;
    this.Call = function (AMCId, NatureId, SubNatureId, StructureIds, MFId, FundId, OptionId, StructureID) {

        var AMCIds = [];
        var ArrStructureId = [];
        var MFIds = [];
        if (angular.isUndefinedOrNullOrEmpty(AMCId) == false) {
            AMCIds.push(AMCId);
        }
        if (angular.isUndefinedOrNullOrEmpty(StructureIds) == false) {
            //if (StructureIds != null && typeof (StructureIds) != undefined && StructureIds.length > 0) {
            ArrStructureId = StructureIds;
        }
        if (angular.isUndefinedOrNullOrEmpty(MFId) == false) {
            //if (MFId != null && typeof (MFId) != undefined) {
            //MFIds.push(MFId);
            MFIds = MFId;
        }
        var ViewFundInputEntity = {};
        //ViewFundInputEntity.AMCId = null;
        //ViewFundInputEntity.NatureId = NatureId;
        //ViewFundInputEntity.SubNatureID = SubNatureId;
        ViewFundInputEntity.NatureId = "";
        ViewFundInputEntity.NatureIDList = NatureId;
        ViewFundInputEntity.SubNatureID = "";
        ViewFundInputEntity.SubNatureIDList = SubNatureId;
        ViewFundInputEntity.StructureIds = StructureIds;
        ViewFundInputEntity.MFId = MFId;
        ViewFundInputEntity.FundId = FundId;
        ViewFundInputEntity.StructureID = 2;
        //ViewFundInputEntity.StructureID = StructureID;
        ViewFundInputEntity.OptionId = OptionId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FundList',
            data: $.param(ViewFundInputEntity),
            method: 'POST'
        });
    }
}]);

SharedServices.service('SearchSchemesBasic', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiFundScreener/SearchSchemesBasic',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);