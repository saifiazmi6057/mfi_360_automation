//angular.module('customIndexDirective', [])
SharedDeractives.directive('customIndex', ['$timeout', '$q', '$log', 'ApiInfo', '$http', '$filter', '$window', 'GetAllCustomIndexSettings', 'PostAddCustomIndexRecord', 'PostModifyCustomIndexRecord', 'PostDeleteCustomIndexRecord', 'PostCustomIndexRecord', 'PostDeleteCustomIndexDetailRecord', 'PostSearchCustomIndexRecord', 'PostAddCustomIndexDetailRecord', 'MFIMsg', 'FetchCustomIndexTemplate', 'GetUserListByClientID','PostModificationPermission',
    function ($timeout, $q, $log, ApiInfo, $http, $filter, $window, GetAllCustomIndexSettings, PostAddCustomIndexRecord, PostModifyCustomIndexRecord, PostDeleteCustomIndexRecord, PostCustomIndexRecord, PostDeleteCustomIndexDetailRecord, PostSearchCustomIndexRecord, PostAddCustomIndexDetailRecord, MFIMsg, FetchCustomIndexTemplate, GetUserListByClientID, PostModificationPermission) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '=',
                userListModel: '=?',
                userSetSettings: '=?',
                options: '=',
            },
            replace: false,
            templateUrl: '/Home/CustomIndex',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    //$scope.names = BasModelcustomindex;
                    $scope.CustIndMaster = true;
                    $scope.CustIndDetail = false;
                    $scope.ShowCusINdex = false;
                    $scope.ShowMulCusIndex = false;
                    $scope.AddCust = false;
                    $scope.ImpVal = false;
                    $scope.ShowMulImp = false;
                    $scope.EditVal = false;
                    $scope.AssignPer = false;
                    $scope.selId = '';
                    $scope.LstselId = [];
                    $scope.CustomIndexName = '';
                    $scope.LstCustomIndexName = [];
                    $scope.MulCusIndexHeader = [];
                    $scope.indexType = 'gen';
                    $scope.LoaderCommonCustomIndex = true;
                    $scope.LoaderImportIndex = false;
                    $scope.CusIndDetailDateRange = null;
                    $scope.hdCreate = false;
                    $scope.IsErrorInExcel = false;
                    $scope.IsUserListShown = true;
                    $scope.HisMultiYearModel = [];
                    $scope.ShowUserList = false;
                    $scope.SetPermissionBtn = true;
                    //var lstSelCusIndDetail = [];
                    var OptionsDateRange = {
                        showDropdowns: true,
                        autoApply: true,
                        locale: {
                            format: 'DD MMM YYYY'
                        }
                    };

                    if (!$scope.userSetSettings) {
                        $scope.userSetSettings = {
                            scrollableHeight: '237px',
                            scrollable: true,
                            enableSearch: true,
                            appendToBody : true,
                            ddltext: "User list",
                            Keyprop: "loginID",
                            Valueprop: "EmailID"
                        };
                    }

                    if (!$scope.userListModel) {
                        $scope.userListModel = [];
                    }

                    $scope.initialUserListModel = []

                    function ApplyDateRange(start, end, label) {
                        //if (angular.isDefined($scope.CusIndDetailDateRange) && $scope.CusIndDetailDateRange != null) {
                        //var ArrDateObj = $scope.CusIndDetailDateRange.split(' - ');
                        //ReturnFromDate = ArrDateObj[0];
                        //ReturnToDate = ArrDateObj[1];
                        $scope.CusDetFromDate = $filter('date')(new Date(start._d), 'dd MMM yyyy');// ArrDateObj[0];//new Date(start);
                        $scope.CusDetToDate = $filter('date')(new Date(end._d), 'dd MMM yyyy'); // ArrDateObj[1];//new Date(end);
                        //}
                        ViewDetRec();
                    }
                    angular.element('#CusIndFromToDateRange').daterangepicker(OptionsDateRange, ApplyDateRange);
                    //var ratingSetParam = { "LogInId": 1 };

                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await GetAllCustomIndexSettings.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('GetAllCustomIndexSettings', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function GetAllCustIndexData() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('GetAllCustomIndexSettings');
                        //if (data) {
                        //    // Parse and return the data from LocalStorage
                        //    return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//


                    var GetAllCustIndex = function () {
                        //var AllCustIndex = GetAllCustomIndexSettings.Call();
                        lstSelCusInd = [];
                        GetAllCustIndexData().then(function (response) {
                            if (response != null) {
                                //$scope.names = response.data.data;
                                $timeout(function () {
                                    $scope.names = response;
                                    $scope.LoaderCommonCustomIndex = false;
                                }, 10);
                                //$scope.LoaderRatingSearch = false;
                            }
                        },
                            function (stu) {
                                $scope.LoaderCommonCustomIndex = false;
                                //$scope.LoaderRatingSearch = false;
                                MFIMsg.AlertHtml("Fail to load data", MFIAlertType.Information);
                            });
                    }

                    GetAllCustIndex();

                    $scope.DeleteIndex = function (idSelected, selName) {
                        MFIMsg.Confirm("You want to delete '" + selName + "'?", "MFI360 Explorer", "Ok", "Cancel").then(function successCallback(response) {
                            //MFIMsg.Confirm("<h3 class='text-center'>Are you sure? </h3> You want to delete '" + selName + "' !!!", "MFI360", "Ok", "Cancel").then(function successCallback(response) {
                            var objDelCustomIndex = {
                                "CustomIndexId": idSelected
                            };
                            $scope.LoaderCommonCustomIndex = true;
                            var deleteIndex = PostDeleteCustomIndexRecord.Call(objDelCustomIndex);
                            deleteIndex.then(function (response) {
                                if (response.data.data) {
                                    localStorage.removeItem('GetAllCustomIndexSettings');
                                    GetAllCustIndex();
                                    $scope.LoaderCommonCustomIndex = false;
                                    //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                                    MFIMsg.AlertHtml("Data deleted sucessfully", MFIAlertType.Success);
                                }
                                else {
                                    $scope.LoaderCommonCustomIndex = false;
                                    MFIMsg.AlertHtml(response.data.Message != null ? response.data.Message : "Cannot delete data", MFIAlertType.Information);
                                }
                            },
                                function errorCallback(response) {
                                    $scope.LoaderCommonCustomIndex = false;
                                    MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                                });
                        });
                    };

                    $scope.ModifyTableIndex = function (idSelected, selName) {
                        $scope.selId = idSelected;
                        $scope.CustomIndexName = selName;
                        //$scope.names.selected = angular.copy(idSelected);
                        $scope.EditVal = true;
                        $scope.AddCust = false;
                        $scope.AssignPer = false;
                    };

                    $scope.ModifyIndex = function () {
                        if ($scope.CustomIndexName == "") {
                            MFIMsg.AlertHtml("Please enter custom index name", MFIAlertType.Information);
                            return false;
                        }
                        var objCustomIndexMaster = {
                            "CustomIndexId": $scope.selId, "CustomIndexName": $scope.CustomIndexName
                        };
                        var ModifyIndex = PostModifyCustomIndexRecord.Call(objCustomIndexMaster);
                        ModifyIndex.then(function (response) {
                            if (response.data.data) {
                                localStorage.removeItem('GetAllCustomIndexSettings');
                                GetAllCustIndex();
                                $scope.EditVal = false;
                                //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                                MFIMsg.AlertHtml("Data saved successfully", MFIAlertType.Information);
                                $scope.searchIndexName = "";
                            }
                            else
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.reset = function () {
                        //$scope.names.selected = {};
                        //$scope.names.IsImport = false;
                        $scope.ImpVal = false;
                        $scope.ShowMulImp = false;
                        $scope.searchIndexName = "";
                    };

                    $scope.resetEdit = function () {
                        //$scope.names.selected = {};
                        //$scope.names.IsImport = false;
                        $scope.EditVal = false;
                        $scope.searchIndexName = "";
                    };

                    $scope.ViewDetailRecords = function (idSelected) {
                        $scope.CusIndexRecords = [];
                        $scope.LstselId = [];
                        $scope.CustIndMaster = false;
                        $scope.CustIndDetail = true;
                        $scope.ShowCusINdex = true;
                        $scope.ShowMulCusIndex = false;
                        $scope.selId = idSelected;
                        $scope.CusDetFromDate = null;
                        $scope.CusDetToDate = null;
                        $scope.CusIndDetailDateRange = null;
                        $scope.IsAllCusIndDetChecked = false;
                        $scope.IsAllCusIndChecked = false;
                        ViewDetRec();
                        //$("#myModalCustomIndex").show();
                    };

                    $scope.tempCusIndexRecords = [];
                    $scope.loadMore = function () {
                        if ($scope.CusIndexRecords.length > 200) {
                            var last = $scope.tempCusIndexRecords.length - 1;
                            var Count = $scope.CusIndexRecords.length < 200 ? $scope.CusIndexRecords.length : 200;
                            for (var i = 1; i <= Count; i++) {
                                $scope.tempCusIndexRecords.push($scope.CusIndexRecords[last + i]);
                            }
                        }
                        else {
                            $scope.tempCusIndexRecords = [...$scope.CusIndexRecords];
                        }
                        
                    }

                    var ViewDetRec = function () {
                        var objViewCustomIndex = {
                            "CustomIndexId": $scope.selId, "FromDate": $scope.CusDetFromDate, "ToDate": $scope.CusDetToDate, "LstCustomIndexId": $scope.LstselId
                        };
                        $scope.LoaderCommonCustomIndexDetail = true;
                        var viewIndex = PostCustomIndexRecord.Call(objViewCustomIndex);
                        viewIndex.then(function (response) {
                            //$scope.CustIndMaster = false;
                            //$scope.CustIndDetail = true;
                            $scope.LoaderCommonCustomIndexDetail = false;
                            if (response.data != null) {
                                $scope.CusIndexRecords = response.data.data;
                                $scope.loadMore();
                            }
                            //debugger;
                            //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                            //alert("Data deleted successfully !!!");
                        },
                            function errorCallback(response) {
                                $scope.LoaderCommonCustomIndexDetail = false;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    }


                    $scope.MultipleViewDetailRecords = function () {
                        if (lstSelCusInd.length <= 0) {
                            MFIMsg.AlertHtml("Please select index to view.", MFIAlertType.Information);
                            return;
                        }
                        $scope.CusIndexRecords = [];
                        $scope.CustIndMaster = false;
                        $scope.CustIndDetail = true;
                        $scope.ShowCusINdex = false;
                        $scope.ShowMulCusIndex = true;
                        $scope.selId = null;
                        $scope.LstselId = [];
                        $scope.MulCusIndexHeader = [];
                        $scope.MulCusIndexHeader.push("Record Date");
                        angular.forEach(lstSelCusInd, function (value) {
                            $scope.LstselId.push(value.CustomIndexId);
                            $scope.MulCusIndexHeader.push(value.CustomIndexName);
                        });
                        //$scope.selId = $scope.LstselId;
                        $scope.CusDetFromDate = null;
                        $scope.CusDetToDate = null;
                        $scope.CusIndDetailDateRange = null;
                        $scope.IsAllCusIndDetChecked = false;
                        $scope.IsAllCusIndChecked = false;
                        ViewDetRec();
                        //$("#myModalCustomIndex").show();
                    };


                    $scope.AddNewIndexRecord = function () {
                        if (angular.isUndefinedOrNullOrEmpty($scope.NewCustomIndexName)) {
                            MFIMsg.AlertHtml("Please enter custom index name", MFIAlertType.Information);
                            return;
                        }

                        var CustomIndexMaster = {
                            "CustomIndexName": $scope.NewCustomIndexName, "strIndexType": $scope.indexType
                        };
                        var AddCustIndex = PostAddCustomIndexRecord.Call(CustomIndexMaster);
                        AddCustIndex.then(function (response) {
                            if (response.data.data) {
                                localStorage.removeItem('GetAllCustomIndexSettings');
                                GetAllCustIndex();
                                $scope.NewCustomIndexName = "";
                                $scope.AddCust = false;
                                MFIMsg.AlertHtml("Index created successfully", MFIAlertType.Information);
                                $scope.hdCreate = false;
                                $scope.searchIndexName = "";
                                //$scope.LoaderRatingSearch = false;
                            }
                            else
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.ImportIndex = function (file) {
                        //var formData = new FormData();
                        //var files = $scope.file;
                        //if (files != null) {
                        //    formData.append("UploadedFile", files);
                        //}
                        //formData.append("CustomIndexId", $scope.selId);
                        //angular.forEach(files, function (key, value) {
                        //    formData.append(key, value);
                        //});, 
                        if ($scope.file == null) {
                            MFIMsg.AlertHtml("Please select a file", MFIAlertType.Information);
                            return;
                        }
                        var data = { "CustomIndexId": $scope.selId, "ObjFile": $scope.file };
                        //var data = formData;
                        angular.element("input[type='file']").val(null);
                        $scope.LoaderImportIndex = true;
                        $http({
                            method: "POST",
                            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexDetailRecord',
                            headers: { 'Content-Type': undefined },
                            transformRequest: function (data, headersGetter) {
                                var formData = new FormData();
                                angular.forEach(data, function (value, key) {
                                    formData.append(key, value);
                                });
                                //var headers = headersGetter();
                                //delete headers['Content-Type'];
                                return formData;
                            },
                            data: { "CustomIndexId": $scope.selId, "files": $scope.file }
                            //dataType: 'json',
                            //contentType: false,
                            //processData: false
                            //files: obj.ObjFile,
                            //data: {"CustomIndexId":obj.CustomIndexId}
                            //data: $.param(obj)
                            //dataType: "json"
                        }).then(function (response) {
                            if (response.data.data) {
                                $scope.LoaderImportIndex = false;
                                $scope.file = null;
                                MFIMsg.AlertHtml("Data uploaded successfully", MFIAlertType.Information);
                                $scope.reset();
                            }
                            else {
                                $scope.LoaderImportIndex = false;
                                $scope.file = null;
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                            }
                        },
                            function errorCallback(response) {
                                $scope.LoaderImportIndex = false;
                                $scope.file = null;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });

                        //var fileCall = PostAddCustomIndexDetailRecord.Call(data);
                        //fileCall.then(function (response) {
                        //    MFIMsg.Alert("Data uploaded successfully !!!"); debugger;
                        //    $scope.reset();
                        //},
                        //    function errorCallback(response) {
                        //        MFIMsg.Alert("Oops, an error occurred !!!");
                        //    });

                        //$http({
                        //    url: "/Benchmark/ImportCustomIndex",
                        //    method: "POST",
                        //    headers: {
                        //        //'Content-Type': 'multipart/form-data'
                        //        'Content-Type': undefined
                        //    },
                        //    transformRequest: function (data, headersGetter) {
                        //        var formData = new FormData();
                        //        angular.forEach(data, function (value, key) {
                        //            formData.append(key, value);
                        //        });
                        //        //var headers = headersGetter();
                        //        //delete headers['Content-Type'];
                        //        return formData;
                        //    },
                        //    data: { "id": JSON.stringify($scope.selId), "files": file }
                        //    //datatype: "json",
                        //    //data: fileData
                        //}).then(function successCallback(response) {
                        //    $scope.reset();
                        //    //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                        //    MFIMsg.Alert("Data uploaded successfully !!!");
                        //},
                        //    function errorCallback(response) {
                        //        MFIMsg.Alert("Oops, an error occurred !!!");
                        //    });
                    };


                    $scope.ImportMultipleIndex = function (file) {
                        //if (lstSelCusInd.length == 0) {
                        //    MFIMsg.AlertHtml("Please select Custom index", MFIAlertType.Information);
                        //    return;
                        //}
                        if ($scope.file == null) {
                            MFIMsg.AlertHtml("Please select a file", MFIAlertType.Information);
                            return;
                        }
                        $scope.LstselId = [];
                        $scope.LstCustomIndexName = [];
                        angular.forEach(lstSelCusInd, function (value) {
                            $scope.LstselId.push(value.CustomIndexId);
                            $scope.LstCustomIndexName.push(value.CustomIndexName);
                        });
                        var data = { "LstCustomIndexId": $scope.LstselId, "LstCustomIndexName": $scope.LstCustomIndexName, "ObjFile": $scope.file };
                        //var data = formData;
                        angular.element("input[type='file']").val(null);
                        $scope.LoaderImportIndex = true;
                        $http({
                            method: "POST",
                            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddMultipleCustomIndexDetailRecord',
                            headers: { 'Content-Type': undefined },
                            transformRequest: function (data, headersGetter) {
                                var formData = new FormData();
                                angular.forEach(data, function (value, key) {
                                    formData.append(key, value);
                                });
                                return formData;
                            },
                            data: { "LstCustomIndexId": $scope.LstselId, "LstCustomIndexName": $scope.LstCustomIndexName, "files": $scope.file }

                        }).then(function (response) {
                            if (response.data.data) {
                                $scope.LoaderImportIndex = false;
                                $scope.IsErrorInExcel = false;
                                $scope.file = null;
                                MFIMsg.AlertHtml("Data uploaded successfully", MFIAlertType.Information);
                                $scope.reset();
                            }
                            else {
                                $scope.LoaderImportIndex = false;
                                if (response.data.Message == "Incorrect format, Please Download Error Excel for more details...")
                                    $scope.IsErrorInExcel = true;
                                $scope.file = null;
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                            }
                        },
                            function errorCallback(response) {
                                $scope.LoaderImportIndex = false;
                                $scope.file = null;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.goBack = function () {
                        $scope.CustIndMaster = true;
                        $scope.CustIndDetail = false;
                        $scope.ShowCusINdex = false;
                        $scope.ShowMulCusIndex = false;
                        $scope.IsErrorInExcel = false;
                        $scope.AssignPer = false;
                        $scope.SetPermissionBtn = true;
                        angular.forEach(lstSelCusInd, function (value) {
                            value.IsChecked = false;
                        });
                        lstSelCusInd = [];
                        $scope.tempCusIndexRecords = [];
                    };

                    $scope.ImportEdit = function (idSelected, selName) {
                        //debugger;
                        $scope.selId = idSelected;
                        $scope.CustomIndexName = selName;
                        //$scope.names.IsImport = true;
                        //$scope.names.selected = angular.copy(idSelected);
                        $scope.ShowMulImp = false;
                        $scope.ImpVal = true;
                    };
                    $scope.onUserSelectionChanged = function () {
                        //$scope.SetPermissionBtn = !$scope.userListModel;
                        if ($scope.initialUserListModel.length !== $scope.userListModel.length) {
                            $scope.SetPermissionBtn = false;
                        }
                        // Compare by loginID (or your unique key)
                        var initialIds = $scope.initialUserListModel.map(u => u.loginID).sort();
                        var currentIds = $scope.userListModel.map(u => u.loginID).sort();
                        var Enable = angular.equals(initialIds, currentIds);
                        $scope.SetPermissionBtn = Enable;
                    };

                    $scope.AssignPermission = function () {
                        $scope.AddCust = false;
                        $scope.hdCreate = false;
                        $scope.EditVal = false;
                        $scope.AssignPer = true;
                        $scope.SetPermissionBtn = true;
                        var userList = GetUserListByClientID.Call();
                        userList.then(function (response) {
                            if (response.data != null) {
                                $scope.UserList = response.data.data;
                                $scope.ShowUserList = true;
                                // Assuming UserList is already populated
                                $scope.userListModel = $scope.UserList.filter(function (user) {
                                    return user.IsChecked === true;
                                });

                                $scope.initialUserListModel = angular.copy($scope.userListModel);
                            }
                            else {
                                MFIMsg.AlertHtml("No user found", MFIAlertType.Information);
                            }
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.SetModificationPermission = function () {
                        var selectedUsers = [];
                        angular.forEach($scope.userListModel, function (value, key) {
                            selectedUsers.push(value.loginID);
                        });
                        //if (selectedUsers.length == 0) {
                        //    MFIMsg.AlertHtml("Please select user", MFIAlertType.Information);
                        //    return;
                        //}
                        var objPermission = {
                            "loginIDlst": selectedUsers
                        };
                        var setPermission = PostModificationPermission.Call(objPermission);
                        setPermission.then(function (response) {
                            if (response.data.data) {
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                                $scope.AssignPer = false;
                                /*$scope.ShowUserList = false;*/
                            }
                            else {
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                                $scope.AssignPermission();
                            }
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });

                    }

                    $scope.AddIndex = function () {
                        $scope.AddCust = true;
                        $scope.hdCreate = true;
                        $scope.EditVal = false;
                        $scope.AssignPer = false;
                        //$("#AddNewCustId").hide();
                    };

                    $scope.ExitIndex = function () {
                        //$("#AddCustId").hide();
                        //$("#AddNewCustId").show();
                        $scope.AddCust = false;
                        $scope.hdCreate = false;
                        $scope.searchIndexName = "";
                    };

                    $scope.ExitAssign = function () {
                        $scope.AssignPer = false;
                    };

                    $scope.MultipleImport = function () {
                        $scope.ShowMulImp = true;
                        $scope.ImpVal = false;
                    };

                    $scope.searchIndex = function () {
                        if ($scope.searchIndexName == "") {
                            MFIMsg.AlertHtml("Please enter custom index name", MFIAlertType.Information);
                            return false;
                        }
                        $scope.LoaderCommonCustomIndex = true;
                        $scope.IsErrorInExcel = false;
                        var searchName = { "CustomIndexName": $scope.searchIndexName };
                        var searchIndex = PostSearchCustomIndexRecord.Call(searchName);
                        searchIndex.then(function (response) {
                            $scope.names = response.data.data;
                            $scope.LoaderCommonCustomIndex = false;
                            //alert("Data saved successfully !!!");
                        },
                            function errorCallback(response) {
                                $scope.LoaderCommonCustomIndex = false;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    //$scope.DeleteIndexDetailRecord = function (CustDetailRec) {
                    //    debugger;
                    //    var objDelDetIndex = {
                    //        "CustomIndexId": CustDetailRec.CustomIndexId, "RecordDate": CustDetailRec.RecordDate
                    //    };
                    //    var delDetIndex = PostDeleteCustomIndexDetailRecord.Call(objDelDetIndex);
                    //    delDetIndex.then(function (response) {
                    //        if (response.data.data) {
                    //            ViewDetRec();
                    //            MFIMsg.Alert("Data deleted successfully !!!");
                    //        }
                    //        else
                    //            MFIMsg.Alert("Cannot delete data !!!");
                    //    },
                    //        function errorCallback(response) {
                    //            MFIMsg.Alert("Oops, an error occurred !!!");
                    //        });
                    //};

                    $scope.DeleteCusIndDetailRecord = function () {
                        //debugger;
                        var CustDetailData = [];
                        if ($window.lstSelCusIndDetail.length == 0) {
                            MFIMsg.AlertHtml("Please select a record", MFIAlertType.Information);
                            return;
                        }
                        var lstCusIndex = [];
                        var lstRecordDate = [];
                        $scope.IsErrorInExcel = false;
                        angular.forEach($window.lstSelCusIndDetail[0].Multi_CustDetailData, function (value, key) {

                            lstCusIndex.push(value.CustomIndexId);
                        });
                        angular.forEach($window.lstSelCusIndDetail, function (value, key) {

                            lstRecordDate.push(value.RecordDate);
                        });
                        var valuedata = {
                            "LstCustomIndexId": lstCusIndex, "LstRecordDate": lstRecordDate
                        };
                        CustDetailData.push(valuedata);
                        //angular.forEach($window.lstSelCusIndDetail, function (value, key) {
                        //    var valuedata = {
                        //        "CustomIndexId": value.split('#')[0], "RecordDate": value.split('#')[1]
                        //    };
                        //    //CustDetailData.push(JSON.stringify(valuedata));
                        //    CustDetailData.push(valuedata);
                        //});
                        var objCustRec = { "CustDetailData": CustDetailData };
                        $scope.LoaderCommonCustomIndexDetail = true;
                        var delDetIndex = PostDeleteCustomIndexDetailRecord.Call(objCustRec);
                        delDetIndex.then(function (response) {
                            if (response.data.data) {
                                ViewDetRec();
                                $scope.LoaderCommonCustomIndexDetail = false;
                                angular.element('#select-all').removeAttr('checked');
                                MFIMsg.AlertHtml("Index deleted successfully", MFIAlertType.Information);
                            }
                            else
                                MFIMsg.AlertHtml("Cannot delete data", MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.GetIndexType = function (type) {
                        if (type == "gen")
                            $scope.indexType = 'gen';
                        if (type == "per")
                            $scope.indexType = 'per';
                    }

                    $scope.ExportTemplate = function () {
                        var downloadPath = "/Content/DownloadExcel/CustomIndexTemplate.xlsx";
                        window.open(downloadPath, '_blank', '');
                    }

                    $scope.ExportMultipleTemplate = function () {
                        var downloadPath = "/Content/DownloadExcel/MultipleCustomIndexTemplate.xlsx";
                        window.open(downloadPath, '_blank', '');
                    }

                    //$scope.ExportMultipleTemplate = function () {
                    //    if (lstSelCusInd.length == 0) {
                    //        MFIMsg.AlertHtml("Please select Custom index", MFIAlertType.Information);
                    //    }
                    //    else {
                    //        $scope.LstCustomIndexName = [];
                    //        angular.forEach(lstSelCusInd, function (value) {
                    //            $scope.LstCustomIndexName.push(value.CustomIndexName);
                    //        });
                    //        var objCustRec = { "LstCusIndexName": $scope.LstCustomIndexName };
                    //        var AllCustIndexName = FetchCustomIndexTemplate.Call(objCustRec);
                    //        AllCustIndexName.then(function (response) {
                    //            if (response.data != null && response.data.data == true) {
                    //                window.open("/Portfolio/GetMultipleCustomIndexTemplate");
                    //                //$scope.LoaderRatingSearch = false;
                    //            }
                    //        },
                    //            function (stu) {
                    //                $scope.LoaderCommonCustomIndex = false;
                    //                //$scope.LoaderRatingSearch = false;
                    //                MFIMsg.AlertHtml("Fail to Create template", MFIAlertType.Information);
                    //            });


                    //    }
                    //}

                    $scope.resetIndex = function () {
                        $scope.searchIndexName = "";
                        lstSelCusInd = [];
                        $scope.IsAllCusIndChecked = false
                        GetAllCustIndex();
                    }

                    $scope.chkCusIndDetChecked = function (event, item, IsItemClickForCheck) {
                        //var itemindex = $scope.lstMergedSchemes.indexOf(item);
                        //var itemindex = $scope.ParrallelLstMergedSchemes.indexOf(JSON.stringify(item));
                        //var itemObject = JSON.parse(JSON.stringify(item));//JSON.parse(item);
                        if (IsItemClickForCheck) {
                            //itemObject.IsChecked = false;
                            lstSelCusIndDetail.push(item);
                        }
                        else {
                            var index = lstSelCusIndDetail.indexOf(item);
                            lstSelCusIndDetail.splice(index, 1);
                        }
                        //$scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                    };

                    $scope.chkAllCusIndDetClick = function (event) {
                        if ($scope.IsAllCusIndDetChecked) {
                            lstSelCusIndDetail = [];
                            angular.forEach($scope.tempCusIndexRecords, function (value) {
                                value.IsChecked = true;
                                //var ItemObject = JSON.parse(JSON.stringify(value));
                                //ItemObject.IsChecked = false;
                                //lstSelCusIndDetail.push(JSON.stringify(value));
                                lstSelCusIndDetail.push(value);
                            });
                        }
                        else {
                            lstSelCusIndDetail = [];
                            angular.forEach($scope.tempCusIndexRecords, function (value) {
                                value.IsChecked = false;
                            });
                        }
                    };

                    var lstSelCusInd = [];
                    $scope.chkCusIndChecked = function (event, item, IsItemClickForCheck) {
                        //var itemindex = $scope.lstMergedSchemes.indexOf(item);
                        //var itemindex = $scope.ParrallelLstMergedSchemes.indexOf(JSON.stringify(item));
                        //var itemObject = JSON.parse(JSON.stringify(item));//JSON.parse(item);
                        if (IsItemClickForCheck) {
                            //itemObject.IsChecked = false;
                            lstSelCusInd.push(item);
                        }
                        else {
                            var index = lstSelCusInd.indexOf(item);
                            lstSelCusInd.splice(index, 1);
                        }
                        //$scope.IsSchemeAllChecked = $scope.lstMergedSchemes.length == $scope.lstMfiSchemes.length;
                    };

                    $scope.chkAllCusIndClick = function (event) {
                        if ($scope.IsAllCusIndChecked) {
                            lstSelCusInd = [];
                            angular.forEach($scope.names, function (value) {
                                value.IsChecked = true;
                                //var ItemObject = JSON.parse(JSON.stringify(value));
                                //ItemObject.IsChecked = false;
                                //lstSelCusIndDetail.push(JSON.stringify(value));
                                lstSelCusInd.push(value);
                            });
                        }
                        else {
                            lstSelCusInd = [];
                            angular.forEach($scope.names, function (value) {
                                value.IsChecked = false;
                            });
                        }
                    };

                    $scope.CustomIndexDtlsExportToExcel = function () {

                        window.open("/Portfolio/CustomIndexDtlsExportToExcel");
                    };

                    $scope.CustomIndexExcelErrorDtls = function () {
                        $scope.IsErrorInExcel = false;
                        window.open("/Portfolio/CustomIndexExcelErrorDtls");
                    };


                    $scope.resetDetailIndex = function () {
                        $scope.CusDetFromDate = null;
                        $scope.CusDetToDate = null;
                        lstSelCusIndDetail = [];
                        $scope.IsAllCusIndDetChecked = false;
                        $scope.CusIndDetailDateRange = null;
                        ViewDetRec();
                    }

                    $scope.closeCustomIndex = function () {
                        if (screen.width <= 767) {
                            angular.element('#customIndexDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#customIndexDetails').hide();
                        } else {
                            angular.element('#customIndexDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#customIndexDetails').hide();
                            });
                        }
                    };

                    $scope.toggleCustomIndexPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-customIndex');
                        var $details = angular.element('#customIndexDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };
                    $scope.MyEvents = {

                    }

                    //$scope.DetChk = function () {
                    //    debugger;
                    //}

                    //$element.iCheck({
                    //    checkboxClass: 'flat',
                    //    radioClass: 'flat'
                    //}).on('ifChanged', function (event) {
                    //    debugger;
                    //});
                }, 0);
            }
        }
   }
]);