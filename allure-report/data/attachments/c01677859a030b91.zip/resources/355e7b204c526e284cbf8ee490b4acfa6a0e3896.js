SharedDeractives.directive('portfolioChangeDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetQAAUMDates', 'GetPortfolioChangeDetails','GetPortfolioChangeDetailsAdvance', 'MFIMsg', 'GetNatureList', 'SubNatureList','GetDateListForQuaterlyCompReport',
    function ($http, $q, $timeout, ApiInfo, GetQAAUMDates, GetPortfolioChangeDetails,GetPortfolioChangeDetailsAdvance, MFIMsg, GetNatureList, SubNatureList, GetDateListForQuaterlyCompReport) {
        return {
            restrict: 'AE',
            scope: {
                lstMfiSchemes: '=',
                lstPeriodOptions: '=',
                selectedMutualFundModel: '=',
                categoryList: '=',               
                natureModel: '=',
                lstFundWiseNature: '=',
                checkNature: '=',
                subNature: '=',
                subNatureModel: '=',
                subCategoryList: '=',
                setfromPortfolioChangeDirective: '&',
                setfromMarketCapforLoader: '&',
                setSchemeAmc: '&',
                setSchemeSelection: '&'
               
            },
            templateUrl: '/PortfolioAnalysis/PortfolioChangeAdvance',

            link: function ($scope, $element, $attrs) {
                $scope.AmcNature = false;
                var IsSubCatSelAll = false;
                //$scope.LstFundWiseNature = [];
                //$scope.NatureModel = [];
                //$scope.subNatureModel = [];
                

                $scope.NetAssetDis = false;
                $scope.IsIndustryWise = false;
                $scope.OnLoad1 = false;
                $scope.ShowIndCom1 = true;
                $scope.OnLoad2 = false;
                $scope.ShowIndCom2 = false;



                
                //function GetSubNature() {
                //    var NatureId = [];
                //    if (!angular.isUndefinedOrNullOrEmpty($scope.NatureModel)) {                                                
                //            for (i = 0; i < $scope.NatureModel.length; i++) {
                //                NatureId.push($scope.NatureModel[i].Id);
                //            }
                                          
                //        var GetFundWiseSubNatureList = SubNatureList.Call(NatureId);
                //        GetFundWiseSubNatureList.then(function successCallback(response) {
                //            $scope.OnLoad2 = false;
                //            $scope.ShowIndCom2 = true;
                //            $scope.LstFundWiseSubNature = response.data.data;
                //            NatureId = [];
                //            $scope.SubNatureModel = [];
                //            //GetFundListOther();                         
                             
                //        },
                //            function errorCallback(response) {                             
                //                NatureId = [];
                //                MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                //            });
                //    }
                //    else {
                //        $scope.LstFundWiseSubNature = [];
                //        $scope.SubNatureModel = [];                   
                //        //$scope.LstFundOther = [];
                //        //$scope.FundOtherModel = [];
                //        //GetFundListOther();
                //    }
                //};

                
               
                
                    //var FundWiseNatureList = GetNatureList.Call();
                    //FundWiseNatureList.then(function successCallback(response) {
                    //    $scope.LstFundWiseNature = response.data.data;
                    //    $scope.OnLoad1 = false;
                    //    $scope.ShowIndCom1 = true;
                    //},
                    //    function errorCallback(response) {
                    //        MFIMsg.AlertHtml("Internal error occurred.", MFIAlertType.Error, "OK");
                    //    });
              
                //$scope.IsSchemeOrAmc = function () {

                //}
                //$scope.lstMfiSchemes = $scope.lstMfiSchemes||[];
                $scope.PrevMonth = "";
                $scope.CurrMonth = "";
                $scope.CurrPeriods = [];
                $scope.QAAUMMonth = "";
                //var PQAAUMDates = [];
                var PQAAUMDates = $scope.lstPeriodOptions;
                if ($scope.lstPeriodOptions.length > 1) {
                    $scope.PrevMonth = $scope.lstPeriodOptions[1];
                }
                else
                    $scope.PrevMonth = $scope.lstPeriodOptions[0];
                FillCurrentMonth($scope.PrevMonth);
                //$scope.PeriodOptions = [];
                $scope.IsNoOfSharesChecked = true;
                $scope.IsMarketValueChecked = false;
                $scope.IsSchemeChecked = true;
                
                $scope.IsAmcChecked = false;
                $scope.IsMonthlyFundSizeChecked = false;
                $scope.IsQAAUMChecked = false;
              
                var getQaaumDates = GetQAAUMDates.Call(20);
                getQaaumDates.then(function (response) {
                    $scope.QAAUMDates = response.data.data;
                    //$scope.QAAUMDates = PQAAUMDates;
                });
                function FillCurrentMonth(PreMonth) {
                    var PreDate = new Date("01 " + PreMonth.MonthYear);
                    var CurrDate;
                    $scope.CurrPeriods = [];

                    angular.forEach($scope.lstPeriodOptions, function (option) {
                        CurrDate = new Date("01 " + option.MonthYear);
                        if (CurrDate > PreDate)
                            $scope.CurrPeriods.push(option);
                    });

                    if ($scope.CurrPeriods.length > 0) {
                        $scope.CurrMonth = $scope.CurrPeriods[0];
                    }
                }
                $scope.GetCurentMonth = function () {
                    var PreMonth = $scope.PrevMonth;
                    FillCurrentMonth(PreMonth);
                };

                var XQAAUMDates = [];
                var QAAUMDates = GetDateListForQuaterlyCompReport.Call(true);//GetQAAUMDates.Call(5);
                QAAUMDates.then(function successCallback(response) {
                    if (response.data.Success == true) {
                       XQAAUMDates = response.data.data;
                    }
                });
               
                //$scope.CheckMonthlyFundsize = function () {
                //    if ($scope.IsMonthlyFundSizeChecked) {
                //        $scope.IsQAAUMChecked = false;
                //        $scope.QAAUMMonth = "";
                //    }
                //};
                
                $scope.SetSchemeOrAmc = function(MarketCapTtpe) {
                    if (MarketCapTtpe == "Scheme") {
                        $scope.NetAssetDis = false;
                        $scope.IsSchemeSelection = true;
                        //$scope.IsIndustryWise = false;
                        $scope.IsSchemeChecked = true;
                        $scope.IsAmcChecked = false;
                        $scope.IsIndustryChecked = false;
                        $scope.AmcNature = false;
                        $("#lblAmc").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        $("#lblIndustry").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblAmc").blur();
                            $("#lblIndustry").blur();
                            $("#lblScheme").addClass("btn btn-success btn-sm active");
                        }, 0);
                        $scope.setSchemeSelection({ IsSchemeOrAmc: $scope.IsSchemeSelection, IsIndustry: $scope.IsIndustryChecked });
                    }
                    else if (MarketCapTtpe == "Amc") {
                        //$scope.NetAssetDis = true;
                        //$scope.ShowHideValue("MktVal");
                        //$scope.IsIndustryWise = true;
                        $scope.IsSchemeChecked = false;
                        $scope.IsAmcChecked = true;
                        $scope.IsIndustryChecked = false;
                        $scope.AmcNature = true;
                        $scope.IsSchemeSelection = false;
                        $("#lblScheme").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        $("#lblIndustry").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblScheme").blur();
                            $("#lblIndustry").blur();
                            $("#lblAmc").addClass("btn btn-success btn-sm active");
                        }, 0);
                        $scope.setSchemeSelection({ IsSchemeOrAmc: $scope.IsSchemeSelection, IsIndustry: $scope.IsIndustryChecked });
                    }
                    else if (MarketCapTtpe == "Industry") {
                        //$scope.NetAssetDis = true;
                        //$scope.ShowHideValue("MktVal");
                        //$scope.IsIndustryWise = true;
                        $scope.IsSchemeChecked = false;
                        $scope.IsAmcChecked = true;
                        $scope.IsIndustryChecked = true;
                        $scope.IsSchemeSelection = true;
                        $("#lblAmc").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        $("#lblScheme").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblScheme").blur();
                            $("#lblAmc").blur();
                            $("#lblIndustry").addClass("btn btn-success btn-sm active");
                        }, 0);
                        $scope.setSchemeSelection({ IsSchemeOrAmc: $scope.IsSchemeSelection, IsIndustry: $scope.IsIndustryChecked });
                    }
                };

              

                //$scope.CheckNoOfShares = function () {
                //    if ($scope.IsNoOfSharesChecked)
                //    {
                //        $scope.IsNoOfSharesChecked = false;
                //        setTimeout(function () {
                //            $("#lblNoOfShares").blur();
                //        }, 0);
                //    }
                //    else {
                //        $scope.IsNoOfSharesChecked = true;
                //        $("#lblMarketValue").removeAttr("class");
                //        $("#lblMarketValue").attr("class","btn btn-success btn-sm");
                //    }
                //    $scope.IsMarketValueChecked = false;
                //};
                //$scope.CheckMarketValue = function () {
                //    if ($scope.IsMarketValueChecked) {
                //        $scope.IsMarketValueChecked = false;
                //        setTimeout(function () {
                //            $("#lblMarketValue").blur();
                //        }, 0);
                //    }
                //    else {
                //        $scope.IsMarketValueChecked = true;
                //        $("#lblNoOfShares").removeAttr("class");
                //        $("#lblNoOfShares").attr("class", "btn btn-success btn-sm");
                //    }

                //    $scope.IsNoOfSharesChecked = false;
                //};
                $scope.IsEquityChk = true;
                $scope.IsEqClk = true;
                $scope.IsDebtChk = false;
                $scope.IsOtherChk = false;
                $scope.IsSectorChk = false;
                $scope.IsInsChk = false;
                $scope.IsShowDebtChk = false;
                $scope.IsNetAssetChk = true;
                $scope.IsMarketValueChk = false;
                $scope.IsNoOfShareChk = false;
                $scope.TermType = "0";
                var EquityType = null;
                $scope.EquityClick = function () {


                    if ($scope.IsEquityChk) {
                        $scope.IsEquityChk = false;
                        $scope.IsEqClk = false;
                        EquityType = null;
                        $('#lblInsAll').removeClass('active');
                        $('#lblInsFutuOpt').removeClass('active');
                        $('#lblInsEquity').removeClass('active');    
                    }
                    else {
                        EquityType = 1;
                        $scope.IsEquityChk = true;
                        $scope.IsEqClk = true;
                    }
                };
                $scope.DebtClick = function () {

                    if ($scope.IsDebtChk) {
                        $scope.IsDebtChk = false;
                    }
                    else {
                        $scope.IsDebtChk = true;
                    }
                };

                $scope.OtherClick = function () {

                    if ($scope.IsOtherChk) {
                        $scope.IsOtherChk = false;
                    }
                    else {
                        $scope.IsOtherChk = true;
                    }
                };
                $scope.CheckNetAsset = function () {


                    if ($scope.IsNetAssetChk) {
                        $scope.IsNetAssetChk = false;
                        $("#lblNetAsset").removeAttr("class").attr("class", "btn btn-success btn-sm active");
                        //$scope.IsEqClk = false;
                        //EquityType = null;
                        
                    }
                    else {
                        //EquityType = 1;
                        $scope.IsNetAssetChk = true;
                        //$scope.IsEqClk = true;
                        $("#lblNetAsset").removeAttr("class").attr("class", "btn btn-success btn-sm");
                    }
                };
                $scope.CheckMarketValue = function () {

                    if ($scope.IsMarketValueChk) {
                        $scope.IsMarketValueChk = false;
                        $("#lblMktVal").removeAttr("class").attr("class", "btn btn-success btn-sm active");
                    }
                    else {
                        $scope.IsMarketValueChk = true;
                        $("#lblMktVal").removeAttr("class").attr("class", "btn btn-success btn-sm");
                    }
                };

                $scope.CheckNoOfShare = function () {

                    if ($scope.IsNoOfShareChk) {
                        $scope.IsNoOfShareChk = false;
                        $("#lblNoOfShares").removeAttr("class").attr("class", "btn btn-success btn-sm active");
                    }
                    else {
                        $scope.IsNoOfShareChk = true;
                        $("#lblNoOfShares").removeAttr("class").attr("class", "btn btn-success btn-sm");
                    }
                };
                $scope.InsClick = function () {

                    if ($scope.IsInsChk) {
                        $scope.IsInsChk = false;
                    }
                    else {
                        $scope.IsInsChk = true;
                        $scope.IsShowNat = false;
                        IsShwNat = false;
                    }
                };

                $scope.SectorClick = function () {

                    if ($scope.IsSectorChk) {
                        $scope.IsSectorChk = false;
                    }
                    else {
                        $scope.IsSectorChk = true;
                    }
                };

                $scope.ShowDebtClick = function () {

                    if ($scope.IsShowDebtChk) {
                        $scope.IsShowDebtChk = false;
                    }
                    else {
                        $scope.IsShowDebtChk = true;
                        $scope.IsShowNat = false;
                        IsShwNat = false;
                    }
                };

                $scope.EquityRadioClick = function (selected) {
                    if ($scope.IsEquityChk)
                    EquityType = selected;

                };


                $scope.IsNoOfSharesChecked = false;
                $scope.IsMarketValue = false;
                $scope.IsNetAsset = true;
                $scope.ShowHideValue = function (Inp) {
                    if (Inp == "NetAsset") {
                        if ($scope.NetAssetDis == false) {
                            $scope.IsNetAsset = true;
                            $scope.IsNoOfSharesChecked = false;
                            $scope.IsMarketValue = false;
                            $("#lblMktVal").removeAttr("class").attr("class", "btn btn-success btn-sm");
                            $("#lblNoOfShares").removeAttr("class").attr("class", "btn btn-success btn-sm");
                            setTimeout(function () {
                                $("#lblMktVal").blur();
                                $("#lblNoOfShares").blur();
                                $("#lblNetAsset").addClass("btn btn-success btn-sm active");
                            }, 0);
                        }
                        else {
                            $("#lblNetAsset").removeAttr("class").attr("class", "btn btn-success btn-sm active");
                            $scope.IsNetAsset = false;
                        }
                    }
                    else if (Inp == "MktVal") {
                        $scope.IsNetAsset = false;
                        $scope.IsNoOfSharesChecked = false;
                        $scope.IsMarketValue = true;
                        $("#lblNetAsset").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        $("#lblNoOfShares").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblNetAsset").blur();
                            $("#lblNoOfShares").blur();
                            $("#lblMktVal").addClass("btn btn-success btn-sm active");
                        }, 0);

                    }
                    else if (Inp == "NoOfShares") {
                        $scope.IsNetAsset = false;
                        $scope.IsNoOfSharesChecked = true;
                        $scope.IsMarketValue = false;
                        $("#lblNetAsset").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        $("#lblMktVal").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblNetAsset").blur();
                            $("#lblMktVal").blur();
                            $("#lblNoOfShares").addClass("btn btn-success btn-sm active");
                        }, 0);

                    }
                };


                //$scope.NatureClick = function (Inp) {
                //    if (Inp == "Equity") {
                //        //if ($scope.NetAssetDis == false) {
                //        $scope.IsEquityChk = true;
                //        $scope.IsDebtChk = false;
                //        $scope.IsOtherChk = false;
                //            $("#lblDbt").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //            $("#lblOtr").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //            setTimeout(function () {
                //                $("#lblDbt").blur();
                //                $("#lblOtr").blur();
                //                $("#lblEqt").addClass("btn btn-success btn-sm active");
                //            }, 0);
                //       // }
                //        //else {
                //        //    $("#lblEqt").removeAttr("class").attr("class", "btn btn-success btn-sm active");
                //        //    $scope.IsNetAsset = false;
                //        //}
                //    }
                //    else if (Inp == "Debt") {
                //        $scope.IsEquityChk = false;
                //        $scope.IsDebtChk = true;
                //        $scope.IsOtherChk = false;
                //        $("#lblEqt").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //        $("#lblOtr").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //        setTimeout(function () {
                //            $("#lblEqt").blur();
                //            $("#lblOtr").blur();
                //            $("#lblDbt").addClass("btn btn-success btn-sm active");
                //        }, 0);

                //    }
                //    else if (Inp == "Other") {
                //        $scope.IsEquityChk = false;
                //        $scope.IsDebtChk = false;
                //        $scope.IsOtherChk = true;
                //        $("#lblEqt").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //        $("#lblDbt").removeAttr("class").attr("class", "btn btn-success btn-sm");
                //        setTimeout(function () {
                //            $("#lblEqt").blur();
                //            $("#lblDbt").blur();
                //            $("#lblOtr").addClass("btn btn-success btn-sm active");
                //        }, 0);

                //    }
                //};
                //$scope.CheckNoOfShare = function () {
                //    if ($scope.IsNoOfSharesChecked) {
                //        $scope.IsNoOfSharesChecked = false;
                //    }
                //    else {
                //        $scope.IsNoOfSharesChecked = true;
                //    }
                //};
                //$scope.CheckMarketValue = function () {
                //    if ($scope.IsMarketValue) {
                //        $scope.IsMarketValue = false;
                //    }
                //    else {
                //        $scope.IsMarketValue = true;
                //    }
                //};
                //$scope.CheckNetAsset = function () {
                //    if ($scope.IsNetAsset) {
                //        $scope.IsNetAsset = false;
                //    }
                //    else {
                //        $scope.IsNetAsset = true;
                //    }
                //};
                $scope.DisSector = false;
                $scope.IsComprehesive = true;
                $scope.ReportType = function (MarketCapTtpe) {
                    if (MarketCapTtpe == "Comp") {
                        
                        $scope.DisSector = false;
                        $scope.IsComprehesive = true;
                        $("#lblSumm").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblSumm").blur();
                            $("#lblComp").addClass("btn btn-success btn-sm active");
                        }, 0);

                    }
                    else if (MarketCapTtpe == "Summ") {
                        $scope.IsInsChk = false;
                        $scope.DisSector = true;
                        $scope.IsSectorChk = false;
                        $("#showinstrument").removeClass("btn btn-success btn-sm active");
                        $("#showinstrument").addClass("btn btn-success btn-sm");
                        $("#Sctr").removeClass("btn btn-success btn-sm active");
                        $("#Sctr").addClass("btn btn-success btn-sm");
                        $scope.IsComprehesive = false;
                        $("#lblComp").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblComp").blur();
                            $("#lblSumm").addClass("btn btn-success btn-sm active");
                        }, 0);

                    }
                };
                $scope.IsMonthlyFundSizeChecked = true;
                $scope.IsQAAUMChecked = false;
             
                //$scope.IsMonthlyFundSizeChecked = true;
                $scope.CheckMonthlyFundsize = function (MarketCapTtpe) {
                    if (MarketCapTtpe == "Monthly") {
                        $scope.IsMonthlyFundSizeChecked = true;
                        $scope.IsQAAUMChecked = false;
                        if ($scope.QAAUMDates.length > 0) {
                            $scope.QAAUMMonth = $scope.QAAUMDates[0];
                        }
                        $scope.lstPeriodOptions = PQAAUMDates;
                        if ($scope.lstPeriodOptions.length > 1) {
                            $scope.PrevMonth = $scope.lstPeriodOptions[1];
                        }
                        else
                            $scope.PrevMonth = $scope.lstPeriodOptions[0];
                     
                        $("#lblQAAUM").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblQAAUM").blur();
                            $("#lblMonthlyFundSize").addClass("btn btn-success btn-sm active");
                        }, 0);
                         
                    }
                    else if (MarketCapTtpe == "Qaaum") {
                        $scope.lstPeriodOptions = XQAAUMDates;
                        if ($scope.lstPeriodOptions.length > 1) {
                            $scope.PrevMonth = $scope.lstPeriodOptions[1];
                        }
                        else
                            $scope.PrevMonth = $scope.lstPeriodOptions[0];
                        
                        $scope.IsMonthlyFundSizeChecked = false;
                        $scope.IsQAAUMChecked = true;
                        $("#lblMonthlyFundSize").removeAttr("class").attr("class", "btn btn-success btn-sm");
                        setTimeout(function () {
                            $("#lblMonthlyFundSize").blur();
                            $("#lblQAAUM").addClass("btn btn-success btn-sm active");
                        }, 0);
                         
                    }






                    //if ($scope.IsMonthlyFundSizeChecked) {
                    //    $scope.IsMonthlyFundSizeChecked = false;
                    //    setTimeout(function () {
                    //        $("#lblMonthlyFundSize").blur();
                    //    }, 0);
                    //}
                    //else {
                    //    $scope.IsMonthlyFundSizeChecked = true;
                    //    $("#lblQAAUM").removeAttr("class");
                    //    $("#lblQAAUM").attr("class", "btn btn-success btn-sm");
                    //}
                    //$scope.IsQAAUMChecked = false;
                    //$scope.QAAUMMonth = "";

                    //$scope.IsMonthlyFundSizeChecked = true;
                    //$timeout(function () {
                    //    angular.element("#lblMonthlyFundSize").addClass("btn btn-success btn-sm active");
                    //}, 0);
                };
                //$scope.CheckQAAUM = function () {
                //    if ($scope.IsQAAUMChecked) {
                //        $scope.IsQAAUMChecked = false;
                //        setTimeout(function () {
                //            $("#lblQAAUM").blur();
                //        }, 0);
                //    }
                //    else {
                //        $scope.IsQAAUMChecked = true;
                //        if ($scope.QAAUMDates.length > 0) {
                //            $scope.QAAUMMonth = $scope.QAAUMDates[0];
                //        }
                //        $("#lblMonthlyFundSize").removeAttr("class");
                //        $("#lblMonthlyFundSize").attr("class", "btn btn-success btn-sm");
                //    }
                //    $scope.IsMonthlyFundSizeChecked = false;
                //};
                $scope.Ismonthly = true;
                $scope.Isfortnightly = false;


                $scope.SelectPortfolioType = function (select) {
                    if (select == 1) {
                        $scope.Ismonthly = true;
                        $scope.Isfortnightly = false;
                        
                    }
                    else {
                        $scope.Ismonthly = false;
                        $scope.Isfortnightly = true;
                        
                    }
                }
                var IsShwAMC = false;
                var IsShwFund = false;
                var IsShwNat = false;
                var IsShwConRpt = false;
                $scope.toggleChange = function (type) {
                    if (type == 'AMC') {
                        if (IsShwAMC) {
                            $scope.IsShowAMC = false;
                            IsShwAMC = false;
                        }
                        else {
                            IsShwAMC = true;
                            $scope.IsShowAMC = true;
                            $scope.IsShowFund = false;
                            $scope.IsShowNat = false;
                            $scope.IsShowConRpt = false;
                            IsShwFund = false;
                            IsShwNat = false;
                            IsShwConRpt = false;
                        }
                    }
                    else if (type == 'Fund') {
                        if (IsShwFund) {
                            $scope.IsShowFund = false;
                            IsShwFund = false;
                        }
                        else {
                            $scope.IsShowAMC = false;
                            $scope.IsShowFund = true;
                            $scope.IsShowNat = false;
                            $scope.IsShowConRpt = false;
                            IsShwFund = true;
                            IsShwNat = false;
                            IsShwAMC = false;
                            IsShwConRpt = false;
                        }
                    }
                    else if (type == 'Nature') {
                        if (IsShwNat) {
                            $scope.IsShowNat = false;
                            IsShwNat = false;
                        }
                        else {
                            $scope.IsShowAMC = false;
                            $scope.IsShowFund = false;
                            $scope.IsShowNat = true;
                            $scope.IsShowConRpt = false;
                            IsShwNat = true;
                            IsShwFund = false;
                            IsShwAMC = false;
                            IsShwConRpt = false;
                        }
                    }
                    if (type == 'ConRpt') {
                        if (IsShwConRpt) {
                            $scope.IsShowConRpt = false;
                            IsShwConRpt = false;
                        }
                        else {
                            IsShwAMC = false;
                            $scope.IsShowConRpt = true;
                            $scope.IsShowAMC = false;
                            $scope.IsShowFund = false;
                            $scope.IsShowNat = false;
                            $scope.IsInsChk = false;
                            $scope.IsShowDebtChk = false;
                            IsShwFund = false;
                            IsShwNat = false;
                            IsShwConRpt = true;
                            $("#lblShowDebt").removeAttr("class").attr("class", "btn btn-success btn-sm");
                            $("#lblshowinstrument").removeAttr("class").attr("class", "btn btn-success btn-sm");
                            setTimeout(function () {
                                $("#lblShowDebt").blur();
                                $("#lblshowinstrument").blur();
                            }, 0);
                        }
                    }
                }

                var CollapseSelCriteria = function () {
                    angular.element("#DivPortfolioChangeDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                }

                $scope.ShowPortfolioChangeReport = function () {
                    //debugger;
                    //var test = $scope.natureModel;
                    //var test1 = $scope.subNatureModel;
                    //var test9 = $scope.subNature;
                    var SelSubNature = [];
                    var SelNature = [];
                    if (!$scope.IsSchemeChecked /*&& !$scope.IsIndustryChecked*/) {
                        if ($scope.subNatureModel.length != 0) {
                            for (i = 0; i < $scope.subNature.length; i++) {
                                if ($scope.subNature[i].IsChecked == true) {
                                    SelSubNature.push({ Id: $scope.subNature[i].Id, Name: $scope.subNature[i].Name });
                                }
                            }

                        }

                        if ($scope.natureModel.length != 0) {
                            for (j = 0; j < $scope.lstFundWiseNature.length; j++) {
                                if ($scope.lstFundWiseNature[j].IsChecked == true) {
                                    SelNature.push({ Id: $scope.lstFundWiseNature[j].Id, Name: $scope.lstFundWiseNature[j].Name });
                                }
                            }
                            $scope.IsIndustryWise = true;
                        }
                        else
                            $scope.IsIndustryWise = false;
                    }
                    

                    var MFIds = [];
                    if ($scope.IsSchemeChecked) {
                        $scope.IsIndustryWise = false;
                        if ($scope.lstMfiSchemes.length == 0) {
                            MFIMsg.AlertHtml("User have to select atleast one scheme.", MFIAlertType.Information, "OK");
                            return;
                        }
                        //if ($scope.lstMfiSchemes.length > MaxSchemeSelectionAllowed) {
                        //    MFIMsg.AlertHtml("You can select only " + MaxSchemeSelectionAllowed + " schemes to show the report", MFIAlertType.Information);
                        //    return false;
                        //}
                        $scope.LstSelectedMFISchemes = [];
                        angular.forEach($scope.lstMfiSchemes, function (value) {
                            var item = { "Id": JSON.parse(value).Id, "Name": JSON.parse(value).Name };
                            $scope.LstSelectedMFISchemes.push(item);
                        });
                    }
                    else if (!$scope.IsSchemeChecked && !$scope.IsIndustryChecked) {
                        if ($scope.selectedMutualFundModel.length == 0) {
                            MFIMsg.AlertHtml("Please select Mutual Fund(s).", MFIAlertType.Information);
                            return false;
                        }
                        angular.forEach($scope.selectedMutualFundModel, function (option) {
                            var itemMF = JSON.parse(option);
                            MFIds.push(itemMF.Id);
                        });

                    }
                    //if ($scope.IsNoOfSharesChecked == false && $scope.IsMarketValueChecked == false) {
                    //    MFIMsg.AlertHtml("Please select one of the option(No. of Shares/Market Value).",MFIAlertType.Information);
                    //    return false;
                    //}

                    if ($scope.PrevMonth == "") {
                        MFIMsg.AlertHtml("Please select previous Month.",  MFIAlertType.Information);
                        return false;
                    }

                    if ($scope.CurrMonth == "") {
                        MFIMsg.AlertHtml("Please select current Month.", MFIAlertType.Information);
                        return false;
                    }

                    var PreDate = new Date("01 " + $scope.PrevMonth.MonthYear);
                    var CurrDate = new Date("01 " + $scope.CurrMonth.MonthYear);

                    //if (CurrDate <= PreDate) {
                    //    MFIMsg.AlertHtml("Please select one of the option( Monthly FundSize/QAAUM).", "", MFIAlertType.Information);
                    //    return false;
                    //}

                    //if ($scope.IsMonthlyFundSizeChecked == false && $scope.IsQAAUMChecked == false) {
                    //    MFIMsg.AlertHtml("Please select one of the option( Monthly FundSize/QAAUM).", "", MFIAlertType.Information);
                    //    return false;
                    //}

                    //if ($scope.IsQAAUMChecked && $scope.QAAUMMonth == "") {
                    //    MFIMsg.AlertHtml("Please select QAAUM Month.", "", MFIAlertType.Information);
                    //    return false;
                    //}
                    
                    /*var IsNoOfShares = $scope.IsNoOfSharesChecked;*/
                    var PreviousPortfolioDate = $scope.PrevMonth;
                    var CurrentPortfolioDate = $scope.CurrMonth;
                    var IsIsMonthlyFundSize = $scope.IsMonthlyFundSizeChecked;
                    var QAAUMDate = $scope.QAAUMMonth;
                    var IsComp = $scope.IsComprehesive;
                    //var IsMktVal = $scope.IsMarketValue;
                    //var IsNetAsset = $scope.IsNetAsset;
                    var IsMktVal = $scope.IsMarketValueChk;
                    var IsNetAsset = $scope.IsNetAssetChk;
                    var IsNoOfShares = $scope.IsNoOfShareChk;
                    
                    if ($scope.IsEquityChk == false && $scope.IsDebtChk == false && $scope.IsOtherChk == false && $scope.IsSectorChk == false && $scope.IsInsChk == false && $scope.IsShowDebtChk == false) {
                        MFIMsg.AlertHtml("Please select atleast one Portfolio Nature", MFIAlertType.Information);
                        return false;                   
                    }

                    if ($scope.Isfortnightly && $scope.TermType == "0") {
                        MFIMsg.AlertHtml("Please select term", MFIAlertType.Information);
                        return false;  
                    }

                    if (!IsMktVal && !IsNetAsset && !IsNoOfShares) {
                        MFIMsg.AlertHtml("Please atleast one parameter selection", MFIAlertType.Information);
                        return false;
                    }
                    CollapseSelCriteria();
                    var Input = {
                        "LstScheme": $scope.LstSelectedMFISchemes,
                        "MutualFundId": MFIds,
                        "IsNoOfShares": IsNoOfShares,
                        "PreviousPortfolioDate": PreviousPortfolioDate.MonthYear,
                        "CurrentPortfolioDate": CurrentPortfolioDate.MonthYear,
                        "FortnightlyPeriod": $scope.Isfortnightly ? $scope.TermType == "1" ? "Term 1" : "Term 2" : "",
                        "IsIsMonthlyFundSize": $scope.IsMonthlyFundSizeChecked,
                        "IsQAAUM": $scope.IsQAAUMChecked,
                        "Ismonthly": $scope.Ismonthly,
                        "Isfortnightly": $scope.Isfortnightly,
                        "IsComp": IsComp,
                        "IsMktVal": IsMktVal,
                        "IsNetAsset": IsNetAsset,
                        "IsEquity": $scope.IsEquityChk,
                        "InstrumentType": EquityType,
                        "IsDebt": $scope.IsDebtChk,
                        "IsOthers": $scope.IsOtherChk,
                        "IsScheme": $scope.IsSchemeChecked,
                        "IsAMC": $scope.IsAmcChecked,
                        "IsSector": !IsComp,
                        "IsInstrument": $scope.IsInsChk,
                        "IsShowDebt": $scope.IsShowDebtChk,
                        "Natures": SelNature,
                        "SubNatures": SelSubNature,
                        "IsIndustryWise": $scope.IsIndustryChecked,
                        "QAAUMDate": $scope.QAAUMMonth.PortDateDisplay,
                        "IsShowAMC": $scope.IsShowAMC,
                        "IsShowFund": $scope.IsShowFund,
                        "IsShowNature": $scope.IsShowNat,
                        "IsShowConRpt": $scope.IsShowConRpt
                    };
                    $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "PORTFOLIOCHANGE" });
                    //angular.element("#DivPortfolioChangeDetails").hide();
                    var PortfolioDetails = GetPortfolioChangeDetailsAdvance.Call(Input);
                    PortfolioDetails.then(function (response) {
                        if (response.data != null && response.data.Success == false) {
                            if (response.data.Message != "")
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Warning);
                            else
                                MFIMsg.AlertHtml("Warning!! internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "PORTFOLIOCHANGE" });
                            return false;
                        }
                        if ($scope.setfromPortfolioChangeDirective != undefined) {
                            $scope.setfromPortfolioChangeDirective({ PortfolioChangeDetailsData: response.data, IsNoofShares: $scope.IsNoOfSharesChecked });
                        }
                        //$scope.setfromMarketCapforLoader({ ShowLoader: false });
                        
                    },
                        function errorCallback(response) {
                            MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "PORTFOLIOCHANGE" });
                        });
                };
                angular.element("#btnResetPortfolioChange").click(function (e) {
                    window.location = "/PortfolioAnalysis/Advance";
                });
            }
        };
    }]);