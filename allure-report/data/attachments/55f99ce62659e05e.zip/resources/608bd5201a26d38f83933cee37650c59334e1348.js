SharedDeractives.directive('dirFundDashboardRatio', ['GetRatioGraphData', 'GetPreCalculatedSchemeIndexRatio', 'GetFetchUserBasicSettings',
    function (GetRatioGraphData, GetPreCalculatedSchemeIndexRatio, GetFetchUserBasicSettings) {
        return {
            //restrict: 'E',
            scope: { schemeId: "=", loginId: "=" },
            templateUrl: function (elem, attrs) {

                return "/FundDashboard/GetStatisticalHTML"
            },
            controller: function ($scope, $http) {

                $scope.isRatioLegShowMore = false;
                $scope.isRatioButtonShowMore = false;
                var CustomColors4Ratio = ["#4b5de4", "#d8b83f", "#ff5800", "#23c6c8", "#ed5565", "#009688"];

                $scope.FDRatio = {};
                $scope.FDRatio.PreCalculatedLoader = true;
                $scope.FDRatio.RiskReturnLoader = true;

                if ($scope.schemeId != 0) {

                    $scope.fnShowMoreLegendData = function (e) {
                        var v = "Show Legend";
                        var s = "Hide Legend";
                        var data = $(e.target).data('id');
                        var text = e.target.innerText;
                        if (text == v) {
                            $scope.isRatioLegShowMore = true;
                            e.target.innerText = s;
                        }
                        else {
                            $scope.isRatioLegShowMore = false;
                            e.target.innerText = v;
                        }
                    };

                    $scope.FDRatio.FNE2EPreCalculatedRatio = function () {
                        window.open("/FundDashboard/ExportToExcelPreCalculatedSchemeIndexRatio?SchemeId=" + $scope.schemeId);
                    };

                    var PreCalculatedRatio = GetPreCalculatedSchemeIndexRatio.Call($scope.schemeId, $scope.loginId);
                    PreCalculatedRatio.then(function (response) {
                        $scope.FDRatio.PreCalculatedRatioData = response.data.data;
                        $scope.FDRatio.PreCalculatedLoader = false;

                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching pre calculated ratio", MFIAlertType.Error, "OK");
                        });

                    $scope.FDRatio.UserBasicSettings = {};
                    var FetchUserBasicSettings = GetFetchUserBasicSettings.Call();
                    FetchUserBasicSettings.then(function (response) {
                        $scope.FDRatio.UserBasicSettings = response.data.data;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching user basic setting.", MFIAlertType.Error, "OK");
                        });

                    var RatioGraphData = GetRatioGraphData.Call($scope.schemeId);

                    RatioGraphData.then(function (response) {
                        $scope.FDRatio.GraphData = {};
                        $scope.FDRatio.GraphData = response.data.data;

                        // //
                        var yxchartstyle = { "fontSize": "13px", "fontFamily": "Roboto Condensed, sans-serif", "color": "rgb(75,93,228)", "fontWeight": "bold" };
                        var titlechartstyle = { "fontSize": "25px", "fontFamily": "Roboto Condensed, sans-serif", "color": "blue", "fontWeight": "bold" };
                        var subtitlechartstyle = { "fontSize": "12px", "fontFamily": "Roboto Condensed, sans-serif", "color": "black", "fontWeight": "bold" };
                        var legendstyle = { "fontSize": "13px", "fontFamily": "Roboto Condensed, sans-serif", "color": "black", "fontWeight": "bold", "align": "center", "verticalAlign": "bottom", "layout": "horizontal" };
                        var barspecialprop = { "maxPointWidth": 45 };
                        var piespecialprop = { "size": 270 };
                        var dualspecialprop = { "ypformat": " °C", "ysformat": " mm" };
                        var navspecialprop = { "selected": 2, "navigator": true, "inputEnabled": true };
                        //-----------start

                        var Model_FundDashboardStatRatio = $scope.FDRatio.GraphData;

                        var CustomColors = ["#9F2B68", "#FFBF00", "#FBCEB1", "#00FFFF", "#0000FF", "#088F8F", "#E1C16E", "#0096FF", "#CD7F32", "#A52A2A", "#5F9EA0", "#AFE1AF", "#DFFF00", "#E4D00A", "#0047AB", "#6495ED", "#FF00FF", "#008000", "#CD5C5C", "#5D3FD3", "#00FF00", "#800000", "#E0B0FF", "#000080", "#FF3131", "#808000", "#A95C68", "#800080", "#FF0000", "#8A9A5B", "#008080", "#D8BFD8", "#7F00FF", "#E37383", "#FFFF00", "#E9DCC9", "#FFDEAD", "#191970", "#89CFF0", "#00A36C", "#3F00FF", "#CCCCFF", "#9FE2BF", "#C19A6B", "#E5AA70", "#F0E68C", "#40E0D0", "#FF69B4", "#3CB371","#34282C", "#3B3131", "#3A3B3C", "#413839", "#3D3C3A", "#463E3F", "#696969", "#726E6D", "#C9C0BB", "#ff1a8c", "#b452ff", "#ff42a1", "#2424ff", "#5252ff", "#ff94c9", "#005700", "#ffbdde", "#6200ad", "#8b8378", "#7fffd4", "#76eec6", "#458b74", "#a8a800", "#ffe552", "#d1d100", "#ad7100", "#00ad00", "#ffff52", "#FF6347", "#FF4500", "#FFD700", "#FFA500", "#FF8C00", "#FF7F50", "#2E8B57", "#808000", "#556B2F", "#6B8E23", "#3CB371", "#40E0D0", "#48D1CC", "#00CED1", "#20B2AA", "#5F9EA0", "#008B8B", "#008080", "#1E90FF", "#6495ED", "#4682B4", "#4169E1", "#0000FF", "#0000CD", "#00008B", "#000080", "#191970", "#7B68EE", "#6A5ACD", "#483D8B", "#EE82EE", "#DA70D6", "#FF00FF", "#FF00FF", "#BA55D3", "#9370DB", "#8A2BE2", "#9400D3", "#9932CC", "#8B008B", "#800080", "#4B0082", "#FF69B4", "#FF1493", "#DB7093", "#C71585", "#DEB887", "#D2B48C", "#BC8F8F", "#F4A460", "#DAA520", "#CD853F", "#D2691E", "#8B4513", "#A0522D", "#A52A2A", "#800000", "#FFA07A", "#FA8072", "#E9967A", "#F08080", "#CD5C5C", "#DC143C", "#B22222", "#FF0000", "#8B0000", "#006400", "#008000", "#228B22", "#00FF00", "#708090", "#FFDF00", "#D4AF37", "#CFB53B", "#C5B358", "#E6BE8A", "#996515", "#E6E6FA", "#B0E0E6", "#ADD8E6", "#87CEFA", "#87CEEB", "#00BFFF", "#B0C4DE", "#1E90FF", "#FFFACD", "#FAFAD2", "#FFEFD5", "#FFE4B5", "#FFDAB9", "#EEE8AA", "#F0E68C", "#BDB76B", "#FFFF00", "#808000", "#FFFFCC", "#FFFF99", "#FFFF66", "#FFFF33", "#FFFF00", "#CCCC00", "#808080", "#A9A9A9", "#C0C0C0", "#F0F8FF", "#E6E6FA", "#B0E0E6", "#ADD8E6", "#87CEFA", "#87CEEB", "#00BFFF", "#A52A2A", "#FFC0CB", "#FFB6C1", "#F0FFF0", "#F5FFFA", "#F0FFFF", "#F0F8FF", "#F8F8FF", "#F5F5F5", "#FFF5EE", "#F5F5DC", "#FDF5E6", "#FFFAF0", "#FFFFF0", "#FAEBD7", "#FAF0E6", "#FFF0F5", "#FFE4E1", "#FFDEAD", "#E6E6FA", "#D8BFD8", "#DDA0DD", "#FFFFE0", "#FFFACD", "#FAFAD2", "#FFEFD5", "#FFE4B5", "#FFDAB9", "#EEE8AA", "#F0E68C", "#FFF8DC", "#FFEBCD", "#FFE4C4", "#FFDEAD", "#F5DEB3", "#DEB887", "#D2B48C", "#D79A9A", "#E7C4C4", "#F8EDED", "#F6D8D8", "#FAEAEA", "#BE2625", "#8B1A1A", "#DF5B5A", "#D93636", "#EDA2A2", "#EA9090", "#FBEAEA", "#E8BDB7", "#F9EDEC", "#FF2400", "#FF664D", "#FFA79", "#FCDC3B", "#FDE674", "#FFEC8B", "#FEF0AD", "#FFF1A9", "#FFFBE6", "#FFF6C7"];
                        var ChartData = GetBubbleChartFormatData(Model_FundDashboardStatRatio, CustomColors);
                        // //
                        var RiskAvgEntity = Model_FundDashboardStatRatio.RiskAvgEntity;
                        //  console.log($scope.FDRatio.UserBasicSettings);
                        bubble3DRiskReturn('divBubbleChart', ChartData, '', '', 'Standard deviation.', '', '', '', '', 'Average Rolling Return', true, false,
                            yxchartstyle, titlechartstyle, subtitlechartstyle, legendstyle, RiskAvgEntity.intAvgGraphMin, RiskAvgEntity.intAvgGraphMax,
                            RiskAvgEntity.intRatioGraphMin, RiskAvgEntity.intRatioGraphMax, RiskAvgEntity.intAvgCrossAt, RiskAvgEntity.intRatioCrossAt,
                            "Higher Risk Lower Returns", "Higher Risk Higher Returns", "Lower Risk Higher Returns", "Lower Risk Lower Returns", true, 'SpanYaxistitle', $scope.FDRatio.UserBasicSettings.ReturnDecimalFormat);

                        function GetBubbleChartFormatData(dataplot, CustomColors) {
                            var BubbleData = [];
                            var AveragePos = 1;
                            var RiskPos = 2;
                            var FundSizePos = 3;
                            var coloursize = 0;
                            for (var i = 0; i < dataplot.LstRatioDataReturn.length; i++) {
                                var Series = {};
                                var valArr = [];
                                var SeriesData = [[]];
                                var LstKeyvaluePair = dataplot.LstRatioDataReturn[i].LstKeyValuePair;
                                ////
                                if ((LstKeyvaluePair == undefined) || (LstKeyvaluePair == null)) {
                                    continue;
                                }
                                if ((LstKeyvaluePair[AveragePos] == undefined) || LstKeyvaluePair[AveragePos] == null) {
                                    continue;
                                }
                                if ((LstKeyvaluePair[RiskPos] == undefined) || LstKeyvaluePair[RiskPos] == null) {
                                    continue;
                                }
                                valArr.push(parseFloat(LstKeyvaluePair[AveragePos].Value), parseFloat(LstKeyvaluePair[RiskPos].Value), 1);
                                //valArr.push(parseFloat(LstKeyvaluePair[AveragePos].Value), parseFloat(LstKeyvaluePair[RiskPos].Value), parseFloat(LstKeyvaluePair[FundSizePos].Value));
                                SeriesData.push(valArr);
                                SeriesData.shift();
                                Series.name = LstKeyvaluePair[0].Value;
                                Series.data = SeriesData;
                                if (dataplot.LstRatioDataReturn[i].SchemeId == dataplot.SchemeId) {
                                    SeriesData.color = '#000000';
                                    Series.color = '#000000';
                                    Series.SchemeId = dataplot.SchemeId;
                                    Series.marker = {
                                        fillOpacity: 1
                                    };
                                    SeriesData.marker = {
                                        fillopacity: 1
                                    };
                                }
                                else {
                                    SeriesData.color = CustomColors[i];
                                    Series.color = CustomColors[i];
                                    Series.marker = {
                                        fillOpacity: 0.1
                                    };
                                    SeriesData.marker = {
                                        fillopacity: 0.1
                                    };
                                }

                                BubbleData.push(Series);
                            }
                            return BubbleData;
                        };

                        $legend = $('#customLegend');
                        var html = "";
                        $.each(ChartData, function (j, data) {

                            if (data.SchemeId == Model_FundDashboardStatRatio.SchemeId)
                            {
                                html = html + '<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0;"><div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"><div class="symbol" style="background-color:#000000;border:#000000 solid 1px;"></div></div> <div class="col-lg-11 col-md-11 col-sm-12 col-xs-12"><div class="serieName" id="" style="font-size: 12px;line-height: 14px; padding-top:3px">' + data.name + '</div></div></div>';
                            }
                            else
                            {
                                html = html + '<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="padding:0;"><div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"><div class="symbol" style="background-color:' + data.color + '25;border:' + data.color + ' solid 1px;"></div></div> <div class="col-lg-11 col-md-11 col-sm-12 col-xs-12"><div class="serieName" id="" style="font-size: 12px;line-height: 14px; padding-top:3px">' + data.name + '</div></div></div>';
                            }
                        });
                        $legend.append(html);
                        $scope.isRatioButtonShowMore = true;
                        $scope.isRatioLegShowMore = false;
                        $scope.FDRatio.RiskReturnLoader = false;

                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Error in fetching ratio graph data.", MFIAlertType.Error, "OK");
                        });
                }
            }
        }
    }]);