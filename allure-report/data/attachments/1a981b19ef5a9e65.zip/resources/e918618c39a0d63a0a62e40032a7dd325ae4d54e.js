SharedDeractives.directive('advanceSetting', ['$timeout', '$q', '$log', 'AllAdvanceSettings', 'MFIMsg', 'SaveAdvanceSetting','AllApplicationSetting',
    function ($timeout, $q, $log, AllAdvanceSettings, MFIMsg, SaveAdvanceSetting, AllApplicationSetting) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '='
            },
            replace: false,

            templateUrl: '/Home/AdvanceSetting',

            link: function ($scope, $element, $attrs) {

                var ShowAdvanceSetting = {};
                
                ShowAdvanceSetting.LstPlan = [];

                //if (angular.element('#rdDirect')[0].className.toUpperCase().indexOf('ACTIVE') > 0) {
                //    ShowAdvanceSetting.LstPlan.push("Direct");
                //}
                //if (angular.element('#rdNonDirect')[0].className.toUpperCase().indexOf('ACTIVE') > 0) {
                //    ShowAdvanceSetting.LstPlan.push("Non-Direct");
                //}

                var CreateBasicSettingEntity = {};
                CreateBasicSettingEntity.BSCIds = [];

                var getData = AllAdvanceSettings.Call();
                getData.then(function (response) {
                    
                    $scope.details = response.data.data;
                  

                },
                    function (stu) {
                        MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                    });

                $scope.FunctNmae = function (Option) {
                   
                    ShowAdvanceSetting.LstPlan = [];
                    CreateBasicSettingEntity.BSCIds = [];
                   // if (Option != "All") {
                        ShowAdvanceSetting.LstPlan.push(Option);
                        for (var i = 0; i < ShowAdvanceSetting.LstPlan.length; i++) {
                            if (Option == ShowAdvanceSetting.LstPlan[i]) {
                                for (var j = 0; j < $scope.details.length; j++) {
                                    if (Option == $scope.details[j].Option) {
                                        CreateBasicSettingEntity.BSCIds.push($scope.details[j].BSCID);
                                    }
                                }
                            }
                    }

                    //ShowAdvanceSetting.LstPlan.map($scope.details)
                    //    .filter(Option == $scope.details.Option)
                    //    .reduce(CreateBasicSettingEntity.BSCIds.push($scope.details.BSCID);


                   // }
                }


                $scope.SaveSettings = function () {
                    var postdata = SaveAdvanceSetting.Call(CreateBasicSettingEntity);
                    postdata.then(function (response) {
                        if (response.data.Success == true) {
                            MFIMsg.Alert("Data Saved Successfully ", "Success", "OK");
                        }

                    },
                        function (stu) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                        });
                }

                var getData = AllApplicationSetting.Call();
                getData.then(function (response) {
                    if (response.data != null) {
                        var lstdata = response.data.data.LstBasicSelectionvalue;
                        for (var i = 0; i < $scope.details.length; i++) {

                            for (var j = 0; j < lstdata.length; j++) {
                                //if (lstdata[j].ScDescription == undefined) {
                                //    continue
                                //}
                                if (lstdata[j].ScDescription == 'Sub Plan Selection') {
                                    if ($scope.details[i].BSCID == lstdata[j].BscId) {
                                        //var data = lstdata[j].BscId;
                                        var name = $scope.details[i].Option;
                                        if (name == "Non-Direct") {
                                            // document.getElementById("#rdDirect").selected = true;
                                            //Element("#rdDirect").ClassNames.add("active")
                                            document.getElementById("rdDirect").classList.remove("active");
                                            document.getElementById("rdAll").classList.remove("active");
                                            document.getElementById("rdNonDirect").classList.add("active");
                                        }
                                        if (name == "All") {
                                            document.getElementById("rdDirect").classList.remove("active");
                                            document.getElementById("rdAll").classList.add("active");
                                            document.getElementById("rdNonDirect").classList.remove("active");
                                        }
                                        // return;
                                    }
                                }
                            }
                        }
                    }
                },
                    function (stu) {
                        MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                    });

            }
        };
    }]);