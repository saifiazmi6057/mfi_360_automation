SharedDeractives.directive('customIndexPortfolio', ['$timeout', '$q', '$log', 'ApiInfo', '$http', '$filter', '$window', 'MFIMsg', 'GetAllCustomIndexPortfolioSettings', 'PostAddCustomIndexPortfolioRecord', 'PostSearchCustomIndexPortRecord', 'PostAddCustomIndexPortDetailRecord', 'PostModifyCustomIndexPortRecord', 'PostDeleteCustomIndexPortRecord', 'PostDeleteCustomIndexPortDetailRecord', 'PostCustomIndexPortRecord', 'GetPortfolioDDL',
    function ($timeout, $q, $log, ApiInfo, $http, $filter, $window, MFIMsg, GetAllCustomIndexPortfolioSettings, PostAddCustomIndexPortfolioRecord, PostSearchCustomIndexPortRecord, PostAddCustomIndexPortDetailRecord, PostModifyCustomIndexPortRecord, PostDeleteCustomIndexPortRecord, PostDeleteCustomIndexPortDetailRecord, PostCustomIndexPortRecord, GetPortfolioDDL) {
        return {
            restrict: 'E',
            scope: {
                PortfolioDatesettings: '=',
            },
            replace: false,
            templateUrl: '/Home/CustomIndexPortfolio',

            link: function ($scope, $element, $attrs) {
                $timeout(function () { 
                $scope.CustIndPortMaster = true;
                $scope.AddPortCust = false;
                $scope.hdCreate = false;
                $scope.ImpVal = false;
                $scope.EditVal = false;
                $scope.LoaderImportIndex = false;
                $scope.CustIndPortMaster = true;
                $scope.CustIndPortDetail = false;
                $scope.shwChooseDate = false;
                $scope.shwSelectedCount = false;

                var serverData = document.getElementById('serverData');
                $scope.Generic = parseInt(serverData.getAttribute('data-generic'));
                $scope.Personal = parseInt(serverData.getAttribute('data-personal'));

                $scope.indexType = $scope.Generic;
                $scope.selId = '';
                $scope.LoaderCommonCustomIndexPortfolio = true;
                $scope.selectedDates = [];
                $scope.selectedPortDates = [];
                $scope.PeriodOptions = [];
                

                var OptionsDateRange = {
                    showDropdowns: true,
                    autoApply: true,
                    locale: {
                        format: 'DD MMM YYYY'
                    }
                };
                function ApplyDateRange(start, end, label) {
                    $scope.CusDetFromDate = $filter('date')(new Date(start._d), 'dd MMM yyyy');// ArrDateObj[0];//new Date(start);
                    $scope.CusDetToDate = $filter('date')(new Date(end._d), 'dd MMM yyyy'); // ArrDateObj[1];//new Date(end);
                    ViewDetRec();
                }
                angular.element('#CusIndPortFromToDateRange').daterangepicker(OptionsDateRange, ApplyDateRange);

                $scope.SelectedPortMonth = [];
                $scope.PortMonth = [];
                //$scope.PortfolioDatesettings = {
                //    scrollableHeight: '400px',
                //    scrollable: true,
                //    enableSearch: true,
                //    ddltext: "Select Portfolio Date",
                //    Keyprop: "PortDateMonthYear",
                //    Valueprop: "PortDateDisplay",
                //};

                var getPortfolioDDLData = GetPortfolioDDL.Call(5);

                getPortfolioDDLData.then(function (response) {

                    $scope.PortMonth = response.data.data;
                },
                    function (stu) {
                        MFIMsg.AlertHtml("Records not gathered!!", MFIAlertType.Error, "OK");
                    });

                $scope.SearchCusIndPortDetailRecord = function () {
                    $scope.cusIndPortDate = $scope.SelectedPortMonth;
                    ViewDetRec();
                };
                $scope.MyEvents = {

                };

                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await GetAllCustomIndexPortfolioSettings.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('GetAllCustomIndexPortfolioSettings', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function AllCustIndex() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('GetAllCustomIndexPortfolioSettings');
                        //if (data) {
                        //    // Parse and return the data from LocalStorage
                        //    return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//

                var GetAllCustIndexPortfolio = function () {
                    //var AllCustIndex = GetAllCustomIndexPortfolioSettings.Call();
                    AllCustIndex().then(function (response) {
                        if (response != null) {
                            //$scope.names = response.data.data;
                            $timeout(function () {
                                $scope.names = response;
                                $scope.LoaderCommonCustomIndexPortfolio = false;
                            }, 10);
                        }
                        else {
                            $scope.LoaderCommonCustomIndexPortfolio = false;
                            MFIMsg.AlertHtml("No records are available", MFIAlertType.Information, "OK");
                        }
                    },
                        function (stu) {
                            $scope.LoaderCommonCustomIndexPortfolio = false;
                            MFIMsg.AlertHtml("Fail to load data", MFIAlertType.Information);
                        });
                }

                GetAllCustIndexPortfolio();
                $scope.ImportEdit = function (idSelected, selName) {
                    //debugger;
                    $scope.selId = idSelected;
                    $scope.CustomIndexName = selName;
                    $scope.ImpVal = true;
                };
                $scope.IsGeneric = true;
                $scope.GetIndexType = function (type) {
                    if (type == "gen") {
                        $scope.indexType = $scope.Generic;
                        $scope.IsGeneric = true;
                    }
                    if (type == "per") {
                        $scope.indexType = $scope.Personal;
                        $scope.IsGeneric = false;
                    }
                }
                $scope.AddIndex = function () {
                    $scope.AddPortCust = true;
                    $scope.hdCreate = true;
                    //$("#AddNewCustId").hide();
                };
                $scope.AddNewIndexPortfolioRecord = function () {
                    if (angular.isUndefinedOrNullOrEmpty($scope.NewCustomIndexPortfolioName)) {
                        MFIMsg.AlertHtml("Please enter custom index portfolio name", MFIAlertType.Information);
                        return;
                    }

                    var CustomIndexMaster = {
                        "CustomIndexName": $scope.NewCustomIndexPortfolioName, "Index_Type": $scope.indexType
                    };
                    var AddCustIndexPortfolio = PostAddCustomIndexPortfolioRecord.Call(CustomIndexMaster);
                    AddCustIndexPortfolio.then(function (response) {
                        if (response.data.data) {
                            localStorage.removeItem('GetAllCustomIndexPortfolioSettings');
                            GetAllCustIndexPortfolio();
                            $scope.NewCustomIndexPortfolioName = "";
                            $scope.AddPortCust = false;
                            MFIMsg.AlertHtml("Custom Index Portfolio created successfully", MFIAlertType.Information);
                            $scope.hdCreate = false;
                            $scope.searchIndexPortName = "";
                            //$scope.LoaderRatingSearch = false;
                        }
                        else
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                    },
                        function errorCallback(response) {
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                        });
                };
                $scope.searchIndexPort = function () {
                    if ($scope.searchIndexPortName == "") {
                        MFIMsg.AlertHtml("Please enter custom index name", MFIAlertType.Information);
                        return false;
                    }
                    $scope.LoaderCommonCustomIndexPortfolio = true;
                    var searchName = { "CustomIndexName": $scope.searchIndexPortName };
                    var searchIndex = PostSearchCustomIndexPortRecord.Call(searchName);
                    searchIndex.then(function (response) {
                        $scope.names = response.data.data;
                        $scope.LoaderCommonCustomIndexPortfolio = false;
                        //alert("Data saved successfully !!!");
                    },
                        function errorCallback(response) {
                            $scope.LoaderCommonCustomIndexPortfolio = false;
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                        });
                };
                $scope.resetEdit = function () {
                    $scope.EditVal = false;
                    $scope.searchIndexPortName = "";
                };
                $scope.reset = function () {
                    $scope.ImpVal = false;
                    $scope.searchIndexPortName = "";
                };
                $scope.resetIndex = function () {
                    $scope.searchIndexPortName = "";
                    GetAllCustIndexPortfolio();
                }
                $scope.ExitIndex = function () {
                    $scope.AddPortCust = false;
                    $scope.hdCreate = false;
                    $scope.searchIndexPortName = "";
                };
                $scope.ExportTemplate = function () {
                    var downloadPath = "/Content/DownloadExcel/CustomIndexPortfolioTemplate.xlsx";
                    window.open(downloadPath, '_blank', '');
                }
                $scope.ImportIndex = function (file) {
                    
                    if ($scope.file == null) {
                        MFIMsg.AlertHtml("Please select a file", MFIAlertType.Information);
                        return;
                    }
                    var data = { "CustomIndexId": $scope.selId, "ObjFile": $scope.file };
                    
                    angular.element("input[type='file']").val(null);
                    $scope.LoaderImportIndex = true;
                    $http({
                        method: "POST",
                        url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAddCustomIndexPortDetailRecord',
                        headers: { 'Content-Type': undefined },
                        transformRequest: function (data, headersGetter) {
                            var formData = new FormData();
                            angular.forEach(data, function (value, key) {
                                formData.append(key, value);
                            });
                            return formData;
                        },
                        data: { "CustomIndexId": $scope.selId, "files": $scope.file, "CustomIndexName": $scope.CustomIndexName }
                    }).then(function (response) {
                        if (response.data.data) {
                            $scope.LoaderImportIndex = false;
                            $scope.file = null;
                            MFIMsg.AlertHtml("Data uploaded successfully", MFIAlertType.Information);
                            $scope.reset();
                        }
                        else {
                            $scope.LoaderImportIndex = false;
                            $scope.file = null;
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        }
                    },
                        function errorCallback(response) {
                            $scope.LoaderImportIndex = false;
                            $scope.file = null;
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                    });
                };
                $scope.ModifyIndex = function () {
                    if ($scope.CustomIndexPortfolioName == "") {
                        MFIMsg.AlertHtml("Please enter custom index name", MFIAlertType.Information);
                        return false;
                    }
                    var objCustomIndexMaster = {
                        "CustIndexId": $scope.selId, "NewCustomIndexName": $scope.CustomIndexPortfolioName
                    };
                    var ModifyIndexPort = PostModifyCustomIndexPortRecord.Call(objCustomIndexMaster);
                    ModifyIndexPort.then(function (response) {
                        if (response.data.data) {
                            localStorage.removeItem('GetAllCustomIndexPortfolioSettings');
                            GetAllCustIndexPortfolio();
                            $scope.EditVal = false;
                            MFIMsg.AlertHtml("Data saved successfully", MFIAlertType.Information);
                            $scope.searchIndexPortName = "";
                        }
                        else
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                    },
                        function errorCallback(response) {
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                        });
                };
                $scope.ModifyTableIndex = function (idSelected, selName) {
                    $scope.selId = idSelected;
                    $scope.CustomIndexPortfolioName = selName;
                    //$scope.names.selected = angular.copy(idSelected);
                    $scope.EditVal = true;
                };
                $scope.goBack = function () {
                    $scope.CustIndPortMaster = true;
                    $scope.CustIndPortDetail = false;
                };
                $scope.chooseDate = function () {
                    if ($scope.shwChooseDate == true) {
                        $scope.shwChooseDate = false;
                    }
                    else {
                        $scope.shwChooseDate = true;
                    }

                };
                $scope.ViewDetailRecords = function (idSelected) {
                    
                    $scope.CusIndexRecords = [];
                    $scope.SelectedPortMonth = [];
                    $scope.CustIndPortMaster = false;
                    $scope.CustIndPortDetail = true;
                    $scope.selId = idSelected;
                    $scope.selectedDates = [];
                    $scope.CusDetFromDate = null;
                    $scope.CusDetToDate = null;
                    $scope.CusIndDetailDateRange = null;
                    $scope.IsAllCusIndDetChecked = false;
                    ViewDetRec();
                };
                var ViewDetRec = function () {
                    var objViewCustomIndex = {
                        "CustIndexId": $scope.selId, "FrmDate": $scope.CusDetFromDate, "ToDate": $scope.CusDetToDate/*, "IsGeneric": $scope.IsGeneric*/
                    };
                    $scope.LoaderCommonCustomIndexPortDetail = true;
                    var viewIndex = PostCustomIndexPortRecord.Call(objViewCustomIndex);
                    viewIndex.then(function (response) {
                        $scope.LoaderCommonCustomIndexPortDetail = false;
                        if (response.data != null) {
                            $scope.CusIndexRecords = response.data.data;
                            $scope.blankData = $scope.CusIndexRecords[0].BlankData;

                        }
                    },
                        function errorCallback(response) {
                            $scope.LoaderCommonCustomIndexPortDetail = false;
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                        });
                }
                $scope.resetDetailIndexPort = function () {
                    $scope.selectedDates = [];
                    $scope.CusDetFromDate = null;
                    $scope.CusDetToDate = null;
                    lstSelCusIndDetail = [];
                    $scope.IsAllCusIndDetChecked = false;
                    $scope.CusIndDetailDateRange = null;
                    $scope.IsAllCusIndChecked = false;
                    if (!$scope.IsAllCusIndChecked) {
                        lstSelCusInd = [];
                        angular.forEach($scope.CusIndexRecords, function (value) {
                            value.IsChecked = false;
                        });
                    }
                    ViewDetRec();
                }
                $scope.DeleteIndex = function (idSelected, selName) {
                    MFIMsg.Confirm("You want to delete '" + selName + "'?", "MFI360 Explorer", "Ok", "Cancel").then(function successCallback(response) {
                        var objDelCustomIndex = {
                            "CustIndexId": idSelected
                        };
                        $scope.LoaderCommonCustomIndexPortfolio = true;
                        var deleteIndex = PostDeleteCustomIndexPortRecord.Call(objDelCustomIndex);
                        deleteIndex.then(function (response) {
                            if (response.data.data) {
                                localStorage.removeItem('GetAllCustomIndexPortfolioSettings');
                                GetAllCustIndexPortfolio();
                                $scope.LoaderCommonCustomIndexPortfolio = false;
                                MFIMsg.AlertHtml("Data deleted sucessfully", MFIAlertType.Success);
                            }
                            else {
                                $scope.LoaderCommonCustomIndexPortfolio = false;
                                MFIMsg.AlertHtml(response.data.Message != null ? response.data.Message : "Cannot delete data", MFIAlertType.Information);
                            }
                        },
                            function errorCallback(response) {
                                $scope.LoaderCommonCustomIndexPortfolio = false;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    });
                };
                var lstSelCusInd = [];
                $scope.chkCusIndChecked = function (event, item, IsItemClickForCheck) {
                    if (IsItemClickForCheck) {
                        lstSelCusInd.push(item.StagId);
                    }
                    else {
                        var index = lstSelCusInd.indexOf(item.StagId);
                        lstSelCusInd.splice(index, 1);
                    }
                };

                $scope.chkPortMonthChecked = function (event, item, IsItemClickForCheck) {
                    if (IsItemClickForCheck) {
                        $scope.SelectedPortMonth.push(item.PortDateDisplay);
                    }
                    else {
                        var index = $scope.SelectedPortMonth.indexOf(item.PortDateDisplay);
                        $scope.SelectedPortMonth.splice(index, 1);
                    }
                    $scope.CountDt = $scope.SelectedPortMonth.length;
                    if ($scope.CountDt > 0) {
                        $scope.shwSelectedCount = true;
                        $scope.SelectedCountTxt = $scope.CountDt + " Selected";
                    }
                    else {
                        $scope.shwSelectedCount = false;
                    }
                };

                $scope.chkAllCusIndClick = function (event) {
                    if ($scope.IsAllCusIndChecked) {
                        lstSelCusInd = [];
                        angular.forEach($scope.CusIndexRecords, function (value) {
                            value.IsChecked = true;
                            lstSelCusInd.push(value.StagId);
                        });
                    }
                    else {
                        lstSelCusInd = [];
                        angular.forEach($scope.CusIndexRecords, function (value) {
                            value.IsChecked = false;
                        });
                    }
                };

                $scope.CustomIndexPortDtlsExportToExcel = function () {

                    window.open("/Portfolio/CustomIndexPortDtlsExportToExcel");
                };

                $scope.DeleteCusIndPortDetailRecord = function () {
                    //debugger;
                    var CustDetailData = [];
                    if (lstSelCusInd.length == 0 && $scope.CusDetFromDate == null && $scope.CusDetToDate == null) {
                        MFIMsg.AlertHtml("Please select a record", MFIAlertType.Information);
                        return;
                    }
                    var objDltCustomIndex = {
                        "StagIdLst": lstSelCusInd, "FrmDate": $scope.CusDetFromDate, "ToDate": $scope.CusDetToDate
                    };
                    $scope.LoaderCommonCustomIndexPortDetail = true;
                    var delDetIndex = PostDeleteCustomIndexPortDetailRecord.Call(objDltCustomIndex);
                    delDetIndex.then(function (response) {
                        if (response.data.data) {
                            ViewDetRec();
                            $scope.LoaderCommonCustomIndexPortDetail = false;
                            angular.element('#select-all').removeAttr('checked');
                            MFIMsg.AlertHtml("Index deleted successfully", MFIAlertType.Information);
                        }
                        else {
                            $scope.LoaderCommonCustomIndexPortDetail = false;
                            MFIMsg.AlertHtml("Cannot delete data", MFIAlertType.Information);
                        }
                    },
                        function errorCallback(response) {
                            $scope.LoaderCommonCustomIndexPortDetail = false;
                            MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                        });
                    };

                $scope.closeCustomIndexPortfolio = function () {
                        $scope.CustIndPortMaster = true;
                        $scope.CustIndPortDetail = false;
                    if (screen.width <= 767) {
                        angular.element('#customIndexPortfolioDetails').hide();
                        angular.element("#settingContainer").show();
                    } else if (screen.width >= 768 && screen.width <= 980) {
                        angular.element('#customIndexPortfolioDetails').hide();
                    } else {
                        angular.element('#customIndexPortfolioDetails').delay(70).animate({
                            right: "-280px",
                            width: 0
                        }, function () {
                            angular.element('#customIndexPortfolioDetails').hide();
                        });
                    }
                };
                $scope.toggleCompositeIndexPortPanel = function () {
                    var displayWidth = window.innerWidth - 236;
                    var $block = angular.element('#expand-collapse-block-customIndexPortfolio');
                    var $details = angular.element('#customIndexPortfolioDetails');

                    if ($block.hasClass('fa-angle-double-left')) {
                        $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                        if (screen.width > 767) {
                            $details.show().animate({ width: displayWidth + "px" }, 70);
                        }
                    } else {
                        $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                        if (screen.width > 767) {
                            $details.show().animate({ width: '65%' }, 70);
                        }
                    }
                };

                },0)
            }
        }
}]);

        