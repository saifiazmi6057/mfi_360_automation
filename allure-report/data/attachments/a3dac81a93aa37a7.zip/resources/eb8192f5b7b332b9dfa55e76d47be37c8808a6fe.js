SharedDeractives.directive('tradeAnalysisDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetTradeAnalysisDetails','GetTradeAnalysisDetailsAdvance', 'MFIMsg','GetLatestTradeDate',
    function ($http, $q, $timeout, ApiInfo, GetTradeAnalysisDetails,GetTradeAnalysisDetailsAdvance, MFIMsg, GetLatestTradeDate) {
        return {
            restrict: 'AE',
            scope: {
                selectedMutualFundModel: '=',
                setfromTradeAnalysisDirective: '&',
                setfromMarketCapforLoader: '&'
            },
            templateUrl: '/PortfolioAnalysis/TradeAnalysisAdvance',
            link: function ($scope, $element, $attrs) {
                //$scope.lstMfiSchemes = $scope.lstMfiSchemes||[];
                
                //$scope.TradeDate = new Date();
                var TrDate = GetLatestTradeDate.Call();
                TrDate.then(function (response) {
                    if (angular.isUndefinedOrNullOrEmpty(response.data.data) && response.data.Success == false) {
                        $scope.SettlmntDt = true;
                        $scope.TDText = "";
                        return false; 
                    }
                    $scope.TDText = "Note: Data for Transaction in Debt and Money Market Securities is available till -";
                    $scope.TradeDate = response.data.data;
                    
                    $scope.TradeToDate = response.data.data;
                    GetRange(false, false);
                    var OptionsSingleDate = {
                        //singleDatePicker: true,
                        showDropdowns: true,
                        autoApply: true,
                        maxDate: new Date($scope.TradeToDate),
                        startDate: new Date($scope.TradeToDate),
                        endDate: new Date($scope.TradeToDate),
                        //autoUpdateInput: false,
                        locale: {
                            format: 'DD MMM YYYY'
                        }
                    };
                    //function ApplySingleDate(start, end, label) {
                    //    //$scope.TradeDate = start;
                    //}
                    function ApplyDateRange(start, end, label) {

                        FromDate = start._d;
                        ToDate = end._d;
                        GetRange(true, false);

                    }
                    $scope.TradeDateRange = response.data.data + " - " + response.data.data;
                    //angular.element('#TradeDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                    angular.element('#txtTradeDateRange').daterangepicker(OptionsSingleDate, ApplyDateRange);
                },
                    function errorCallback(response) {
                        MFIMsg.Alert("Waning!! Internal error occurred.");

                    });

                
                //var TradeFromDate = new Date();
                var TradeToDate = new Date();
               
                //TradeFromDate = TradeFromDate;
                //TradeToDate = TradeFromDate;
                var ChkDate = 0;
                var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

                //$scope.TradeFromDate = TradeFromDate.getDate() + ' ' + months[TradeFromDate.getMonth()] + ' ' + TradeFromDate.getFullYear();
                $scope.TradeToDate = TradeToDate.getDate() + ' ' + months[TradeToDate.getMonth()] + ' ' + TradeToDate.getFullYear();
                


                //function ApplyDateRange(start, end, label) {

                //        FromDate = start._d;
                //        ToDate = end._d;
                //        GetRange(true, false);

                //}

                var CollapseSelCriteria = function () {
                    angular.element("#DivTradeAnalysisDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                }
                
                function GetRange(IsDateRange, IsPortDateChge) {
                    //var DateRange = $scope.AUMMovementPortDateRange;
                    ChkDate = 0;
                    if (!IsDateRange) {
                        FromDate = new Date($scope.TradeToDate);
                        ToDate = new Date($scope.TradeToDate);
                    }
                    var diff = new Date(ToDate - FromDate);
                    TradeFromDate = FromDate.getDate() + ' ' + months[FromDate.getMonth()] + ' ' + FromDate.getFullYear();
                    TradeToDate = ToDate.getDate() + ' ' + months[ToDate.getMonth()] + ' ' + ToDate.getFullYear();
                    $scope.TradeFromDate =  TradeFromDate;
                    $scope.TradeToDate = TradeToDate;
                    // get days
                    var days = diff / 1000 / 60 / 60 / 24;
                    if (days > 15) {
                        ChkDate = 1;
                        MFIMsg.AlertHtml("Date range greater than 15 days, please select range below or equal to 15", MFIAlertType.Warning);                                         
                        return;
                    }
                }

                //angular.element('#TradeDate').daterangepicker(OptionsSingleDate, ApplySingleDate);
                //angular.element('#txtTradeDateRange').daterangepicker(OptionsSingleDate, ApplyDateRange);

                $scope.ShowTradeAnalysisReport = function () {
                    if ($scope.selectedMutualFundModel.length == 0) {
                        //MFIMsg.Alert("Please select Mutual Fund(s).", "");
                        MFIMsg.AlertHtml("Please select Mutual Fund(s).", "");   
                        return false;
                    }
                    //if (angular.isUndefinedOrNullOrEmpty(angular.element('#TradeDate').val())) {
                    //    MFIMsg.Alert("Settlement Date Can Not be Blanked.");
                    //    return false;
                    //}
                    if (ChkDate == 1) {
                        MFIMsg.Alert("please select range below or equal to 15.", "");
                        return;
                    }
                    var MFIds = [];
                    angular.forEach($scope.selectedMutualFundModel, function (option) {
                        var itemMF = JSON.parse(option);
                        MFIds.push(itemMF.Id);
                    });
                    CollapseSelCriteria();
                    var Input = {
                        "MutualFundId": MFIds,
                        "SettlementDate": angular.element('#TradeDate').val(),
                        "SettlementFromDate": TradeFromDate,
                        "SettlementToDate": TradeToDate
                    };
                    $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "TRADEANALYSIS" });
                    //angular.element("#DivTradeAnalysisDetails").hide();
                    var TradeAnalysisDetails = GetTradeAnalysisDetailsAdvance.Call(Input);
                    TradeAnalysisDetails.then(function (response) {
                        if (response.data != null && response.data.Success == false) {
                            if (response.data.Message != "")
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                            else
                                MFIMsg.Alert("Warning!! internal error occurred.");
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "TRADEANALYSIS"});
                            return false;
                        }
                        if ($scope.setfromTradeAnalysisDirective != undefined) {
                            $scope.setfromTradeAnalysisDirective({ TradeAnalysisDetails: response.data});
                        }
                        //$scope.setfromMarketCapforLoader({ ShowLoader: false });

                    },
                        function errorCallback(response) {
                            MFIMsg.Alert("Waning!! Internal error occurred.");
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "TRADEANALYSIS" });
                        });
                };
                angular.element("#btnResetTradeAnalysis").click(function (e) {
                    window.location = "/PortfolioAnalysis/Advance";
                });
            }
        };
    }]);