SharedDeractives.directive('portfolioAnalysisMarketcapDirective', ['$http', '$q', '$timeout', 'ApiInfo', 'GetMarketCapSlabByMonthYear',
    'GetCustomMarketCapSlabByLoginId', 'GetCustomPEClassificationSlabByLoginId', 'SaveCustomMarketCapSlab', 'RemoveCustomMarketCapSlab',
    'SaveCustomPEClassificationSlab', 'RemoveCustomPEClassificationSlab', 'GetAllNiftyBSEMFIIndex', 'GetMarketCapDetails', 'GetPEClassificationDetails' ,'MFIMsg',
    function ($http, $q, $timeout, ApiInfo, GetMarketCapSlabByMonthYear, GetCustomMarketCapSlabByLoginId,
        GetCustomPEClassificationSlabByLoginId, SaveCustomMarketCapSlab, RemoveCustomMarketCapSlab, SaveCustomPEClassificationSlab,
        RemoveCustomPEClassificationSlab, GetAllNiftyBSEMFIIndex, GetMarketCapDetails, GetPEClassificationDetails, MFIMsg) {
        return {
            restrict: 'AE',
            scope: {
                lstMfiSchemes: '=',
                lstPortfolioDates: '=',
                setfromMarketCapDirective: '&',
                setfromMarketCapforLoader: '&'
            },
            templateUrl: '/PortfolioAnalysis/MarketCapAdvance',
            link: function ($scope, $element, $attrs) {
                //$scope.lstMfiSchemes = $scope.lstMfiSchemes||[];
                $scope.IsMFI = true;
                $scope.IndexSetsettings = {
                    isFullHide:true,
                };
                $scope.LoaderMarketCap = false;
                $scope.IsRangeEntrySectionDisabled = true;
                $scope.MarketCapitilizationSlab = [];
                $scope.CustomMarketCapitilizationSlab = [];
                $scope.CustomPEClassificationSlab = [];
                $scope.PortDatesforPE = [];
                $scope.PortDatesforCustom = [];
                $scope.selectedAllPortDates = [];
                $scope.selectedAllPortDatesforPE = [];
                $scope.PartialIndexData = {};
                $scope.PartialIndexDataForPE = {};
                $scope.PartialIndexData.LstMFIndexes = [];
                $scope.PartialIndexDataForPE.LstMFIndexes = [];
                $scope.SelctedMFIIndexModel = [];
                $scope.SelctedMFIIndexModelForPE = [];
                $scope.IsSchemeIndex = false;
                $scope.selectedPeriod = [];

                $scope.UserSetsettingsPortDateforCustom = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: false,
                    ddltext: "Select Portfolio Period",
                    Keyprop: "MonthYear",
                    Valueprop: "MonthYear",
                };
                $scope.UserSetsettingsDetailedMarketCap = {
                    scrollableHeight: '200px',
                    scrollable: true,
                    enableSearch: false,
                    showMultiCheckAll: false,
                    ddltext: "Select Period",
                    Keyprop: "MonthYear",
                    Valueprop: "MonthYear",
                };
                $scope.PortfolioDateEvent = {
                    onItemSelect: function () {
                        $scope.GetSlabByMonthYearForMarketCap();
                    },
                    onItemDeselect: function () {
                        $scope.GetSlabByMonthYearForMarketCap();
                    },
                    onSelectAll: function () {
                        $scope.GetSlabByMonthYearForMarketCap();
                    },
                    onDeselectAll: function () {
                        $scope.GetSlabByMonthYearForMarketCap();
                    }
                };
                $scope.LstAllPortfolioDates = $scope.lstPortfolioDates.map(function (a) {
                    var tempdate1 = JSON.parse(JSON.stringify(a));
                    var tempdate2 = JSON.parse(JSON.stringify(a));
                    var tempdate3 = JSON.parse(JSON.stringify(a));
                    $scope.SwitchForPortDateData = "IsloadedPortDateData";
                    $scope.PortDatesforCustom.push(tempdate2);
                    $scope.PortDatesforPE.push(tempdate3);
                    return tempdate1;
                });
                $scope.SwitchForPortDateDataCustomPE = "IsloadedPortDateDataForCustomPE";
                //$scope.selectedPeriod = $scope.LstAllPortfolioDates[0];
                $scope.GetSlabByMonthYearForMarketCap = function () {
                    if (!angular.isUndefinedOrNullOrEmpty($scope.selectedPeriod)) {
                        $scope.LoaderMarketCap = true;
                        var DatesMonthYear = [];
                        angular.forEach($scope.selectedPeriod, function (value) {
                            DatesMonthYear.push(new Date("01 " + value.MonthYear));
                        });
                        let maximumDate = new Date(Math.max.apply(null, DatesMonthYear));
                        if (new Date(maximumDate) < new Date("01 May 2018")) {
                            angular.element("#thSlabCaption").text('Slab Caption MFI')
                        }
                        else {
                            angular.element("#thSlabCaption").text('Slab Caption SEBI')
                        }
                        var JSONDATA = {
                            //"MonthYear": $scope.selectedPeriod.MonthYear
                            "MonthYear": maximumDate.toLocaleString('mmm', { month: 'short' }) + " " + maximumDate.getFullYear()
                        };
                        var GetMarketCapSlab = GetMarketCapSlabByMonthYear.Call(JSONDATA);
                        GetMarketCapSlab.then(function successCallback(response) {
                            if (response.data != null)
                                $scope.MarketCapitilizationSlab = response.data.data;
                            else
                                $scope.MarketCapitilizationSlab = [];
                            $scope.LoaderMarketCap = false;
                        },
                            function errorCallback(response) {
                                $scope.LoaderMarketCap = false;
                                MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            });
                    }
                    else {
                        $scope.MarketCapitilizationSlab = [];
                    }
                };
                $scope.GetSlabByMonthYearForMarketCap();
                $scope.SetMFIOrCustom = function (tag) {
                    if (tag == 'MFI') {
                        var Element = document.getElementById("CustomDiv");
                        if (Element != null)
                            Element.style.visibility = 'hidden';
                        var Element = document.getElementById("SebiDiv");
                        if (Element != null)
                            Element.style.visibility = 'visible';
                        $scope.IsMFI = true;
                        $scope.IsRangeEntrySectionDisabled = true;
                        ////$("#DivMarketCapIndex :input").attr("disabled", "disabled");
                        angular.forEach($scope.PartialIndexData.LstMFIndexes, function (value) {
                            value.IsDisabled = true;
                            value.IsChecked = false;
                            $scope.SelctedMFIIndexModel = [];
                        });
                        angular.element("#DivMarketCapIndex input[id^=" + "MarketCapIndexSelection" + "chkDirectiveIndex_Mfi_").prop("checked", false);
                        angular.element("#DivMarketCapIndex input[id^=" + "MarketCapIndexSelection" + "chkDirectiveIndex_Mfi_").prop("disabled", true);
                    }
                    else {
                        var Element = document.getElementById("CustomDiv");
                        if (Element != null)
                            Element.style.visibility = 'visible';
                        var Element = document.getElementById("SebiDiv");
                        if (Element != null)
                            Element.style.visibility = 'hidden';
                        $scope.IsMFI = false;
                        $scope.IsRangeEntrySectionDisabled = false;
                        angular.forEach($scope.PartialIndexData.LstMFIndexes, function (value) {
                            value.IsDisabled = false;
                            value.IsChecked = false;
                            $scope.SelctedMFIIndexModel = [];
                        });
                        angular.element("#DivMarketCapIndex input[id^=" + "MarketCapIndexSelection" + "chkDirectiveIndex_Mfi_").prop("disabled", false);
                    }
                };
                $timeout(function () {
                    angular.element("#DivMarketCapIndex input[id^=" + "MarketCapIndexSelection" + "chkDirectiveIndex_Mfi_").prop("disabled", true);
                }, 100);
                var GetCustomMarketSlab = GetCustomMarketCapSlabByLoginId.Call();
                GetCustomMarketSlab.then(function (response) {
                    $scope.CustomMarketCapitilizationSlab = response.data.data = null ? [] : response.data.data;
                });
                var GetCustomPESlab = GetCustomPEClassificationSlabByLoginId.Call();
                GetCustomPESlab.then(function (response) {
                    $scope.CustomPEClassificationSlab = response.data.data = null ? [] : response.data.data;
                });
                var MFIIndexEntity = { isDiscardRestrictedIndex: true };
                var AllMFIIndex = GetAllNiftyBSEMFIIndex.Call(MFIIndexEntity);
                AllMFIIndex.then(function successCallback(response) {
                    $scope.PartialIndexData.LstMFIndexes = response.data.data;
                    $scope.PartialIndexDataForPE.LstMFIndexes = $scope.PartialIndexData.LstMFIndexes.map(function (a) {
                        a.IsDisabled = true;
                        var tempval = JSON.parse(JSON.stringify(a));
                        tempval.IsDisabled = false;
                        return tempval;
                    });
                },
                    function errorCallback(response) {
                    });
                $scope.SaveCustomMarketCapitalizationSlab = function () {
                    if (angular.element("#txtMarketCapCaption").val() == "") {
                        MFIMsg.AlertHtml("Please enter caption", MFIAlertType.Information);
                        return false;
                    }
                    if (angular.element("#txtMarketCapCaption").val().length > 50) {
                        MFIMsg.AlertHtml("Maximum 50 characters are allowed for caption.", MFIAlertType.Information);
                        return false;
                    }
                    if (angular.element("#txtmarketCapFromRange").val() == "") {
                        MFIMsg.AlertHtml("Please enter  'Range From' Value", MFIAlertType.Information);
                        return false;
                    }
                    var JSONDATA = {
                        "Caption": angular.element("#txtMarketCapCaption").val(),
                        "FromRange": angular.element("#txtmarketCapFromRange").val(),
                        "ToRange": angular.element("#txtmarketCapToRange").val(),
                        "FromOperator": angular.element("#CustomFromOperator").val(),
                        "ToOperator": angular.element("#CustomToOperator").val()
                    };
                    $scope.LoaderMarketCap = true;
                    var MarketCapSlabAfterSave = SaveCustomMarketCapSlab.Call(JSONDATA);
                    MarketCapSlabAfterSave.then(function successCallback(response) {
                        if (response.data.data == null && response.data.Message != "") {
                            //var msg = $sce.parseAsHtml(response.data.Message);
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Warning);
                            $scope.LoaderMarketCap = false;
                            return false;
                        }
                        $scope.CustomMarketCapitilizationSlab = response.data.data;
                        angular.element("#txtMarketCapCaption").val('');
                        angular.element("#txtmarketCapFromRange").val('');
                        angular.element("#txtmarketCapToRange").val('');
                        MFIMsg.AlertHtml("Custom range is created successfully.", MFIAlertType.Success);
                        $scope.LoaderMarketCap = false;
                    },
                        function errorCallback(response) {
                            $scope.LoaderMarketCap = false;
                            MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                        });
                };
                $scope.RemoveSlab = function (RangeId) {
                    MFIMsg.Confirm("You want to delete this slab.Please confirm.").then(function successCallback(response) {
                        var JSONDATA = { "Id": RangeId };
                        $scope.LoaderMarketCap = true;
                        var CustomMarketCapSlabAfterRemove = RemoveCustomMarketCapSlab.Call(JSONDATA);
                        CustomMarketCapSlabAfterRemove.then(function successCallback(response) {
                            $scope.CustomMarketCapitilizationSlab = $scope.CustomMarketCapitilizationSlab.filter(function (item) {
                                return item.RangeId != RangeId;
                            });
                            MFIMsg.AlertHtml("Custom range is deleted successfully", MFIAlertType.Success);
                            $scope.LoaderMarketCap = false;
                        },
                            function errorCallback(response) {
                                $scope.LoaderMarketCap = false;
                                MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            });
                    });
                };
                $scope.SaveCustomPEClassificationSlab = function () {
                    if (angular.element("#txtPEClassificationCaption").val() == "") {
                        MFIMsg.AlertHtml("Please enter caption", MFIAlertType.Information);
                        return false;
                    }
                    if (angular.element("#txtPEClassificationCaption").val().length>50) {
                        MFIMsg.AlertHtml("Maximum 50 characters are allowed for caption.", MFIAlertType.Information);
                        return false;
                    }
                    if (angular.element("#txtPEClassificationFromRange").val() == "") {
                        MFIMsg.AlertHtml("Please enter  'Range From' value", MFIAlertType.Information);
                        return false;
                    }
                    var JSONDATA = {
                        "Caption": angular.element("#txtPEClassificationCaption").val(),
                        "FromRange": angular.element("#txtPEClassificationFromRange").val(),
                        "ToRange": angular.element("#txtPEClassificationRangeTo").val(),
                        "FromOperator": angular.element("#CustomPEFromOperator").val(),
                        "ToOperator": angular.element("#CustomPEToOperator").val()
                    };
                    $scope.LoaderMarketCap = true;
                    var PEClassificationSlabAfterSave = SaveCustomPEClassificationSlab.Call(JSONDATA);
                    PEClassificationSlabAfterSave.then(function successCallback(response) {
                        if (response.data.data == null && response.data.Message != "") {
                            MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Warning);
                            $scope.LoaderMarketCap = false;
                            return false;
                        }
                        $scope.CustomPEClassificationSlab = response.data.data;
                        angular.element("#txtPEClassificationCaption").val('');
                        angular.element("#txtPEClassificationFromRange").val('');
                        angular.element("#txtPEClassificationRangeTo").val('');
                        MFIMsg.AlertHtml("Custom range is created successfully.", MFIAlertType.Success);
                        $scope.LoaderMarketCap = false;
                    },
                        function errorCallback(response) {
                            $scope.LoaderMarketCap = false;
                            MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                        });
                };
                $scope.RemovePESlab = function (RangeId) {
                    MFIMsg.Confirm("You want to delete this slab").then(function successCallback(response) {
                        var JSONDATA = { "Id": RangeId };
                        $scope.LoaderMarketCap = true;
                        var CustomPEclassificationSlabAfterRemove = RemoveCustomPEClassificationSlab.Call(JSONDATA);
                        CustomPEclassificationSlabAfterRemove.then(function successCallback(response) {
                            $scope.CustomPEClassificationSlab = $scope.CustomPEClassificationSlab.filter(function (item) {
                                return item.RangeId != RangeId;
                            });
                            MFIMsg.AlertHtml("Custom range is deleted successfully", MFIAlertType.Success);
                            $scope.LoaderMarketCap = false;
                        },
                            function errorCallback(response) {
                                $scope.LoaderMarketCap = false;
                                MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            });
                    });
                };

                var CollapseSelCriteria = function () {
                    angular.element("#DivMarketCapPEDetails").hide();
                    angular.element('#PortfolioAnalysisappliedFilter').show();
                    angular.element('#PortfolioAnalysisfilter').show().removeClass('filter-overlap');
                    angular.element('#PortfolioAnalysisbackToFilter').removeClass('hidden').show();
                    angular.element('#PortfolioAnalysisfilter').slideUp();
                    angular.element('#PortfolioAnalysiscloseFilter').hide();
                };

                $scope.ShowMarketCapReport = function () {
                    var ArrPortDates = [];
                    if ($scope.IsMFI) {
                        //ArrPortDates.push($scope.selectedPeriod.MonthYear);
                        angular.forEach($scope.selectedPeriod, function (value, index) {
                            ArrPortDates.push(value.MonthYear);
                        });
                    }
                    else {
                        angular.forEach($scope.selectedAllPortDates, function (value, index) {
                            ArrPortDates.push(value.MonthYear);
                        });
                    }
                    if (ArrPortDates.length == 0) {
                        MFIMsg.AlertHtml("Please select portfolio periods", MFIAlertType.Information);
                        return false;
                    }
                    if (ArrPortDates.length > 84) {
                        MFIMsg.AlertHtml("You can select maximum " + 84 + " periods", MFIAlertType.Information);
                        return false;
                    }

                    if ($scope.lstMfiSchemes.length == 0) {
                        MFIMsg.AlertHtml("Please select schemes", MFIAlertType.Information);
                        return false;
                    }
                    //if ($scope.lstMfiSchemes.length > MaxSchemeSelectionAllowed) {
                    //    MFIMsg.AlertHtml("You can select only " + MaxSchemeSelectionAllowed + " schemes to show the report", MFIAlertType.Information);
                    //    return false;
                    //}
                    var SchemeList = [];
                    angular.forEach($scope.lstMfiSchemes, function (option) {
                        var itemScheme = JSON.parse(option);
                        SchemeList.push(itemScheme.Id);
                        //SchemeList.push({ Id: itemScheme.Id, Name: itemScheme.Name });
                    });
                    var IndexList = [];
                    angular.forEach($scope.SelctedMFIIndexModel, function (option) {
                        var itemMFI = JSON.parse(option);
                        IndexList.push(itemMFI.Id);
                        //IndexList.push({ Id: itemMFI.Id, Name: itemMFI.Name });
                    });
                    CollapseSelCriteria();
                    var JSONDATA = {
                        "IsMFI": $scope.IsMFI,
                        "PortfolioDates": ArrPortDates, "IsButtonClicked": true,
                        //"LstSelectedSchemes": SchemeList,
                        //"LstMFIndexes": IndexList,
                        "SchemeIds": SchemeList,
                        "IndexIds": IndexList,
                        "IsAdvance": true
                    };
                    //angular.element("#DivMarketCapPEDetails").hide();
                    //$scope.LoaderMarketCap = true;
                    $scope.setfromMarketCapforLoader({ ShowLoader: true,tabname:"MARKETCAP" });
                    var MarCapitalizationDetails = GetMarketCapDetails.Call(JSONDATA);
                    MarCapitalizationDetails.then(function successCallback(response) {
                        if (response.data != null && response.data.Success == false) {
                            if (response.data.Message != "")
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Warning);
                            else
                                MFIMsg.AlertHtml("Warning!! internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "MARKETCAP" });
                            return false;
                        }
                        //angular.element("#DivMarketCapPEDetails").show();
                        //angular.element("#divMarketCapDetails").show();
                        //location.hash = "#tblMarketCapData";
                        //$scope.LoaderMarketCap = false;

                        if ($scope.setfromMarketCapDirective != undefined) {
                            $scope.setfromMarketCapDirective({ MarketCapDataDetails: response.data,IsMarketCap:true});
                        }
                        //$scope.setfromMarketCapforLoader({ ShowLoader: false });
                    },
                        function errorCallback(response) {
                            MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "MARKETCAP" });
                        });
                };
                $scope.ShowPEClassification = function () {
                    var ArrPortDates = [];
                    angular.forEach($scope.selectedAllPortDatesforPE, function (value, index) {
                        ArrPortDates.push(value.MonthYear);
                    });
                    if (ArrPortDates.length == 0) {
                        MFIMsg.AlertHtml("Please select portfolio periods", MFIAlertType.Information);
                        return false;
                    }
                    if (ArrPortDates.length > 84) {
                        MFIMsg.AlertHtml("You can select maximum " + 84 + " periods", MFIAlertType.Information);
                        return false;
                    }
                    if ($scope.lstMfiSchemes.length == 0) {
                        MFIMsg.AlertHtml("Please select schemes", MFIAlertType.Information);
                        return false;
                    }
                    if ($scope.lstMfiSchemes.length > MaxSchemeSelectionAllowed) {
                        MFIMsg.AlertHtml("You can select only " + MaxSchemeSelectionAllowed + " schemes to show the report", MFIAlertType.Information);
                        return false;
                    }
                    var SchemeList = [];
                    angular.forEach($scope.lstMfiSchemes, function (option) {
                        var itemScheme = JSON.parse(option);
                        SchemeList.push(itemScheme.Id);
                        //SchemeList.push({ Id: itemScheme.Id, Name: itemScheme.Name });
                    });
                    if (SchemeList.length == 0) {
                        MFIMsg.AlertHtml("Please select schemes", MFIAlertType.Information);
                        return false;
                    }
                    var IndexList = [];
                    angular.forEach($scope.SelctedMFIIndexModelForPE, function (option) {
                        var itemMFI = JSON.parse(option);
                        IndexList.push(itemMFI.Id);
                        //IndexList.push({ Id: itemMFI.Id, Name: itemMFI.Name });
                    });
                    CollapseSelCriteria();
                    var JSONDATA = {
                        "PortfolioDates": ArrPortDates, "IsButtonClicked": true,
                        //"LstSelectedSchemes": SchemeList,
                        //"LstMFIndexes": IndexList,
                        "SchemeIds": SchemeList,
                        "IndexIds": IndexList,
                        "IsAdvance": true
                    };
                    //angular.element("#DivMarketCapPEDetails").hide();
                    //$scope.LoaderMarketCap = true;
                    $scope.setfromMarketCapforLoader({ ShowLoader: true, tabname: "MARKETCAP"});
                    var PEClassificationDetails = GetPEClassificationDetails.Call(JSONDATA);
                    PEClassificationDetails.then(function successCallback(response) {
                        if (response.data != null && response.data.Success == false) {
                            if (response.data.Message != "")
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Warning);
                            else
                                MFIMsg.AlertHtml("Warning!! internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "MARKETCAP" });
                            return false;
                        }
                        IsSubmitlickForPE = true;
                        //angular.element("#DivMarketCapPEDetails").show();
                        //angular.element("#divPEClassificationDetails").show();
                        //location.hash = "#tblPEClassificationData";
                        if ($scope.setfromMarketCapDirective != undefined) {
                            $scope.setfromMarketCapDirective({ MarketCapDataDetails: response.data, IsMarketCap: false });
                        }
                        //$scope.setfromMarketCapforLoader({ ShowLoader: false });
                    },
                        function errorCallback(response) {
                            MFIMsg.AlertHtml("Waning!! Internal error occurred.", MFIAlertType.Error);
                            $scope.setfromMarketCapforLoader({ ShowLoader: false, tabname: "MARKETCAP" });
                        });
                };
                
                angular.element("#btnResetMarketCap").click(function (e) {
                    window.location = "/PortfolioAnalysis/Advance";
                });
                var IsSubmitlickForPE = false;
                angular.element("#txtmarketCapFromRange,#txtmarketCapToRange,#txtPEClassificationFromRange,#txtPEClassificationRangeTo").bind('keypress', function (event) {
                    //return CheckNumericorFloat(event, this.value);
                    if (this.value.length >= 10)
                        return false;
                    return CheckNumeric(event, this.value);
                });
                angular.element("#MarketCap-tab").click(function (e) {
                    angular.element("#btnGetMarketCap").show();
                    angular.element("#btnGetPEClassification").hide();
                    angular.element("#ExportMarketCap").show();
                    angular.element("#ExportPEClassification").hide();
                    angular.element("#divMarketCapDetails").show();
                    angular.element("#divPEClassificationDetails").hide();
                });
                angular.element("#PEClassification-tab").click(function (e) {
                    angular.element("#btnGetPEClassification").show();
                    angular.element("#btnGetMarketCap").hide();
                    angular.element("#ExportMarketCap").hide();
                    angular.element("#ExportPEClassification").show();
                    angular.element("#divMarketCapDetails").hide();
                    if (IsSubmitlickForPE) {
                        angular.element("#DivMarketCapPEDetails").show();
                        angular.element("#divPEClassificationDetails").show();
                    }
                    else {
                        angular.element("#DivMarketCapPEDetails").hide();
                        angular.element("#divPEClassificationDetails").hide();
                    }
                });
            }
        };
    }]);