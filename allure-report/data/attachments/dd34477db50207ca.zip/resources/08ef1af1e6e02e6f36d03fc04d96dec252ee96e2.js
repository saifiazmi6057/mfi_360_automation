//var FilterNFO = angular.module('FilterNFO', []);

SharedCommon.filter('NFOSerchFilter', function ($filter) {
    return function (items, AmcIds, NatureID, SubNatureId, StructureId, daterange) {
     

        var filtered = [];
        var Amcfiltered = [];
        var Naturefiltered = [];
        var SubNaturefiltered = [];
        var Structurefiltered = [];

        if (AmcIds.length > 0) {

            angular.forEach(AmcIds, function (id) {

                angular.forEach(items, function (itm) {

                    if (itm.AmcId == id.AMCId) {
                        Amcfiltered.push(itm);

                    }
                });
            });

        }
        else
        {
            Amcfiltered = items;
        }
        if (NatureID !== undefined && NatureID!=null) 
        {
            Naturefiltered = $filter('filter')(Amcfiltered, { NatureID: NatureID }, true);
        }
        else {
            Naturefiltered = Amcfiltered;
        }
        if (SubNatureId !== undefined && SubNatureId != null) {
            SubNaturefiltered = $filter('filter')(Naturefiltered, { SubNatureId: SubNatureId }, true);
        }
        else {
            SubNaturefiltered = Naturefiltered;
        }
        if (StructureId !== undefined && StructureId != null) {
            Structurefiltered = $filter('filter')(SubNaturefiltered, { StructureId: StructureId }, true);
        }
        else {
            Structurefiltered = SubNaturefiltered;
        }
        if (daterange != null)
        {
            angular.forEach(Structurefiltered, function (Amcfiltered) {
           
                if (new Date(Amcfiltered.NFOStartDate) >= daterange.frmdate && daterange.todate <= new Date(Amcfiltered.NFOEndDate) ) {
                    filtered.push(Amcfiltered);

                }
            });

        }
        else
        {
            filtered = Structurefiltered;
        }
      
        return filtered;
    };
});