//var ServiceAMC = angular.module('ServiceAMC', []);

//ServiceAMC.config(BaseServiceConfig);


SharedServices.service('GetMaxPortfolioDateForSelectedAMC', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiAmc/GetMaxPortfolioDateForSelectedAMC?Amcid='+id,
            method: 'GET'
        });
    }

}]);



SharedServices.service('AMCBasicDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
       
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCBasicDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('AUMDataForGraph', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AUMDataForGraph',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);




SharedServices.service('SponsorWiseAUMData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/SponsorWiseAUMData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);




SharedServices.service('T15B15AUMDataPerAMC', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/T15B15AUMDataPerAMC',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('AMCNatureAllocationPieChart', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCNatureAllocationPieChart',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('AMCNatureAllocationForFundTable', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCNatureAllocationForFundTable',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('AMCSectorwiseAllocationDrillDown', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCSectorwiseAllocationDrillDown',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('AMCSectorWiseCompanyAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCSectorWiseCompanyAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('AMCCreditQualityPieDrillDown', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCCreditQualityPieDrillDown',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('CreditQualityWiseRatingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/CreditQualityWiseRatingSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('MaturityProfileDetailsBarChart', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/MaturityProfileDetailsBarChart',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('MatProfileWiseInstrumentAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/MatProfileWiseInstrumentAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('MatProfileWiseInstrumentWiseFundAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/MatProfileWiseInstrumentWiseFundAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('AMCCompanyWiseFundAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiAmc/AMCCompanyWiseFundAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetAMCCreditQualityBasicInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetAMCCreditQualityBasicInfo',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetAMCCreditQualityReturnsInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetAMCCreditQualityReturnsInfo',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetAMCCreditQualityRiskRatiosInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetAMCCreditQualityRiskRatiosInfo',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetAMCCreditQualityPortfolioInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetAMCCreditQualityPortfolioInfo',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetExportToExcelCreditQTY', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {

    this.Call = function (obj1,obj2) {
        return $http({
            method: "post",
            url: '/AMC/ExportToExcelForCreaditQty' + '?tablename=' + obj1 + "&AMCID=" + obj2,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $httpParamSerializerJQLike(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('AMCGetSectorExposerDetailsService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetSectorExposerDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('AMCGetFundsDetailsService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetFundsDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);
SharedServices.service('AMCGetKeyPersonnelService', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetKeyPersonnel',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

SharedServices.service('AMCGetRiskRatioGraphService', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiAmc/GetRiskRatioGraph',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);