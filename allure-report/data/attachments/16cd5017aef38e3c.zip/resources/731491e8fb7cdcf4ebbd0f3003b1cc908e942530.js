SharedDeractives.directive('mutualFundSelectionDirective', ['$http', function ($http) {
    return {        
        restrict: 'AE',
        scope: {
            selectedPartialText: '=',
            selectedMutualFundModel: '=',
            options: '=',
            extraSettings: '=',
            setAllInputMFData: '&',
        },

        templateUrl: '/Portfolio/MutualFundSelection',
        link: function ($scope, $element, $attrs) {
            $scope.IsMutualFundAllChecked = false;
            $scope.mfattrid = $attrs.id;
            $scope.settings = {
                IsSingleSelection: ($scope.extraSettings != undefined && $scope.extraSettings.IsSingleSelection) || false
            };
            $scope.chkMutualFundClick = function (event, Id, Name, IsItemClickForCheck) {
                //debugger;
                var itemMutualFund = JSON.stringify({ Id: Id, Name: Name });
                if (IsItemClickForCheck) {
                    if ($scope.settings.IsSingleSelection) {
                        $scope.selectedMutualFundModel = [];
                        angular.forEach($scope.options.LstMutualFunds, function (value) {
                            value.IsChecked = value.Id == Id ? true : false;
                        });
                    }
                    $scope.selectedMutualFundModel.push(itemMutualFund);
                }
                else {
                    var index = $scope.selectedMutualFundModel.indexOf(itemMutualFund);
                    $scope.selectedMutualFundModel.splice(index, 1);
                    if ($scope.settings.IsSingleSelection) {
                        angular.forEach($scope.options.LstMutualFunds, function (value) {
                            value.IsChecked = false;
                        });
                    }
                }
                $scope.IsMutualFundAllChecked = $scope.options.LstMutualFunds.length == $scope.selectedMutualFundModel.length;       
                $scope.setAllInputMFData({ MFModel: $scope.selectedMutualFundModel });
            };
            $scope.checkAssociatedMFNameCheckBox = function (idindex, attrid) {
                    setTimeout(function () {
                        angular.element("#" + attrid + "chkDirectiveIndex_MFName_" + idindex).find("fieldset").trigger('click');
                    }, 0);
            };
            $scope.chkMutualFundAllClick = function (event) {
                //debugger;
               
               
                if ($scope.IsMutualFundAllChecked) {                
                      
                    $scope.selectedMutualFundModel = [];
                  
                    angular.forEach($scope.options.LstMutualFunds, function (value) {
                      
                        $scope.selectedMutualFundModel.push(JSON.stringify({ Id: value.Id, Name: value.Name }));
                            value.IsChecked = true;
                           
                        });
                
                   
                }
                else {
                    $scope.selectedMutualFundModel = [];
                    angular.forEach($scope.options.LstMutualFunds, function (value) {
                        value.IsChecked = false;
                    });
                }
                $scope.setAllInputMFData({ MFModel: $scope.selectedMutualFundModel });
            };            
        }
    };
}]);
