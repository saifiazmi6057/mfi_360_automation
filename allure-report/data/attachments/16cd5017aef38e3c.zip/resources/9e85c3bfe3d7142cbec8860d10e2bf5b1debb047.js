SharedServices.service('FetchUniqueStockDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiUniqueStocks/FetchUniqueStockDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);