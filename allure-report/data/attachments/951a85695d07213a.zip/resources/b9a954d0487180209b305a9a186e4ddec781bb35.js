//var ServiceNFO = angular.module('ServiceNFO', []);

//ServiceNFO.config(BaseServiceConfig);


SharedServices.service('GetAllNFO', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    //this.Call = function () {
    //    return $http({
    //        url: ApiInfo.BaseApiUrl +'ApiNFO/GetAllNFO',
    //        method: 'GET'
    //    });
    //}
    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNFO/FetchAllNFO',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);


SharedServices.service('GetNFODetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiNFO/GetNFODetails?FundId=' + id,
            method: 'GET'
        });
    }

}]);


SharedServices.service('FetchNFOSimilarFund', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiNFO/FetchNFOSimilarFund',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetNFOWhoCanInvest', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiNFO/GetNFOWhoCanInvest?FundId=' + id,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetDefaultSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFetchUserBasicSettings',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetSubscriptionDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiNFO/GetSubscriptionDate',
            method: 'GET'
        });
    }

}]);