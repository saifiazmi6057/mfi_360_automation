SharedServices.service('RiskQuestionerInfoAPI', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnalytics/GetRiskQuestions',
            method: 'GET'
        });
    }

}]);

SharedServices.service('RiskQuestionerSaveAPI', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Input) {
        //console.log('questionerAns api service call ', questionerAns);
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnalytics/SubmitRiskQuestions',
            data: $.param( Input ),
            method: 'POST'
        });
    }

}]);

//SharedServices.service('GetStyleBox', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (fundId, portfolioDate) {
//        var data2push = {};
//        data2push.FundId = fundId;
//        data2push.PortfolioDate = portfolioDate;
//        return $http({
//            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetStyleBox',
//            data: $.param(data2push),
//            method: 'POST'
//        });
//    }
//}]);


SharedServices.service('GetDataStatusInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Input) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnalytics/FetchDataStatusInfo',
            data: $.param(Input),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetPortfolioDataStatusInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Input) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiAnalytics/GetPortfolioDataStatusInfo',
            data: $.param(Input),
            method: 'POST'
        });
    }
}]);
