//var ServiceCreditratingMonitor = angular.module('ServiceCreditratingMonitor', []);

//ServiceCreditratingMonitor.config(BaseServiceConfig);

//SharedServices.service('GetAllMFIIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (obj) {
//        return $http({
//            method: "get",
//            url: ApiInfo.BaseApiUrl +'ApiSchemePerofamance/GetAllMFIIndex',
//        });
//    }
//}]);
SharedServices.service('GetPotfolioDatesByFundId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCreditRatingAdv/FetchPotfolioDatesByFundId',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetUserSelectedFunds', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchUserSelectedFunds',
            //data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetAllPotfolioDates', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Years) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/GetAllPotfolioDates?Years=' + Years,
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetPotfolioDatesByMFId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchPotfolioDatesByMFId',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetUserRatingSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCreditRatingAdv/FetchUserRatingSet',
            //data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetCreditRatingCompanyWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchCreditRatingForCompanyWise',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetCreditRatingFundWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCreditRatingAdv/FetchCreditRatingFundWise',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetCreditRatingForCompareFundWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchCreditRatingForCompareFundWise',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);
SharedServices.service('GetCreditRatingForCompareIndustryWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchCreditRatingForCompareIndustryWise',
            data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);

SharedServices.service('FetchMyWatchListSelectedFunds', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCreditRatingAdv/FetchMyWatchListSelectedFunds',
            //data: $.param(obj),
            method: 'POST',
            dataType: "json"
        });
    }
}]);