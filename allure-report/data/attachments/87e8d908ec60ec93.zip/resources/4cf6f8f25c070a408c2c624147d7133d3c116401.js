
//var serviceFundDashboard = angular.module('serviceFundDashboard', ['SharedCommon']);

//SharedServices.config(BaseServiceConfig);

SharedServices.service('GetFundOthersInfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (fundId) {
        //alert(ApiInfo.BaseApiUrl);
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFundOthersInfo?FundId=' + fundId,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetStyleBox', ['$http','ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (fundId, portfolioDate) {
        var data2push = {};
        data2push.FundId = fundId;
        data2push.PortfolioDate = portfolioDate;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetStyleBox',
            data: $.param(data2push),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetDividendSchemeByFundId', ['$http','ApiInfo', function ($http, ApiInfo) {

    this.Call = function (fundId) {
        var data2push = { "FundId": fundId, };
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetDividendSchemeByFundId?FundId=' + fundId,
            //data: $.param(data2push),
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetDividendHist', ['$http','ApiInfo', function ($http, ApiInfo) {
    
    this.Call = function (SchemeId) {
        
        var DividendParam = {};
        DividendParam.SchemeId = SchemeId;
      //  DividendParam.LatestCount = LatestCount;
        return $http({
            url: ApiInfo.BaseApiUrl + '/ApiCommonExplorer/GetDividend',
            data: $.param(DividendParam),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetTopFundReturnComperation', ['$http','ApiInfo', function ($http, ApiInfo) {

    this.Call = function (SchemeId, TopfundCount) {
        
        var TopfundInput = {};
        TopfundInput.SchemeIDs = SchemeId;
        TopfundInput.TopfundCount = TopfundCount;
       // TopfundInput.LoginId = LoginId;
        //TopfundInput.RETDF = RETDF;
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/TopFundReturnComperation',
            data: $.param(TopfundInput),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAddendum', ['$http','ApiInfo', function ($http, ApiInfo) {

    this.Call = function (FundId, TopCount, LoginId) {

        var AddendumInputs = {};
        AddendumInputs.FundId = FundId;
        AddendumInputs.TopCount = TopCount;
        AddendumInputs.LoginId = LoginId;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAddendum',
            data: $.param(AddendumInputs),
            method: 'POST'
        });
    }
}]);
SharedServices.service('GetNewsDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (MfiNewsId, LoginId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetNewsDetails?MfiNewsId=' + MfiNewsId + '&LoginId=' + LoginId,
           // data: $.param(NewsInputs),
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetNews', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId, TopCount, LoginId) {
        
        var NewsInputs = {};
        NewsInputs.FundId = FundId;
        NewsInputs.LoginId = LoginId;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetNews',
            data: $.param(NewsInputs),
            method: 'POST'
        });
    }
}]);
SharedServices.service('GetPePbDivYieldMarketcap', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, LoginId) {

        return $http({
            //url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetPePbDivYieldMarketcap?SchemeId=' + SchemeId + '&LoginId=' + LoginId,
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetPePbDivYieldMarketcap?SchemeId=' + SchemeId,
            //data: $.param(NewsInputs),
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetCreditRatingQualityByFundId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId) {
        var ObjCreditRatingQualityByFundId = {};
        ObjCreditRatingQualityByFundId.FundId = FundId;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FetchCreditRatingQualityByFundId',
            data: $.param(ObjCreditRatingQualityByFundId),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetFundPortfolio', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, FundId, PortDate, AvgMaturityMonthCount, TopSectorCount, Sector_Level) {
       // debugger;
        var FundPortfolioParam = {};
        FundPortfolioParam.SchemeId = SchemeId;
        FundPortfolioParam.FundId = FundId;
        FundPortfolioParam.PortDate = PortDate;
        //FundPortfolioParam.LoginId = LoginId;
        //FundPortfolioParam.OTHDF = OTHDF;
        FundPortfolioParam.AvgMaturityMonthCount = AvgMaturityMonthCount;
        FundPortfolioParam.TopSectorCount = TopSectorCount;
        FundPortfolioParam.SectorLevel = Sector_Level;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFundPortfolio',
            data: $.param(FundPortfolioParam),
            method: 'POST'
        });
    }
}]);

//SharedServices.service('GetRatioGraphData', ['$http','ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (SchemeId) {
//        return $http({
//            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetStatisticalData?SchemeId=' + SchemeId,
//            // data: $.param(FundPortfolioParam),
//            method: 'GET'
//        });
//    }
//}]);

SharedServices.service('GetRatioGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetStatisticalDataNew?SchemeId=' + SchemeId,
            // data: $.param(FundPortfolioParam),
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetPreCalculatedSchemeIndexRatio', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, LoginId) {
        //debugger;
        return $http({
            //url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetPreCalculatedSchemeIndexRatio?SchemeId=' + SchemeId + '&LoginId=' + LoginId,
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetPreCalculatedSchemeIndexRatio?SchemeId=' + SchemeId,
            // data: $.param(FundPortfolioParam),
            method: 'GET'
        });
    }
}]);

//SharedServices.service('GetPreCalculatedSchemeIndexRatio2ndlook', ['$http','ApiInfo', function ($http, ApiInfo) {
//    this.Call = function (SchemeId, LoginId) {
//        //debugger;
//        return $http({
//            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetPreCalculatedSchemeIndexRatio2ndlook?SchemeId=' + SchemeId + '&LoginId=' + LoginId,
//            // data: $.param(FundPortfolioParam),
//            method: 'GET'
//        });
//    }
//}]);


//
//------1st Page

SharedServices.service('GetReportWiseDefaultScheme', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (LoginId, UIAction, UIController) {
        var ReportWiseDefaultSchemeParam = {};
        ReportWiseDefaultSchemeParam.LoginId = LoginId;
        ReportWiseDefaultSchemeParam.UIAction = UIAction;
        ReportWiseDefaultSchemeParam.UIController = UIController;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetReportWiseDefaultScheme',
            data: $.param(ReportWiseDefaultSchemeParam),
            method: 'POST'
        });
    }
}]);


SharedServices.service('GetGetTopPerformingFund', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetTopPerformingFund',
            method: 'GET'
        });
    }
}]);

//GetParentScheme


SharedServices.service('GetParentScheme', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId, SchemeId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetParentScheme?FundId=' + FundId + '&SchemeId=' + SchemeId,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetSchemeBySelectedSubPlan', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSchemeBySelectedSubPlan?FundId=' + FundId,
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetAMCList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAMCList',
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetCompanyList_CreditRating', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (CompanyName) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetCompanyList_CreditRating',//?CompanyName=' + CompanyName,
            method: 'GET',
            params: { "CompanyName": CompanyName}
        });
    }
}]);
SharedServices.service('GetCompanyList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (CompanyName) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetCompanyList',//?CompanyName=' + CompanyName,
            method: 'GET',
            params: { "CompanyName": CompanyName }
        });
    }
}]);
SharedServices.service('GetMFMasterList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFMasterList',
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetMFMasterListStructureWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFMasterListStructureWise',
            method: 'POST',
            data: $.param(Obj)
        });
    }
}]);

SharedServices.service('GetSchemeObjective', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId,LoginId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSchemeObjective?SchemeId=' + SchemeId ,//+ '&LoginId=' + LoginId,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetNatureList', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetNatureList',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetFundList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
   // debugger;
    this.Call = function (AMCId, NatureId, SubNatureId, StructureIds, MFId, FundId, OptionId, StructureID) {
      //  debugger;
        var AMCIds = [];
        var ArrStructureId = [];
        var MFIds = [];
       // debugger;
        if(angular.isUndefinedOrNullOrEmpty(AMCId)==false)
        {
            AMCIds.push(AMCId);
        }
        if(angular.isUndefinedOrNullOrEmpty(StructureIds) == false)
        {
        //if (StructureIds != null && typeof (StructureIds) != undefined && StructureIds.length > 0) {
            ArrStructureId = StructureIds;
        }
        if(angular.isUndefinedOrNullOrEmpty(MFId) == false)
        {
        //if (MFId != null && typeof (MFId) != undefined) {
            //MFIds.push(MFId);
            MFIds = MFId;
        }
        var ViewFundInputEntity = {};
        ViewFundInputEntity.AMCId = AMCIds;
        ViewFundInputEntity.NatureId = NatureId;
        ViewFundInputEntity.SubNatureID = SubNatureId;
        ViewFundInputEntity.StructureIds = ArrStructureId;
        ViewFundInputEntity.MFId = MFIds;
        ViewFundInputEntity.FundId = FundId;
        ViewFundInputEntity.StructureID = 2;
        //ViewFundInputEntity.StructureID = StructureID;
        ViewFundInputEntity.OptionId = OptionId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FundList',
            data: $.param(ViewFundInputEntity),
            method: 'POST'
        });
    }
}]);
SharedServices.service('GetFundListAddendum', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    // debugger;
    this.Call = function (AMCId, NatureId, SubNatureId, StructureIds, MFId, FundId, OptionId, StructureID) {
        //  debugger;
        var AMCIds = [];
        var ArrStructureId = [];
        var MFIds = [];
        // debugger;
        if (angular.isUndefinedOrNullOrEmpty(AMCId) == false) {
            AMCIds.push(AMCId);
        }
        if (angular.isUndefinedOrNullOrEmpty(StructureIds) == false) {
            //if (StructureIds != null && typeof (StructureIds) != undefined && StructureIds.length > 0) {
            ArrStructureId = StructureIds;
        }
        if (angular.isUndefinedOrNullOrEmpty(MFId) == false) {
            //if (MFId != null && typeof (MFId) != undefined) {
            //MFIds.push(MFId);
            MFIds = MFId;
        }
        var ViewFundInputEntity = {};
        ViewFundInputEntity.AMCId = AMCIds;
        ViewFundInputEntity.NatureId = NatureId;
        ViewFundInputEntity.SubNatureID = SubNatureId;
        ViewFundInputEntity.StructureIds = ArrStructureId;
        ViewFundInputEntity.MFId = MFIds;
        ViewFundInputEntity.FundId = FundId;
        //ViewFundInputEntity.StructureID = 2;
        ViewFundInputEntity.StructureID = StructureID;
        ViewFundInputEntity.OptionId = OptionId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FundList',
            data: $.param(ViewFundInputEntity),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetSchemesOneDayNavChange', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (NavDate, FundId, SchemeId, LoginId) {
        var OneDayNavChangeParam = {};
        OneDayNavChangeParam.NavDate = NavDate;
        OneDayNavChangeParam.FundId = FundId;
        OneDayNavChangeParam.SchemeId = SchemeId;
        OneDayNavChangeParam.LoginId = LoginId;

        //OneDayNavChangeParam.DATEF = DATEF;
        //OneDayNavChangeParam.NAVDF = NAVDF;
        //OneDayNavChangeParam.OTHDF = OTHDF;
        //debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSchemesOneDayNavChange',
            data: $.param(OneDayNavChangeParam),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetHistoricalNav', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (NavDate, SchemeId, IndexId, AdditionalIndexId, LoginId) {
        var HistorycalNavParam = {};
        HistorycalNavParam.NavDate = NavDate;

        HistorycalNavParam.SchemeId = SchemeId;
        HistorycalNavParam.IndexId = IndexId;
        HistorycalNavParam.AdditionalIndexId = AdditionalIndexId;
        //HistorycalNavParam.LoginId = LoginId;
        //HistorycalNavParam.NAVDF = NAVDF;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetHistoricalNav',
            data: $.param(HistorycalNavParam),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAUMMovementData', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, MonthCount, loginId) {
       // debugger;
        return $http({
            //url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFundSize?SchemeId=' + SchemeId + '&MonthCount=' + MonthCount + '&loginId=' + loginId,
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFundSize?SchemeId=' + SchemeId + '&MonthCount=' + MonthCount,
            //data: $.param(HistorycalNavParam),
            method: 'GET'
        });
    }
}]);


SharedServices.service('GetTopFundReturn', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeIDs) {
        var TopfundInput = {};
        TopfundInput.SchemeIDs = SchemeIDs;
       // TopfundInput.LoginId = LoginId;
        //TopfundInput.DATEF = DATEF;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/TopFundReturn',
            data: $.param(TopfundInput),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetTopFundIndexReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (IndexIDs) {
        var TopfundInput = {};
        TopfundInput.SchemeIDs = IndexIDs;
       // TopfundInput.LoginId = LoginId;
        //TopfundInput.DATEF = DATEF;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/TopFundIndexReturn',
            data: $.param(TopfundInput),
            method: 'POST'
        });
    }
}]);
SharedServices.service('GetYearlyReturn', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, YearCount, IndexIds, LoginId) {
        var YearlyReturnParam = {};
        YearlyReturnParam.SchemeId = SchemeId;
        YearlyReturnParam.LoginId = LoginId;
        YearlyReturnParam.YearCount = YearCount;
        YearlyReturnParam.IndexIds = IndexIds;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetYearlyReturn',
            data: $.param(YearlyReturnParam),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetSEBIFormatReturn', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeId, LoginId) {
        var SEBIFormatReturnParam = {};
        SEBIFormatReturnParam.SchemeId = SchemeId;
        //SEBIFormatReturnParam.LoginId = LoginId;
       // SEBIFormatReturnParam.DATEF = DATEF;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSEBIFormatReturn',
            data: $.param(SEBIFormatReturnParam),
            method: 'POST'
        });
    }
}]);
SharedServices.service('ExportToPDFFactsheet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: '/FundDashboard/ExportToPDFFactsheet',
            data: obj,// $.param(obj),
            headers: { 'Content-Type': undefined },
            method: 'POST',
            dataType: "json"
        });
    }
}]);


SharedServices.service('GetRollingReturnGraphData', ['$http','ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ObjRollingParam) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetRollingReturnGraphData?SchemeId=' + ObjRollingParam.SchemeId + '&IndexId=' + ObjRollingParam.IndexId + '&AdditionalIndexId=' + ObjRollingParam.AdditionalIndexId,
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetRollingReturnData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ObjRollingParam) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetRollingReturnData?SchemeId=' + ObjRollingParam.SchemeId + '&IndexId=' + ObjRollingParam.IndexId + '&AdditionalIndexId=' + ObjRollingParam.AdditionalIndexId,
            method: 'GET'
        });
    }
}]);
SharedServices.service('SetReportWiseDefaultScheme', ['$http','ApiInfo', function ($http, ApiInfo) {

    this.Call = function (SetParam, LoginId, UIAction, UIController) {
      //  debugger;
        var ReportWiseDefaultSchemeParam = {};
        ReportWiseDefaultSchemeParam.SetParam = SetParam;
        ReportWiseDefaultSchemeParam.LoginId = LoginId;
        ReportWiseDefaultSchemeParam.UIAction = UIAction;
        ReportWiseDefaultSchemeParam.UIController = UIController;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/SetReportWiseDefaultScheme',
            data: $.param(ReportWiseDefaultSchemeParam),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetLatestPortMonths', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId, MonthCount) {
        //debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetLatestPortMonths?FundId=' + FundId + '&MonthCount=' + MonthCount,
            //  data: $.param(ReportWiseDefaultSchemeParam),
            method: 'GET'
        });
    }
}]);
SharedServices.service('GetDefaultSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFetchUserBasicSettings',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetFundManagerPeriods', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFundManagerPeriods?FundId=' + FundId,
            //data: $.param(obj),
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetAvgMatYTMMacDuration', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (FundId) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAvgMatYTMMacDuration?FundId=' + FundId,
            //data: $.param(obj),
            method: 'GET'
        });
    }
}]);

//
//    //var service = {};

//    //service.GetPager = GetPager;

//    //return service;

//    // service implementation
//    this.GetPager = function GetPager(totalItems, currentPage, pageSize) {
//        // default to first page
//        currentPage = currentPage || 1;
//        var PgSize = 2;
//        // default page size is 10
//        pageSize = pageSize || PgSize;

//        // calculate total pages
//        var totalPages = Math.ceil(totalItems / pageSize);
//        var startPage, endPage;
//        if (totalPages <= PgSize) {
//            // less than 10 total pages so show all
//            startPage = 1;
//            endPage = totalPages;
//        } else {
//            // more than 10 total pages so calculate start and end pages
//            if (currentPage <= 6) {
//                startPage = 1;
//                endPage = PgSize;
//            } else if (currentPage + 4 >= totalPages) {
//                startPage = totalPages - 9;
//                endPage = totalPages;
//            } else {
//                startPage = currentPage - 5;
//                endPage = currentPage + 4;
//            }
//        }

//        // calculate start and end item indexes
//        var startIndex = (currentPage - 1) * pageSize;
//        var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

//        // create an array of pages to ng-repeat in the pager control
//        var pages = _.range(startPage, endPage + 1);

//        // return object with all pager properties required by the view
//        return {
//            totalItems: totalItems,
//            currentPage: currentPage,
//            pageSize: pageSize,
//            totalPages: totalPages,
//            startPage: startPage,
//            endPage: endPage,
//            startIndex: startIndex,
//            endIndex: endIndex,
//            pages: pages
//        };
//    }




//}]);

SharedServices.service('GetCompanyListByISIN', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ISIN) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetCompanyListByISIN',//?CompanyName=' + CompanyName,
            method: 'GET',
            params: { "ISIN": ISIN }
        });
    }
}]);
SharedServices.service('ExportToPDFExist', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/ExportToPDFExist',
            method: 'POST',
            data: $.param(obj)

        });
    }
}]);

SharedServices.service('ExportToPDF', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/ExportToPDFExist',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }
}]);

