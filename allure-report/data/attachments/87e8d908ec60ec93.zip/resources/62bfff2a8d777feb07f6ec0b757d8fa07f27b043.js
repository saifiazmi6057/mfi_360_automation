SharedDeractives.directive('compositeSchemes', ['$timeout', '$q', '$log', 'MFIMsg', 'GetAllCompositeSchSettings', 'GetSchemeSetByName', 'SchemeSetData', 'SearchSchemeCodeBysearchText', 'ChnageSchemeCode', 'CreateSchemeSetDetails', 'CheckSchemeSetNameExists', 'DeleteSchemeSet', '$http', 'ApiInfo', 'IsAccessibleforActiveuser',
    function ($timeout, $q, $log, MFIMsg, GetAllCompositeSchSettings, GetSchemeSetByName, SchemeSetData, SearchSchemeCodeBysearchText, ChnageSchemeCode, CreateSchemeSetDetails, CheckSchemeSetNameExists, DeleteSchemeSet, $http, ApiInfo, IsAccessibleforActiveuser) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '=',
                logInId: '='
            },
            replace: false,
            templateUrl: '/Home/CompositeSchemes',
            /**
             * 
             * @param {ScopeTypeCopositeScheme} $scope
             * @param {any} $element
             * @param {any} $attrs
             */
            link: function ($scope, $element, $attrs) {
                $timeout(function () {

                    $scope.showDirective = false;

                    $timeout(function () {
                        $scope.showDirective = true;
                    }, 4000); 

                    $scope.LstSchemeSet = [];
                    $scope.LstSchemeSetDetails = [];
                    $scope.clickedEdit = false;
                    $scope.hiddetails = false;
                    $scope.disableIsDefault = false;
                    $scope.Data = [];
                    $scope.IsPersonalized = "";
                    $scope.IsDefault = "";
                    $scope.disableIsDefault = "";
                    $scope.FlagIsGeneralized = false;
                    $scope.FlagIsPersonalized = false;
                    $scope.AMFICode = false;
                    $scope.RTACode = false;
                    $scope.ICRONCode = false;
                    $scope.ICRONSchemeName = false;
                    $scope.LstCodeDetails = [];
                    $scope.TypeName = "";
                    $scope.showSaveCancel = false;
                    $scope.LoaderCompositeSchemes = true;
                    $scope.LstTemp = [];
                    $scope.WatchArr = [{
                        "NewValue": "AMFI",
                        "Oldvalue": "AMFI"
                    }];
                    $scope.LoaderEditTable = false;
                    $scope.searchText = "";
                    $scope.IsGeneric = false;
                    $scope.SaveUpdate = "Save";
                    $scope.ImpCmpSch = false;
                    $scope.UploadCmpSch = true;
                    $scope.isCompositeSchemes = true;
                    $scope.OptionsForSelectedSchesmes = { LstSelectedSchemes: [], LstUserSetSchemes: [], LstMywatchListSchemes: [] };
                    $scope.lstMfiSchemes = [];
                    $scope.LstMergedSchemes = [];
                    $scope.UserSetModel = [];
                    $scope.UserSetSettings = {
                        scrollableHeight: '300px',
                        scrollable: true,
                        enableSearch: true,
                        ddltext: "Select User Set",
                        Keyprop: "UssId",
                        Valueprop: "UssName",
                    };
                    $scope.CompositeSchemesTableHeadersLst = [
                        { HeaderName: 'Composite Scheme name', PropertyName: 'SchemeSetName' },
                        { HeaderName: 'Created By', PropertyName: 'CreatedBy' },
                        { HeaderName: 'Type', PropertyName: 'Type' },
                        { HeaderName: 'Created On', PropertyName: 'CreatedOnStr' },
                        { HeaderName: 'Modified By', PropertyName: 'modifiedBy' },
                        { HeaderName: 'Modified On', PropertyName: 'modifiedonStr' }
                    ].map((x, i) => ({
                        HeaderName: x.HeaderName, PropertyName: x.PropertyName, Index: i,
                        SortByASC: true, SortByDESC: false,
                        SortByASCId: angular.generateID(), SortByDESCId: angular.generateID()
                    }));
                    $scope.CompositeSchemesTableHeadersLst.push({ HeaderName: 'Action' });
                    angular.element('#tableContainer2').fixTableHeader();

                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await GetAllCompositeSchSettings.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('GetAllCompositeSchSettings', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function AllCompositeSch() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('GetAllCompositeSchSettings');
                        //if (data) {
                        //    // Parse and return the data from LocalStorage
                        //    return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//

                    var GetAllCompositeSch = function () {
                        $scope.LoaderCompositeSchemes = true;
                        //var AllCompositeSch = GetAllCompositeSchSettings.Call();
                        AllCompositeSch().then(function (response) {
                            if (response != null) {
                                //$scope.LstSchemeSetDetails = response?.data?.data ?? [];
                                $timeout(function () {
                                    $scope.LstSchemeSetDetails = response ?? [];
                                    $scope.LstSchemeSetDetails = $scope.LstSchemeSetDetails.map(x => { x.Name = x.SchemeSetName; return x });
                                    let setIds = new Set([-1]); setIds.clear();
                                    $scope.LstSchemeSetDetailsGrp = $scope.LstSchemeSetDetails.filter(x => { if (setIds.has(x.SchemeSetID)) return false; else { setIds.add(x.SchemeSetID); return true; } })
                                    $scope.LstSchemeSetDetailsMap = new Map(); let map = $scope.LstSchemeSetDetailsMap;
                                    $scope.LstSchemeSetDetails.forEach(x => map.set(x.SchemeSetID, map.has(x.SchemeSetID) ? [...map.get(x.SchemeSetID), x] : [x]));
                                    $scope.LoaderCompositeSchemes = false;
                                    $scope.hiddetails = true;
                                }, 10);
                                //$scope.LoaderRatingSearch = false;
                            }
                        }, function (stu) {
                            $scope.LoaderCompositeSchemes = false;
                            //$scope.LoaderRatingSearch = false;
                            MFIMsg.AlertHtml("Fail to load data", MFIAlertType.Error);
                        });
                    }

                    GetAllCompositeSch();
                    $scope.getSchemeUpdates = {
                        /**
                         * 
                         * @param {Map<number,string>} arg
                         * @returns
                         */
                        Call: (arg) => {
                            if ($scope.LstSchemeSetDetails?.length === 1 && String($scope.LstSchemeSetDetails[0].SchemeName).trim() == '') {
                                $scope.LstSchemeSetDetails = [];
                            }
                            if ($scope.LstSchemeSetDetails[$scope.LstSchemeSetDetails.length - 1]?.SchemeName.trim() == '') {
                                $scope.LstSchemeSetDetails.pop();
                            }
                            let schemeIds = new Set($scope.LstSchemeSetDetails?.map(x => x.SchemeID));
                            arg?.forEach((val, key) => schemeIds.has(key) ? '' : $scope.LstSchemeSetDetails.push({ SchemeID: key, SchemeName: val }));
                        },
                        /**
                         * @param {boolean} IsCheck
                         * @param {boolean} IsAll
                         */
                        CheckUnceck: [(IsCheck, IsAll) => {

                        }],
                        /** @type {(function(SchemeSetDetailsEntity): void)[] } */
                        UncheckScheme: [],
                    }
                    var getData = GetSchemeSetByName.Call();
                    getData.then(function (response) {
                        $scope.LstSchemeSet = response.data.data;
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Composite schemes set loading failed", MFIAlertType.Error);
                        });

                    $scope.querySearch = querySearch;
                    $scope.selectedItemChange = selectedItemChange;
                    $scope.searchTextChange = searchTextChange;

                    function querySearch(query) {
                        let queryStr = String(query).trim().toLowerCase();
                        //let results = $scope.LstSchemeSetDetailsGrp.filter(x => String(x.SchemeSetName).toLowerCase().includes(queryStr));
                        $scope.LstSchemeSetDetailsGrp = Array.from($scope.LstSchemeSetDetailsMap.entries())
                            .map(([setId, schems]) => schems[0])
                            .filter(x => String(x.SchemeSetName).toLowerCase().includes(queryStr));
                        return $scope.LstSchemeSetDetailsGrp;
                    }

                    function searchTextChange(text) {
                        //$log.info('Text changed to ' + text);
                    }

                    $scope.FnCleanTextCompositeScheme = function () {
                        $scope.searchText = '';
                        $scope.ShowClearButtonCompositeScheme = false;
                        GetAllCompositeSch();
                    }
                    /** * @param {SchemeSetDetailsEntity} item */
                    function selectedItemChange(item) {
                        if (item) {
                            $scope.LstSchemeSetDetails = $scope.LstSchemeSetDetailsMap.get(item.SchemeSetID);
                            if (item.Type == 'Generic') { $scope.FlagIsGeneralized = true; } else { $scope.FlagIsPersonalized = true; }
                            $scope.Data = item;
                            $scope.Data.SchemeSetName = item.SchemeSetName;
                            $scope.Data.SchemeSetID = item.SchemeSetID;
                            $scope.UpdateWeightageSum();
                        }
                    }
                    $scope.UpdateWeightageSum = () => {
                        $scope.LstSchemeSetDetails.forEach(item => {
                            if (item.Weightage !== 0)
                                item.Weightage = item.Weightage || '';
                        })
                        $scope.totalWeightage = Sum($scope.LstSchemeSetDetails.map(x => x.Weightage));
                        console.log($scope.totalWeightage, $scope.LstSchemeSetDetails);
                    }
                    /** * @param {number[]} arr */
                    function Sum(arr) {
                        const sumVal = arr.reduce((prev, curr) => prev + (curr || 0), 0);
                        return isNaN(sumVal) ? 0 : sumVal;
                    }
                    /**
                     * @param {number} i
                     * @param {SchemeSetDetailsEntity} item
                     */
                    $scope.CreateSet = function (i, item) {
                        $scope.CreateTab = true;
                        $scope.clickedEdit = true;
                        $scope.showSaveCancel = true;
                        $scope.IsAMFI = "AMFI";
                        $scope.TypeName = "AMFI";
                        $scope.AMFICode = false;
                        $scope.RTACode = false;
                        $scope.ICRONCode = false;
                        $scope.ICRONSchemeName = false;
                        $scope.WatchArr = [];
                        $scope.WatchArr = [{
                            "NewValue": "AMFI",
                            "Oldvalue": "AMFI"
                        }];
                        $scope.totalWeightage = null;
                        if (i == 1) {
                            $scope.Data.SchemeSetName = null;
                            var obj = {
                                SchemeID: 0,
                                Weightage: 0,
                                SchemeName: ""
                            };
                            $scope.LstSchemeSetDetails = [];
                            $scope.LstSchemeSetDetails.push(obj);
                            $scope.setnameDisable = false;
                            $scope.Data.SchemeSetID = 0;
                            $scope.FlagIsPersonalized = false;
                            $scope.FlagIsGeneralized = true;
                            $scope.SaveUpdate = "Save";
                            $scope.IsGeneric = false;
                            $scope.UploadCmpSch = true;
                        }
                        else if (i == 3) {
                            $scope.CreateTab = false;
                            selectedItemChange(item);
                            if ($scope.FlagIsGeneralized == true)
                                $scope.IsGeneric = true;
                            else
                                $scope.IsGeneric = false;
                            $scope.setnameDisable = true;
                            $scope.showSaveCancel = false;
                            $scope.viewOnly = true;
                        }
                        else // Edit Block
                        {
                            $scope.CreateTab = false;
                            //$scope.isCompositeSchemes = true;
                            selectedItemChange(item);
                            if ($scope.FlagIsGeneralized == true)
                                $scope.IsGeneric = true;
                            else
                                $scope.IsGeneric = false;
                            $scope.setnameDisable = true;
                            $scope.SaveUpdate = "Update";
                            $scope.UploadCmpSch = false;
                        }
                        Array.from($scope.getSchemeUpdates.CheckUnceck).forEach(item => item(false, true));
                        $scope.viewOnly = i == 3;
                    }

                    var CheckIsStandardAdvanceUser = function () {
                        $scope.LoaderCompositeSchemes = true;
                        var Isadvanceuser = IsAccessibleforActiveuser.Call();
                        Isadvanceuser.then(function (response) {
                            if (response.data != null) {
                                $scope.IsAdvanceUser = response?.data?.data;
                                $scope.LoaderCompositeSchemes = false;
                                if ($scope.IsAdvanceUser) {
                                    document.getElementById("Compositeschemesid").style.display = "block";
                                }
                                else {
                                    document.getElementById("Compositeschemesid").style.display = "none";
                                }
                                //$scope.LoaderRatingSearch = false;
                            }
                            else {
                                $scope.LoaderCompositeSchemes = false;
                            }
                        }, function (stu) {
                            $scope.LoaderCompositeSchemes = false;
                            //$scope.LoaderRatingSearch = false;
                            MFIMsg.AlertHtml("Fail to load data", MFIAlertType.Error);
                        });
                    }
                    CheckIsStandardAdvanceUser();

                    $scope.checkchange = function (codename) {
                        if (codename == 'AMFI Code') {
                            $("#CodeName").html('AMFI Code');
                            $scope.AMFICode = false;
                            $scope.RTACode = false;
                            $scope.ICRONCode = false;
                            $scope.ICRONSchemeName = false;
                            $scope.TypeName = "AMFI";
                            $scope.WatchArr[0].Oldvalue = $scope.WatchArr[0].NewValue;
                            $scope.WatchArr[0].NewValue = "AMFI";
                        }

                        if (codename == 'RTA Code') {
                            $("#CodeName").html('RTA Code');
                            $scope.AMFICode = false;
                            $scope.RTACode = true;
                            $scope.ICRONCode = false;
                            $scope.ICRONSchemeName = false;
                            $scope.TypeName = "RTA";
                            $scope.WatchArr[0].Oldvalue = $scope.WatchArr[0].NewValue;
                            $scope.WatchArr[0].NewValue = "RTA";
                        }

                        if (codename == 'ICRON Code') {
                            $("#CodeName").html('ICRON Code');
                            $scope.AMFICode = false;
                            $scope.RTACode = false;
                            $scope.ICRONCode = true;
                            $scope.ICRONSchemeName = false;
                            $scope.TypeName = "ICRONCode";
                            $scope.WatchArr[0].Oldvalue = $scope.WatchArr[0].NewValue;
                            $scope.WatchArr[0].NewValue = "ICRONCode";
                        }
                        if (codename == 'ICRON Scheme Name') {
                            $("#CodeName").html('ICRON Scheme Name');
                            $scope.AMFICode = false;
                            $scope.RTACode = false;
                            $scope.ICRONCode = false;
                            $scope.ICRONSchemeName = true;
                            $scope.TypeName = "ICRON Scheme Name";
                            $scope.WatchArr[0].Oldvalue = $scope.WatchArr[0].NewValue;
                            $scope.WatchArr[0].NewValue = "ICRONScheme";
                        }

                        var arr = [];
                        for (i = 0; i < $scope.LstSchemeSetDetails.length; i++) {
                            if ($scope.LstSchemeSetDetails[i].SchemeCode != null) {
                                arr.push($scope.LstSchemeSetDetails[i].SchemeCode);

                            }
                        }

                        if (arr.length > 0) {
                            $scope.LoaderEditTable = true;
                            var param = { "SchemeCode": arr, "SchTypenew": $scope.WatchArr[0].NewValue, "SchTypeold": $scope.WatchArr[0].Oldvalue };
                            var getData = ChnageSchemeCode.Call(param);
                            getData.then(function (response) {
                                $scope.LoaderEditTable = false;
                                var codeData = response.data.data;
                                for (i = 0; i < $scope.LstSchemeSetDetails.length; i++) {
                                    if ($scope.LstSchemeSetDetails[i].SchemeCode != null) {
                                        for (j = 0; j < codeData.length; j++) {
                                            if ($scope.LstSchemeSetDetails[i].SchemeCode == codeData[j].OldschCode) {
                                                $scope.LstSchemeSetDetails[i].SchemeCode = codeData[j].NewschCode;
                                            }
                                        }
                                    }
                                }
                            },
                                function (stu) {
                                    $scope.LoaderEditTable = false;
                                    MFIMsg.AlertHtml("Change Scheme Code failed", MFIAlertType.Error);
                                });
                        }

                    }

                    $scope.querySearchcrt = querySearchcrt;
                    $scope.selectedItemChangecrt = selectedItemChangecrt;
                    $scope.searchTextChangecrt = searchTextChangecrt;


                    function querySearchcrt(query) {
                        var param = { "TypeName": $scope.TypeName, "SerachCodeText": query }
                        var getData = SearchSchemeCodeBysearchText.Call(param);
                        return getData.then(function (response) {
                            return response.data == null ? {} : response.data.data;
                        }, function (stu) {
                            MFIMsg.AlertHtml("Error", MFIAlertType.Error);
                        });
                    }

                    function searchTextChangecrt(text) {
                        $log.info('Text changed to ' + text);
                    }

                    function createFilterForcrt(query) {
                        var lowercaseQuery = angular.lowercase(query);

                        return function filterFn(state) {
                            return (angular.lowercase(state.Name).indexOf(lowercaseQuery) === 0);
                        };

                    }

                    function selectedItemChangecrt(item, id) {
                        if (item != undefined) {
                            if (item.SchemeName != undefined)
                                $scope.LstSchemeSetDetails[id].Name = item.SchemeName;
                            if (item.SchemeID != undefined)
                                $scope.LstSchemeSetDetails[id].SchemeID = item.SchemeID;
                            if (item.SchemeName != undefined)
                                $scope.LstSchemeSetDetails[id].SchemeName = item.SchemeName;
                            if (item.SchemeCode != undefined)
                                $scope.LstSchemeSetDetails[id].SchemeCode = item.SchemeCode;
                        }
                        $log.info('Item changed to ' + JSON.stringify(item));
                    }

                    $scope.add = function (id) {

                        if ($scope.LstSchemeSetDetails[id].SchemeID == 0) {
                            MFIMsg.AlertHtml('Please select code', MFIAlertType.Information);
                            return false;
                        }
                        if ($scope.LstSchemeSetDetails[id].Weightage == 0) {
                            MFIMsg.AlertHtml('Please enter weightage', MFIAlertType.Information);
                            return false;
                        }
                        if ($.isNumeric($scope.LstSchemeSetDetails[id].Weightage) == false) {
                            MFIMsg.AlertHtml('Please enter numeric value in weightage', MFIAlertType.Information);
                            return false;
                        }
                        if ($scope.LstSchemeSetDetails.length > 1) {
                            for (i = 0; i < $scope.LstSchemeSetDetails.length - 1; i++) {
                                if ($scope.LstSchemeSetDetails[id].SchemeID == $scope.LstSchemeSetDetails[i].SchemeID) {
                                    MFIMsg.AlertHtml('This code ' + $scope.LstSchemeSetDetails[id].SchemeCode.SchemeCode + ' is Already Exits, please enter unique', MFIAlertType.Information);
                                    return false;
                                }
                            }
                        }

                        var obj = {
                            SchemeID: 0,
                            Weightage: 0,
                            SchemeName: ""
                        };

                        $scope.LstSchemeSetDetails.push(obj);

                    }

                    $scope.remove = function (id, scheme) {
                        console.log(id, scheme, $scope.LstSchemeSetDetails);
                        if ($scope.LstSchemeSetDetails.length == 1) {
                            var obj = {
                                SchemeID: 0,
                                Weightage: 0,
                                SchemeName: ""
                            };
                            $scope.LstSchemeSetDetails = [];
                            $scope.LstSchemeSetDetails.push(obj);
                        }
                        if ($scope.LstSchemeSetDetails.length > 1) {
                            $scope.getSchemeUpdates.UncheckScheme.forEach(func => func($scope.LstSchemeSetDetails[id]));
                            $scope.LstSchemeSetDetails.splice(id, 1);

                        }
                        $scope.UpdateWeightageSum();
                    }

                    $scope.CancelSchemeSet = function () {
                        $scope.clickedEdit = false;
                        $scope.IsDefault = false;
                        $scope.Data.SchemeSetName = null;
                        $scope.FlagIsPersonalized = false;
                        //$scope.hiddetails = false;
                        $scope.showSaveCancel = false;
                        $scope.LstSchemeSetDetails = [];
                        $scope.searchText = "";
                        var getData = GetSchemeSetByName.Call();
                        getData.then(function (response) {
                            $scope.LstSchemeSet = response.data.data;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Composite schemes set loading failed", MFIAlertType.Error);
                            });
                        //localStorage.removeItem('GetAllCompositeSchSettings');
                        GetAllCompositeSch();
                    }
                    function IsNum(value) {
                        return typeof value === 'number';
                    }
                    $scope.CreateSchemeSet = function () {
                        if ($scope.FlagIsGeneralized == false && $scope.FlagIsPersonalized == false) {
                            MFIMsg.AlertHtml("Please choose either generic or personal", MFIAlertType.Information); return false;
                        }
                        if ($scope.Data.SchemeSetName == "" || $scope.Data.SchemeSetName == null) {
                            MFIMsg.AlertHtml("Please enter a scheme set name", MFIAlertType.Information); return false;
                        }

                        //const lstlen = $scope.LstSchemeSetDetails.length;

                        //if ($scope.LstSchemeSetDetails[lstlen - 1].SchemeID == 0)
                        //{
                        //    MFIMsg.AlertHtml("Please enter valid code in last row", MFIAlertType.Information);
                        //    return false;
                        //}
                        //if ($scope.LstSchemeSetDetails[lstlen - 1].Weightage == 0) {
                        //    MFIMsg.AlertHtml("Please enter weightage in last row", MFIAlertType.Information);
                        //    return false;
                        //}
                        for (let i of $scope.LstSchemeSetDetails) {
                            if (typeof i.Weightage === 'number' && (i.Weightage <= 0 || i.Weightage > 100)) {
                                MFIMsg.AlertHtml("Please enter weightage greater than 0 and less than equal to 100 against all the selected schemes", MFIAlertType.Information); return false;
                            }
                            if (i.Weightage === "" || i.Weightage === undefined) {
                                MFIMsg.AlertHtml("Please enter weightage for " + i.SchemeName, MFIAlertType.Information); return false;
                            }
                        }
                        const totalWeightage = $scope.LstSchemeSetDetails.reduce((prev, curr) => prev + (curr.Weightage || 0), 0);
                        if (totalWeightage > 100) {
                            MFIMsg.AlertHtml('Total Weightage must be equal to 100%. Please Check', MFIAlertType.Information); return false;
                        }
                        if (totalWeightage < 100) {
                            MFIMsg.AlertHtml('Total Weightage must be equal to 100%. Please Check', MFIAlertType.Information); return false;
                        }
                        Array.from($scope.getSchemeUpdates.CheckUnceck).forEach(item => item(false, true));
                        var datax = {
                            SchemeSetName: $scope.Data.SchemeSetName,
                            SchemeSetID: $scope.Data.SchemeSetID,
                            LoginId: $scope.Data.LoginId,
                            IsActive: $scope.Data.IsActive,
                            ClientId: $scope.Data.ClientId
                        };

                        var objSchemesetDetails = {
                            Data: datax,
                            LstSchemeSetDetails: $scope.LstSchemeSetDetails
                                .filter(x => IsNum(x.SchemeID) && x.SchemeID !== 0)
                                .map(x => { x.Id = x.SchemeID; x.Name = x.SchemeName; return x; }),
                            IsAMFI: $scope.AMFICode,
                            IsRTA: $scope.RTACode,
                            IsICRONCode: $scope.ICRONCode,
                            IsICRONScheme: $scope.ICRONSchemeName,
                            IsPersonalized: $scope.FlagIsPersonalized,
                            IsDefault: $scope.IsDefault
                        };

                        if ($scope.Data.SchemeSetID <= 0) {
                            var param = { "StrSetName": $scope.Data.SchemeSetName };
                            var getData = CheckSchemeSetNameExists.Call(param);
                            getData.then(function (response) {
                                if (response.data.data == true) {
                                    var getData = CreateSchemeSetDetails.Call(objSchemesetDetails);
                                    getData.then(function (response) {
                                        if (response.data.data.IsCompleted == true) {
                                            MFIMsg.AlertHtml("Data saved successfully", MFIAlertType.Success);
                                            var getData = GetSchemeSetByName.Call();
                                            getData.then(function (response) {
                                                $scope.LstSchemeSet = response.data.data;
                                            },
                                                function (stu) {
                                                    MFIMsg.AlertHtml("Composite schemes set loading failed", MFIAlertType.Error);
                                                });
                                            $scope.clickedEdit = false;
                                            $scope.showSaveCancel = false;
                                            localStorage.removeItem('GetAllCompositeSchSettings');
                                            GetAllCompositeSch();
                                        }
                                        else {
                                            MFIMsg.AlertHtml("Save failed", MFIAlertType.Error);
                                        }
                                    }, function (stu) {
                                        MFIMsg.AlertHtml("Save failed", MFIAlertType.Error);
                                    });
                                }
                                else {
                                    MFIMsg.AlertHtml("Set name already exists", MFIAlertType.Error);
                                }
                            }, function (stu) {
                                MFIMsg.AlertHtml("Failed", MFIAlertType.Error);
                            });
                        }
                        else {
                            var getData = CreateSchemeSetDetails.Call(objSchemesetDetails);
                            getData.then(function (response) {
                                if (response.data.data.IsCompleted == true) {
                                    MFIMsg.AlertHtml("Data updated successfully", MFIAlertType.Information);
                                    $scope.clickedEdit = false;
                                    $scope.showSaveCancel = false;
                                    localStorage.removeItem('GetAllCompositeSchSettings');
                                    GetAllCompositeSch();
                                }
                                else {
                                    MFIMsg.AlertHtml("Data updation failed", MFIAlertType.Error);
                                }
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Update failed", MFIAlertType.Error);
                                });
                        }
                    }

                    $scope.DeleteSet = function (SchemeSetID) {
                        MFIMsg.Confirm("You want to delete", "MFI360 Explorer", "Ok", "Cancel").then(function () {
                            var param = { "SchemeSetId": SchemeSetID };
                            var getData = DeleteSchemeSet.Call(param);
                            getData.then(function (response) {
                                //$scope.hiddetails = false;
                                $scope.searchText = "";
                                var getData = GetSchemeSetByName.Call();
                                getData.then(function (response) {
                                    $scope.LstSchemeSet = response.data.data;
                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Composite schemes set loading failed", MFIAlertType.Error);
                                    });
                                localStorage.removeItem('GetAllCompositeSchSettings');
                                GetAllCompositeSch();
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Delete failed", MFIAlertType.Error);
                                });

                        }, function () {

                        })

                    }

                    $scope.general = function () {
                        $scope.FlagIsGeneralized = true;
                        $scope.FlagIsPersonalized = false;
                    }

                    $scope.personal = function () {
                        $scope.FlagIsGeneralized = false;
                        $scope.FlagIsPersonalized = true;
                    }

                    $scope.ExportTemplate = function () {
                        var downloadPath = "/Content/DownloadExcel/CompositeSchemesTemplate.xlsx";
                        window.open(downloadPath, '_blank', '');
                    }

                    $scope.UploadCompositeSchems = function () {
                        $scope.ImpCmpSch = true;
                    }
                    $scope.ImportSchemes = function (file) {
                        if ($scope.file == null) {
                            MFIMsg.AlertHtml("Please select a file", MFIAlertType.Information);
                            return;
                        }
                        var data = { "ObjFile": $scope.file };

                        $scope.LoaderImportSchemes = true;
                        $http({
                            method: "POST",
                            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/UploadCompositeSchems',
                            headers: { 'Content-Type': undefined },
                            transformRequest: function (data, headersGetter) {
                                var formData = new FormData();
                                angular.forEach(data, function (value, key) {
                                    formData.append(key, value);
                                });
                                return formData;
                            },
                            data: { "files": $scope.file }
                        }).then(function (response) {
                            if (response.data.data) {
                                $scope.LstSchemeSetDetails = [];
                                angular.forEach(response.data.data, function (value) {
                                    var obj = {
                                        SchemeCode: value.Code,
                                        Weightage: value.Weightage != "" ? parseInt(value.Weightage) : value.Weightage,
                                        SchemeName: value.ICRONSchemeName
                                    };
                                    $scope.LstSchemeSetDetails.push(obj);
                                });
                                $scope.LoaderImportSchemes = false;
                                //$scope.file = null;
                                $scope.reset();
                            }
                            else {
                                $scope.LoaderImportSchemes = false;
                                //$scope.file = null;
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);
                            }
                        },
                            function errorCallback(response) {
                                $scope.LoaderImportSchemes = false;
                                //$scope.file = null;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });

                    };
                    $scope.reset = function () {
                        $scope.ImpCmpSch = false;
                    }

                    /**
                     * @param {CompositeSchemesTableHeader} header
                     * @param {'ASC' | 'DESC'} SortOrder
                     */
                    $scope.SortCompositeSchemesTable = (header, SortOrder) => {
                        if (!$scope.LstSchemeSetDetailsGrpOriginal) $scope.LstSchemeSetDetailsGrpOriginal = $scope.LstSchemeSetDetailsGrp.map(x => ({ ...x }));
                        ({ arr: $scope.LstSchemeSetDetailsGrp, Header: $scope.CompositeSchemesTableHeadersLst[header.Index] } = angular.SortListByProperty($scope.LstSchemeSetDetailsGrpOriginal.map(x => ({ ...x })), SortOrder, header))
                    }

                    $scope.closeCompositeSchemes = function () {
                        $scope.clickedEdit = false;
                        $scope.IsDefault = false;
                        $scope.Data.SchemeSetName = null;
                        $scope.FlagIsPersonalized = false;
                        //$scope.hiddetails = false;
                        $scope.showSaveCancel = false;
                        $scope.LstSchemeSetDetails = [];
                        $scope.searchText = "";
                        if (screen.width <= 767) {
                            angular.element('#compositeSchemesDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#compositeSchemesDetails').hide();
                        } else {
                            angular.element('#compositeSchemesDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#compositeSchemesDetails').hide();
                            });
                        }
                    };

                    $scope.toggleCompositeIndexPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-compositeScheme');
                        var $details = angular.element('#compositeSchemesDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };

                }, 0);
            }
        };
    }
]);

/**
* @typedef { Object } ScopeTypeCopositeScheme
* @property { SchemeSetDetailsEntity[]  } LstSchemeSetDetails
* @property   { SchemeSetDetailsEntity[]} LstSchemeSetDetailsGrp
* @property {Map<number, SchemeSetDetailsEntity[]>} LstSchemeSetDetailsMap
* @property {UserSetModel[]} userSetModel
* @property {number} totalWeightage
* @property {function():void} UpdateWeightageSum
* @property {CompositeSchemesTableHeader[]} CompositeSchemesTableHeadersLst
* @property {SchemeSetDetailsEntity[]}LstSchemeSetDetailsGrpOriginal
* @property {GetSchemeUpdatesConfig} getSchemeUpdates
 * 
 * @typedef {Object} GetSchemeUpdatesConfig
 * @property {function(Map<number,string>): void} Call
 * @property {(function(SchemeSetDetailsEntity): void)[]} UncheckScheme
* 
* @typedef { Object } ScopeOptions
* @property { any[] } LstMywatchListSchemes
* @property { any[] } CompositeSchemes
* @property { CompositeSchemeEntity[] } CompositeSchemes
* @property {Map<number, SchemeSetDetailsEntity[]>} CompositeSchemesSetDetails
* 
 * @typedef {Object} CompositeSchemesTableHeader
 * @property {string} HeaderName
 * @property {boolean} SortByDESC
 * @property {boolean} SortByASC
 * @property {string} PropertyName
 * @property {number} Index
 * @property {string} SortByDESCId
 * @property {string} SortByASCId
 * 
 * @typedef {function(SchemeSetDetailsEntity): void} SchemeInfo
 */


