
SharedServices.service('GetSingleInstrumentSetdetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SingleInstrumentSetDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetCompositInstrumentDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/CopositInstrumentDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetInstrumentSetsData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/GetInstrumentSetsData',
            method: 'GET'
        });
    }

}]);

SharedServices.service('SaveSetandCustomInstrumentName', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SaveInstrumentSetsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('MakeDefaultInstrumentSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SaveDefaultInstrumentSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('InstrumentSetsDelete', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/InstrumentSetDelete',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('InstrumentSave', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SaveInstrumentsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);