
//var ServicePortfolio=angular.module('ServicePortfolio', []);

//ServicePortfolio.config(BaseServiceConfig);

///////overlap/////


SharedServices.service('GetFundSelector', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/GetFundSelector',
            method: 'GET'
        });
    }



}]);

SharedServices.service('DefaultOverlappingFund', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/DefaultOverlappingFund',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('POStockSummary', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/POStockSummary',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('FilterFundCategory', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/FilterFundCategory',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SectorWiseAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SectorWiseAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('SectorWiseAllocationDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SectorWiseAllocationDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('TopFiveOverLapFundA', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/TopFiveOverLapFundA',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('TopFiveOverLapFundB', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/TopFiveOverLapFundB',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('FetchTopOverlappingFundWRTFundA', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/FetchTopOverlappingFundWRTFundA',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('OverLapValue', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/OverLapValue',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

///////overlap end/////
SharedServices.service('GetQAAUMDates', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (Years) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/GetQAAUMDates?Years=' + Years
        });
    }

}]);

SharedServices.service('PostNxtQAAUMDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostNxtQAAUMDate',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetLiqudityAnalysis', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: 'get',
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFMasterList',           
        });
    }

}]);

SharedServices.service('PostLiqudityAnalysis', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostLiqudityAnalysisData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostAMCWiseLiqudityAnalysis', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/PostAMCWiseLiqudityAnalysis',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('PostInsertUpdateOverLapFunds', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/InsertUpdateOverLapFunds',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('GetLatestTradeDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiPortfolioAnalysis/GetLatestTradeDate',
            method: 'GET'
        });
    }



}]);


SharedServices.service('GetFundsizeOverNavCalc', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiPortfolio/ShowFundSizeChangeOverNav',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



