SharedDeractives.directive('compositeIndex', ['$timeout', '$q', '$log', '$filter', 'MFIMsg', 'GetAllCompositeIndexRec', 'PostModifyCompositeIndexRecord', 'PostSearchCompositeIndexRecord', 'PostDeleteCompositeIndexRecord', 'GetAllMFIIndex', 'GetAllCustomIndex', 'PostCompositeIndexDetailRecord', 'PostAddCompositeIndexDetailRecord', 'PostAddCompositeIndexRecord', 'GetAllNonRestrictedMFIIndex',
    function ($timeout, $q, $log, $filter, MFIMsg, GetAllCompositeIndexRec, PostModifyCompositeIndexRecord, PostSearchCompositeIndexRecord, PostDeleteCompositeIndexRecord, GetAllMFIIndex, GetAllCustomIndex, PostCompositeIndexDetailRecord, PostAddCompositeIndexDetailRecord, PostAddCompositeIndexRecord, GetAllNonRestrictedMFIIndex) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '=',
                logInId: '='
            },
            replace: false,
            templateUrl: '/Home/CompositeIndex',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    //$scope.names = BasModelcustomindex;
                    $scope.AddComp = false;
                    $scope.ComIndMaster = true;
                    $scope.ComtIndDetail = false;
                    $scope.SelInd = [];
                    $scope.SelInd.ComIndPartsArr = [];
                    $scope.TotalPer = 0;
                    $scope.SelIndex = [];
                    $scope.LstMFIndexes = [];
                    $scope.SelIndex.IndexName = null;
                    $scope.ComIndexType = 'gen';
                    var CompositeIndexId = null;
                    $scope.hdComCreate = false;


                    //-------------------- local storage test ----------------------------//
                    // Function to fetch data from API
                    async function fetchData() {
                        try {
                            const response = await GetAllCompositeIndexRec.Call();
                            // Store the data in LocalStorage
                            //localStorage.setItem('GetAllCompositeIndexRec', JSON.stringify(response.data.data));
                            return response.data.data;
                        } catch (error) {
                            MFIMsg.Alert("Data fetch failed !!!", "Error", "OK");
                            throw error;
                        }
                    }

                    // Function to get data
                    async function AllComIndex() {
                        // Check if data is present in LocalStorage
                        //let data = localStorage.getItem('GetAllCompositeIndexRec');
                        //if (data) {
                        //    // Parse and return the data from LocalStorage
                        //    return JSON.parse(data);
                        //} else {
                            // If not present, fetch from API
                            let data = await fetchData();
                            return data;
                        //}
                    }
                    //-------------------- end test---------------------------------------//

                    var GetAllCompositeIndex = function () {
                        //var AllComIndex = GetAllCompositeIndexRec.Call();
                        AllComIndex().then(function (response) {
                            if (response != null) {
                                //$scope.Comnames = response.data.data;
                                $timeout(function () {
                                    $scope.Comnames = response;
                                    $scope.LoaderCommonCompositeIndex = false;
                                }, 10);
                                //$scope.LoaderRatingSearch = false;
                            }
                        },
                            function (stu) {
                                $scope.LoaderCommonCompositeIndex = false;
                                //$scope.LoaderRatingSearch = false;
                                MFIMsg.AlertHtml("Fail to load data", MFIAlertType.Error);
                            });
                    }

                    GetAllCompositeIndex();

                    //var MFIIndexEntity = { isDiscardRestrictedIndex: true };
                    //var AllMFIIndex = GetAllMFIIndex.Call(MFIIndexEntity);
                    var AllMFIIndex = GetAllNonRestrictedMFIIndex.Call();
                    AllMFIIndex.then(function successCallback(response) {
                        $scope.LstMFIndexes = response.data.data;
                        $scope.LstCusIndexes = [];
                        var AllCustomIndex = GetAllCustomIndex.Call();
                        AllCustomIndex.then(function successCallback(response) {
                            var cusData = response.data.data;
                            angular.forEach(cusData, function (value, key) {
                                var obj = {
                                    Id: value.CustomIndexId,
                                    IndexId: value.CustomIndexId,
                                    Name: value.CustomIndexName + '**',
                                    IndexName: value.CustomIndexName + '**'
                                };
                                $scope.LstCusIndexes.push(obj);
                            });
                            $scope.LstMFIndexes = $scope.LstMFIndexes.concat($scope.LstCusIndexes);
                        },
                            function errorCallback(response) {
                            });
                    },
                        function errorCallback(response) {
                        });

                    $scope.resetComIndex = function () {
                        $scope.searchComIndexName = "";
                        GetAllCompositeIndex();
                    }

                    $scope.AddComIndex = function () {
                        $scope.AddComp = true;
                        $scope.hdComCreate = true;
                        //$("#AddNewCustId").hide();
                    };

                    $scope.ExitComIndex = function () {
                        //$("#AddCustId").hide();
                        //$("#AddNewCustId").show();
                        $scope.AddComp = false;
                        $scope.hdComCreate = false;
                        $scope.searchComIndexName = "";
                    };

                    $scope.AddNewComIndexRecord = function () {
                        if (angular.isUndefinedOrNullOrEmpty($scope.NewCompositeIndexName)) {
                            MFIMsg.AlertHtml("Please enter composite index name", MFIAlertType.Information);
                            return;
                        }

                        var CompositeIndexMaster = {
                            "COMPINDEXNAME": $scope.NewCompositeIndexName, "strComIndexType": $scope.ComIndexType
                        };
                        var AddCompIndex = PostAddCompositeIndexRecord.Call(CompositeIndexMaster);
                        AddCompIndex.then(function (response) {
                            if (response.data.data) {
                                localStorage.removeItem('GetAllCompositeIndexRec');
                                GetAllCompositeIndex();
                                $scope.NewCompositeIndexName = "";
                                $scope.AddComp = false;
                                MFIMsg.AlertHtml("Index created successfully", MFIAlertType.Information);
                                $scope.hdComCreate = false;
                                $scope.searchComIndexName = "";
                                //$scope.LoaderRatingSearch = false;
                            }
                            else
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.GetComIndexType = function (type) {
                        if (type == "gen")
                            $scope.ComIndexType = 'gen';
                        if (type == "per")
                            $scope.ComIndexType = 'per';
                    }

                    $scope.DeleteComIndex = function (idSelected, selName) {
                        MFIMsg.Confirm("You want to delete '" + selName + "'?", "MFI360 Explorer", "Ok", "Cancel").then(function successCallback(response) {
                            var objDelCompositeIndex = {
                                "COMPINDEXID": idSelected
                            };
                            $scope.LoaderCommonCompositeIndex = true;
                            var deleteIndex = PostDeleteCompositeIndexRecord.Call(objDelCompositeIndex);
                            deleteIndex.then(function (response) {
                                if (response.data.data) {
                                    localStorage.removeItem('GetAllCompositeIndexRec');
                                    GetAllCompositeIndex();
                                    $scope.LoaderCommonCompositeIndex = false;
                                    //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                                    MFIMsg.AlertHtml("Index deleted successfully", MFIAlertType.Success);
                                }
                                else {
                                    $scope.LoaderCommonCompositeIndex = false;
                                    //MFIMsg.Alert(response.data.Message != null ? response.data.Message : "Cannot delete data !!!");
                                    MFIMsg.AlertHtml(response.data.Message != null ? response.data.Message : "Cannot delete data", MFIAlertType.Information);
                                }
                            },
                                function errorCallback(response) {
                                    $scope.LoaderCommonCompositeIndex = false;
                                    MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                                });
                        });
                    };

                    $scope.ModifyComTableIndex = function (idSelected, selName) {
                        $scope.selComId = idSelected;
                        $scope.CompositeIndexName = selName;
                        //$scope.names.selected = angular.copy(idSelected);
                        $scope.EditComVal = true;
                    };

                    $scope.ModifyComIndex = function () {
                        if ($scope.CompositeIndexName == "") {
                            MFIMsg.AlertHtml("Please enter composite index name", MFIAlertType.Information);
                            return false;
                        }
                        var objCompositeIndexMaster = {
                            "COMPINDEXID": $scope.selComId, "COMPINDEXNAME": $scope.CompositeIndexName
                        };
                        var ModifyComIndex = PostModifyCompositeIndexRecord.Call(objCompositeIndexMaster);
                        ModifyComIndex.then(function (response) {
                            if (response.data.data) {
                                localStorage.removeItem('GetAllCompositeIndexRec');
                                GetAllCompositeIndex();
                                $scope.EditComVal = false;
                                //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                                MFIMsg.AlertHtml("Data saved successfully", MFIAlertType.Information);
                                $scope.searchComIndexName = "";
                            }
                            else
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.resetComEdit = function () {
                        //$scope.names.selected = {};
                        //$scope.names.IsImport = false;
                        $scope.EditComVal = false;
                        $scope.searchComIndexName = "";
                    };

                    $scope.ViewComDetailRecords = function (selComObj) {
                        $scope.ComIndMaster = false;
                        $scope.AddModiComp = true;
                        $scope.SelInd.ComIndPartsArr = [];
                        $scope.TotalPer = 0;
                        $scope.ComPartWtg = null;
                        $scope.SelIndex = [];
                        CompositeIndexId = selComObj.COMPINDEXID;
                        var ComObj = { "CompositeIndexId": selComObj.COMPINDEXID };
                        var ComIndDetRec = PostCompositeIndexDetailRecord.Call(ComObj);
                        ComIndDetRec.then(function successCallback(response) {
                            $scope.ComRec = response.data.data;
                            angular.forEach($scope.ComRec, function (value, key) {
                                var comPartRec = { "IndexPartId": value.IndexId, "IndexPartName": value.strIndexName, "IndexPartWtg": value.Weightage };
                                $scope.TotalPer = $scope.TotalPer + value.Weightage;
                                $scope.SelInd.ComIndPartsArr.push(comPartRec);
                            });
                            $scope.TotalPer = $scope.TotalPer + "%";
                        },
                            function errorCallback(response) {
                            });
                        $scope.SelInd.selId = selComObj.COMPINDEXID;
                        $scope.SelInd.createdBy = selComObj.strCreatedBy;
                        $scope.SelInd.createdOn = selComObj.strCreatedOn;
                        $scope.SelInd.modifiedBy = selComObj.strModifiedBy;
                        $scope.SelInd.modifiedOn = selComObj.strModifiedOn;
                        //$("#myModalCustomIndex").show();
                    };

                    $scope.goComBack = function () {
                        $scope.ComIndMaster = true;
                        $scope.AddModiComp = false;
                    };

                    $scope.searchComIndex = function () {
                        if ($scope.searchComIndexName == "") {
                            MFIMsg.AlertHtml("Please enter composite index name", MFIAlertType.Information);
                            return false;
                        }
                        $scope.LoaderCommonCompositeIndex = true;
                        var searchName = { "COMPINDEXNAME": $scope.searchComIndexName };
                        var searchIndex = PostSearchCompositeIndexRecord.Call(searchName);
                        searchIndex.then(function (response) {
                            $scope.Comnames = response.data.data;
                            $scope.LoaderCommonCompositeIndex = false;
                            //alert("Data saved successfully !!!");
                        },
                            function errorCallback(response) {
                                $scope.LoaderCommonCompositeIndex = false;
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    };

                    $scope.AddComIndexPart = function () {

                        if ($scope.SelIndex.IndexName == null || $scope.SelIndex.IndexName == "") {
                            MFIMsg.AlertHtml("Please select MFI Index", MFIAlertType.Information);
                            return;
                        }
                        if ($scope.ComPartWtg == null || $scope.ComPartWtg == "") {
                            MFIMsg.AlertHtml("Please enter Weightage %", MFIAlertType.Information);
                            return;
                        }
                        if (!isNaN($scope.ComPartWtg) && angular.isNumber(parseFloat($scope.ComPartWtg))) {
                        }
                        else {
                            MFIMsg.AlertHtml("Please enter valid Weightage %", MFIAlertType.Information);
                            return;
                        }
                        if ($filter('filter')($scope.SelInd.ComIndPartsArr, { IndexPartId: $scope.SelIndex.IndexId }, true).length == 1) {
                            MFIMsg.AlertHtml("Index already exist", MFIAlertType.Information);
                            return;
                        }
                        var comPartRec = { "IndexPartId": $scope.SelIndex.IndexId, "IndexPartName": $scope.SelIndex.IndexName, "IndexPartWtg": $scope.ComPartWtg };
                        $scope.SelInd.ComIndPartsArr.push(comPartRec);
                        $scope.TotalPer = parseFloat($scope.TotalPer.replace('%', '')) + parseFloat($scope.ComPartWtg);
                        $scope.TotalPer = $scope.TotalPer + "%";
                    };

                    $scope.DeleteComDetRec = function (item) {
                        $scope.SelInd.ComIndPartsArr.forEach(function (iteitem, index) {
                            if (iteitem === item) {
                                $scope.SelInd.ComIndPartsArr.splice(index, 1);
                            }
                        });
                        $scope.TotalPer = parseFloat($scope.TotalPer.replace('%', '')) - parseFloat(item.IndexPartWtg);
                        $scope.TotalPer = $scope.TotalPer + "%";
                    };

                    $scope.WtgValCng = function (num) {
                        if (!isNaN(num) && angular.isNumber(parseFloat(num))) {
                            $scope.TotalPer = 0;
                            angular.forEach($scope.SelInd.ComIndPartsArr, function (value, key) {
                                $scope.TotalPer = parseFloat($scope.TotalPer) + parseFloat(value.IndexPartWtg);
                            });
                            //$scope.TotalPer = parseFloat($scope.TotalPer.replace('%', '')) - parseFloat(num);
                            $scope.TotalPer = $scope.TotalPer + "%";
                        }
                    };

                    $scope.onSelChange = function () {
                        $scope.ComPartWtg = "";
                    }
                    //$scope.EditComDetRec = function (item) {
                    //    $scope.ComPartWtg = item.IndexPartWtg;
                    //    //$scope.SelIndex = { 'IndexId': item.IndexPartId, 'IndexName': item.IndexPartName, 'Id': item.IndexPartId, 'Name': item.IndexPartName, 'IsRestrictedIndex': false, 'IsChecked': false };
                    //    var foundItem = $filter('filter')($scope.LstMFIndexes, { IndexId: item.IndexPartId }, true)[0];
                    //    //get the index
                    //    var index = $scope.LstMFIndexes.indexOf(foundItem);
                    //    $scope.SelIndex = $scope.LstMFIndexes[index];
                    //}

                    $scope.SaveUpdate = function () {
                        if ($scope.TotalPer.replace('%', '') != "100") {
                            MFIMsg.AlertHtml("Summation of weightage is not 100%", MFIAlertType.Information);
                            return;
                        }
                        var comIndRec = [];
                        angular.forEach($scope.SelInd.ComIndPartsArr, function (value, key) {
                            var CompData = { "CompositeIndexId": CompositeIndexId, "IndexId": value.IndexPartId, "Weightage": value.IndexPartWtg, "IsCustomIndex": (value.IndexPartName.indexOf("**") != -1) ? true : false };
                            comIndRec.push(CompData);
                        });
                        var objComInd = { "CompData": comIndRec };
                        var AddComDetIndex = PostAddCompositeIndexDetailRecord.Call(objComInd);
                        AddComDetIndex.then(function (response) {
                            if (response.data.data) {
                                $scope.goComBack();
                                localStorage.removeItem('GetAllCompositeIndexRec');
                                GetAllCompositeIndex();
                                //$scope.EditComVal = false;
                                //$scope.Baseset.LstBasicSelectionvalue[parameter].BasicSettingMappingId = response.data.BasicSettingMappingId;
                                MFIMsg.AlertHtml("Data saved successfully", MFIAlertType.Information);
                            }
                            else
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Information);
                        },
                            function errorCallback(response) {
                                MFIMsg.AlertHtml("Oops, an error occurred", MFIAlertType.Error);
                            });
                    }

                    $scope.closeCompositeIndex = function () {
                        if (screen.width <= 767) {
                            angular.element('#compositeIndexDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#compositeIndexDetails').hide();
                        } else {
                            angular.element('#compositeIndexDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#compositeIndexDetails').hide();
                            });
                        }
                    };

                    $scope.toggleCompositeIndexPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-compositeIndex');
                        var $details = angular.element('#compositeIndexDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };

                }, 0);
            }
        };
    }
]);