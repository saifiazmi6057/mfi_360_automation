//var ServiceFundmanage = angular.module('ServiceFundmanager', []);

//ServiceFundmanage.config(BaseServiceConfig);


SharedServices.service('GetRangeSelectorValues', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/GetRangeSelectorValues',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('FundList', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FundList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('FMDashboardBasicData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMDashboardBasicData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('GetFundManagerDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/GetFundManagerDetails?FundManID=' + id,
            method: 'GET'
        });
    }

}]);


SharedServices.service('GetFMManagedNatureWise', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id, stat) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/GetFMManagedNatureWise?FundManID=' + id + '&Status=' + stat,
            method: 'GET'
        });
    }

}]);



SharedServices.service('FetchCastFMAssetAllocationToParentChild', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FetchCastFMAssetAllocationToParentChild',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('FMCompanywiseAlocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMCompanywiseAlocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('FMSEBIReturnsDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMSEBIReturnsDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);





SharedServices.service('FetchCastSectorAllocationToParentChild', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FetchCastSectorAllocationToParentChild',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('FMSectorWiseCompanyAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMSectorWiseCompanyAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('FundManagerPerformanceHistory', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FundManagerPerformanceHistory',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('FMRatingWiseAllocationParentChild', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMRatingWiseAllocationParentChild',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('FMRatingWiseCompanyAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMRatingWiseCompanyAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('FundCompanyWiseAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FundCompanyWiseAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('GetFMManagedSchemeList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/GetFMManagedSchemeList?FundManID=' + id,
            method: 'GET'
        });
    }

}]);


SharedServices.service('FMCompanyWiseFundAllocation', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMCompanyWiseFundAllocation',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('ReportDateService', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetComPortDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('ReportMaxPortDateService', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMaxPortDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetDefaultSetting', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFetchUserBasicSettings',
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetFMLatestPortfolioDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFMLatestPortfolioDate?FundManID=' + id,
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(id),
            dataType: "json"
        });
    }

}]);
SharedServices.service('ExportDataToExcel', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {

    this.Call = function (dtLst) {


        return $http({
            method: 'post',
            url: '/FundManager/ExportToExcelFMList',
            data: $httpParamSerializerJQLike(dtLst),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }
}]);
SharedServices.service('ExportToExcel', ['$http', '$httpParamSerializerJQLike', function ($http, $httpParamSerializerJQLike) {

    this.Call = function (name, dtLst) {
        return $http({
            method: 'post',
            url: '/FundManager/ExportToExcel' + '?tablename=' + name,
            data: $httpParamSerializerJQLike(dtLst),
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
            }
        });
    }
}]);

SharedServices.service('FMRowDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FMRowDetails',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('FetchFundManagersAdvanced', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/FetchFundManagersAdvanced',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('ExportToPDFExist', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiFundManager/ExportToPDFExist',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);