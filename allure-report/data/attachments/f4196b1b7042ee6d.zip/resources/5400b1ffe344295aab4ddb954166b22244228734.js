angular.isUndefinedOrNull = function (val) {
    return angular.isUndefined(val) || val === null
}
angular.isUndefinedOrNullOrEmpty = function (val) {
    return angular.isUndefined(val) || val === null || val == ""
}
angular.TransposeTable = TransposeTable;


/** * @param {Table} table */
function TransposeTable(table) {
    const data = [...table.Thead, ...table.Tbody];
    data.forEach((row, rowNo) => {
        row.forEach((cell, cellNo) => {
            cell.Rowspan ??= 1; cell.Colspan ??= 1;
        });
    });
    const maxCols = data[0].reduce((prev, curr) => prev + curr.Colspan, 0);
    /** @type TR[] */
    let modifiedData = [];
    for (var i = 0; i < maxCols; i++) {
        modifiedData[i] = [];
    }
    data.forEach((row, rowNo) => {
        let index = 0;
        if (!modifiedData[index]) modifiedData[index] = [];
        row.forEach((cell, cellNo) => {
            cell.Rowspan ??= 1; cell.Colspan ??= 1;
            /** @type {Cell} */
            const newCell = { ...cell, ...{ Colspan: cell.Rowspan, Rowspan: cell.Colspan } };
            let rowInfo = FindStartRow(modifiedData);
            InserCellWithBlanks(newCell, modifiedData, rowInfo.RowNo);
            index += cell.Colspan;
        });
    });
    /** * @param {TR[]} dataRows */
    function FindStartRow(dataRows) {
        let colsNo = dataRows[0].length; let RowNo = 0;
        dataRows.forEach((row, no) => {
            if (row.length < colsNo) {
                colsNo = row.length;
                RowNo = no;
            }
        })
        return { Row: dataRows[RowNo], RowNo: RowNo };
    }
    /**
     * @param {Cell} cell
     * @param {TR[]} dataRows
     * @param {number} rowNo
     */
    function InserCellWithBlanks(cell, dataRows, rowNo) {
        let newCell = cell;
        for (let i = rowNo; i < rowNo + cell.Rowspan; i++) {
            for (var j = 0; j < cell.Colspan; j++) {
                dataRows[i].push(newCell); newCell = { IsHidden: true };
            }
        }
    }
    /** @type Table */
    const newTable = {
        Thead: modifiedData.slice(0, 1),
        Tbody: modifiedData.slice(1),
    }
    return newTable;
}

angular.SortListByProperty = SortListByProperty;

/**
 * @typedef {Object} Header
 * @property {boolean} SortByDESC
 * @property {boolean} SortByASC
 * @property {string} PropertyName
 * 
 * @param {any[]} arr
 * @param {'ASC' | 'DESC'} SortOrder
 * @param {Header} Header
 */
function SortListByProperty(arr, SortOrder, Header) {
    const orderValue = SortOrder === 'ASC' ? 1 : -1;
    if (SortOrder === 'ASC') { // For updating html 
        Header.SortByASC = false; Header.SortByDESC = true;
    } else {
        Header.SortByASC = true; Header.SortByDESC = false;
    }
    arr = arr.sort((a, b) => {
        let [aStr, bStr] = [String(a[Header.PropertyName]).toLowerCase(), String(b[Header.PropertyName]).toLowerCase()];
        let aDate = new Date(aStr), bDate = new Date(bStr);
        if (!isNaN(aDate.getTime()) && !isNaN(bDate.getTime()))
            return orderValue * (aDate < bDate ? -1 : aDate > bDate ? 1 : 0);
        let aNum = parseFloat(aStr), bNum = parseFloat(bStr);
        if (!isNaN(aNum) && !isNaN(bNum))
            return orderValue * (aNum < bNum ? -1 : aNum > bNum ? 1 : 0);

        return orderValue * (aStr < bStr ? -1 : aStr > bStr ? 1 : 0);
    });
    return { arr: arr, Header: Header };
}
angular.generateUUID = () => {
    let
        d = new Date().getTime(),
        d2 = ((typeof performance !== 'undefined') && performance.now && (performance.now() * 1000)) || 0;
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        let r = Math.random() * 16;
        if (d > 0) {
            r = (d + r) % 16 | 0;
            d = Math.floor(d / 16);
        } else {
            r = (d2 + r) % 16 | 0;
            d2 = Math.floor(d2 / 16);
        }
        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
    });
};
angular.generateID = () => `id_${angular.generateUUID()}`;
$.fn.input_val = function () {
    if (typeof ($(this)) === "undefined") {
        return '';
    }
    if ($(this).is("input[type=checkbox]")) {
        if ($(this).is(":checked")) {
            return $(this).val();
        } else {
            return false;
        }
    }
    else if ($(this).is("input[type=radio]")) {
        if ($(this).is(":checked")) {
            return $(this).val();
        } else {
            return false;
        }
    }
    else if ($(this).is("input[type=input]")) {
        return $(this).val();
    }
    else if ($(this).is("input[type=hidden]")) {
        return $(this).val();
    } else {
        return $(this).val();
    }
};

$.fn.scrollView = function () {
    return this.each(function () {
        $('html, body').animate({
            scrollTop: $(this).offset().top
        }, 500);
    });
}

$(function () {
    var interval;
    $('[rel=popover]').popover({
        trigger: 'hover',
        template: '<div class="popover"><div class="arrow"></div><div class="popover-inner"><div class="popover-content"><p></p></div></div></div>'
    });



    jQuery.event.special.contentchange = {
        setup: function () {
            var self = this,
                $this = $(this),
                $originalContent = $this.text();
            interval = setInterval(function () {
                if ($originalContent != $this.text()) {
                    $originalContent = $this.text();
                    jQuery.event.handle.call(self, { type: 'contentchange' });
                }
            }, 100);
        },
        teardown: function () {
            clearInterval(interval);
        }
    };

    var autocompleter = $("input#autocomplete");
    autocompleter.unbind("blur.autocomplete")

    var ajaxForSubmit = function () {
        var $form = $(this);
        var $loading = $($form.attr("data-mfi-loading"));
        var $target = $($form.attr("data-mfi-target"));
        //var $block = $($form.attr("data-mfi-block"));
        var $hideShow = $($form.attr("data-mfi-hideShow"));
        var $scrollTo = $($form.attr("data-mfi-scrollToControl"));
        var $sortList = $form.attr("data-mfi-sortListBox");
        var $fixedHeader = $($form.attr("data-mfi-fixedtableHeader"));
        var options = {
            cache: false,
            url: $form.attr("action"),
            type: $form.attr("method"),
            data: $form.serialize(),
            beforeSend: function (data) {
                $target.hide();
                $loading.show();
                $hideShow.hide();
            },
            error: function () {
                $loading.hide();
                $target.html('<p>Sorry, An error occurred, please try again later...</p>');
                $target.show();
                $target.effect("pulsate");
            }
        };
        $.ajax(options).done(function (data) {
            var $newHtml = $($.trim(data));
            $target.html($newHtml);
            $target.show();
            $newHtml.effect("highlight");
            $loading.hide();
            $scrollTo.scrollView();
            $hideShow.show();
            if (typeof ($sortList) != "undefined")
                Sort($sortList);
            if ($fixedHeader.length != 0)
                $fixedHeader.fixedtableheader();
        });
        return false;
    };

    createAutoComplete = function () {
        //debugger;

        var $input = $(this);
        var $additional = $($input.attr('data-mfi-autocomplete-additionalparam'));
        var $hidden = $($input.attr('data-mfi-autocomplete-hiddenval'));
        var $progress = $($input.attr('data-mfi-autocomplete-progressval'));
        var $autoURl = $($input.attr('data-mfi-set-auto-url'));//syed
        //====Rajat        
        var minLength = 1;
        var inputMinlength = $input.attr('data-mfi-autocomplete-minlength');
        if (typeof (inputMinlength) === "undefined") {
            minLength = 3;
        }
        else {
            minLength = parseInt(inputMinlength);
        }

        //=====Rajat
        var options = {
            cache: false,
            source: function (request, response) {

                $.post($input.attr('data-mfi-autocomplete') + '?additionalparamvalue=' + $additional.val(), request, response)
                    //$.post($input.attr('data-mfi-autocomplete') + '?additionalparamvalue=' + $input.attr('data-mfi-autocomplete-additionalparam'), request, response)
                    //               
                    .fail(function (ev) {
                        // debugger;
                        if (ev.status == 401) {
                            window.location = "/Home/SessionTimeOut";
                        }
                        else {
                            alert('Failed to fetch data, timeout occurred, please try again in a few seconds.');
                            if (typeof ($progress) !== "undefined") {
                                $progress.hide();
                            }
                        }
                    });
            },
            //            error: function (ev,error) {
            //            debugger;
            //                        if (ev.status === 401) {
            //                       window.location="/Home/SessionTimeOut";
            //                    }
            //                    //$loading.hide();
            //                    $target.html('<p>Sorry, An error occurred, please try again later...</p>');
            //                    $target.show();
            //                    $target.effect("pulsate");
            //                     waitingDialog.hide();
            //                }
            //            },
            type: 'POST',
            //minLength: 3,
            minLength: minLength,//rajat
            focus: function (event, ui) {
                var $txt = $(this);
                $txt.val(ui.item.label);
                return false;
            },
            select: function (event, ui) {
                // debugger;
                var $txt = $(this);
                $txt.val(ui.item.label);
                $hidden.val(ui.item.id).trigger('change');
                //alert($hidden.val());
                //alert($hidden.attr('id'));
                //var AttId = $hidden.attr('id');
                //$("#" + AttId).val(ui.item.id);
                //alert($("#" + AttId).val());
            },

            search: function () {
                $hidden.val(-1);
                if (typeof ($progress) !== "undefined") {
                    $progress.show();
                }
            },
            response: function () {
                if (typeof ($progress) !== "undefined") {
                    $progress.hide();
                }
            },
            open: function () {
                $("li.ui-menu-item a").each(function (index) {
                    $(this).addClass('tooltip1');
                    $(this).attr("title", $(this).text());
                });
                $('.tooltip1').tooltipster({ position: 'left' });
                //$('#tbl_Add_Activities .ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all').attr("Style", "z-index: 1100");
                //$('.ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all').css({ 'z-index': '1200' });
                //ui-id-1
                //$('.ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all').attr({ "style": "z-index:1200" });
                //$('#ui-id-1').attr({ "style": "z-index:1200" });
                $('.ui-autocomplete').css("zIndex", "3000");

            }
        };
        $input.autocomplete(options);
    };

    var getPage = function () {
        var $a = $(this);
        var options = {
            url: $a.attr("href"),
            type: "get",
            data: $("form").serialize()
        };

        $.ajax(options).done(function (data) {
            var target = $a.parents("div.pagedList").attr("data-mfi-target");
            $(target).replaceWith(data);
        });

        return false;
    };

    $("form[data-mfi-ajax='true']").submit(ajaxForSubmit);
    $("input[data-mfi-autocomplete]").each(createAutoComplete);
    $(".main-content").on("click", ".pagedList a", getPage);

    // $("#schemeWatchText").watermark("Type scheme name");
    $('#icraOnline').css('cursor', 'pointer');
    $('#icraOnline').click(function () {
        window.location.href = 'http://www.icraanalytics.com';
    });



    //$("a[data-target=#feedBack]").click(function (ev) {
    //    ev.preventDefault();
    //    $.ajax({
    //        cache: false,
    //        dataType: "html",
    //        url: '/Feedback/Add',
    //        type: 'GET',
    //        success: function (results) {
    //            $("#feedBack .modal-body").html(results);
    //            addRecaptcha('recaptcha_div');
    //            $("#Email").watermark("Type e-mail");
    //            $("#Password").watermark("Type password");
    //            $("#ConfirmPassword").watermark("Confirm password");
    //            $('#fdWithoutReg').click(function (ev) {
    //                if (feedbackValidation() == false)
    //                    return false;
    //                if ($('#Email').val().trim() == "") {
    //                    alert('Please provide an e-mail.');
    //                    $('#Email').focus();
    //                    return false;
    //                }
    //            });
    //            $('#fdWithReg').click(function (ev) {
    //                if (feedbackValidation() == false)
    //                    return false;
    //                if ($('#Email').val().trim() == "") {
    //                    alert('Please provide an e-mail.');
    //                    $('#Email').focus();
    //                    return false;
    //                }
    //                if ($('#Password').val().trim() == "" || $('#ConfirmPassword').val().trim() == "") {
    //                    $('#Password').focus();
    //                    alert('Please provide password properly.');
    //                    return false;
    //                }
    //                if ($('#Password').val().trim() != $('#ConfirmPassword').val().trim()) {
    //                    $('#Password').focus();
    //                    alert('Passwords do not match.');
    //                    return false;
    //                }
    //            });
    //            //---------------------------add by syed //-------------------//
    //            $('#Description').keyup(function (ev) {
    //                limitText(this, 500);
    //            });
    //            $('#Title').keyup(function (ev) {
    //                if (this.value.length > 50) {
    //                    this.value = this.value.substring(0, 50);
    //                }
    //            })
    //            //-------------------------------end------------------------//
    //            $('#frmFeedback').submit(function (ev) {
    //                ev.preventDefault();
    //                $.ajax({
    //                    url: '/Feedback/Add',
    //                    type: 'POST',
    //                    data: $("#frmFeedback").serialize(),
    //                    success: function (results) {
    //                        if (results.substr(results.length - 1).toUpperCase() == "N") {
    //                            alert(results.substring(0, results.length - 1));
    //                            $("#feedBack").modal("show");
    //                        }
    //                        else {
    //                            alert(results);
    //                            $("#feedBack").modal("hide");
    //                            resetFeedback();
    //                        }
    //                    },
    //                    failure: function (error) {
    //                        alert('Failed to submit. Please try again after sometime.');
    //                        $("#feedBack").modal("hide");
    //                    }
    //                });

    //            });
    //            $("#feedBack").modal("show");
    //        },
    //        error: function (data) {
    //            alert('Sorry, Can not open feedback now.');
    //            $("#feedBack").modal("show");
    //        }
    //    });
    //});

    $("#frmHomeSearch a").click(function (ev) {
        ev.preventDefault;
        //alert("test");
        $("#frmHomeSearch").submit();
    });

    //$("a").click(function (ev) {
    //    debugger;
    //    if (this.parentNode.nodeName == "LI") {
    //        //this.parentNode.attr.addClass("Active");
    //        $(this).parent().attr('class', 'Active');
    //    }
    //});
});

function OpenAlert(messageBody, headerText, width) {
    //    if (height == null) {
    //        height = 200;
    //    }
    var width1 = 430;
    if (width == null) {
        width = 400;
    }
    if (headerText == null) {
        headerText = "&nbsp;";
    }
    var divv = "<div id='mfiMessageBox' style='position:fixed;top:30%;left:0%' class='modal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>"
        + "<div class='modal-dialog' style='width:" + width.toString() + "px'>"
        + "<div class='modal-content'>"
        + "<div class='modal-header'>"
        + "<span >" + headerText + "</label>" + "</span>" + "<button type='button' class='close' data-dismiss='modal' aria-hidden='true' style='padding-right:1px; color:#fff'>×</button>" +
        "</div>" +
        "<div class='modal-body'>" +
        "<p style='margin-bottom:0px;'>" + messageBody + "</p>" +
        "</div>" + '<div></div>' +
        "<div class='modal-footer'>" +
        "<button class='btn btn-default btn-sm'  data-dismiss='modal' >OK</button>" +
        "</div>" +
        "</div>" +
        "</div>" +
        "</div>";
    $('#mfiMessageBox').remove();
    //var modal = $('#mfiMessageBox');
    //modal.css({"margin-top":(modal.outerHeight() / 2) * -1,'margin-left':(modal.outerWidth() / 2) * -1});
    //modal.css('margin-left', (modal.outerWidth() / 2) * -1);
    var modalAlert = $(divv);
    //    modalAlert.modal({                
    //                keyboard: true,
    //                backdrop:false
    //    })  
    //======i have to register the event before modal show like following way
    modalAlert.on('show.bs.modal', function () {
        $('.btn').focus();
    });

    modalAlert.on('hidden.bs.modal', function () {
        $(this).remove();
    });
    modalAlert.modal({
        keyboard: true,
        backdrop: false
    });
    //==============
    modalAlert.draggable({
        handle: ".modal-header1",
        // cursor: "move"
    });
    modalAlert.mouseenter(function () {
        $('.modal-header1').css('cursor', 'move');
    });
    return false;
}

function customDateParse(str) {
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        n = months.length, re = /(\d{2}) ([a-z]{3}) (\d{4})/i, matches;

    while (n--) { months[months[n]] = n; } // map month names to their index :)

    matches = str.match(re); // extract date parts from string

    return new Date(matches[3], months[matches[2]], matches[1]);
}

function OpenConfirm(messageBody, width, headeText) {
    //    if (height == null) {
    //        height = 200;
    //    }
    if (width == null) {
        width = 350;
    }
    if (headeText == null) {
        headeText = "ICRON INTRANET";
    }
    var divv = "<div id='mfiMessageBox' style='width:" + width.toString() + "px;position:fixed;top:70%;left:60%' class='modal hide fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>"
        + "<div class='modal-header' style='background-color:#BDBDBD;'>"
        + "<span >" + headeText + "</label>" + "</span>" + "<button type='button' class='close' data-dismiss='modal' aria-hidden='true' style='padding-right:1px'>×</button>" +
        "</div>" +
        "<div class='modal-body'>" +
        "<p>" + messageBody + "</p>" +
        "</div>" + '<div></div>' +
        "<div class='modal-footer'style='background-color:#F0F0F0;'>" +
        "<button class='btn' style='padding-bottom:3px'  data-dismiss='modal' aria-hidden='true'>Close</button>" +
        "<button class='btn btn-primary' style='padding-bottom:3px' onclick='OkClicked();'  data-dismiss='modal' aria-hidden='true'>OK</button>" +
        "</div>" +
        "</div>";
    //var modal = $('#mfiMessageBox');
    //modal.css({"margin-top":(modal.outerHeight() / 2) * -1,'margin-left':(modal.outerWidth() / 2) * -1});
    //modal.css('margin-left', (modal.outerWidth() / 2) * -1);
    var modalAlert = $(divv);
    modalAlert.modal({
        keyboard: true,
        backdrop: false
    })
    modalAlert.draggable({
        handle: ".modal-header",
        // cursor: "move"
    });
    modalAlert.mouseenter(function () {
        $('.modal-header').css('cursor', 'move');
    });
    if (GlobalClickOkOrNot == false) {
        return false;
    }
    else {
        return true;
    }
}
var GlobalClickOkOrNot = false;
function OkClicked() {
    alert('rajat');
    GlobalClickOkOrNot = true;
}
function validateEmail(sEmail) {

    //var index = sEmail.toString().indexOf('.com');
    //if (index > 0) {
    //    return false;
    //}
    var filter = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if (filter.test(sEmail)) {
        return true;
    }
    else {
        return false;
    }
}

function ShowMessageLogin() {
    //bootbox.confirm("Please log in using your registered id to download the report", function (result) {
    //    if (result == true) {
    //        window.location.href = "/Account/Login";
    //    }
    //});

    bootbox.dialog({
        message: "Please log in using your registered login id to download the report",
        buttons: {
            main: {
                label: "Ok",
                className: "btn btn-primary btn-sm",
                callback: function () {
                    window.location.href = "/Account/Login";
                }
            },
            main1: {
                label: "Cancel",
                className: "btn btn-danger btn-sm",
                callback: function () {

                }
            }
        }
    });

}
function ShowMessageLoginView() {
    //bootbox.confirm("Please log in using your registered id to download the report", function (result) {
    //    if (result == true) {
    //        window.location.href = "/Account/Login";
    //    }
    //});

    bootbox.dialog({
        message: "Please log in using your registered id to view the report",
        buttons: {
            main: {
                label: "Ok",
                className: "btn btn-primary btn-sm",
                callback: function () {
                    window.location.href = "/Account/Login";
                }
            },
            main1: {
                label: "Cancel",
                className: "btn btn-danger btn-sm",
                callback: function () {

                }
            }
        }
    });

}



function ShowMessagePlayerProfileLogin() {
    //bootbox.confirm("Please log in using your registered id to view the report", function (result) {
    //    if (result == true) {
    //        window.location.href = "/Account/Login";
    //    }
    //});

    bootbox.dialog({
        message: "Please log in using your registered id to view the report",
        buttons: {
            main: {
                label: "Ok",
                className: "btn btn-primary btn-sm",
                callback: function () {
                    window.location.href = "/Account/Login";
                }
            },
            main1: {
                label: "Cancel",
                className: "btn btn-danger btn-sm",
                callback: function () {

                }
            }
        }
    });
}

function ShowMessageSubscribtion() {
    //bootbox.confirm("You are currently not subscribed to use this feature. Please contact support@icraoinline.com / Phone: +91-124-4545300", function (result) {
    //    //if (result == true) {
    //    //    window.location.href("/Account/Login");
    //    //}
    //});

    bootbox.dialog({
        message: "You are currently not subscribed to use this feature. Please contact email id infodesk@icraindia.com",
        buttons: {
            main: {
                label: "Ok",
                className: "btn btn-primary btn-sm",
                callback: function () {
                    // window.location.href = "/Account/Login";
                }
            }
        }
    });
}

//bootbox.confirm({
//    title: "danger - danger - danger",
//    message: "Are you sure of this?",
//    buttons: {
//        cancel: {
//            label: "Cancel",
//            className: "btn-default pull-right"
//        },
//        confirm: {
//            label: "Delete",
//            className: "btn-danger pull-left"
//        }
//    },
//    callback: function (result) {
//        // Do your stuff here
//    }
//});

function showplaceholeder() {
    jQuery(function () {
        jQuery.support.placeholder = false;
        webkit_type = document.createElement('input');
        if ('placeholder' in webkit_type) jQuery.support.placeholder = true;
    });
    $(function () {

        if (!$.support.placeholder) {

            var active = document.activeElement;

            $(':text, textarea, :password').focus(function () {

                if (($(this).attr('placeholder')) && ($(this).attr('placeholder').length > 0) && ($(this).attr('placeholder') != '') && $(this).val() == $(this).attr('placeholder')) {
                    $(this).val('').removeClass('hasPlaceholder');
                }
            }).blur(function () {
                if (($(this).attr('placeholder')) && ($(this).attr('placeholder').length > 0) && ($(this).attr('placeholder') != '') && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                    $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
                }
            });

            $(':text, textarea, :password').blur();
            $(active).focus();


            $(':text, textarea, :password').focus(function () {

                if (($(this).attr('placeholder')) && ($(this).attr('placeholder').length > 0) && ($(this).attr('placeholder') != '') && $(this).val() == $(this).attr('placeholder')) {
                    $(this).val('').removeClass('hasPlaceholder');
                }
            }).load(function () {
                if (($(this).attr('placeholder')) && ($(this).attr('placeholder').length > 0) && ($(this).attr('placeholder') != '') && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                    $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
                }
            });
            $(':text, textarea, :password').load();
            $(active).focus();


            $('form').submit(function () {
                $(this).find('.hasPlaceholder').each(function () { $(this).val(''); });
            });
        }
    });
}

function SessionCheck(ev) {
    if (ev.status == 401) {
        //alert("tyr");
        window.location = "/Home/SessionTimeOut";
    }
}