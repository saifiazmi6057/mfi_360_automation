
/**
 * Resize function without multiple trigger
 * 
 * Usage:
 * $(window).smartresize(function(){  
 *     // code here
 * });
 */
(function($,sr){
    // debouncing function from John Hann
    // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
    var debounce = function (func, threshold, execAsap) {
      var timeout;

        return function debounced () {
            var obj = this, args = arguments;
            function delayed () {
                if (!execAsap)
                    func.apply(obj, args); 
                timeout = null; 
            }

            if (timeout)
                clearTimeout(timeout);
            else if (execAsap)
                func.apply(obj, args);

            timeout = setTimeout(delayed, threshold || 100); 
        };
    };

    // smartresize 
    jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');
/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var CURRENT_URL = window.location.href.split('#')[0].split('?')[0],
    $BODY = $('body'),
    $MENU_TOGGLE = $('#menu_toggle'),
    $SIDEBAR_MENU = $('#sidebar-menu'),
    $SIDEBAR_FOOTER = $('.sidebar-footer'),
    $LEFT_COL = $('.left_col'),
    $RIGHT_COL = $('.right_col'),
    $NAV_MENU = $('.nav_menu'),
    $FOOTER = $('footer');

// Sidebar
function init_sidebar() {
    // TODO: This is some kind of easy fix, maybe we can improve this
    var setContentHeight = function () {
        // reset height
        $RIGHT_COL.css('min-height', $(window).height());

        var bodyHeight = $BODY.outerHeight(),
            footerHeight = $BODY.hasClass('footer_fixed') ? -10 : $FOOTER.height(),
            leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
            contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

        // normalize content
        contentHeight -= $NAV_MENU.height() + footerHeight;

        $RIGHT_COL.css('min-height', contentHeight);
    };

    $SIDEBAR_MENU.find('a').on('click',function (ev) {
        //   console.log('clicked - sidebar_menu');
        var $li = $(this).parent();

        if ($li.is('.active')) {
            $li.removeClass('active active-sm');
            $('ul:first', $li).slideUp(function () {
                setContentHeight();
            });
        } else {
            // prevent closing menu if we are on child menu
            if (!$li.parent().is('.child_menu')) {
                $SIDEBAR_MENU.find('li').removeClass('active active-sm');
                $SIDEBAR_MENU.find('li ul').slideUp();
            } else {
                if ($BODY.is(".nav-sm")) {
                    $SIDEBAR_MENU.find("li").removeClass("active active-sm");
                    //	$SIDEBAR_MENU.find( "li ul" ).slideUp();
                }
            }
           $li.addClass('active');
           //$li.removeClass('active');

           $('ul:first', $li).slideDown(function () {
                setContentHeight();
            });
        }
    });

    // toggle small or large menu 
    $MENU_TOGGLE.on('click', function () {
        console.log('clicked - menu toggle');

        if ($BODY.hasClass('nav-md')) {
            $SIDEBAR_MENU.find('li.active ul').hide();
            $SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
        } else {
            $SIDEBAR_MENU.find('li.active-sm ul').show();
            $SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
        }

        $BODY.toggleClass('nav-md nav-sm');

        setContentHeight();

        $('.dataTable').each(function () { $(this).dataTable().fnDraw(); });
    });

    // check active menu
    $SIDEBAR_MENU.find('a[href="' + CURRENT_URL + '"]').parent('li').addClass('current-page');

    $SIDEBAR_MENU.find('a').filter(function () {
        return this.href == CURRENT_URL;
    }).parent('li').addClass('current-page').parents('ul').slideDown(function () {
        setContentHeight();
    }).parent().addClass('active');

    // recompute content when resizing
    $(window).smartresize(function () {
        setContentHeight();
    });

    setContentHeight();

    // fixed sidebar
    if ($.fn.mCustomScrollbar) {
        $('.menu_fixed').mCustomScrollbar({
            autoHideScrollbar: true,
            theme: 'minimal',
            mouseWheel: { preventDefault: true }
        });
    }
}
// /Sidebar

// Tooltip
$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip({
        container: 'body'
    });
});
// /Tooltip

// NProgress
if (typeof NProgress != 'undefined') {
    $(document).ready(function () {
        NProgress.start();
    });

    $(window).load(function () {
        NProgress.done();
    });
}

//hover and retain popover when on popover content
var originalLeave = $.fn.popover.Constructor.prototype.leave;
$.fn.popover.Constructor.prototype.leave = function(obj) {
  var self = obj instanceof this.constructor ?
	obj : $(obj.currentTarget)[this.type](this.getDelegateOptions()).data('bs.' + this.type);
  var container, timeout;

  originalLeave.call(this, obj);

  if (obj.currentTarget) {
	container = $(obj.currentTarget).siblings('.popover');
	timeout = self.timeout;
	container.one('mouseenter', function() {
	  //We entered the actual popover – call off the dogs
	  clearTimeout(timeout);
	  //Let's monitor popover content instead
	  container.one('mouseleave', function() {
		$.fn.popover.Constructor.prototype.leave.call(self, self);
	  });
	});
  }
};

$('body').popover({
  selector: '[data-popover]',
  trigger: 'click hover',
  delay: {
	show: 50,
	hide: 400
  }
});

//displaying the result table
function init_fetchResult(){
    $('#fetchResult').on('click', function(){
        $(this).hide();
        $('#fetchResult1').hide();
       $('#result-div').show();
       $('#appliedFilter').show();
        $('#filter').show().removeClass('filter-overlap');
        $('#backToFilter').removeClass('hidden').show();
        $('#filter').slideUp();
        $('#closeFilter').hide();
        $('#schemePerformanceResultDisplay').removeClass('hidden').slideDown();
        
    });
};

//displaying the filter div
function init_filterReveal(){
    $('#backToFilter').on('click', function(){
         //$(this,'#result-div').show();
        $('#closeFilter').css('bottom','0');
        $('#fetchResult').show();
        $('#fetchResult1').show();
        $('#closeFilter').show();
        $('#filter').addClass('filter-overlap');
        $('#closeFilter').animate({
            opacity: 1,
            bottom: "-435px"
        },500);
        $('#filter').slideDown(500);
    });
};

//closing filter on click
function init_closeFilter(){
    $('#closeFilter').on('click', function(){
        $(this).animate({
            bottom: 0,
            opacity: 0
        },500);
        $('#filter').slideUp(500);
    });
};

//custom scrollbar
function init_customScrollBar(){
    (function($){
        $(window).on("load",function(){
			if ($.fn.mCustomScrollbar) {
                $(".overflow-scroll").mCustomScrollbar();
			}
        });
    })(jQuery);
};

function init_settingPanel(){
    $('.btn_setting').on('click', function(){
        $('#settingOverlay').delay(100).fadeIn();
        $('#settingContainer').delay(200).animate({
            right: "0"
        });
        $("body").css("overflow","hidden")
    });

    $('.btn-close').on('click', function(){
        $('#settingContainer').delay(200).animate({
            right: "-230px"
        });
        $('#settingOverlay').delay(350).fadeOut();
        $("#appSettingDetails").fadeOut();
        $("#advanceSettingDetails").fadeOut();
        $("#customIndexDetails").fadeOut();
        $("#instrumentSetDetails").fadeOut();
        $("#ratingSetDetails").fadeOut();
        $("#customSectorDetails").fadeOut();
        $("#returnSettingDetails").fadeOut();
        $("#customIndexPortfolioDetails").fadeOut();
        $("#compositeIndexDetails").fadeOut();
        $("#compositeSchemesDetails").fadeOut();
        $("body").removeAttr("style")
    });
};

function init_saveSearch(){
    $('#saveSearch').on('click', function(){
        $('#modalSaveSearch').modal('toggle');
    });
}

function init_settingMenu() {
    var displayWidth = window.innerWidth - 236;
    var displayHeight = window.innerHeight - 60;
    $('#appSetting').on('click', function () {
        //$(this).unbind();
        if($('#appSettingDetails').css('display') != 'none')
        {
            
            return ;
            //$(this).unbind();
        }
        $('#appSettingDetails').removeClass('settings-page-transition-active');
      //  console.log("screen.width", screen.width);
       $('.setting-submenu').hide();
      //$("#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#appSettingDetails').show().css({
                width: '95%',
                right: "-8px",
                top: "30px",
               // marginTop: "70px",
                //height: "400px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#appSettingDetails #expand-collapse-img-blk').css({'display':'none'});
            $('#appSettingDetails #main-blk').css({'width':'100%'});
        }
        
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#appSettingDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#appSettingDetails').show().css({
                width: "65%",
                //right: "210px",
               // width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
                
            }, 70);
            $('#expand-collapse-block').removeClass('fa-angle-double-right');
            $('#expand-collapse-block').addClass('fa-angle-double-left');

        }
        $('#appSettingDetails').addClass('settings-page-transition-active');
    });
 
    $('#advanceSetting').on('click', function () {
        //$(this).unbind();
        if($('#advanceSettingDetails').css('display') != 'none')
        {
            return ;
        }
        $('#advanceSettingDetails').removeClass('settings-page-transition-active');
      //  console.log("screen.width", screen.width);
       $('.setting-submenu').hide();
      //$("#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#advanceSettingDetails').show().css({
                width: '95%',
                right: "-8px",
                top: "30px",
               // marginTop: "70px",
                //height: "400px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#advanceSettingDetails #expand-collapse-img-blk').css({'display':'none'});
            $('#advanceSettingDetails #main-blk').css({'width':'100%'});
        }
        
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#advanceSettingDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#advanceSettingDetails').show().css({
                width: "65%",
                //right: "210px",
               // width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
                
            }, 70);
            $('#expand-collapse-block-advancesettings').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-advancesettings').addClass('fa-angle-double-left');

        }
        $('#advanceSettingDetails').addClass('settings-page-transition-active');
    });

    $('#instrumentSet').on('click', function () {
         if($('#instrumentSetDetails').css('display') != 'none')
            {
                return ;
            }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#instrumentSetDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#instrumentSetDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#instrumentSetDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#instrumentSetDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#instrumentSetDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#instrumentSetDetails').show().css({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-instrument').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-instrument').addClass('fa-angle-double-left');
        }
        $('#instrumentSetDetails').addClass('settings-page-transition-active');
    });

    $('#ratingSet').on('click', function () {
        if($('#ratingSetDetails').css('display') != 'none')
                    {
                        return ;
                    }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#ratingSetDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //alert("ratingSet");
        //$("#appSettingDetails,#instrumentSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#ratingSetDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#ratingSetDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#ratingSetDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#ratingSetDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#ratingSetDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-ratingset').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-ratingset').addClass('fa-angle-double-left');
        }
        $('#ratingSetDetails').addClass('settings-page-transition-active');
    });

    $('#customSector').on('click', function () {
        if($('#customSectorDetails').css('display') != 'none')
                    {
                        return ;
                    }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#customSectorDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //alert("customSector");
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#customSectorDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#customSectorDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#customSectorDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width <= 768 && screen.width <= 980){
        //    $('#customSectorDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#customSectorDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-customSector').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-customSector').addClass('fa-angle-double-left');
        }
        $('#customSectorDetails').addClass('settings-page-transition-active');
    });

    $('#customIndex').on('click', function () {
        if($('#customIndexDetails').css('display') != 'none')
                    {
                        return ;
                    }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#customIndexDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#customIndexDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#customIndexDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#customIndexDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#customIndexDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#customIndexDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-customIndex').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-customIndex').addClass('fa-angle-double-left');
        }
        $('#customIndexDetails').addClass('settings-page-transition-active');
    });

    $('#customIndexPortfolio').on('click', function () {
        if ($('#customIndexPortfolioDetails').css('display') != 'none') {
            return;
        }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#customIndexPortfolioDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#returnSettingDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#customIndexPortfolioDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#customIndexPortfolioDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#customIndexPortfolioDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#customIndexDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#customIndexPortfolioDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-customIndexPortfolio').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-customIndexPortfolio').addClass('fa-angle-double-left');
        }
        $('#customIndexPortfolioDetails').addClass('settings-page-transition-active');
    });

    $('#returnSetting').on('click', function () {
        if($('#returnSettingDetails').css('display') != 'none')
                            {
                               return ;
                           }
       // $(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#returnSettingDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#compositeSchemesDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#returnSettingDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                 top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#returnSettingDetails #expand-collapse-img-blk').css({'display':'none'});
            $('#returnSettingDetails #main-blk').css({'width':'100%'});
        }
        //else if (screen.width >= 768 && screen.width <= 980) {
        //    $('#returnSettingDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#returnSettingDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-return').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-return').addClass('fa-angle-double-left');
        }
        $('#returnSettingDetails').addClass('settings-page-transition-active');
    });

    $('#compositeSchemes').on('click', function () {
        if($('#compositeSchemesDetails').css('display') != 'none')
                            {
                                return ;
                            }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#compositeSchemesDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeIndexDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#compositeSchemesDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#compositeSchemesDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#compositeSchemesDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width >= 768 & screen.width <= 980) {
        //    $('#compositeSchemesDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#compositeSchemesDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-compositeScheme').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-compositeScheme').addClass('fa-angle-double-left');
        }
        $('#compositeSchemesDetails').addClass('settings-page-transition-active');
    });

    $('#compositeIndex').on('click', function () {
        if($('#compositeIndexDetails').css('display') != 'none')
                            {
                                return ;
                            }
        //$(this).unbind();
        //var displayWidth = window.innerWidth - 236;
        //var displayHeight = window.innerHeight - 60;
        $('#compositeIndexDetails').removeClass('settings-page-transition-active');
        $('.setting-submenu').hide();
        //$("#appSettingDetails,#instrumentSetDetails,#ratingSetDetails,#customSectorDetails,#customIndexDetails,#returnSettingDetails,#compositeSchemesDetails").hide();
        if (screen.width <= 767) {
            $("#settingContainer").fadeOut();
            $('#compositeIndexDetails').show().css({
                width: '95%',
                right: "-8px",
                //marginTop: "70px",
                //height: "400px",
                top: "30px",
                height: displayHeight + "px",
                overflow: "auto"
            }, 70);
            $('#compositeIndexDetails #expand-collapse-img-blk').css({ 'display': 'none' });
            $('#compositeIndexDetails #main-blk').css({ 'width': '100%' });
        }
        //else if (screen.width <= 768 && screen.width <= 980) {
        //    $('#compositeIndexDetails').show().css({
        //        width: '71%',
        //        right: "-8px",
        //        marginTop: "71px",
        //        height: "650px",
        //        overflow: "auto"
        //    }, 70);
        //}
        else {
            $('#compositeIndexDetails').show().animate({
                width: '65%',
                //right: "210px"
                //width: displayWidth + "px",
                top: "30px",
                right: "212px",
                height: displayHeight + "px"
            }, 70);
            $('#expand-collapse-block-compositeIndex').removeClass('fa-angle-double-right');
            $('#expand-collapse-block-compositeIndex').addClass('fa-angle-double-left');
        }
        $('#compositeIndexDetails').addClass('settings-page-transition-active');
    });
}


/* for the fun manager section - soumya -- start */
function init_fundManaggerResultShow(){
    var lastentry = "";

    $('#searchFM').keyup(function() {
        if($('#searchFM').val() != lastentry) {       
            $('.fund-manager__search-list').slideDown();
        }
    });

    $('#clear-fm-search-result').on('click', function(){
        $('.fund-manager__search-list').slideUp(function(){
            $('#searchFM').val('');
        });        
    });
}

function init_showFMAdvFilter(){
    $('#showFMAdvFilter').on('click', function(){
        $('.fund-adv-filter').fadeToggle();
    });
}
function init_showFMAdvFilterSebi() {
    $('#showFMAdvFilterSebi').on('click', function () {
        $('.fund-adv-filtersebi').fadeToggle();
    });
}

function init_showMFDailyDossier() {
    $('#showMFDailyDossier').on('click', function () {
        $('.MF-Daily-Dossier').fadeToggle();
    });
}

function init_fundManagerAdvFilter(){
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
}

function init_showFM(){
    $('#showFM').on("click", function(){
        $('.fund-manager__serach-result').show();
    })
}
/* for the numeric up down */		
function initNumericUpDown(){		
    $('.btn-number').click(function(e){		
        e.preventDefault();		
        		
        fieldName = $(this).attr('data-field');		
        type      = $(this).attr('data-type');		
        var input = $("input[name='"+fieldName+"']");		
        var currentVal = parseInt(input.val());		
        if (!isNaN(currentVal)) {		
            if(type == 'minus') {		
                		
                if(currentVal > input.attr('min')) {		
                    input.val(currentVal - 1).change();		
                } 		
                if(parseInt(input.val()) == input.attr('min')) {		
                    $(this).attr('disabled', true);		
                }		
    		
            } else if(type == 'plus') {		
    		
                if(currentVal < input.attr('max')) {		
                    input.val(currentVal + 1).change();		
                }		
                if(parseInt(input.val()) == input.attr('max')) {		
                    $(this).attr('disabled', true);		
                }		
    		
            }		
        } else {		
            input.val(0);		
        }		
    });		
    $('.input-number').focusin(function(){		
       $(this).data('oldValue', $(this).val());		
    });		
    $('.input-number').change(function() {		
        		
        minValue =  parseInt($(this).attr('min'));		
        maxValue =  parseInt($(this).attr('max'));		
        valueCurrent = parseInt($(this).val());		
        		
        name = $(this).attr('name');		
        if(valueCurrent >= minValue) {		
            $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')		
        } else {		
            alert('Sorry, the minimum value was reached');		
            $(this).val($(this).data('oldValue'));		
        }		
        if(valueCurrent <= maxValue) {		
            $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')		
        } else {		
            alert('Sorry, the maximum value was reached');		
            $(this).val($(this).data('oldValue'));		
        }		
        		
        		
    });		
    $(".input-number").keydown(function (e) {		
            // Allow: backspace, delete, tab, escape, enter and .		
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||		
                 // Allow: Ctrl+A		
                (e.keyCode == 65 && e.ctrlKey === true) || 		
                 // Allow: home, end, left, right		
                (e.keyCode >= 35 && e.keyCode <= 39)) {		
                     // let it happen, don't do anything		
                     return;		
            }		
            // Ensure that it is a number and stop the keypress		
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {		
                e.preventDefault();		
            }		
        });		
}		
/* for the numeric up down end */		
/* reveal the schemeSelectionFilter */
var chkschemeSelectionFilterBtn = false;
function init_schemeSelectionFilter() {
   // debugger;

    $('#schemeSelectionFilterBtn').on('click', function () {
      //  debugger;
        if (chkschemeSelectionFilterBtn == false) {
            chkschemeSelectionFilterBtn = true;
            $('#schemeSelectionFilter').slideDown(500);
        }
        else {
            $(this).animate({
                bottom: 0,
                opacity: 1
            }, 500);
            chkschemeSelectionFilterBtn = false;
            $('#schemeSelectionFilter').slideUp(500);
        }
    });
};
//closing scheme selection filter on click		
//function init_schemeSelectionFilterBtnClose() {
//     debugger;
//     if (chkschemeSelectionFilterBtn == true) {
//         chkschemeSelectionFilterBtn = false;

//        $('#schemeSelectionFilterBtn').on('click', function () {
//            $(this).animate({
//                bottom: 0,
//                opacity: 1
//            }, 500);

//            $('#schemeSelectionFilter').slideUp(500);
//        });
//    }
//};



$(document).ready(function () {

    //jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

/*$(".next").click(function () {
    if (animating) return false;
    animating = true;

    current_fs = $(this).parent();
    next_fs = $(this).parent().next();

    //activate next step on progressbar using the index of next_fs
    $("#progressbar li").eq($("fieldset.fieldset-wiz").index(next_fs)-1).addClass("active");

    //show the next fieldset
    next_fs.show();
    //hide the current fieldset with style
    current_fs.animate({ opacity: 0 }, {
        step: function (now, mx) {
            //as the opacity of current_fs reduces to 0 - stored in "now"
            //1. scale current_fs down to 80%
            scale = 1 - (1 - 1) * 0.2;
            //2. bring next_fs from the right(50%)
            left = (now * 50) + "%";
            //3. increase opacity of next_fs to 1 as it moves in
            opacity = 1 - now;
            current_fs.css({
                'transform': 'scale(' + scale + ')',
                'position': 'absolute'
            });
            next_fs.css({ 'left': left, 'opacity': opacity });
        },
        duration: 400,
        complete: function () {
            current_fs.hide();
            animating = false;
        },
        //this comes from the custom easing plugin
        //easing: 'easeInOutBack'
    });
});

$(".previous").click(function () {
    if (animating) return false;
    animating = true;

    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();

    //de-activate current step on progressbar
    $("#progressbar li").eq($("fieldset.fieldset-wiz").index(current_fs)-1).removeClass("active");

    //show the previous fieldset
    previous_fs.show();
    //hide the current fieldset with style
    current_fs.animate({ opacity: 0 }, {
        step: function (now, mx) {
            //as the opacity of current_fs reduces to 0 - stored in "now"
            //1. scale previous_fs from 80% to 100%
            scale = 1 + (1 - 1) * 0.2;
            //2. take current_fs to the right(50%) - from 0%
            left = ((1 - now) * 50) + "%";
            //3. increase opacity of previous_fs to 1 as it moves in
            opacity = 1 - now;
            current_fs.css({ 'left': left });
            previous_fs.css({ 'transform': 'scale(' + scale + ')', 'opacity': opacity });
        },
        duration: 400,
        complete: function () {
            current_fs.hide();
            animating = false;
        },
        //this comes from the custom easing plugin
        //easing: 'easeInOutBack'
    });
});*/

$(".submit").click(function () {
    return false;
})


    $("#flip_").click(function () {
        $("#panel_").slideToggle()
    })
    $("#DivSelectedScheme").fadeOut("fast");
    $("#btnSelectedScheme, #btnSelectedSchemeClose").on("click", function () {
        $("#DivSelectedScheme").fadeToggle("fast");
    });

    init_sidebar();
    init_fetchResult();
    init_filterReveal();
    init_customScrollBar();
    init_settingPanel();
    init_saveSearch();
    init_closeFilter();
    init_settingMenu();
      /* for the fun manager section - soumya -- start */
    init_fundManagerAdvFilter();
    init_fundManaggerResultShow();
    init_showFMAdvFilter();
    init_showFMAdvFilterSebi();
    init_showFM();
    /* for the fun manager section - soumya -- end */

   /* for the numeric up down -- soumya*/
    initNumericUpDown();

    /* scheme selection filter -- soumya */
    init_schemeSelectionFilter();
    //init_schemeSelectionFilterBtnClose();
});
