//var ServiceNavIndex = angular.module('ServiceNavIndex', []);

//ServiceNavIndex.config(BaseServiceConfig);

//SharedServices.service('PostNavIndexReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostNavIndexReport',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    }

//}]);
SharedServices.service('PostNavIndexReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostNavIndexReport',
            headers: { 'Content-Type': undefined },//headers: { 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: obj,//$.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);
SharedServices.service('PostCompositeSchemeReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostCompositeSchemeReportAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostMulNavIndexReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostMulNavIndexReport',
            headers: { 'Content-Type': undefined },//{ 'Content-Type': 'application/x-www-form-urlencoded' },
            data: obj,//$.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostHisNavIndexReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostHisNavIndexReport',
            headers: { 'Content-Type': undefined },// { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: obj,//$.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostPerNavIndexReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostPerNavIndexReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostGetYearRng', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostGetYearRng',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostDidivend', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostDidivend',
            headers: { 'Content-Type': undefined }, //{ 'Content-Type': 'application/x-www-form-urlencoded' },
            data: obj, //$.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('PostExpenseRatio', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostExpenseRatio',
            //headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            //data: $.param(obj),
            headers: { 'Content-Type': undefined },//{ 'Content-Type': 'application/x-www-form-urlencoded' },
            data: obj,//$.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('NavIndexGraphData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/NavIndexGraphData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    };

}]); 

//SharedServices.service('PostHisNavIndexReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostHisNavIndexReportAdvance',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    };

//}]);
SharedServices.service('PostHisNavIndexReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostHisNavIndexReportAdvance',
            headers: { 'Content-Type': undefined },//{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: obj,//$.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);

SharedServices.service('PostPerNavIndexReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostPerNavIndexReportAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    };

}]);

SharedServices.service('NavIndexGraphDataAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/NavIndexGraphDataAdvance',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    };

}]); 

//SharedServices.service('PostNavIndexReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (obj) {
//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostNavIndexReportAdvance',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    };

//}]); 

SharedServices.service('PostNavIndexReportAdvance', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostNavIndexReportAdvance',
            headers: { 'Content-Type': undefined },//{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: obj,//$.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);

SharedServices.service('ShowEntryExitReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/ShowEntryExitReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    };

}]); 

SharedServices.service('PostPortfolioStatReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/PostPortfolioStatReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    };

}]); 

SharedServices.service('FetchAUMMonitorReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/fetchAUMMonitor',
            method: 'POST',
            data: $.param(obj)

        });
    }
}]);

SharedServices.service('FetchSchemeWiseAUMMonitorReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiNavIndex/fetchSchemeWiseAUMMonitor',
            method: 'POST',
            data: $.param(obj)

        });
    }
}]);