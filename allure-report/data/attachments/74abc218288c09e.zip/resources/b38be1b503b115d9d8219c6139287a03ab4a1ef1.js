
SharedServices.service('GetFetchUserBasicSettings', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFetchUserBasicSettings',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('GetDashBoardSliders', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {

    this.Call = function (obj) {
        //var def = $q.defer();
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetDashBoardSliders',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj)
            //dataType: "json"
        });
    }

}]);

SharedServices.service('GetFundmanagerList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (sts) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetFundmanagerList?IsActive='+sts,
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetAllRiskometer', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (sts) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAllRiskometer',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetAMCList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetAMCList',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetMFList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFList',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetMFListFrRedeemed', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMFListFrRedeemed',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetAllActiveSchemeIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        //debugger;
        var obj = {};
        obj.IsShowAllActiveSchemeIndex = true;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAllActiveSchemeIndex',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetNatureList',
            method: 'GET'
        });
    }

}]);



SharedServices.service('SubNatureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrNatureID) {
        var obj = {};
        if (ArrNatureID == undefined) {
           // obj.ArrNatureID = null;
        }
        else {
            obj.ArrNatureID = ArrNatureID;
        }
       // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/SubNatureList',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('SubNatureListFrRedeem', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrNatureID) {
        var obj = {};
        if (ArrNatureID == undefined) {
            // obj.ArrNatureID = null;
        }
        else {
            obj.ArrNatureID = ArrNatureID;
        }
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/SubNatureListFrRedeem',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetAllPlan_sector', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrNatureID) {
        var obj = {};
        if (ArrNatureID == undefined) {
            // obj.ArrNatureID = null;
        }
        else {
            obj.ArrSubNatureID = ArrNatureID;
        }
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAllPlan_sector',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetAllPlan_sectorFrRedeem', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrNatureID) {
        var obj = {};
        if (ArrNatureID == undefined) {
            // obj.ArrNatureID = null;
        }
        else {
            obj.ArrSubNatureID = ArrNatureID;
        }
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAllPlan_sectorFrRedeem',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetOptionList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetOptionList',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetAppPeriodList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        // debugger;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetAppPeriodList?IsApp=' + obj,
            method: 'GET',
            // data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetAllPlan', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrSubNatureID) {
       // debugger;
        var obj = {};
        obj.ArrSubNatureID = [];
        if (ArrSubNatureID != undefined) {

            for (c = 0; c < ArrSubNatureID.length; c++)
            {
                obj.ArrSubNatureID.push(ArrSubNatureID[c].Id);
            }
           // obj.ArrSubNatureID = ArrSubNatureID;
        }
        else
        {
            obj.ArrSubNatureID =null;
        }
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetAllPlan',
            method: 'POST',
            data: $.param(obj)
        });
    }

}]);

//ServiceSchemePerformance.service('GetAllMFIIndex', ['$http', function ($http) {
//    this.Call = function (obj) {
//        return $http({
//            method: "get",
//            url: ApiInfo.BaseApiUrl +'ApiSchemePerofamance/GetAllMFIIndex',
//        });
//    }

//}]);

SharedServices.service('GetSchemeList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetSchemeList?StrScheme=' + Obj,
        });
    }

}]);

SharedServices.service('GetSelectedScheme', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetSelectedScheme',
        });
    }

}]);

SharedServices.service('GetSchemeSetSchemesBySetId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSchemeSetSchemesBySetId?USSID=' + Obj
        });
    }
}]);

SharedServices.service('GetSchemesByUserSchemeSetId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + '/ApiSchemePerofamance/GetSchemesByUserSchemeSetId?USSId=' + Obj + "&CheckedUssIds=",
        });
    }

}]);

SharedServices.service('SetSelectedScheme', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrSchemeID,LoginId) {
        var obj = {};
        obj.LoginId = LoginId;
        obj.ArrSchemeID = ArrSchemeID;
        //if (ArrSchemeID != undefined) {
        //    for (c = 0; c < ArrSchemeID.length; c++) {
        //        obj.ArrSchemeID.push(ArrSchemeID);
        //    }
        //}
        //else {
        //    obj.ArrSchemeID = null;
        //}
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/SetSelectedScheme',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('SetUserSchemeSetSchemes', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (UssId, SchemeIds) {
        var obj = {};
        obj.UssId = UssId;
        obj.SchemeIds = SchemeIds;
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/SetUserSchemeSetSchemes',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('SetUserSchemeSetSchemesFundScreener', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (UssId, SchemeIds) {
        var obj = {};
        obj.UssId = UssId;
        obj.SchemeIds = SchemeIds;
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/SetUserSchemeSetSchemesFundScreener',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetStructureList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetStructureList',
            method: 'GET'
        });
    }

}]);

SharedServices.service('CreateUserSchemeSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (StrSchemeSetName) {
        // debugger;
        var obj = {};
       // obj.LoginId = LoginId;
        obj.SchemeSetName = StrSchemeSetName;
    
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/CreateUserSchemeSet',
            method: 'POST',
            data: $.param(obj)
        });
    }

}]);
SharedServices.service('CreateUserSetAddSchemesToSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeSetName, SchemeIds) {
        // debugger;
        var obj = {};
        // obj.LoginId = LoginId;
        obj.SchemeSetName = SchemeSetName;
        obj.SchemeIds = SchemeIds;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/CreateUserSetAddSchemesToSet',
            method: 'POST',
            data: $.param(obj)
        });
    }

}]);

SharedServices.service('DeleteUserSelectedScheme', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (ArrSchemeID, LoginId) {
        var obj = {};
        obj.LoginId = LoginId;
        obj.ArrSchemeID = ArrSchemeID;
      
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/DeleteUserSelectedScheme',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('DeleteUserSchemeSetScheme', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeIds, UssId) {
        var obj = {};
        obj.SchemeIds = SchemeIds;
        obj.UssId = UssId;

        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/DeleteUserSchemeSetScheme',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('DeleteUserSchemeSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (UssId) {
        var obj = {};
        obj.UssId = UssId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/DeleteUserSchemeSet',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('AddUserSchemeWatchList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeIds, LoginId) {
        var obj = {};
        obj.LoginId = LoginId;
        obj.SelectedScheme = SchemeIds;
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/AddUserSchemeWatchList',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('DeleteSchemeWatchList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeIds) {
        var obj = {};
        obj.SchemeIds = SchemeIds;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/DeleteSchemeWatchList',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);
SharedServices.service('DeleteAllWatchListScheme', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (LoginId) {
        var obj = {};
        obj.LoginId = LoginId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/DeleteAllWatchListScheme',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetUserSchemeWatchList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (LoginId) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiCommonExplorer/GetUserSchemeWatchList?LoginId=' + LoginId,
            method: 'GET',
        });
    }
}]);

SharedServices.service('DeleteUserSchemeSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (UssId) {
        var obj = {};
        obj.UssId = UssId;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/DeleteUserSchemeSet',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetDataPointList', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetDataPointList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('GetFilterDataBasedOnDatapoint', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (dpId,fromDt,toDt,divBy) {
        var obj = {};
        obj.DataPointID = dpId;
        obj.FromDate = fromDt;
        obj.ToDate = toDt;
        obj.DividedBy = divBy;

        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetFilterDataBasedOnDatapoint',
            method: 'POST',
            data: $.param(obj)
        });
    }
}]);

SharedServices.service('GetComPortDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetComPortDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetMinComPortDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMinComPortDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetSubscriptionDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetSubscriptionDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetMaxMinNAVDate', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetMaxMinNAVDate',
            method: 'GET'
        });
    }
}]);

SharedServices.service('GetNotificationDetails', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (ModuleNameTag, IsVisited) {
        if (IsVisited == null || IsVisited === undefined)
            IsVisited = null;
        if (ModuleNameTag == null || ModuleNameTag === undefined)
            ModuleNameTag = "";
        return $http({
            method: "GET",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetNotificationDetails?ModuleNameTag=' + ModuleNameTag + '&IsVisited=' + IsVisited,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('UpdateNotificationDetails', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (notiID) {
        return $http({
            method: "POST",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/UpdateNotificationDetails?notificationID=' + notiID,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('CategoryAvgReturn', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (SchemeIDs) {
        var TopfundInput = {};
        TopfundInput.SchemeIDs = SchemeIDs;
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/CategoryAvgReturn',
            data: $.param(TopfundInput),
            method: 'POST'
        });
    }
}]);

SharedServices.service('GetAllNonRestrictedMFIIndex', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonData/GetAllNonRestrictedMFIIndex',
            method: 'GET'
        });
    }

}]);

SharedServices.service('GetLaunchPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/GetLaunchPeriod',
            method: 'GET'
        });
    }

}]);
SharedServices.service('GetTutorialVideoList', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FetchTutorialVideoList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj)
        });
    }

}]);
SharedServices.service('GetTutorialVideoForEachReport', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiCommonExplorer/FetchTutorialVideoForEachReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj)
        });
    }

}]);