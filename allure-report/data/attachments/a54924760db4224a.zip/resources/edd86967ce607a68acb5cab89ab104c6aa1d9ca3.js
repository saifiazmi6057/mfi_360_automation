//var ServiceReturnSetting = angular.module('ServiceReturnSetting', []);

//ServiceReturnSetting.config(BaseServiceConfig);


SharedServices.service('GetReturnSettingdata', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/GetReturnSettingdata',
            method: 'GET'
        });
    }

}]);


SharedServices.service('GetSetDetails', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/GetSetDetails?setid=' + id,
            method: 'GET'
        });
    }

}]);


SharedServices.service('SavecustomizesetData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/SavecustomizesetData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);



SharedServices.service('GetSetDeleteinfo', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (id) {
        return $http({
            url: ApiInfo.BaseApiUrl +'ApiPortfolio/GetSetDeleteinfo?setid=' + id,
            method: 'GET'
        });
    }

}]);