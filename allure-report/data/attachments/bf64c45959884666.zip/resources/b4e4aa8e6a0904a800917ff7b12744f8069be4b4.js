SharedServices.service('FetchFieldsData', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: 'GET',
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetQueryBuilderFieldsData',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('FetchReportList', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: 'GET',
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetQueryBuilderReportList',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);
SharedServices.service('CheckExcelGenerated', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: 'GET',
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetExcelGenerated',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);
SharedServices.service('UploadDividendFile', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiReport/UploadDividendFile',
            method: 'POST',
            headers: {
                'Content-Type': undefined,
                //"RequestVerificationToken": $('#RiskReturnMatrixantiForgeryToken').val()
            },
            transformRequest: function (data, headersGetter) {
                var formData = new FormData();
                angular.forEach(data, function (value, key) {
                    formData.append(key, value);
                });
                return formData;
            },
            data: obj,
        });
    }
}]);
//SharedServices.service('FetchQueryBuilderReportData', ['$http', 'ApiInfo', function ($http, ApiInfo) {

//    this.Call = function (obj) {

//        return $http({
//            method: "post",
//            url: ApiInfo.BaseApiUrl + 'ApiReport/FetchQueryBuilderReportData',
//            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//            data: $.param(obj),
//            dataType: "json"
//        });
//    }

//}]);

SharedServices.service('FetchQueryBuilderReportData', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/FetchQueryBuilderReportData',
            headers: { 'Content-Type': undefined },//{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: obj,//$.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);

SharedServices.service('FetchQueryBuilderFromReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/FetchQueryBuilderFromReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SaveQueryBuilderReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/SaveQueryBuilderReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);
SharedServices.service('DeleteQueryBuilderReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/RemoveQueryBuilderReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('DoExcel', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/DoExcel',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetAllP2PPeriod', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetAllP2PPeriod',
            //params: obj
        });
    }
}]);

SharedServices.service('BuildReportBuilder', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/BuildReportBuilder',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('SaveReportBuilder', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/SaveReportBuilder',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);


SharedServices.service('GetReportList', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (IsCusRep) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetReportBuilderReportList?IsCusRep=' + IsCusRep,
            //params: obj
        });
    }
}]);

SharedServices.service('FetchReportBuilderParamSet', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/FetchReportBuilderParamSet',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('DeleteReportBuilder', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/RemoveReportBuilderReport',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('GetMFIRatingset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetMFIRatingset',
            //params: obj
        });
    }
}]);

SharedServices.service('FetchMFIInstrumentset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetMFIInstrumentset',
            //params: obj
        });
    }
}]);

SharedServices.service('FetchMFISectorset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetMFISectorset',
            //params: obj
        });
    }
}]);

SharedServices.service('GetCustomInstrumentset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetCustomInstrumentset',
            //params: obj
        });
    }
}]);

SharedServices.service('GetCustomRatingset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetCustomRatingset',
            //params: obj
        });
    }
}]);

SharedServices.service('GetCustomSectorset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetCustomSectorset',
            //params: obj
        });
    }
}]);

SharedServices.service('FetchalldatafromCaching', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetalldatafromCaching?Id=' + Id,
            //params: obj
        });
    }
}]);

SharedServices.service('RegenerateReportBuilder', ['$http', 'ApiInfo', function ($http, ApiInfo) {

    this.Call = function (obj) {

        return $http({
            method: "post",
            url: ApiInfo.BaseApiUrl + 'ApiReport/RegenerateReportBuilder',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            data: $.param(obj),
            dataType: "json"
        });
    }

}]);

SharedServices.service('ScheduleCustomReport', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/ScheduleCustomReport',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);

SharedServices.service('MakeCombinationset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/MakeCombinationset',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"
        });
    };
}]);

SharedServices.service('FetchUserSetByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetSchesets?Id=' + Id,
            //params: obj
        });
    }
}]);

SharedServices.service('FetchCombSetByLoginId', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetCombsets',
            //params: obj
        });
    }
}]);
SharedServices.service('FetchCombinationsetSelection', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetCombsetsSelectedbyuser?ReporId=' + Id,
            //params: obj
        });
    }
}]);

SharedServices.service('SaveCombinationset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/SaveCombinationset',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"
        });
    }
}]);

SharedServices.service('Fetchallreports', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function () {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetAllReports',
            //params: obj
        });
    }
}]);

SharedServices.service('ScheduleReportsdetls', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetScheduleReportsdetls?id=' + Id,
            //params: obj
        });
    }
}]);
SharedServices.service('GenRepOntheFly', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/GenCustomReportonFly',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);

SharedServices.service('PostDeleteCobset', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/PostDeleteCobset',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);

SharedServices.service('PostMakeGroupOfInputParamters', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/PostMakeGroupOfInputParamters',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);

SharedServices.service('SaveSequence', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/SaveSequence',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);

SharedServices.service('GetExcel', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/PostExcel',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);
SharedServices.service('DeleteExistingSchedule', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: 'POST',
            url: ApiInfo.BaseApiUrl + 'ApiReport/PostdeleteExistingSchedule',
            headers: /*{ 'Content-Type': undefined }*/{ 'Content-Type': 'application/x-www-form-urlencoded' },//for post large data
            data: $.param(obj),//for post large data
            dataType: "json"//params: obj
        });
    }
}]);

SharedServices.service('ChangeRptPresnttation', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (IsParameterwise, Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/Getchangerptpresnttation?IsParameterwise=' + Id + "&Id=" + Id,
            //params: obj
        });
    }
}]);

SharedServices.service('Gethistory', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/Gethistory?CustomReptId=' + Id,
            //params: obj
        });
    }
}]);




SharedServices.service('GetlatestExcel', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (Id) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetlatestExcel?ReptId=' + Id,
            //params: obj
        });
    }
}]);

SharedServices.service('GetCurrentIndexValue', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            method: "get",
            url: ApiInfo.BaseApiUrl + 'ApiSchemePerofamance/GetCurrentIndexValue',
            params: obj
        });
    }
}]);

SharedServices.service('GetMaxNavDate', ['$http', '$q', 'ApiInfo', function ($http, $q, ApiInfo) {
    this.Call = function () {
        return $http({
            method: 'GET',
            url: ApiInfo.BaseApiUrl + 'ApiReport/GetMaxNavDate',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
    }
}]);

SharedServices.service('UploadEmailConfigFile', ['$http', 'ApiInfo', function ($http, ApiInfo) {
    this.Call = function (obj) {
        return $http({
            url: ApiInfo.BaseApiUrl + 'ApiReport/UploadEmailConfigFile',
            method: 'POST',
            headers: {
                'Content-Type': undefined,
                //"RequestVerificationToken": $('#RiskReturnMatrixantiForgeryToken').val()
            },
            transformRequest: function (data, headersGetter) {
                var formData = new FormData();
                angular.forEach(data, function (value, key) {
                    formData.append(key, value);
                });
                return formData;
            },
            data: obj,
        });
    }
}]);