SharedDeractives.directive('instrumentSet', ['$timeout', '$q', '$log', 'GetSingleInstrumentSetdetails', 'GetCompositInstrumentDetails', 'GetInstrumentSetsData', 'SaveSetandCustomInstrumentName', 'MakeDefaultInstrumentSet', 'InstrumentSetsDelete', 'InstrumentSave', 'MFIMsg', '$filter',
    function ($timeout, $q, $log, GetSingleInstrumentSetdetails, GetCompositInstrumentDetails, GetInstrumentSetsData, SaveSetandCustomInstrumentName, MakeDefaultInstrumentSet, InstrumentSetsDelete, InstrumentSave, MFIMsg, $filter) {
        return {
            restrict: 'E',
            scope: {
                extraSettings: '=',
                logInId:'='
            },
            replace: false,
            templateUrl: '/Home/InstrumentSet',

            link: function ($scope, $element, $attrs) {
                $timeout(function () {
                    //$scope.LstColor = ["Red", "Pink", "Blue", "Gray"];
                    $scope.LstColor = ["#1b847d", "#a0700f", "#1e5205", "#a22409", "#0e6ba0", "#3339FF", "#7e0684", "#FF33A2", "#FFD433"];
                    $scope.labelcolor = { "color": "green" };
                    $scope.divshow = false;
                    $scope.divshowtable = true;
                    $scope.divshowAllInstrument = false;
                    $scope.selectedId = null;
                    $scope.radioSelectionId;
                    $scope.SetName = "";
                    $scope.InstrumentSetName = "";
                    $scope.Default;
                    $scope.AddUpdate = "";
                    $scope.Gen = false;
                    $scope.editcreate = "";
                    $scope.IsGeneric = false;
                    $scope.InstrumentSubSetName = "";
                    $scope.InstrumentSetName = "";
                    $scope.InstrumentSetId = 0;
                    $scope.InstrumentSubSetId = 0;
                    $scope.LstInstrumentIdSelect = [];
                    $scope.LstInstrumentIdForDisable = [];
                    $scope.InstrumentSubSetName = "";
                    $scope.LstInstrument = [];
                    $scope.radioClassId = "";
                    $scope.LoaderInstrumentSearch = true;
                    $scope.radioSelectedId = "";
                    $scope.searchText = "";
                    $scope.showAdd = false;
                    $scope.divshowInstruments = false;
                    $scope.showUpdate = false;
                    $scope.IsSetNameDisable = false;
                    $scope.IsCreateNew = "";
                    $scope.IsExist = "";
                    $scope.UserLogInId = "";
                    $scope.CreatedLogInId = "";
                    $scope.LstInstrumentWithOutFilter = [];

                    var getData = GetInstrumentSetsData.Call();
                    getData.then(function (response) {
                        $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                        $scope.LoaderInstrumentSearch = false;
                        if (response.data.data.LstInstrumentSingleSetDetails != null) {
                            $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                            $scope.LoaderInstrumentTable = false;
                            $scope.divshow = false;
                            $scope.divshowInstruments = false;
                            if (response.data.data.Data.IsDefault == true) {
                                //$scope.SetName = "Default";
                                //$scope.Default = true;
                                $scope.SetName = "Undo";
                                $scope.Default = false;
                            }
                            else {
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                            }
                            if (response.data.data.Data.IsGeneric == true) {
                                $scope.Gen = true;
                            }
                            else {
                                $scope.Gen = false;
                            }
                            $scope.divshowAllInstrument = false;
                            $scope.UserLogInId = response.data.data.UserLogInId;
                            $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                        }
                    },
                        function (stu) {
                            MFIMsg.AlertHtml("Instrument set loading failed", MFIAlertType.Error);
                        });



                    $scope.getClassForDefault = function (IsDefault) {
                        if (IsDefault)
                            return "label label-primary";
                        else
                            return "label label-warning";
                    }

                    //$scope.getClass = function (radioSelectionId) {
                    //    if (radioSelectionId == 0)
                    //        return { "color": $scope.LstColor[0] };//$scope.LstColor[0];
                    //    else if (radioSelectionId == 1)
                    //        return  { "color": $scope.LstColor[1] };//$scope.LstColor[1];
                    //    else if (radioSelectionId == 2)
                    //        return { "color": $scope.LstColor[2] };//$scope.LstColor[2];
                    //    else if (radioSelectionId == 3)
                    //        return { "color": $scope.LstColor[3] };//$scope.LstColor[3];
                    //}

                    //$scope.getClassForCheckbox = function (radioSelectionId, IsChecked) {
                    //    if (radioSelectionId == 0 && IsChecked == true)
                    //        return $scope.LstColor[0];
                    //    else if (radioSelectionId == 1 && IsChecked == true)
                    //        return $scope.LstColor[1];
                    //    else if (radioSelectionId == 2 && IsChecked == true)
                    //        return $scope.LstColor[2];
                    //    else if (radioSelectionId == 3 && IsChecked == true)
                    //        return $scope.LstColor[3];
                    //}

                    $scope.editSingleRow = function (setId, setSubId, SubSetName, id, setName) {
                        if ($scope.search != "" && $scope.search != undefined)
                            $scope.search.InstrumentName = "";
                        $scope.radioClassId = id;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.LoaderCustomInstrument = true;
                            $scope.LoaderAllInstrument = true;
                            $scope.IsCreateNew = false;
                            $scope.divshow = false;
                            $scope.divshowInstruments = false;
                            $scope.divshowAllInstrument = true;
                            var instuDetailParam = { "InstrumentSetId": setId, "InstrumentSubSetId": setSubId, "InstrumentSubSetName": SubSetName/*.Replace("\"", "")*/, "IsCreateNew": $scope.IsCreateNew };
                            var getData = GetCompositInstrumentDetails.Call(instuDetailParam);
                            getData.then(function (response) {
                                $scope.LoaderCustomInstrument = false;
                                $scope.LoaderAllInstrument = false;
                                if ($scope.LstInstrumentIdSelect == null)
                                    $scope.LstInstrumentIdSelect = [];
                                $scope.LstInstrumentIdSelect = response.data.data.LstInstrumentId;
                                $scope.LstInstrumentIdForDisable = response.data.data.LstInstrumentIdForDisable;
                                $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                                $scope.InstrumentSetId = setId;
                                $scope.InstrumentSubSetId = setSubId;
                                $scope.InstrumentSubSetName = SubSetName;
                                $scope.LstInstrument = response.data.data.LstInstrument;
                                $scope.divshowAllInstrument = true;
                                $scope.InstrumentSetName = setName;

                                if (response.data.data.LstInstrumentId != null) {
                                    for (var i = 0; i < response.data.data.LstInstrumentId.length; i++) {
                                        for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                            if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentId[i]) {
                                                $scope.LstInstrument[j].IsChecked = true;
                                                $scope.LstInstrument[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                            }
                                        }
                                    }
                                }
                                if (response.data.data.LstInstrumentIdForDisable != null) {
                                    for (var i = 0; i < response.data.data.LstInstrumentIdForDisable.length; i++) {
                                        for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                            if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentIdForDisable[i]) {
                                                $scope.LstInstrument[j].IsDisable = true;
                                            }
                                        }
                                    }
                                }
                                var incr = 0;
                                angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                    value.IsChecked = value.InstrumentSubSetId == setSubId ? true : false;
                                    value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                    incr++;
                                });
                                incr = 0;
                                $scope.LstInstrumentWithOutFilter = $scope.LstInstrument;
                                $("#InstrumentAll").addClass("btn btn-success btn-xs active");
                                $("#InstrumentSelected").removeClass("btn btn-success btn-xs active");
                                $("#InstrumentUnselected").removeClass("btn btn-success btn-xs active");
                                $("#InstrumentSelected").addClass("btn btn-success btn-xs");
                                $("#InstrumentUnselected").addClass("btn btn-success btn-xs");
                            },
                                function (stu) {
                                    $scope.LoaderCustomInstrument = false;
                                    $scope.LoaderAllInstrument = false;
                                    $scope.divshowAllInstrument = false;
                                    MFIMsg.AlertHtml("Single custom set details fetched failed", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }
                    }

                    $scope.querySearch = querySearch;
                    $scope.selectedItemChange = selectedItemChange;
                    $scope.searchTextChange = searchTextChange;


                    function querySearch(query) {
                        var results = query ? $scope.LstInstrumentSet.filter(createFilterFor(query)) : $scope.LstInstrumentSet;
                        return results;
                    }

                    function searchTextChange(text) {
                        $log.info('Text changed to ' + text);
                    }

                    $scope.FnCleanTextInstrument = function () {
                        $scope.searchText = '';
                        $scope.ShowClearButtonInstrument = false;
                    }

                    function selectedItemChange(item) {
                        if (item != undefined) {
                            $scope.ShowClearButtonInstrument = true;
                            var instuParam = { "SetId": item.Id };
                            var getData = GetSingleInstrumentSetdetails.Call(instuParam);
                            $scope.LoaderInstrumentTable = true;

                            getData.then(function (response) {
                                $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                                $scope.LoaderInstrumentTable = false;
                                $scope.divshow = false;
                                $scope.divshowInstruments = false;
                                if (response.data.data.Data.IsDefault == true) {
                                    //$scope.SetName = "Default";
                                    //$scope.Default = true;
                                    $scope.SetName = "Undo";
                                    $scope.Default = false;
                                }
                                else {
                                    $scope.SetName = "Make Default";
                                    $scope.Default = true;
                                }
                                if (response.data.data.Data.IsGeneric == true) {
                                    $scope.Gen = true;
                                }
                                else {
                                    $scope.Gen = false;
                                }
                                $scope.divshowAllInstrument = false;
                                $scope.UserLogInId = response.data.data.UserLogInId;
                                $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Single custom set details fetched failed from search selection", MFIAlertType.Error);
                                });
                        }
                        $log.info('Item changed to ' + JSON.stringify(item));
                    }

                    function createFilterFor(query) {
                        var lowercaseQuery = angular.lowercase(query);

                        return function filterFn(state) {
                            return (angular.lowercase(state.Name).indexOf(lowercaseQuery) === 0);
                        };

                    }

                    $scope.getData = function (setId, setSubId, SubSetName, id) {
                        if ($scope.search != "" && $scope.search != undefined)
                            $scope.search.InstrumentName = "";
                        $scope.LoaderCustomInstrument = true;
                        $scope.LoaderAllInstrument = true;
                        $scope.radioClassId = id;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        $scope.divshow = false;
                        var instuDetailParam = { "InstrumentSetId": setId, "InstrumentSubSetId": setSubId, "InstrumentSubSetName": SubSetName/*.Replace("\"", "")*/ };
                        var getData = GetCompositInstrumentDetails.Call(instuDetailParam);
                        getData.then(function (response) {
                            $scope.LoaderCustomInstrument = false;
                            $scope.LoaderAllInstrument = false;
                            if ($scope.LstInstrumentIdSelect == null)
                                $scope.LstInstrumentIdSelect = [];
                            $scope.LstInstrumentIdSelect = response.data.data.LstInstrumentId;
                            $scope.LstInstrumentIdForDisable = response.data.data.LstInstrumentIdForDisable;
                            $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                            $scope.InstrumentSetId = setId;
                            $scope.InstrumentSubSetId = setSubId;
                            $scope.InstrumentSubSetName = SubSetName;
                            $scope.LstInstrument = response.data.data.LstInstrument;
                            $scope.divshowAllInstrument = true;

                            if (response.data.data.LstInstrumentId != null) {
                                for (var i = 0; i < response.data.data.LstInstrumentId.length; i++) {
                                    for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                        if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentId[i]) {
                                            $scope.LstInstrument[j].IsChecked = true;
                                            $scope.LstInstrument[j].CheckBoxTextColor = { "color": $scope.LstColor[id] };
                                        }
                                    }
                                }
                            }
                            if (response.data.data.LstInstrumentIdForDisable != null) {
                                for (var i = 0; i < response.data.data.LstInstrumentIdForDisable.length; i++) {
                                    for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                        if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentIdForDisable[i]) {
                                            $scope.LstInstrument[j].IsDisable = true;
                                        }
                                    }
                                }
                            }
                            var incr = 0;
                            angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                value.IsChecked = value.InstrumentSubSetId == setSubId ? true : false;
                                value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                incr++;
                            });
                            incr = 0;
                            $scope.LstInstrumentWithOutFilter = $scope.LstInstrument;
                            $("#InstrumentAll").addClass("btn btn-success btn-xs active");
                            $("#InstrumentSelected").removeClass("btn btn-success btn-xs active");
                            $("#InstrumentUnselected").removeClass("btn btn-success btn-xs active");
                            $("#InstrumentSelected").addClass("btn btn-success btn-xs");
                            $("#InstrumentUnselected").addClass("btn btn-success btn-xs");
                        },
                            function (stu) {
                                $scope.LoaderCustomInstrument = false;
                                $scope.LoaderAllInstrument = false;
                                MFIMsg.AlertHtml("Single custom set details fetched failed", MFIAlertType.Error);
                            });

                    }

                    $scope.createNew = function (instuName) {
                        $scope.divshowAllInstrument = false;
                        $scope.divshow = true;
                        $scope.InstrumentSetName = instuName;
                        $scope.InstrumentSubSetName = null;
                        $scope.InstrumentSetId = 0;
                        $scope.InstrumentSubSetId = 0;
                        $scope.AddUpdate = "Add";
                        $scope.editcreate = "Create Instrument";
                        $scope.IsGeneric = false;
                        $scope.showAdd = false;
                        $scope.showUpdate = false;
                        $scope.IsSetNameDisable = false;
                        $scope.divshowInstruments = true;
                        $scope.IsExist = false;
                        $scope.LoaderAllInstrument = true;
                        $scope.LoaderCreationSection = true;
                        $scope.LstInstrumentIdSelect = [];
                        var getData = GetInstrumentSetsData.Call();
                        getData.then(function (response) {
                            $scope.LoaderAllInstrument = false;
                            $scope.LoaderCreationSection = false;
                            $scope.LstInstrument = response.data.data.LstInstrument;
                        },
                            function (stu) {
                                $scope.LoaderAllInstrument = false;
                                $scope.LoaderCreationSection = false;
                                $scope.divshow = false;
                                $scope.divshowInstruments = false;
                                MFIMsg.AlertHtml("Instruments loading failed", MFIAlertType.Error);
                            });
                    }

                    //$scope.createNewFrmSearch = function (instuName) {
                    //    $scope.divshowAllInstrument = false;
                    //    $scope.divshow = true;
                    //    $scope.InstrumentSetName = instuName;
                    //    $scope.InstrumentSubSetName = null;
                    //    $scope.InstrumentSetId = 0;
                    //    $scope.InstrumentSubSetId = 0;
                    //    $scope.AddUpdate = "Add";
                    //    $scope.editcreate = "Create Instrument";
                    //    $scope.IsGeneric = false;
                    //    //$scope.showAdd = false;
                    //    $scope.IsSetNameDisable = false;
                    //    $scope.divshowInstruments = true;
                    //    $scope.IsExist = false;
                    //    $scope.LoaderAllInstrument = true;
                    //    $scope.LoaderCreationSection = true;
                    //    var getData = GetInstrumentSetsData.Call();
                    //    getData.then(function (response) {
                    //        $scope.LoaderAllInstrument = false;
                    //        $scope.LoaderCreationSection = false;
                    //        $scope.LstInstrument = response.data.data.LstInstrument;
                    //    },
                    //        function (stu) {
                    //            $scope.LoaderAllInstrument = false;
                    //            $scope.LoaderCreationSection = false;
                    //            $scope.divshow = false;
                    //            $scope.divshowInstruments = false;
                    //            MFIMsg.AlertHtml("Instruments loading failed", "Error", "OK");
                    //        });
                    //}


                    $scope.saveSetAndCustomInstrumnetName = function (op) {
                        if (op == 'Add') {
                            var matchincr = 0;
                            angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                if (value.InstrumentSubSetName == $scope.InstrumentSubSetName) {
                                    matchincr++;
                                }
                            });
                            if (matchincr >= 1) {
                                MFIMsg.AlertHtml("Custom instrument name already exist", MFIAlertType.Information);
                                return;
                            }
                            $scope.InstrumentSubSetId = 0;
                        }
                        else {
                            var matchincr = 0;
                            angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                if (value.InstrumentSubSetName == $scope.InstrumentSubSetName && value.InstrumentSubSetId != $scope.InstrumentSubSetId) {
                                    matchincr++;
                                }
                            });
                            if (matchincr >= 1) {
                                MFIMsg.AlertHtml("Custom instrument name already exist", MFIAlertType.Information);
                                return;
                            }
                        }
                        if ($scope.InstrumentSetName == "" || $scope.InstrumentSetName == null) {
                            MFIMsg.AlertHtml("Please enter set name", MFIAlertType.Information);
                            return;
                        }
                        if ($scope.InstrumentSubSetName == "" || $scope.InstrumentSubSetName == null) {
                            MFIMsg.AlertHtml("Please enter custom instrument name", MFIAlertType.Information);
                            return;
                        }

                        var setParam = { "InstrumentSetName": $scope.InstrumentSetName, "InstrumentSubSetName": $scope.InstrumentSubSetName, "InstrumentSetId": $scope.InstrumentSetId, "InstrumentSubSetId": $scope.InstrumentSubSetId, "IsGeneric": $scope.IsGeneric };
                        var getSetData = SaveSetandCustomInstrumentName.Call(setParam);

                        getSetData.then(function (response) {
                            $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                            $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                            if ($scope.InstrumentSetId == 0) {
                                MFIMsg.AlertHtml("Instrument set created successfully", MFIAlertType.Success);
                            }
                            else {
                                if (op == 'Add')
                                    MFIMsg.AlertHtml("Custom instrument created successfully", MFIAlertType.Success);
                                else
                                    MFIMsg.AlertHtml("Instrument set updated successfully", MFIAlertType.Success);
                                var incr = 0;
                                angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                    value.IsChecked = value.InstrumentSubSetId == $scope.radioSelectedId ? true : false;
                                    value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                    incr++;
                                });
                                incr = 0;
                            }
                            $scope.InstrumentSetName = null;
                            $scope.InstrumentSubSetName = null;
                            $scope.IsGeneric = false;
                            $scope.divshow = false;
                            if (response.data.data.Data.IsGeneric == true) {
                                $scope.Gen = true;
                            }
                            else {
                                $scope.Gen = false;
                            }
                            $scope.SetName = "Make Default";
                            $scope.Default = true;
                            $scope.UserLogInId = response.data.data.UserLogInId;
                            $scope.CreatedLogInId = response.data.data.CreatedLogInId;

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Instrument set create or update error", MFIAlertType.Error);
                            });

                    }

                    $scope.instrumentSave = function () {
                        var instuSaveParam = { "InstrumentSetId": $scope.InstrumentSetId, "InstrumentSubSetId": $scope.InstrumentSubSetId, "LstInstrumentIdSelectSave": $scope.LstInstrumentIdSelect, "InstrumentSubSetName": $scope.InstrumentSubSetName, "IsCreationSet": false, "IsExist": $scope.IsExist };
                        var getInstrumentSaveData = InstrumentSave.Call(instuSaveParam);
                        getInstrumentSaveData.then(function (response) {
                            if ($scope.search != "" && $scope.search != undefined)
                                $scope.search.InstrumentName = "";
                            MFIMsg.AlertHtml("Instrument saved successfully", MFIAlertType.Success);
                            if ($scope.LstInstrumentIdSelect == null)
                                $scope.LstInstrumentIdSelect = [];
                            $scope.LstInstrumentIdSelect = response.data.data.LstInstrumentId;
                            $scope.LstInstrumentIdForDisable = response.data.data.LstInstrumentIdForDisable;
                            $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                            if (response.data.data.LstInstrumentSetSubSet != null)
                                $scope.LstInstrumentSetSubSet = response.data.data.LstInstrumentSetSubSet;

                            if (response.data.data.LstInstrumentId != null) {
                                for (var i = 0; i < response.data.data.LstInstrumentId.length; i++) {
                                    for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                        if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentId[i]) {
                                            $scope.LstInstrument[j].IsChecked = true;
                                            $scope.LstInstrument[j].CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioClassId] };
                                        }
                                    }
                                }
                            }
                            if (response.data.data.LstInstrumentIdForDisable != null) {
                                for (var i = 0; i < response.data.data.LstInstrumentIdForDisable.length; i++) {
                                    for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                        if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentIdForDisable[i]) {
                                            $scope.LstInstrument[j].IsDisable = true;
                                        }
                                    }
                                }
                            }
                            var incr = 0;
                            angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                                value.IsChecked = value.InstrumentSubSetId == $scope.InstrumentSubSetId ? true : false;
                                value.RadioTextColor = { "color": $scope.LstColor[incr] };
                                incr++;
                            });
                            incr = 0;
                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Instrument saved failed", MFIAlertType.Error);
                            });
                    }

                    $scope.removeRow = function (InsSubId, InstrumentSetId) {
                        if (InsSubId == 0 && InstrumentSetId == 0)
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            MFIMsg.Confirm("You want to delete", "MFI360 Explorer", "Yes", "No").then(function () {
                                var delParam = { "InstrumentSetId": InstrumentSetId, "InstrumentSubId": InsSubId };
                                var getDelData = InstrumentSetsDelete.Call(delParam);

                                getDelData.then(function (response) {
                                    MFIMsg.AlertHtml("Instrument sets deleted successfully", MFIAlertType.Success);
                                    $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                                    $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                                    $scope.divshowAllInstrument = false;
                                    $scope.divshow = false;
                                    if ($scope.LstInstrumentSingleSetDetails.length == 0) {
                                        $scope.searchText = "";
                                        var getData = GetInstrumentSetsData.Call();
                                        getData.then(function (response) {
                                            $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                                        },
                                            function (stu) {
                                                MFIMsg.AlertHtml("Instrument set loading failed", MFIAlertType.Error);
                                            });
                                    }
                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Instrument sets deletion failed", MFIAlertType.Error);
                                    });
                            }, function () {
                            })


                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to delete", MFIAlertType.Information);
                        }
                    }

                    $scope.edit = function (instruset) {
                        if (instruset.InstrumentSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.InstrumentSetName = instruset.InstrumentSetName;
                            $scope.InstrumentSubSetName = instruset.InstrumentSubSetName;
                            $scope.InstrumentSetId = instruset.InstrumentSetId;
                            $scope.InstrumentSubSetId = instruset.InstrumentSubSetId;
                            $scope.divshow = true;
                            $scope.AddUpdate = "Update";
                            $scope.IsGeneric = $scope.Gen;
                            $scope.editcreate = "Update Instrument";
                            $scope.showAdd = false;
                            $scope.showUpdate = true;
                            $scope.IsSetNameDisable = true;
                            $scope.divshowInstruments = false;
                            $scope.divshowAllInstrument = false;
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }
                    }

                    $scope.makeSetDefault = function (setId, SubSetName, id) {
                        if (SubSetName == "--")
                            return;
                        if ($scope.Default == "Default")
                            return;

                        if ($scope.Gen == true || $scope.UserLogInId == $scope.CreatedLogInId) {
                            var setDefaultParam = { "SetId": setId, "IsDefault": $scope.Default };
                            var getDefaultData = MakeDefaultInstrumentSet.Call(setDefaultParam);


                            getDefaultData.then(function (response) {
                                if (response.data.data.Data.IsDefault == true) {
                                    //$scope.SetName = "Default";
                                    //$scope.Default = true;
                                    $scope.SetName = "Undo";
                                    $scope.Default = false;
                                }
                                else {
                                    $scope.SetName = "Make Default";
                                    $scope.Default = true;
                                }

                            },
                                function (stu) {
                                    MFIMsg.AlertHtml("Default creation error", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no permission to set default", MFIAlertType.Information);
                        }
                    }

                    $scope.toggleSelection = function (id, IsDisable) {
                        if (IsDisable == false) {
                            if ($scope.LstInstrumentIdSelect == null)
                                $scope.LstInstrumentIdSelect = [];
                            var index = $scope.LstInstrumentIdSelect.indexOf(id);
                            if (index == -1) {
                                $scope.LstInstrumentIdSelect.push(id);
                                angular.forEach($scope.LstInstrument, function (value) {
                                    if (value.InstrumentId == id)
                                        value.CheckBoxTextColor = { "color": $scope.LstColor[$scope.radioClassId] };
                                });
                            }
                            else {
                                $scope.LstInstrumentIdSelect.splice(index, 1);
                                angular.forEach($scope.LstInstrument, function (value) {
                                    if (value.InstrumentId == id)
                                        value.CheckBoxTextColor = { "color": "black" };
                                });
                            }

                        }
                    }

                    $scope.createInExistingSet = function (setId, setSubId, SubSetName, id, setName) {
                        $scope.radioClassId = id;
                        $scope.radioSelectedId = setSubId;
                        if (SubSetName == "--")
                            return;
                        if ($scope.Gen == false || $scope.UserLogInId == $scope.CreatedLogInId) {
                            $scope.editcreate = "Add Instrument";
                            $scope.LoaderAllInstrument = true;
                            $scope.IsCreateNew = true;
                            $scope.IsExist = true;
                            $scope.divshow = true;
                            $scope.showAdd = false;
                            $scope.showUpdate = false;
                            $scope.divshowAllInstrument = false;
                            $scope.LoaderCreationSection = true;
                            $scope.divshowInstruments = true;
                            $scope.IsGeneric = $scope.Gen;
                            var instuDetailParam = { "InstrumentSetId": setId, "InstrumentSubSetId": setSubId, "InstrumentSubSetName": SubSetName, "IsCreateNew": $scope.IsCreateNew };
                            var getData = GetCompositInstrumentDetails.Call(instuDetailParam);
                            getData.then(function (response) {
                                $scope.LoaderAllInstrument = false;
                                $scope.LoaderCreationSection = false;
                                $scope.LstInstrumentIdSelect = [];
                                $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                                $scope.InstrumentSetId = setId;
                                $scope.InstrumentSubSetId = "";
                                $scope.InstrumentSubSetName = "";
                                $scope.LstInstrument = response.data.data.LstInstrument;
                                $scope.divshowInstruments = true;
                                $scope.InstrumentSetName = setName;
                                $scope.divshow = true;
                                $scope.showAdd = false;
                                $scope.showUpdate = false;
                                $scope.IsSetNameDisable = true;
                                if (response.data.data.LstInstrumentIdForDisable != null) {
                                    for (var i = 0; i < response.data.data.LstInstrumentIdForDisable.length; i++) {
                                        for (var j = 0; j < $scope.LstInstrument.length; j++) {
                                            if ($scope.LstInstrument[j].InstrumentId == response.data.data.LstInstrumentIdForDisable[i]) {
                                                $scope.LstInstrument[j].IsDisable = true;
                                            }
                                        }
                                    }
                                }
                            },
                                function (stu) {
                                    $scope.LoaderAllInstrument = false;
                                    $scope.LoaderCreationSection = false;
                                    $scope.divshow = false;
                                    $scope.divshowInstruments = false;
                                    MFIMsg.AlertHtml("Custom set creation details fetched failed", MFIAlertType.Error);
                                });
                        }
                        else {
                            MFIMsg.AlertHtml("You have no edit permission", MFIAlertType.Information);
                        }
                    }

                    $scope.instrumentCreateSave = function () {
                        if ($scope.InstrumentSubSetName == "" || $scope.InstrumentSubSetName == null) {
                            MFIMsg.AlertHtml("Please enter custom instrument name", MFIAlertType.Information);
                            return;
                        }
                        var matchincr = 0;
                        angular.forEach($scope.LstInstrumentSingleSetDetails, function (value) {
                            if (value.InstrumentSubSetName.toUpperCase() == $scope.InstrumentSubSetName.toUpperCase()) {
                                matchincr++;
                            }
                        });
                        if (matchincr >= 1) {
                            MFIMsg.AlertHtml("Custom instrument name already exist", MFIAlertType.Information);
                            return;
                        }
                        $scope.InstrumentSubSetId = 0;
                        if ($scope.LstInstrumentIdSelect.length == 0) {
                            MFIMsg.AlertHtml("Please select atleast one instrument", MFIAlertType.Information);
                            return;
                        }

                        var instuSaveParam = { "InstrumentSetId": $scope.InstrumentSetId, "InstrumentSubSetId": $scope.InstrumentSubSetId, "InstrumentSetName": $scope.InstrumentSetName, "LstInstrumentIdSelectSave": $scope.LstInstrumentIdSelect, "InstrumentSubSetName": $scope.InstrumentSubSetName, "IsCreationSet": true, "IsGeneric": $scope.IsGeneric, "IsExist": $scope.IsExist };
                        var getInstrumentSaveData = InstrumentSave.Call(instuSaveParam);
                        getInstrumentSaveData.then(function (response) {
                            if (response.data.Message == "Success") {
                                MFIMsg.AlertHtml("Instrument Set Created Successfully", MFIAlertType.Success);
                                $scope.LstInstrumentSingleSetDetails = response.data.data.LstInstrumentSingleSetDetails;
                                $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                                $scope.divshowInstruments = false;
                                $scope.divshow = false;
                                $scope.InstrumentSetName = null;
                                $scope.InstrumentSubSetName = null;
                                $scope.IsGeneric = false;
                                if (response.data.data.Data.IsGeneric == true) {
                                    $scope.Gen = true;
                                }
                                else {
                                    $scope.Gen = false;
                                }
                                $scope.SetName = "Make Default";
                                $scope.Default = true;
                                $scope.LstInstrumentIdSelect = [];
                                $scope.UserLogInId = response.data.data.UserLogInId;
                                $scope.CreatedLogInId = response.data.data.CreatedLogInId;
                                $scope.searchText = "";
                                var getData = GetInstrumentSetsData.Call();
                                getData.then(function (response) {
                                    $scope.LstInstrumentSet = response.data.data.LstInstrumentSetSubSet;
                                },
                                    function (stu) {
                                        MFIMsg.AlertHtml("Instrument set loading failed", MFIAlertType.Error);
                                    });
                            }
                            else {
                                MFIMsg.AlertHtml(response.data.Message, MFIAlertType.Error);
                            }

                        },
                            function (stu) {
                                MFIMsg.AlertHtml("Instrument creation failed", MFIAlertType.Error);
                            });
                    }

                    $scope.FnSetFilterInstrument = function (selection) {
                        if (selection == 'All')
                            $scope.LstInstrument = $scope.LstInstrumentWithOutFilter;
                        if (selection == 'Selected')
                            $scope.LstInstrument = $filter('filter')($scope.LstInstrumentWithOutFilter, { IsChecked: true }, true);
                        if (selection == 'Unselected')
                            $scope.LstInstrument = $filter('filter')($scope.LstInstrumentWithOutFilter, { IsChecked: false, IsDisable: false }, true);
                    }


                    $scope.isCollapsed = true;
                    $scope.toggleCollapse = function () {
                        $scope.isCollapsed = !$scope.isCollapsed;

                        $timeout(function () {
                            var toggleDiv = angular.element(document.querySelector('.toggleDiv'));
                            var toggleHeight = angular.element(document.querySelector('.toggleHeight'));
                            toggleDiv.slideToggle('fast', function () {
                                if (toggleDiv.css('display') === 'none') {
                                    toggleHeight.css('height', '300px');
                                } else {
                                    toggleHeight.css('height', '165px');
                                }
                            });
                        }, 0);
                    };


                    $scope.closeInstrumentSet = function () {
                        if (screen.width <= 767) {
                            angular.element('#instrumentSetDetails').hide();
                            angular.element("#settingContainer").show();
                        } else if (screen.width >= 768 && screen.width <= 980) {
                            angular.element('#instrumentSetDetails').hide();
                        } else {
                            angular.element('#instrumentSetDetails').delay(70).animate({
                                right: "-280px",
                                width: 0
                            }, function () {
                                angular.element('#instrumentSetDetails').hide();
                            });
                        }
                    };

                    $scope.toggleCustomIndexPanel = function () {
                        var displayWidth = window.innerWidth - 236;
                        var $block = angular.element('#expand-collapse-block-instrument');
                        var $details = angular.element('#instrumentSetDetails');

                        if ($block.hasClass('fa-angle-double-left')) {
                            $block.removeClass('fa-angle-double-left').addClass('fa-angle-double-right');
                            if (screen.width > 767) {
                                $details.show().animate({ width: displayWidth + "px" }, 70);
                            }
                        } else {
                            $block.removeClass('fa-angle-double-right').addClass('fa-angle-double-left');
                            if (screen.width > 767) {
                                $details.show().animate({ width: '65%' }, 70);
                            }
                        }
                    };

                }, 0);
            }
        };
    }
]);


